import { createClient } from "@supabase/supabase-js";

let authClient;

export class ServerAuthenticationError extends Error {
  constructor(category, cause) {
    super(category);
    this.name = "ServerAuthenticationError";
    this.category = category;
    this.cause = cause;
  }
}

function getAuthClient() {
  const supabaseUrl = process.env.SUPABASE_URL?.trim();
  const supabasePublishableKey = process.env.SUPABASE_PUBLISHABLE_KEY?.trim();

  if (!supabaseUrl || !supabasePublishableKey) {
    throw new ServerAuthenticationError("configuration");
  }

  if (!authClient) {
    authClient = createClient(supabaseUrl, supabasePublishableKey, {
      auth: {
        autoRefreshToken: false,
        detectSessionInUrl: false,
        persistSession: false
      }
    });
  }

  return authClient;
}

export async function verifySupabaseAccessToken(accessToken) {
  if (typeof accessToken !== "string" || !accessToken.trim()) {
    throw new ServerAuthenticationError("unauthorized");
  }

  try {
    const { data, error } = await getAuthClient().auth.getUser(accessToken.trim());

    if (error || !data.user) {
      throw new ServerAuthenticationError("unauthorized", error);
    }

    return data.user;
  } catch (error) {
    if (error instanceof ServerAuthenticationError) {
      throw error;
    }
    throw new ServerAuthenticationError("verification_failed", error);
  }
}
