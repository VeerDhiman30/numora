import http from "node:http";
import fs from "node:fs";
import { promises as fileSystem } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import {
  GeminiServiceError,
  generateCoachReply,
  generateSimulationCoachReply,
  supportedGradeLevels
} from "./server/services/geminiService.js";
import { ServerAuthenticationError, verifySupabaseAccessToken } from "./server/services/supabaseAuthService.js";
import { getSimulationStory } from "./scripts/data/simulation/stories.js";

const projectDirectory = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(projectDirectory, ".env"), quiet: true });

const defaultPort = 3001;
const maxAiRequestBytes = 12 * 1024;
const maxCoachMessageLength = 1200;
const maxSimulationResponseLength = 700;
const maxSimulationHistoryTurns = 6;
const maxSimulationHistoryMessageLength = 600;
const maxSimulationStoryFieldLength = 96;
const maxSimulationEvidenceRows = 12;
const maxSimulationEvidenceColumns = 6;
const requestedPort = Number.parseInt(process.env.PORT ?? "", 10);
const port = Number.isInteger(requestedPort) && requestedPort > 0 && requestedPort <= 65535
  ? requestedPort
  : defaultPort;

const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".gif": "image/gif",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".mp3": "audio/mpeg",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".wav": "audio/wav",
  ".webp": "image/webp"
};

function sendResponse(response, statusCode, headers, body = "") {
  response.writeHead(statusCode, headers);
  response.end(body);
}

function sendJson(response, statusCode, payload, { sendBody = true } = {}) {
  const body = JSON.stringify(payload);
  sendResponse(response, statusCode, {
    "Cache-Control": "no-store",
    "Content-Length": Buffer.byteLength(body),
    "Content-Type": "application/json; charset=utf-8",
    "X-Content-Type-Options": "nosniff"
  }, sendBody ? body : "");
}

function getRequestUrl(requestUrl) {
  try {
    return new URL(requestUrl, "http://localhost");
  } catch {
    return null;
  }
}

function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getBearerToken(request) {
  const authorization = request.headers.authorization;
  const match = typeof authorization === "string" && authorization.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim() ?? "";
}

function createSafeAiFailure(message = "Numora's coach is temporarily unavailable. Please try again.") {
  return { success: false, message };
}

async function readJsonBody(request) {
  const contentLength = Number.parseInt(request.headers["content-length"] ?? "", 10);

  if (Number.isInteger(contentLength) && contentLength > maxAiRequestBytes) {
    throw new Error("request_too_large");
  }

  const chunks = [];
  let byteLength = 0;

  for await (const chunk of request) {
    byteLength += chunk.length;
    if (byteLength > maxAiRequestBytes) {
      throw new Error("request_too_large");
    }
    chunks.push(chunk);
  }

  const text = Buffer.concat(chunks).toString("utf8");
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("invalid_json");
  }
}

function validateAiPayload(payload) {
  if (!isPlainObject(payload)) {
    return { error: "Send a JSON object with a coaching question." };
  }

  if (typeof payload.message !== "string") {
    return { error: "Enter a coaching question to continue." };
  }

  const message = payload.message.trim();
  if (!message) {
    return { error: "Enter a coaching question to continue." };
  }
  if (message.length > maxCoachMessageLength) {
    return { error: "Keep your coaching question under 1,200 characters." };
  }

  if (payload.context !== undefined && !isPlainObject(payload.context)) {
    return { error: "Use a valid learning context." };
  }

  const requestedGradeLevel = payload.context?.gradeLevel ?? "middle";
  if (!supportedGradeLevels.has(requestedGradeLevel)) {
    return { error: "Choose a supported Numora learning level." };
  }

  const mode = payload.context?.mode === "test" ? "test" : undefined;
  return {
    message,
    context: {
      gradeLevel: requestedGradeLevel,
      ...(mode ? { mode } : {})
    }
  };
}

function isValidSimulationIdentifier(value) {
  return typeof value === "string"
    && value.length > 0
    && value.length <= maxSimulationStoryFieldLength
    && /^[a-z0-9][a-z0-9-]*$/.test(value);
}

function trimSimulationText(value, maxLength) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function sanitizeSimulationEvidence(evidence) {
  if (!isPlainObject(evidence)) {
    return null;
  }

  const columns = Array.isArray(evidence.columns)
    ? evidence.columns.slice(0, maxSimulationEvidenceColumns).map((column) => trimSimulationText(column, 120)).filter(Boolean)
    : [];
  const rows = Array.isArray(evidence.rows)
    ? evidence.rows.slice(0, maxSimulationEvidenceRows).map((row) => (
      Array.isArray(row)
        ? row.slice(0, maxSimulationEvidenceColumns).map((cell) => trimSimulationText(cell, 180))
        : []
    )).filter((row) => row.length > 0)
    : [];

  return {
    title: trimSimulationText(evidence.title, 160),
    description: trimSimulationText(evidence.description, 360),
    columns,
    rows
  };
}

function getCorrectResponseContext(step) {
  const options = Array.isArray(step.options)
    ? step.options.slice(0, 8).map((option) => ({
      id: trimSimulationText(option?.id, maxSimulationStoryFieldLength),
      label: trimSimulationText(option?.label, 240),
      description: trimSimulationText(option?.description, 240)
    })).filter((option) => option.id && option.label)
    : [];
  const correctAnswers = Array.isArray(step.correctAnswer)
    ? step.correctAnswer
    : [step.correctAnswer];
  const answerLabels = correctAnswers.map((answer) => {
    const option = options.find((item) => item.id === answer);
    return option?.label ?? trimSimulationText(answer, 240);
  }).filter(Boolean);

  return {
    responseType: trimSimulationText(step.responseType, 64),
    options,
    acceptedReasoning: Array.isArray(step.acceptedPhrases)
      ? step.acceptedPhrases.slice(0, 8).map((phrase) => trimSimulationText(phrase, 200)).filter(Boolean)
      : [],
    correctTarget: answerLabels,
    selectionMode: step.selectionMode === "multiple" ? "multiple" : "single",
    requiredSelections: Number.isInteger(step.requiredSelections) ? step.requiredSelections : undefined
  };
}

function getTrustedSimulationTurn(storyId, gradeLevel, currentStep) {
  const story = getSimulationStory(storyId);
  if (!story || story.gradeLevel !== gradeLevel || !Array.isArray(story.steps)) {
    return null;
  }

  const step = story.steps.find((candidate) => candidate?.id === currentStep);
  if (!step) {
    return null;
  }

  return {
    storyContext: {
      id: story.id,
      title: trimSimulationText(story.title, 180),
      description: trimSimulationText(story.description, 360),
      coach: {
        name: trimSimulationText(story.character?.name, 120),
        role: trimSimulationText(story.character?.role, 160)
      },
      mathConcepts: Array.isArray(story.mathConcepts)
        ? story.mathConcepts.slice(0, 8).map((concept) => trimSimulationText(concept, 100)).filter(Boolean)
        : [],
      evidence: sanitizeSimulationEvidence(story.evidence)
    },
    stepContext: {
      id: step.id,
      prompt: trimSimulationText(step.coachMessage, 600),
      expectedResponse: getCorrectResponseContext(step),
      scriptedGuidance: {
        incorrect: trimSimulationText(step.incorrectGuidance, 500),
        unsure: trimSimulationText(step.noIdeaGuidance, 500),
        hint: trimSimulationText(step.hint, 360),
        progressiveHints: Array.isArray(step.progressiveHints)
          ? step.progressiveHints.slice(0, 3).map((hint) => trimSimulationText(hint, 360)).filter(Boolean)
          : [],
        strongHint: trimSimulationText(step.strongHint, 360)
      }
    }
  };
}

function validateSimulationHistory(history) {
  if (history === undefined) {
    return { value: [] };
  }

  if (!Array.isArray(history) || history.length > maxSimulationHistoryTurns) {
    return { error: "Use up to six recent Simulation conversation turns." };
  }

  const value = [];
  for (const turn of history) {
    if (!isPlainObject(turn) || !["student", "coach"].includes(turn.role)
      || typeof turn.content !== "string") {
      return { error: "Use valid recent Simulation conversation turns." };
    }

    const content = turn.content.trim();
    if (!content || content.length > maxSimulationHistoryMessageLength) {
      return { error: "Keep each recent Simulation turn under 600 characters." };
    }
    value.push({ role: turn.role, content });
  }

  return { value };
}

function validateSimulationPayload(payload) {
  if (!isPlainObject(payload)) {
    return { error: "Send a valid Simulation coaching request." };
  }

  const { storyId, gradeLevel, currentStep } = payload;
  if (!isValidSimulationIdentifier(storyId)
    || !supportedGradeLevels.has(gradeLevel)
    || !isValidSimulationIdentifier(currentStep)) {
    return { error: "Use a valid Simulation story and step." };
  }

  const interaction = payload.interaction === undefined ? "answer" : payload.interaction;
  if (!["answer", "no_idea"].includes(interaction)) {
    return { error: "Use a valid Simulation response type." };
  }
  if (typeof payload.studentResponse !== "string") {
    return { error: "Enter a Simulation response to continue." };
  }

  const studentResponse = payload.studentResponse.trim();
  if ((interaction === "answer" && !studentResponse) || studentResponse.length > maxSimulationResponseLength) {
    return { error: "Keep your Simulation response under 700 characters." };
  }

  const guidanceLevel = payload.guidanceLevel === undefined ? 0 : payload.guidanceLevel;
  if (!Number.isInteger(guidanceLevel) || guidanceLevel < 0 || guidanceLevel > 3) {
    return { error: "Use a valid Simulation guidance level." };
  }

  const history = validateSimulationHistory(payload.conversationHistory);
  if (history.error) {
    return history;
  }

  const trustedTurn = getTrustedSimulationTurn(storyId, gradeLevel, currentStep);
  if (!trustedTurn) {
    return { error: "That Simulation story step is unavailable." };
  }

  return {
    storyId,
    gradeLevel,
    currentStep,
    interaction,
    studentResponse: studentResponse || "I have no idea yet.",
    guidanceLevel,
    conversationHistory: history.value,
    ...trustedTurn
  };
}

async function handleAiChatRequest(request, response) {
  if (request.method !== "POST") {
    sendJson(response, 405, createSafeAiFailure("Use POST to send a coaching question."));
    return;
  }

  const contentType = request.headers["content-type"] ?? "";
  if (!contentType.toLowerCase().startsWith("application/json")) {
    sendJson(response, 415, createSafeAiFailure("Send your coaching question as JSON."));
    return;
  }

  let payload;
  try {
    payload = await readJsonBody(request);
  } catch (error) {
    const message = error.message === "request_too_large"
      ? "Keep your coaching question under 1,200 characters."
      : "We couldn't read that coaching question. Please try again.";
    sendJson(response, 400, createSafeAiFailure(message));
    return;
  }

  const requestDetails = validateAiPayload(payload);
  if (requestDetails.error) {
    sendJson(response, 400, createSafeAiFailure(requestDetails.error));
    return;
  }

  try {
    await verifySupabaseAccessToken(getBearerToken(request));
  } catch (error) {
    if (error instanceof ServerAuthenticationError && error.category === "unauthorized") {
      console.info("[ai] request rejected: unauthenticated");
      sendJson(response, 401, createSafeAiFailure("Please sign in to use Numora's coach."));
      return;
    }

    console.warn("[ai] request rejected: authentication verification unavailable");
    sendJson(response, 503, createSafeAiFailure());
    return;
  }

  const startedAt = Date.now();
  console.info("[ai] coach request started");

  try {
    const message = await generateCoachReply(requestDetails);
    console.info(`[ai] coach request succeeded in ${Date.now() - startedAt}ms`);
    sendJson(response, 200, { success: true, message });
  } catch (error) {
    const category = error instanceof GeminiServiceError ? error.category : "unknown";
    console.warn(`[ai] coach request failed: ${category}`);
    const statusCode = category === "rate_limited" ? 429 : 503;
    sendJson(response, statusCode, createSafeAiFailure());
  }
}

async function handleSimulationCoachRequest(request, response) {
  if (request.method !== "POST") {
    sendJson(response, 405, createSafeAiFailure("Use POST to send a Simulation response."));
    return;
  }

  const contentType = request.headers["content-type"] ?? "";
  if (!contentType.toLowerCase().startsWith("application/json")) {
    sendJson(response, 415, createSafeAiFailure("Send your Simulation response as JSON."));
    return;
  }

  let payload;
  try {
    payload = await readJsonBody(request);
  } catch (error) {
    const message = error.message === "request_too_large"
      ? "Keep your Simulation response concise."
      : "We couldn't read that Simulation response. Please try again.";
    sendJson(response, 400, createSafeAiFailure(message));
    return;
  }

  const requestDetails = validateSimulationPayload(payload);
  if (requestDetails.error) {
    sendJson(response, 400, createSafeAiFailure(requestDetails.error));
    return;
  }

  try {
    await verifySupabaseAccessToken(getBearerToken(request));
  } catch (error) {
    if (error instanceof ServerAuthenticationError && error.category === "unauthorized") {
      console.info("[simulation-ai] request rejected: unauthenticated");
      sendJson(response, 401, createSafeAiFailure("Please sign in to use Numora's coach."));
      return;
    }

    console.warn("[simulation-ai] request rejected: authentication verification unavailable");
    sendJson(response, 503, createSafeAiFailure());
    return;
  }

  const startedAt = Date.now();
  console.info(`[simulation-ai] coach request started: ${requestDetails.storyId}`);

  try {
    const coaching = await generateSimulationCoachReply(requestDetails);
    console.info(`[simulation-ai] coach request succeeded in ${Date.now() - startedAt}ms`);
    sendJson(response, 200, { success: true, ...coaching });
  } catch (error) {
    const category = error instanceof GeminiServiceError ? error.category : "unknown";
    console.warn(`[simulation-ai] coach request failed: ${category}`);
    const statusCode = category === "rate_limited" ? 429 : 503;
    sendJson(response, statusCode, createSafeAiFailure());
  }
}

async function handleApiRequest(request, response) {
  const requestUrl = getRequestUrl(request.url ?? "/");

  if (!requestUrl) {
    sendResponse(response, 400, { "Content-Type": "text/plain; charset=utf-8" }, "Bad request");
    return true;
  }

  if (requestUrl.pathname === "/api/ai/chat") {
    await handleAiChatRequest(request, response);
    return true;
  }

  if (requestUrl.pathname === "/api/ai/simulation") {
    await handleSimulationCoachRequest(request, response);
    return true;
  }

  if (requestUrl.pathname !== "/api/config") {
    return false;
  }

  if (request.method !== "GET" && request.method !== "HEAD") {
    sendJson(response, 405, { success: false, message: "Method not allowed." });
    return true;
  }

  const publicConfig = {
    supabaseUrl: process.env.SUPABASE_URL ?? "",
    supabasePublishableKey: process.env.SUPABASE_PUBLISHABLE_KEY ?? ""
  };
  sendJson(response, 200, publicConfig, { sendBody: request.method !== "HEAD" });
  return true;
}

function getFilePath(requestUrl) {
  let pathname;

  try {
    pathname = new URL(requestUrl, "http://localhost").pathname;
    pathname = decodeURIComponent(pathname);
  } catch {
    return null;
  }

  if (pathname.includes("\0")) {
    return null;
  }

  const safePathname = path.posix.normalize(pathname.replaceAll("\\", "/"));
  const relativePath = safePathname.replace(/^\/+/, "") || "index.html";
  if (relativePath.split("/").some((segment) => segment.startsWith("."))) {
    return null;
  }
  // The challenge bank and its answers live in SQL; only client assets are public.
  if (!["index.html", "favicon.ico"].includes(relativePath)
    && !["scripts", "styles", "assets"].includes(relativePath.split("/")[0])) {
    return null;
  }
  const resolvedPath = path.resolve(projectDirectory, relativePath);
  const isInsideProject = resolvedPath === projectDirectory
    || resolvedPath.startsWith(`${projectDirectory}${path.sep}`);

  return isInsideProject ? resolvedPath : null;
}

async function serveStaticFile(request, response) {
  const filePath = getFilePath(request.url ?? "/");

  if (!filePath) {
    sendResponse(response, 400, { "Content-Type": "text/plain; charset=utf-8" }, "Bad request");
    return;
  }

  try {
    const fileInfo = await fileSystem.stat(filePath);

    if (!fileInfo.isFile()) {
      sendResponse(response, 404, { "Content-Type": "text/plain; charset=utf-8" }, "Not found");
      return;
    }

    const contentType = mimeTypes[path.extname(filePath).toLowerCase()]
      ?? "application/octet-stream";
    const headers = {
      "Content-Length": fileInfo.size,
      "Content-Type": contentType,
      "X-Content-Type-Options": "nosniff"
    };

    if (request.method === "HEAD") {
      sendResponse(response, 200, headers);
      return;
    }

    response.writeHead(200, headers);
    const stream = fs.createReadStream(filePath);
    stream.on("error", () => {
      if (!response.headersSent) {
        sendResponse(response, 500, { "Content-Type": "text/plain; charset=utf-8" }, "Server error");
      } else {
        response.destroy();
      }
    });
    stream.pipe(response);
  } catch (error) {
    if (error.code === "ENOENT" || error.code === "ENOTDIR") {
      sendResponse(response, 404, { "Content-Type": "text/plain; charset=utf-8" }, "Not found");
      return;
    }

    console.error("Unable to serve request:", error);
    sendResponse(response, 500, { "Content-Type": "text/plain; charset=utf-8" }, "Server error");
  }
}

const server = http.createServer((request, response) => {
  void handleApiRequest(request, response)
    .then((handled) => {
      if (handled) {
        return;
      }

      if (request.method !== "GET" && request.method !== "HEAD") {
        sendResponse(response, 405, {
          Allow: "GET, HEAD",
          "Content-Type": "text/plain; charset=utf-8"
        }, "Method not allowed");
        return;
      }

      return serveStaticFile(request, response);
    })
    .catch(() => {
      if (!response.headersSent) {
        sendJson(response, 500, { success: false, message: "Numora could not complete that request." });
      }
    });
});

server.on("clientError", (_error, socket) => {
  socket.end("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");
});

server.on("error", (error) => {
  console.error("Numora could not start:", error.message);
  process.exitCode = 1;
});

server.listen(port, () => {
  console.log(`Numora is running at http://localhost:${port}`);
});
