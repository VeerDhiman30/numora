import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createGameState,evaluateGameAction,advanceGameState,getArcadeGame} from '../scripts/arcade/games.js';
import {LINE_GRID,lineRounds,createLineState,linePointFromSvg,lineMatchesEquation,evaluateLineAction,renderLineBoard} from '../scripts/arcade/lineGame.js';
const fresh=()=>createGameState('draw-the-line');
const plot=(state,x,y)=>evaluateLineAction(state,`line-plot:${x}:${y}`);

test('click mapping snaps to grid intersections and inverts screen y in all quadrants',()=>{
  for(const [x,y] of [[-6,-6],[-6,6],[6,6],[6,-6],[0,0],[-2,-4],[2,2]]) {
    const point=linePointFromSvg(LINE_GRID.origin+x*LINE_GRID.scale,LINE_GRID.origin-y*LINE_GRID.scale);
    assert.deepEqual(point,{x,y});
  }
  assert.deepEqual(linePointFromSvg(279,159),{x:2,y:2});
  for(const [x,y] of [[39,220],[401,220],[220,39],[220,401],[NaN,100],[100,Infinity]]) assert.equal(linePointFromSvg(x,y),null);
});

test('line appears only after two distinct points and joins their actual SVG positions',()=>{
  const state=fresh();assert.doesNotMatch(renderLineBoard(state),/data-line-connection/);
  assert.equal(plot(state,0,-1).kind,'select');assert.equal(state.graph.activePoint,1);
  assert.doesNotMatch(renderLineBoard(state),/data-line-connection/);
  assert.equal(plot(state,2,2).kind,'select');
  assert.match(renderLineBoard(state),/data-line-connection x1="220" y1="250" x2="280" y2="160"/);
  assert.equal(state.correctActions,0);assert.equal(state.moves,0);
});

test('all distinct pairs on the equation are accepted, including alternative and fractional points',()=>{
  for(const [index,round] of lineRounds.entries()) {
    const candidates=[];
    for(let x=-6;x<=6;x+=.5) {
      const y=round.slope*x+round.intercept;
      if(y>=-6&&y<=6)candidates.push({x,y});
    }
    for(const a of candidates) for(const b of candidates) if(a!==b) {
      assert.equal(lineMatchesEquation([a,b],round),true);
      const state=fresh();state.round=index;
      plot(state,a.x,a.y);plot(state,b.x,b.y);
      const outcome=evaluateLineAction(state,'graph-check');
      assert.equal(outcome.kind,'correct');assert.equal(outcome.complete,index===2);
    }
  }
});

test('wrong intercepts, wrong slopes and vertical lines fail only on check',()=>{
  for(const pair of [[[0,0],[2,3]],[[0,-1],[2,1]],[[2,1],[2,2]],[[1,1],[1,1.0000000001]]]) {
    const state=fresh();
    for(const [x,y] of pair) assert.equal(plot(state,x,y).kind,'select');
    assert.equal(evaluateLineAction(state,'graph-check').kind,'incorrect');
    assert.equal(state.graph.lastCheck,'incorrect');assert.match(renderLineBoard(state),/line-graph--incorrect/);
  }
});

test('incomplete, duplicate, out-of-bounds and malformed inputs never incur a wrong-answer outcome',()=>{
  const state=fresh();
  assert.equal(evaluateLineAction(state,'graph-check').kind,'select');
  plot(state,0,-1);
  assert.equal(evaluateLineAction(state,'graph-check').kind,'select');
  assert.equal(plot(state,0,-1).kind,'select');assert.equal(state.graph.points[1],null);
  const before=structuredClone(state.graph);
  for(const action of ['line-plot:','line-plot::2','line-plot:1:','line-plot:7:1','line-plot:0:-7','line-plot:NaN:1','line-plot:1:Infinity','line-plot:1:2:3','line-plot:text:2']) {
    assert.equal(evaluateLineAction(state,action).kind,'select',action);
    assert.deepEqual(state.graph,before,action);
  }
  assert.equal(lineMatchesEquation([{x:0,y:-1},{x:0,y:-1}],lineRounds[0]),false);
});

test('either point can be edited or cleared, without changing rewards or rounds',()=>{
  const state=fresh();plot(state,0,0);plot(state,2,3);
  evaluateLineAction(state,'graph-check');
  evaluateLineAction(state,'line-select:0');plot(state,0,-1);
  assert.equal(state.graph.lastCheck,null);assert.deepEqual(state.graph.points[1],{x:2,y:3});
  evaluateLineAction(state,'line-select:1');plot(state,2,2);
  assert.equal(evaluateLineAction(state,'graph-check').kind,'correct');
  evaluateLineAction(state,'graph-reset');
  assert.deepEqual(state.graph,createLineState());assert.equal(state.round,0);assert.equal(state.correctActions,0);
});

test('keyboard cursor stays inside the grid, and the legacy steppers cannot submit an answer',()=>{
  const state=fresh();
  for(let i=0;i<20;i++){evaluateLineAction(state,'line-cursor:up');evaluateLineAction(state,'line-cursor:left');}
  assert.deepEqual(state.graph.cursor,{x:-6,y:6});
  evaluateLineAction(state,'line-cursor:home');assert.deepEqual(state.graph.cursor,{x:0,y:0});
  assert.equal(evaluateLineAction(state,'line-cursor:invalid').kind,'none');
  assert.equal(evaluateGameAction(getArcadeGame('draw-the-line'),state,'graph-slope:0.5').kind,'none');
  assert.equal(evaluateGameAction(getArcadeGame('draw-the-line'),state,'graph-intercept:1').kind,'none');
});

test('each checked correct line advances once and clears points for the next equation',()=>{
  const state=fresh(), game=getArcadeGame('draw-the-line');
  for(const [index,round] of lineRounds.entries()) {
    plot(state,0,round.intercept);plot(state,2,2*round.slope+round.intercept);
    const result=evaluateGameAction(game,state,'graph-check');
    assert.equal(result.kind,'correct');state.correctActions++;
    advanceGameState(game,state,result);
    assert.equal(result.complete,index===2);
    if(index<2){assert.equal(state.round,index+1);assert.deepEqual(state.graph,createLineState());}
  }
  assert.equal(state.correctActions,3);
});

test('plot state and drafts survive serialization; rendered UI has coordinates and keyboard alternatives',()=>{
  const state=fresh();plot(state,1,.5);state.graph.draft={x:'3',y:'3.5'};
  const restored=JSON.parse(JSON.stringify(state));assert.deepEqual(restored,state);
  const html=renderLineBoard(restored);
  assert.match(html,/data-line-grid/);assert.match(html,/data-line-coordinates/);
  assert.match(html,/type="number" min="-6" max="6" step="any"/);
  assert.match(html,/aria-describedby="line-keyboard-help"/);assert.doesNotMatch(html,/graph-slope|graph-intercept/);
  state.graph.draft.x='" onfocus="alert(1)';assert.match(renderLineBoard(state),/&quot; onfocus=&quot;/);
});
