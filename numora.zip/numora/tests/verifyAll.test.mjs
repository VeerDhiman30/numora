import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createFixture } from './leaderboardFixture.mjs';
let db, sql;
before(async () => {
  ({db} = await createFixture());
  sql = await readFile(new URL('../supabase/verify_all_phases.sql', import.meta.url), 'utf8');
});
after(async () => { await db?.close(); });
const audit = async () => (await db.query(sql)).rows[0];
async function altered(change, check) {
  await db.exec('begin');
  try { await db.exec(change); await check(await audit()); }
  finally { await db.exec('rollback'); }
}
test('complete setup passes inside a read-only transaction', async () => {
  await db.exec('begin read only');
  try {
    const result = await audit();
    assert.equal(result.missing, 0, JSON.stringify(result.failed_checks));
    assert.ok(result.checks_run > 200);
  } finally { await db.exec('rollback'); }
});
test('missing tables and private schema are reported rather than crashing', async () => {
  await altered('drop table public.arcade_state cascade; drop schema numora_private cascade', result => {
    assert.ok(result.missing > 0);
    assert.ok(result.failed_checks.some(row => row.check === 'Table: public.arcade_state'));
    assert.ok(result.failed_checks.some(row => row.check === 'Table: numora_private.challenge_bank'));
  });
});
test('disabled triggers, RLS and duplicate protection are detected', async () => {
  await altered('alter table public.activity_events disable trigger simulation_completion_reward_guard; alter table public.profiles disable row level security; alter table public.activity_events drop constraint activity_events_user_id_event_key_key', result => {
    assert.equal(result.missing, 3, JSON.stringify(result.failed_checks));
  });
});
test('anonymous execution and extra permissive policies are detected', async () => {
  await altered("grant execute on function public.get_weekly_tournament(integer) to anon; create policy unsafe_test_policy on public.student_stats for all to authenticated using (true) with check (true)", result => {
    assert.equal(result.missing, 2, JSON.stringify(result.failed_checks));
  });
});
test('missing Phase 8 API and overwritten calendar implementation are detected', async () => {
  await altered("drop function public.get_weekly_tournament(integer); create or replace function numora_private.local_day(p_user uuid) returns date language sql stable security definer set search_path = '' as $$ select current_date $$", result => {
    assert.ok(result.failed_checks.some(row => row.check.includes('Function: public.get_weekly_tournament')));
    assert.ok(result.failed_checks.some(row => row.check.includes('Current implementation: numora_private.local_day')));
  });
});
