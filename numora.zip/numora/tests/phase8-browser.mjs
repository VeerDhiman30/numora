// Optional real-UI integration with an ISOLATED database and mocked sign-in.
// Test profiles below are never installed in the app or a live Supabase database.
import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createFixture } from "./leaderboardFixture.mjs";
const { chromium } = await import(process.env.NUMORA_PLAYWRIGHT_PATH || "playwright");
const { db, student, login, addXp, scalar, board } = await createFixture();
const uid = await student({ first: "Alex", last: "Morgan" });
await login(uid);
await addXp(uid, 40);
await db.query("update public.student_stats set total_xp=40 where user_id=$1", [uid]);
const others = [];
for (const [index, full] of ["Maya Patel", "Jordan Lee", "Sam Rivera", "Amelia Thompson", "Noah Chen", "Avery Johnson", "Emma Wilson", "Oliver Garcia", "Riley Martin", "Sofia Williams", "Ethan Anderson", "Isabella Nguyen"].entries()) {
  const [first, last] = full.split(" ");
  const id = await student({ first, last });
  others.push(id);
  await addXp(id, 120 - index);
}
const base = process.env.NUMORA_TEST_ORIGIN || "http://localhost:3001";
const artifacts = process.env.NUMORA_TEST_ARTIFACTS || await mkdtemp(join(tmpdir(), "numora-leaderboard-"));
const browser = await chromium.launch({ headless: true, channel: "chrome" });
const page = await browser.newPage({ viewport: { width: 1365, height: 1050 } });
page.setDefaultTimeout(15000);
const errors = [];
page.on("pageerror", error => errors.push(error.message));
page.on("console", message => { if (message.type() === "error") errors.push(message.text()); });
let failBoard = false;
let release;
let gate = new Promise(resolve => { release = resolve; });
let boardCalls = 0;
const rpcArgs = { get_weekly_tournament: ["p_limit"], get_my_economy_snapshot: [], get_my_weekly_xp: [], get_my_today_activity: [], get_my_daily_challenge: ["p_grade_level"], get_my_arcade_state: [] };
await page.route("**/scripts/services/authService.js", route => route.fulfill({ contentType: "text/javascript", body: `
  import { setAuthenticatedUser, setLoggedOut } from './appState.js';
  import { refreshStudentProgress } from './progressService.js';
  export class FriendlyAuthError extends Error {}
  export async function initializeAuthentication() { setAuthenticatedUser({ id:'${uid}', firstName:'Alex', lastName:'Morgan', gradeLevel:'high', timezone:'UTC' }); await refreshStudentProgress(); }
  export async function signOut() { setLoggedOut(); }
  export const signUp = async () => ({}), signIn = async () => {}, sendPasswordRecovery = async () => {}, updatePassword = async () => {};
` }));
await page.route("**/scripts/services/supabase.js", route => route.fulfill({ contentType: "text/javascript", body: `
  const call = body => fetch('/__phase8_test',{method:'POST',body:JSON.stringify(body)}).then(r=>r.json());
  export async function getSupabaseClient() { return {
    rpc: (name,args={}) => call({rpc:name,args}),
    from: table => {const options={table}; const q={select(){return q},eq(){return q},order(){return q},limit(n){options.limit=n;return q},maybeSingle(){options.single=true;return q},then(resolve,reject){return call(options).then(resolve,reject)}};return q;}
  }; }
` }));
await page.route("**/__phase8_test", async route => {
  try {
    const body = JSON.parse(route.request().postData());
    let data;
    if (body.rpc) {
      const args = rpcArgs[body.rpc];
      assert.ok(args, `Unknown RPC ${body.rpc}`);
      if (body.rpc === "get_weekly_tournament") {
        boardCalls++;
        if (failBoard) throw new Error("PRIVATE SQL ERROR secret table / email@example.com");
      }
      const rows = (await db.query(`select * from public.${body.rpc}(${args.map((_, i) => "$" + (i + 1)).join(",")})`, args.map(key => body.args[key] ?? null))).rows;
      data = rows[0]?.[body.rpc] ?? rows;
      if (body.rpc === "get_weekly_tournament" && gate) await gate;
    } else {
      assert.ok(["module_progress", "simulation_progress", "activity_events", "student_stats"].includes(body.table));
      data = (await db.query(`select * from public.${body.table} where user_id=$1`, [uid])).rows;
      if (body.limit) data = data.slice(0, body.limit);
      if (body.single) data = data[0] ?? null;
    }
    await route.fulfill({ json: { data, error: null } });
  } catch (error) { await route.fulfill({ json: { data: null, error: { message: error.message } } }); }
});
const loaded = () => page.waitForFunction(() => document.querySelector("[data-leaderboard-content]")?.getAttribute("aria-busy") === "false" && document.querySelector(".leaderboard-table, .leaderboard-empty"));
const refresh = async () => { await page.getByRole("button", { name: "Refresh", exact: true }).click(); await loaded(); };
try {
  await page.goto(`${base}/#/leaderboard`);
  await page.locator(".leaderboard-skeleton").waitFor();
  assert.equal(await page.locator("[data-leaderboard-content]").getAttribute("aria-busy"), "true");
  assert.match(await page.locator("[data-leaderboard-status]").innerText(), /Loading/);
  release(); gate = null;
  await loaded();
  assert.equal(await page.locator(".leaderboard-table tbody th[scope=row]").count(), 11);
  assert.equal(await page.locator(".leaderboard-rank--medal").count(), 3);
  assert.equal(await page.locator("[data-current-student]").count(), 1);
  assert.match(await page.locator("[data-current-student]").innerText(), /Rank 13/);
  assert.match(await page.locator("[data-current-student]").innerText(), /Alex Morgan You/);
  assert.equal(await page.locator(".leaderboard-table tbody tr").nth(3).locator(".leaderboard-rank").innerText(), "4");
  assert.equal(await page.locator("[data-leaderboard-own-xp]").innerText(), "40 XP");
  assert.ok(!(await page.locator("body").innerText()).includes(uid));
  const initialOrder = await page.locator(".leaderboard-name").allTextContents();
  // Keyboard refresh preserves focus and stable row order.
  await page.getByRole("button", { name: "Refresh", exact: true }).focus();
  await page.keyboard.press("Enter"); await loaded();
  assert.deepEqual(await page.locator(".leaderboard-name").allTextContents(), initialOrder);
  assert.equal(await page.locator("[data-leaderboard-refresh]").evaluate(el => el === document.activeElement), true);
  await page.screenshot({ path: join(artifacts, "leaderboard-desktop.png"), fullPage: true });
  for (const width of [320, 390, 768, 1024, 1180, 1365]) {
    await page.setViewportSize({ width, height: 844 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Overflow at ${width}`);
    assert.equal(await page.locator(".leaderboard-table").evaluate(el => el.scrollWidth <= el.clientWidth + 1), true);
    assert.equal(await page.locator(".primary-nav").evaluate(el => {
      if (!el.getClientRects().length) return true;
      return el.lastElementChild.getBoundingClientRect().right <= document.querySelector(".header-actions").getBoundingClientRect().left;
    }), true, `Header overlap at ${width}`);
    if (width === 390) await page.screenshot({ path: join(artifacts, "leaderboard-mobile.png"), fullPage: true });
  }
  // Error with retained data, plus first-load failure/retry. Raw errors stay private.
  failBoard = true;
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await page.getByRole("heading", { name: "We couldn’t load the leaderboard" }).waitFor();
  assert.equal(await page.locator(".leaderboard-table").count(), 1);
  assert.ok(!(await page.locator("body").innerText()).includes("PRIVATE SQL ERROR"));
  await page.reload();
  await page.getByRole("heading", { name: "We couldn’t load the leaderboard" }).waitFor();
  assert.equal(await page.locator(".leaderboard-table").count(), 0);
  failBoard = false;
  await page.getByRole("button", { name: "Try again", exact: true }).click();
  await loaded();
  assert.equal(await page.locator("[data-leaderboard-refresh]").evaluate(el => el === document.activeElement), true);
  // Dashboard shows the same total, and returning after earning XP sees the update.
  await page.getByRole("link", { name: "Dashboard", exact: true }).last().click();
  await page.getByRole("heading", { name: "Welcome back, Alex" }).waitFor();
  assert.match(await page.locator(".dashboard-xp").innerText(), /40\s*XP this week/);
  await scalar("select to_jsonb(r) from public.record_quant_activity_event('quant:browser:correct','algebra','correct_answer') r");
  await page.evaluate(() => { location.hash = "#/leaderboard"; });
  await loaded();
  assert.equal(await page.locator("[data-leaderboard-own-xp]").innerText(), "41 XP");
  // A cross-tab XP refresh updates an open leaderboard, but coin-only changes don't.
  await page.evaluate(async () => { await (await import('/scripts/services/economyService.js')).refreshEconomy(); });
  await loaded();
  await scalar("select to_jsonb(r) from public.record_quant_activity_event('quant:cross-tab:correct','algebra','correct_answer') r");
  await page.evaluate(async () => { await (await import('/scripts/services/economyService.js')).refreshEconomy(); });
  await page.waitForFunction(() => document.querySelector('[data-leaderboard-own-xp]')?.textContent === '42 XP');
  const calls = boardCalls;
  await scalar("select to_jsonb(r) from public.record_activity_event('arcade:browser:coins','arcade','optimization-challenge','arcade_correct') r");
  await page.evaluate(async () => { await (await import('/scripts/services/economyService.js')).refreshEconomy(); });
  await page.waitForTimeout(700);
  assert.equal(boardCalls, calls);
  assert.equal(await page.locator("[data-leaderboard-own-xp]").innerText(), "42 XP");
  // Confirmed XP received while hidden refreshes on return, even inside cooldown.
  await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); });
  await scalar("select to_jsonb(r) from public.record_quant_activity_event('quant:hidden-tab:correct','algebra','correct_answer') r");
  await page.evaluate(async () => { await (await import('/scripts/services/economyService.js')).refreshEconomy(); });
  assert.equal(await page.locator("[data-leaderboard-own-xp]").innerText(), "42 XP");
  await page.evaluate(() => { delete document.hidden; document.dispatchEvent(new Event('visibilitychange')); });
  await page.waitForFunction(() => document.querySelector('[data-leaderboard-own-xp]')?.textContent === '43 XP');
  // Full names are text, not HTML. Long names still wrap at narrow widths.
  await db.query("update public.profiles set first_name=$2,last_name=$3 where id=$1", [others[0], '<img src=x onerror=alert(1)>', 'VeryLongSurname'.repeat(8)]);
  await refresh(); await page.setViewportSize({ width: 320, height: 844 });
  assert.equal(await page.locator(".leaderboard-table img").count(), 0);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.emulateMedia({ reducedMotion: "reduce" });
  // Current student inside Top 10 only appears once, in their true ranked row.
  await addXp(uid, 500); await refresh();
  assert.equal(await page.locator("[data-current-student]").count(), 1);
  assert.match(await page.locator("[data-current-student]").innerText(), /Rank 1/);
  assert.equal(await page.locator(".leaderboard-divider").count(), 0);
  await db.exec("delete from public.daily_activity"); await refresh();
  await page.getByRole("heading", { name: "No weekly activity yet" }).waitFor();
  assert.equal(await page.locator("[data-leaderboard-own-xp]").innerText(), "0 XP");
  assert.equal(await page.locator(".leaderboard-table").count(), 0);
  assert.equal((await board()).current_student.rank, null);
  // An in-flight response must not repopulate the page after sign-out/navigation.
  gate = new Promise(resolve => { release = resolve; });
  await page.getByRole("button", { name: "Refresh", exact: true }).click();
  await page.evaluate(async () => { (await import('/scripts/services/appState.js')).setLoggedOut(); });
  await page.waitForURL("**/#/signin"); release(); gate = null;
  await page.waitForTimeout(400);
  assert.equal(await page.locator(".leaderboard").count(), 0);
  assert.equal((await page.request.get(`${base}/supabase/008_weekly_leaderboard.sql`)).status(), 400);
  assert.equal(errors.length, 0, errors.join("\n"));
  console.log("Phase 8 browser checks passed: loading, real DB rankings, medals, outside/inside Top 10, keyboard refresh, privacy, Dashboard consistency, reward refresh, coin-only stability, error/retry, empty state, escaped names, widths 320–1365, sign-out/stale-response protection, no console errors.");
  console.log(`Screenshots: ${artifacts}`);
} finally { release?.(); await browser.close(); await db.close(); }
