import assert from 'node:assert/strict';
import {mkdtemp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {finalHarness} from './finalHarness.mjs';
import {installArcadeAudioProbe} from './arcadeAudioProbe.mjs';

const {db,uid,browser,page,base,calls,controls,errors}=await finalHarness();
await installArcadeAudioProbe(page);
const artifacts=await mkdtemp(join(tmpdir(),'numora-memory-'));
const storageKey=`numora:arcade-session:v1:${uid}`;
const session=()=>page.evaluate(key=>JSON.parse(sessionStorage.getItem(key)),storageKey);
const card=index=>page.locator(`[data-arcade-action="memory:${index}"]`);
const lives=async()=> (await db.query('select lives from public.arcade_state where user_id=$1',[uid])).rows[0].lives;
const pairs=async()=>{
  const cards=(await session()).gameState.memory.cards;
  return [...new Set(cards.map(c=>c.pairId))].map(id=>cards.flatMap((card,i)=>card.pairId===id?[i]:[]));
};
const ready=()=>page.waitForFunction(key=>{
  const s=JSON.parse(sessionStorage.getItem(key));
  return s?.gameState?.memory?.status==='playing'&&!s.pendingReward&&!s.pendingMemoryFailure;
},storageKey);
const failedSave=()=>page.waitForFunction(()=>document.querySelector('.arcade-feedback--error')?.textContent.includes("save this board"));
async function mismatch(a,b,{last=false}={}) {
  await card(a).click();await card(b).click();
  if (!last) await ready();
}
const reload=async()=>{
  await page.reload();await page.locator('.arcade-hud__lives strong').filter({hasText:/^\d\/8$/}).waitFor();
};
try {
  await page.goto(`${base}/#/arcade`);
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.locator('[data-arcade-action="grade:entry"]').click();
  await page.locator('[data-arcade-action="choose-game:memory-match"]').click();
  assert.match(await page.locator('.arcade-instructions__notice').innerText(),/8 individual card flips/);
  await page.locator('[data-arcade-action="start-game"]').click();
  await page.locator('.arcade-memory').waitFor();
  const original=(await session()).gameState.memory.cards;
  let [a,b,c]=await pairs();
  await card(a[0]).focus();await page.keyboard.press('Enter');
  assert.equal(await page.locator('[data-memory-flips]').innerText(),'7');
  assert.equal(await card(a[0]).evaluate(el=>el===document.activeElement),true);
  await card(a[0]).evaluate(el=>el.click());
  assert.equal(await page.locator('[data-memory-flips]').innerText(),'7');
  await reload();
  assert.deepEqual((await session()).gameState.memory.cards,original);
  assert.equal(await page.locator('[data-memory-flips]').innerText(),'7');
  await card(b[0]).click();
  assert.equal(await page.locator('.arcade-memory-card.is-mismatch').count(),2);
  assert.equal(await card(a[0]).evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(84, 44, 52)');
  assert.equal(await page.locator('.memory-wrong-mark').count(),2);
  assert.match(await page.locator('.arcade-feedback--incorrect').innerText(),/Not a match/);
  assert.deepEqual(await page.evaluate(()=>window.__arcadeAudioStarts.map(n=>[n.type,n.state])),[['sawtooth','running']]);
  await page.locator('.arcade-play-area').screenshot({path:join(artifacts,'wrong-pair.png')});
  await card(c[0]).evaluate(el=>el.click());
  assert.equal((await session()).gameState.memory.flips,2,'third card locked during mismatch');
  assert.equal(await page.evaluate(()=>window.__arcadeAudioStarts.length),1);
  await ready();
  assert.equal(await page.locator('.arcade-memory-card.is-mismatch').count(),0);
  assert.equal(await lives(),8);assert.equal(calls.filter(c=>c.rpc==='lose_arcade_life').length,0);
  await page.locator('[data-desktop-sound] [data-sound-toggle]').click();
  await mismatch(a[0],b[0]);
  assert.equal(await page.evaluate(()=>window.__arcadeAudioStarts.length),1,'sound-off keeps wrong answers silent');
  await page.locator('[data-desktop-sound] [data-sound-toggle]').click();
  await mismatch(a[0],b[0]);
  assert.equal(await page.evaluate(()=>window.__arcadeAudioStarts.length),2);
  assert.equal(await lives(),8);
  controls.failRpc='lose_arcade_life';
  await mismatch(a[0],b[0],{last:true});
  await page.locator('[data-arcade-action="restart-game"]').click();
  assert.equal((await session()).gameState.memory.flips,8,'restart cannot bypass failed board');
  await failedSave();
  assert.equal(await lives(),8);
  const failureKey=(await session()).pendingMemoryFailure.eventKey;
  await reload();
  assert.equal((await session()).pendingMemoryFailure.eventKey,failureKey);
  assert.equal(await page.locator('[data-memory-flips]').innerText(),'0');
  controls.failRpc=null;controls.loseResponseOnceRpc='lose_arcade_life';
  await page.locator('[data-arcade-action="retry-memory-board"]').click();
  await failedSave();
  assert.equal(await lives(),7,'lost response still commits exactly one life');
  await reload();
  await page.locator('[data-arcade-action="retry-memory-board"]').evaluate(el=>{el.click();el.click();});
  await ready();
  assert.equal((await session()).gameState.round,1);
  assert.equal(await lives(),7);
  assert.ok(calls.filter(c=>c.rpc==='lose_arcade_life').every(c=>c.args.p_event_key===failureKey));
  assert.equal((await db.query('select count(*)::int as n from public.arcade_life_events where user_id=$1',[uid])).rows[0].n,1);
  const next=(await session()).gameState.memory.cards;
  assert.ok(next.every(card=>!original.some(old=>old.label===card.label)));
  assert.equal(await page.locator('[data-memory-flips]').innerText(),'8');
  await page.locator('.arcade-game').screenshot({path:join(artifacts,'fresh-board.png')});

  // A correct but incomplete pair on flip eight must save its reward, then
  // charge one life and reset. Reward retries must not increment either twice.
  [a,b,c]=await pairs();
  await card(a[0]).click();await card(a[1]).click();await ready();
  await mismatch(b[0],c[0]);await mismatch(b[0],c[0]);
  await card(b[0]).click();controls.failRpc='record_activity_event';
  await card(b[1]).click();
  await page.locator('.arcade-feedback--error').waitFor();
  assert.equal(await lives(),7);
  assert.equal((await session()).gameState.memory.status,'failed');
  controls.failRpc=null;
  await page.locator('[data-arcade-action="retry-reward"]').click();
  await page.waitForFunction(key=>JSON.parse(sessionStorage.getItem(key))?.gameState.round===2,storageKey);
  await ready();assert.equal(await lives(),6);
  assert.equal((await session()).gameState.correctActions,2);

  // Mobile layout and completion exactly on the eighth flip; the two rewards
  // from previous boards must not falsely complete this new board early.
  await page.setViewportSize({width:390,height:844});
  [a,b,c]=await pairs();
  await mismatch(a[0],b[0]);
  await card(a[0]).click();await card(a[1]).click();await ready();
  assert.equal(await page.locator('.arcade-complete').count(),0);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.locator('.arcade-play-area').screenshot({path:join(artifacts,'mobile-board.png')});
  await card(b[0]).click();await card(b[1]).click();await ready();
  await card(c[0]).click();await card(c[1]).click();
  await page.locator('.arcade-complete').waitFor();
  assert.equal((await session()).gameState.memory.flips,8);
  assert.equal(await lives(),6);
  assert.equal((await db.query('select coin_balance from public.student_stats where user_id=$1',[uid])).rows[0].coin_balance,5);
  assert.equal((await db.query('select count(*)::int as n from public.arcade_life_events where user_id=$1',[uid])).rows[0].n,2);

  // Exhausting the last life still deals the new board, but keeps it locked.
  await db.query('update public.arcade_state set lives=1 where user_id=$1',[uid]);
  await page.locator('[data-arcade-action="restart-game"]').click();
  await reload();[a,b]=await pairs();
  for(let i=0;i<4;i++) await mismatch(a[0],b[0],{last:i===3});
  await page.getByRole('heading',{name:'Your lives are regenerating'}).waitFor();
  assert.equal(await lives(),0);assert.equal(await page.locator('.arcade-memory-card').count(),0);
  assert.equal((await session()).gameState.memory.flips,0);
  assert.equal((await session()).gameState.round,1);
  assert.deepEqual(errors,[]);
  console.log('Memory browser checks passed: one try per flip, mismatch without life loss, eight-flip failure, new values, reload and retry safety, lost-response idempotency, eighth-flip success, rewards, keyboard/mobile layout, zero-life lock.');
  console.log('Screenshots:',artifacts);
} catch(error) {await page.screenshot({path:join(artifacts,'failure.png'),fullPage:true});console.error({artifacts,errors});throw error;}
finally {await browser.close();await db.close();}
