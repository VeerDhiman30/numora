import { test, before, beforeEach, after } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createFixture } from "./leaderboardFixture.mjs";
import { installTestClock } from "./testClock.mjs";
import { readCalendar, secondsUntil, formatWeeklyCountdown } from "../scripts/utils/calendar.js";
let db, scalar, login, student, addXp, clock;
const snapshot = () => scalar("select public.get_my_economy_snapshot()");
const tournament = () => scalar("select public.get_weekly_tournament(10)");
before(async () => {
  ({ db, scalar, login, student, addXp } = await createFixture());
  clock = await installTestClock(db);
});
beforeEach(async () => { await db.exec("truncate auth.users cascade"); await clock(""); });
after(async () => { await db?.close(); });

test("Simulation saves/resumes and awards completion once without downgrading completed progress", async () => {
  const uid = await student(); await login(uid);
  const save = (step, history = []) => db.query(
    "select * from public.upsert_simulation_progress('entry-snack-budget','entry',$1,0,0,0,$2::jsonb)",
    [step, JSON.stringify(history)]);
  assert.equal((await save(1)).rows[0].current_step, 1);
  assert.equal((await save(3)).rows[0].current_step, 3);
  await assert.rejects(save(6), /Invalid Simulation progress/);
  await save(5, Array.from({length:5}, () => ({role:'student',content:'answer'})));
  const reward = () => scalar("select to_jsonb(r) from public.record_activity_event('simulation:entry-snack-budget:completed','simulation','entry-snack-budget','story_completed','{\"grade_level\":\"entry\",\"story_id\":\"entry-snack-budget\"}') r");
  assert.equal((await reward()).event_recorded, true);
  assert.equal((await reward()).event_recorded, false);
  const saved = (await save(0)).rows[0];
  assert.equal(saved.status, 'completed'); assert.equal(saved.current_step, 5);
  assert.equal((await snapshot()).stats.total_xp, 10);
});

test("calendar uses each stored zone: next Monday midnight, half-hour offsets, DST 167/169-hour weeks", async () => {
  for (const [zone, now, start, reset, hours] of [
    ["America/New_York", "2026-03-02T05:00:00Z", "2026-03-02", "2026-03-09T04:00:00+00:00", 167],
    ["America/New_York", "2026-10-26T04:00:00Z", "2026-10-26", "2026-11-02T05:00:00+00:00", 169],
    ["Asia/Kolkata", "2026-10-11T18:30:00Z", "2026-10-12", "2026-10-18T18:30:00+00:00", 168],
    ["Pacific/Kiritimati", "2026-10-11T10:00:00Z", "2026-10-12", "2026-10-18T10:00:00+00:00", 168]
  ]) {
    const id = await student({ zone }); await login(id); await clock(now);
    const data = (await tournament()).calendar;
    assert.equal(data.week_start, start);
    assert.equal(Date.parse(data.next_weekly_reset), Date.parse(reset));
    assert.equal((Date.parse(reset) - Date.parse(data.server_now)) / 3600000, hours);
    assert.equal((await snapshot()).calendar.next_weekly_reset, data.next_weekly_reset);
  }
});

test("Sunday→Monday recalculates rank/weekly/today without erasing XP, coins, history or a continuing streak", async () => {
  const own = await student({ zone: "America/New_York" }); await login(own);
  await clock("2026-10-12T03:59:59Z");
  await addXp(own, 50, "2026-10-10"); await addXp(own, 50, "2026-10-11");
  await db.query("update public.student_stats set total_xp=100,coin_balance=520 where user_id=$1", [own]);
  const before = await snapshot();
  assert.equal(before.weekly_xp, 100); assert.equal(before.today.xp_earned, 50); assert.equal(before.stats.current_streak, 2);
  assert.equal((await tournament()).current_student.rank, 1);
  await clock("2026-10-12T04:00:00Z");
  const after = await snapshot(); const board = await tournament();
  assert.equal(after.weekly_xp, 0); assert.equal(board.current_student.weekly_xp, 0);
  assert.equal(board.current_student.rank, null); assert.deepEqual(board.entries, []);
  assert.equal(after.today.xp_earned, 0); assert.equal(after.stats.total_xp, 100);
  assert.equal(after.stats.coin_balance, 520); assert.equal(after.stats.current_streak, 2);
  assert.equal(await scalar("select count(*)::int from public.daily_activity"), 2);
  assert.equal(await scalar("select count(*)::int from public.streak_days"), 2);
  await scalar("select to_jsonb(r) from public.record_quant_activity_event('quant:new-week:correct','algebra','correct_answer') r");
  const earned = await snapshot();
  assert.equal(earned.weekly_xp, 1); assert.equal(earned.today.xp_earned, 1);
  assert.equal(earned.stats.total_xp, 101); assert.equal(earned.stats.coin_balance, 520);
  assert.equal((await tournament()).current_student.weekly_xp, 1);
  assert.equal((await tournament()).current_student.rank, 1);
});

test("Sunday/Monday ties remain deterministic as new-week activity arrives", async () => {
  const ids = [await student({ first: "Same", last: "Name" }), await student({ first: "Same", last: "Name" })].sort();
  await login(ids[0]); await clock("2026-10-11T23:59:59Z");
  for (const id of ids) await addXp(id, 55, "2026-10-11");
  assert.equal((await tournament()).current_student.rank, 1);
  await clock("2026-10-12T00:00:00Z");
  assert.equal((await tournament()).current_student.rank, null);
  for (const id of ids) await addXp(id, 5, "2026-10-12");
  assert.equal((await tournament()).current_student.rank, 1);
  await addXp(ids[1], 6, "2026-10-12");
  assert.equal((await tournament()).current_student.rank, 2);
  await addXp(ids[0], 6, "2026-10-12");
  assert.equal((await tournament()).current_student.rank, 1);
});

test("countdown uses server anchors, handles sleep/clock skew, invalid responses, and never goes negative", () => {
  const raw = { local_date: "2026-10-11", week_start: "2026-10-05", week_end: "2026-10-12", server_now: "2026-10-12T03:59:00Z", next_midnight: "2026-10-12T04:00:00Z", next_weekly_reset: "2026-10-12T04:00:00Z" };
  const calendar = readCalendar(raw, 100, 9000);
  assert.equal(secondsUntil(calendar, "nextWeeklyReset", 100, 9000), 60);
  assert.equal(secondsUntil(calendar, "nextWeeklyReset", 1100, 8000), 59);
  assert.equal(secondsUntil(calendar, "nextWeeklyReset", 100, 69000), 0);
  assert.equal(secondsUntil(calendar, "nextWeeklyReset", 900000, 900000), 0);
  assert.equal(formatWeeklyCountdown(2*86400+7*3600+18*60), "2d 07h 18m");
  assert.equal(formatWeeklyCountdown(10), "Less than 1 minute");
  assert.equal(formatWeeklyCountdown(0), "Updating this week…");
  assert.throws(() => readCalendar({ ...raw, next_weekly_reset: "invalid" }));
});

test("8 shared lives, duplicate losses, three-minute regeneration and server-side zero-life reward blocking", async () => {
  const own = await student(); await login(own);
  const lives = () => scalar("select to_jsonb(r) from public.get_my_arcade_state() r");
  const lose = key => scalar("select to_jsonb(r) from public.lose_arcade_life($1) r", [`arcade:${key}:wrong`]);
  const coin = key => scalar("select to_jsonb(r) from public.record_activity_event($1,'arcade','balloon-pop','arcade_correct') r", [`arcade:${key}:correct`]);
  assert.equal((await lives()).lives, 8);
  await coin("already-saved");
  assert.equal((await lose("one")).lives, 7); assert.equal((await lose("one")).life_lost, false);
  for (let index=0; index<7; index++) await lose(`more-${index}`);
  assert.equal((await lives()).lives, 0);
  await assert.rejects(coin("blocked"), /life required/);
  assert.equal((await coin("already-saved")).event_recorded, false);
  await db.query("update public.arcade_state set regeneration_started_at=now()-interval '181 seconds' where user_id=$1", [own]);
  assert.equal((await lives()).lives, 1);
  assert.equal((await coin("after-regen")).event_recorded, true);
  assert.equal((await snapshot()).weekly_xp, 0);
  assert.equal((await snapshot()).stats.coin_balance, 2);
});

test("tournament/helper permissions and setup verification; rerun preserves all balances", async () => {
  const own = await student(); await login(own); await addXp(own, 60);
  await db.exec("set role anon");
  try { await assert.rejects(tournament(), /permission denied/); } finally { await db.exec("reset role"); }
  await db.exec("set role authenticated");
  try {
    assert.equal((await tournament()).current_student.weekly_xp, 60);
    await assert.rejects(db.exec("select * from numora_private.calendar_window(auth.uid())"), /permission denied/);
  } finally { await db.exec("reset role"); }
  const before = await snapshot();
  await db.exec(await readFile(new URL("../supabase/009_weekly_reset.sql", import.meta.url), "utf8"));
  const after = await snapshot(); assert.equal(after.weekly_xp, before.weekly_xp);
  assert.equal(after.stats.total_xp, before.stats.total_xp); assert.equal(after.stats.coin_balance, before.stats.coin_balance);
  const check = (await db.query(await readFile(new URL("../supabase/009_verify_weekly_reset.sql", import.meta.url), "utf8"))).rows[0];
  assert.equal(check.missing, 0, check.failed_checks.join(", "));
});
