// TEST DATABASE ONLY. No clock-override setting is read by production migrations.
export async function installTestClock(db) {
  await db.exec(`alter function numora_private.calendar_window(uuid,timestamptz) rename to calendar_window_real;
    create function numora_private.calendar_window(p_user_id uuid, p_now timestamptz default now())
    returns table(local_date date,week_start date,week_end date,next_midnight timestamptz,next_weekly_reset timestamptz,server_now timestamptz,timezone text)
    language sql stable set search_path = '' as $$select * from numora_private.calendar_window_real(p_user_id,
      coalesce(nullif(current_setting('numora.test_now',true),'')::timestamptz,p_now))$$;
    revoke all on function numora_private.calendar_window(uuid,timestamptz) from public,anon,authenticated;`);
  return instant => db.query("select set_config('numora.test_now',$1,false)", [instant]);
}
