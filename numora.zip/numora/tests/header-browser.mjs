// Isolated presentation test: real header, styles and state, no auth/API calls.
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const { chromium } = await import(process.env.NUMORA_PLAYWRIGHT_PATH || 'playwright');
const browser = await chromium.launch({ headless: true, channel: 'chrome' });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const artifacts = await mkdtemp(join(tmpdir(), 'numora-header-'));
const errors = [];
page.on('pageerror', error => errors.push(error.message));
await page.route('**/scripts/app.js', route => route.fulfill({ contentType: 'text/javascript', body: `
  import { createHeader } from './components/header.js';
  import * as state from './services/appState.js';
  window.headerTestState = state;
  let header;
  const render = () => {
    header?.destroy();
    header = createHeader(document.querySelector('#app-header'), {
      currentRoute: '#/simulation', onRouteChange() {}, onSignOut: state.setLoggedOut
    });
  };
  state.subscribeToAppState(render);
  state.setAuthenticatedUser({id:'header-test', firstName:'Alex', lastName:'Morgan', gradeLevel:'high'});
` }));

const xp = page.locator('.reward-counter--xp');
const coins = page.locator('.reward-counter--coins');
const update = values => page.evaluate(values => window.headerTestState.setStudentProgressSummary(values), values);
try {
  await page.goto(process.env.NUMORA_TEST_ORIGIN || 'http://localhost:3001/');
  await xp.waitFor();
  assert.equal(await xp.getAttribute('aria-label'), 'XP is loading');
  assert.match(await xp.innerText(), /— XP/);
  await update({totalXp:0, coinBalance:0, currentStreak:0});
  assert.equal(await xp.getAttribute('aria-label'), '0 total XP');
  assert.match(await xp.innerText(), /^0 XP$/);
  await update({totalXp:1250, coinBalance:88, currentStreak:7});
  assert.equal(await xp.getAttribute('aria-label'), '1,250 total XP');
  assert.equal(await coins.getAttribute('aria-label'), '88 coins');
  assert.equal(await xp.getAttribute('title'), 'Total XP');
  for (const width of [1440,1280,1200,1153,1024,768,480,390,320]) {
    await page.setViewportSize({width, height:900});
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    const layout = await page.evaluate(() => {
      const rect = selector => document.querySelector(selector).getBoundingClientRect();
      const rewards = rect('.header-rewards'), brand = rect('.brand'), actions = rect('.header-actions');
      const nav = rect('.header-nav-slot');
      const lastLink = rect('.primary-nav .nav-link:last-child');
      return { width:innerWidth, overflow:actions.right > innerWidth,
        brandOverlap:brand.right > actions.left && brand.bottom > actions.top, rewardsRight:rewards.right,
        navOverlap:nav.width > 0 && lastLink.right > actions.left };
    });
    assert.equal(layout.overflow, false, JSON.stringify(layout));
    assert.equal(layout.brandOverlap, false, JSON.stringify(layout));
    assert.equal(layout.navOverlap, false, JSON.stringify(layout));
    assert.ok(layout.rewardsRight <= width, JSON.stringify(layout));
    if ([1440,390,320].includes(width)) await page.screenshot({path:join(artifacts, `header-${width}.png`)});
  }
  await update({totalXp:1234567, coinBalance:98765, currentStreak:365});
  for (const width of [1440,1200,1153,768,390,320]) {
    await page.setViewportSize({width,height:900});
    assert.equal(await page.locator('.header-actions').evaluate(el => {
      const bounds=el.getBoundingClientRect();
      return bounds.left>=0 && bounds.right<=innerWidth;
    }), true, `Large balances at ${width}`);
    assert.equal(await xp.isVisible(), true);
  }
  await page.getByRole('button', {name:'Open navigation menu'}).click();
  assert.equal(await page.getByRole('navigation', {name:'Mobile navigation'}).isVisible(), true);
  await page.keyboard.press('Escape');
  assert.equal(await page.getByRole('navigation', {name:'Mobile navigation'}).isVisible(), false);
  await page.evaluate(() => window.headerTestState.setAuthenticatedUser({id:'another-student'}));
  assert.equal(await xp.getAttribute('aria-label'), 'XP is loading');
  await page.evaluate(() => window.headerTestState.setLoggedOut());
  assert.equal(await xp.count(), 0);
  assert.equal(await coins.count(), 0);
  assert.deepEqual(errors, []);
  console.log('Header checks passed: loading, zero, live totals, user changes, sign-out, desktop/mobile layout, and mobile menu.');
  console.log('Screenshots:', artifacts);
} catch (error) {
  await page.screenshot({path:join(artifacts,'failure.png')});
  console.error('Screenshots:', artifacts);
  throw error;
} finally { await browser.close(); }
