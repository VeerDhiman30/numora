// Real app/auth services + storage policy, isolated PostgreSQL, simulated auth
// provider. No real accounts, confirmation mail, API keys, or Gemini calls.
import assert from "node:assert/strict";
import { createFixture } from "./leaderboardFixture.mjs";
import { installTestClock } from "./testClock.mjs";
export async function finalHarness({hasTouch=false}={}) {
  const fixture = await createFixture();
  const { db, student, login } = fixture;
  const clock = await installTestClock(db);
  const uid = await student({ first: "Alex", last: "Morgan" }); await login(uid);
  const { chromium } = await import(process.env.NUMORA_PLAYWRIGHT_PATH || "playwright");
  const browser = await chromium.launch({ headless: true, channel: "chrome" });
  const context = await browser.newContext({ viewport: { width:1440,height:1000 }, timezoneId:"UTC", hasTouch });
  const page = await context.newPage(); page.setDefaultTimeout(15000);
  page.on("dialog", dialog => dialog.accept()); // Confirm test-only hint spending.
  const errors = []; page.on("pageerror", error => errors.push(error.message));
  const controls = { malformedRpc:null, failRpc:null, loseResponseOnceRpc:null, profileGate:null, ai:"offline" };
  const calls = [], dbErrors = [];
  await context.route("**/api/config", route => route.fulfill({ json:{supabaseUrl:"https://fixture.example",supabasePublishableKey:"sb_publishable_isolated_test"} }));
  await context.route("https://cdn.jsdelivr.net/npm/@supabase/**", route => route.fulfill({contentType:"text/javascript",body:`
    export function createClient(url,key,options) {
      const storage=options.auth.storage, storageKey=options.auth.storageKey;
      const user={id:'${uid}',email:'fixture@example.test',user_metadata:{first_name:'Alex',last_name:'Morgan',grade_level:'high',timezone:'UTC'}};
      const makeSession=()=>({user,access_token:'isolated-test-token'});
      let callback;
      const current=()=>JSON.parse(storage.getItem(storageKey)||'null');
      const save=s=>s?storage.setItem(storageKey,JSON.stringify(s)):storage.removeItem(storageKey);
      const emit=(event,session)=>callback?.(event,session);
      const call=body=>fetch('/__final_test',{method:'POST',body:JSON.stringify(body)}).then(r=>r.json());
      window.__authTest={calls:[],emit: event=>emit(event,current()),expire:()=>{save(null);emit('SIGNED_OUT',null)}};
      if (['confirmed','reset'].includes(new URL(location.href).searchParams.get('auth'))) save(makeSession());
      return {auth:{
        getSession:async()=>({data:{session:current()},error:null}),
        onAuthStateChange:fn=>{callback=fn;return {data:{subscription:{unsubscribe(){callback=null}}}}},
        signUp:async input=>{window.__authTest.calls.push({type:'signup',input});return {data:{user,session:null},error:null}},
        signInWithPassword:async input=>{window.__authTest.calls.push({type:'signin'});if(input.password==='wrong')return {data:{session:null},error:{message:'private provider detail'}};const session=makeSession();save(session);queueMicrotask(()=>emit('SIGNED_IN',session));return {data:{session},error:null}},
        signOut:async()=>{save(null);emit('SIGNED_OUT',null);return {error:null}},
        resetPasswordForEmail:async(email,options)=>{window.__authTest.calls.push({type:'recovery',email,options});return {error:null}},
        updateUser:async input=>{window.__authTest.calls.push({type:'password'});return {data:{user},error:null}}
      },rpc:(rpc,args={})=>call({rpc,args}),from:table=>{
        const o={table,filters:[]};const q={select(){return q},eq(k,v){o.filters.push([k,v]);return q},order(){return q},limit(n){o.limit=n;return q},maybeSingle(){o.single=true;return q},upsert(data){o.write=data;return q},update(data){o.write=data;return q},then(resolve,reject){return call(o).then(resolve,reject)}};return q;
      }};
    }
  `}));
  const rpcArgs = {
    get_my_economy_snapshot:[],get_weekly_tournament:["p_limit"],get_my_weekly_xp:[],get_my_today_activity:[],
    get_my_daily_challenge:["p_grade_level"],submit_daily_challenge:["p_grade_level","p_challenge_id","p_local_date","p_answer"],repair_my_streak:["p_missed_date"],
    get_my_arcade_state:[],lose_arcade_life:["p_event_key"],record_activity_event:["p_event_key","p_module","p_topic","p_activity_type","p_metadata"],
    record_quant_activity_event:["p_event_key","p_topic","p_activity_type","p_metadata"],
    upsert_simulation_progress:["p_story_id","p_grade_level","p_current_step","p_attempts","p_help_uses","p_guidance_level","p_response_history"]
  };
  await context.route("**/__final_test", async route => {
    const body=JSON.parse(route.request().postData()); calls.push(body);
    try {
      let data;
      if(body.rpc) {
        assert.ok(rpcArgs[body.rpc],body.rpc);
        if(controls.failRpc===body.rpc) throw new Error('Private provider failure');
        if(controls.malformedRpc===body.rpc) data={broken:true};
        else {
          const keys=rpcArgs[body.rpc];
          const rows=(await db.query(`select to_jsonb(r) as wire from public.${body.rpc}(${keys.map((_,i)=>'$'+(i+1)).join(',')}) r`,keys.map(k=>{
            const value=body.args[k]??null;
            return value!==null && typeof value==='object' ? JSON.stringify(value) : value;
          }))).rows.map(row=>row.wire);
          const scalarRpc=['get_my_economy_snapshot','get_weekly_tournament','get_my_weekly_xp','get_my_daily_challenge','submit_daily_challenge','repair_my_streak'].includes(body.rpc);
          data=rows[0]?.[body.rpc]??(scalarRpc?rows[0]:rows);
          if(controls.loseResponseOnceRpc===body.rpc) {
            controls.loseResponseOnceRpc=null;
            throw new Error('Test-only lost response after successful commit');
          }
        }
      } else {
        assert.ok(['profiles','student_stats','module_progress','activity_events','simulation_progress'].includes(body.table));
        if(body.write) data=null;
        else {
          data=(await db.query(`select * from public.${body.table} where ${body.table==='profiles'?'id':'user_id'}=$1`,[uid])).rows;
          for(const [key,value] of body.filters) data=data.filter(row=>row[key]===value);
          if(body.limit)data=data.slice(0,body.limit);
          if(body.single)data=data[0]??null;
          if(body.table==='profiles' && controls.profileGate) await controls.profileGate;
        }
      }
      await route.fulfill({json:{data,error:null}});
    } catch(error) { dbErrors.push({rpc:body.rpc,message:error.message}); await route.fulfill({json:{data:null,error:{message:error.message}}}); }
  });
  await context.route("**/api/ai/**",route=> controls.ai==='success'
    ? route.fulfill({json:{success:true,status:'guided',coachMessage:'Compare the two quantities before choosing your next step.',guidanceLevel:1}})
    : route.fulfill({status:503,json:{success:false,message:"Numora's coach is temporarily unavailable. Please try again."}}));
  const base=process.env.NUMORA_TEST_ORIGIN||'http://localhost:3002';
  return {...fixture,clock,uid,browser,context,page,controls,calls,dbErrors,errors,base};
}
