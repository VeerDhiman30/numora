// Executes the real migrations against an isolated PostgreSQL (PGlite) database.
// No network calls, credentials, or live Supabase data are used.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";

const { PGlite } = await import(process.env.NUMORA_PGLITE_PATH || "@electric-sql/pglite");
let db;
let user;
let today;
const scalar = async (sql, params = []) => Object.values((await db.query(sql, params)).rows[0])[0];
async function student(zone = "UTC") {
  user = randomUUID();
  await db.query("insert into auth.users (id, raw_user_meta_data) values ($1, $2)", [user, { first_name: "Test", grade_level: "middle", timezone: zone }]);
  await db.query("select set_config('request.jwt.claim.sub', $1, false)", [user]);
  today = await scalar("select numora_private.local_day(auth.uid())::text");
  return user;
}
const snapshot = () => scalar("select public.get_my_economy_snapshot()");
async function addDay(offset, xp) {
  await db.query("insert into public.daily_activity (user_id, local_date, xp_earned) values ($1, $2::date + $3::integer, $4) on conflict (user_id, local_date) do update set xp_earned = excluded.xp_earned", [user, today, offset, xp]);
}
const quant = (id, type = "correct_answer") => scalar("select to_jsonb(r) from public.record_quant_activity_event($1, 'algebra', $2, '{\"grade_level\":\"high\"}') r", [`quant:${id}:${type === "hint" ? "hint" : "correct"}`, type]);
async function challenge(grade = "high") {
  const data = await scalar("select public.get_my_daily_challenge($1)", [grade]);
  const answer = await scalar("select answer from numora_private.challenge_bank where id = $1", [data.id]);
  return { ...data, answer };
}
const submit = (item, answer = item.answer) => scalar("select public.submit_daily_challenge($1,$2,$3,$4)", [item.grade_level, item.id, item.local_date, answer]);

before(async () => {
  db = new PGlite();
  await db.exec(`create role anon; create role authenticated;
    create schema auth;
    create table auth.users (id uuid primary key, raw_user_meta_data jsonb default '{}');
    create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid$$;
    grant usage on schema auth to authenticated, anon;
    grant execute on function auth.uid() to authenticated, anon;`);
  for (const file of ["001_profiles.sql", "progress-schema.sql", "002_decision_lab_rewards.sql", "003_quant_lab_rewards.sql", "004_simulation_lab.sql", "005_simulation_security_hardening.sql", "006_arcade_state.sql"]) {
    await db.exec(await readFile(new URL(`../supabase/${file}`, import.meta.url), "utf8"));
  }
  // Supabase's ordinary public-schema grants; Phase 7 revokes writes on its tables.
  await db.exec("grant select, insert, update, delete on all tables in schema public to authenticated");
  const migration = await readFile(new URL("../supabase/007_dashboard_economy.sql", import.meta.url), "utf8");
  await db.exec(migration);
  await db.exec(migration); // Prove rerunning does not fail or reset data.
  // Run the existing reward/streak regressions with the current weekly RPC too.
  await db.exec(await readFile(new URL("../supabase/008_weekly_leaderboard.sql", import.meta.url), "utf8"));
  await db.exec(await readFile(new URL("../supabase/009_weekly_reset.sql", import.meta.url), "utf8"));
});
after(async () => { await db?.close(); });

test("new accounts have zero real totals and stable daily questions without exposed answers", async () => {
  await student();
  const data = await snapshot();
  assert.equal(data.stats.total_xp, 0);
  assert.equal(data.stats.coin_balance, 0);
  assert.equal(data.stats.current_streak, 0);
  assert.equal(data.today.xp_earned, 0);
  assert.equal(data.weekly_xp, 0);
  for (const grade of ["entry", "middle", "high"]) {
    const a = await scalar("select public.get_my_daily_challenge($1)", [grade]);
    const b = await scalar("select public.get_my_daily_challenge($1)", [grade]);
    assert.equal(a.id, b.id);
    assert.equal(a.answer, undefined);
  }
});

test("49 XP does not qualify; 50 qualifies once and later XP does not increment again", async () => {
  await student();
  await addDay(0, 49);
  assert.equal((await snapshot()).qualified_today, false);
  const awarded = await quant("threshold");
  assert.equal(awarded.today_xp, 50);
  assert.equal(awarded.current_streak, 1);
  const first = await snapshot();
  assert.equal(first.celebrate, true);
  assert.equal((await snapshot()).celebrate, false);
  const again = await quant("threshold");
  assert.equal(again.event_recorded, false);
  assert.equal(again.today_xp, 50);
  await quant("above-threshold");
  assert.equal((await snapshot()).stats.current_streak, 1);
});

test("daily completion is server-checked, adds 20/20, qualifies 35→55 XP, and only rewards one difficulty", async () => {
  await student();
  await addDay(0, 35);
  const item = await challenge();
  const wrong = item.options.find((option) => option !== item.answer);
  assert.equal((await submit(item, wrong)).correct, false);
  assert.equal((await snapshot()).today.xp_earned, 35);
  assert.equal((await submit(item)).event_recorded, true);
  let result = await snapshot();
  assert.equal(result.today.xp_earned, 55);
  assert.equal(result.stats.coin_balance, 20);
  assert.equal(result.stats.current_streak, 1);
  assert.equal(result.weekly_xp, 55);
  assert.equal((await submit(item)).event_recorded, false);
  const other = await challenge("entry");
  assert.equal(other.completed, true);
  assert.equal((await submit(other)).event_recorded, false);
  result = await snapshot();
  assert.equal(result.stats.coin_balance, 20);
  assert.equal(result.today.xp_earned, 55);
  assert.equal(await scalar("select attempt_count from public.daily_challenges where user_id = $1", [user]), 2);
});

test("general activity API cannot bypass daily answer or streak repair validation", async () => {
  await student();
  await assert.rejects(db.query("select public.record_activity_event($1, 'daily_challenge', 'math', 'daily_challenge')", [`daily_challenge:${today}`]));
  await assert.rejects(db.query("select public.record_activity_event($1, 'streak', null, 'streak_repair')", [`streak_repair:${today}`]));
  assert.equal((await snapshot()).stats.coin_balance, 0);
});

test("consecutive calendar days continue; one gap breaks and repairs atomically for exactly 200", async () => {
  await student();
  await addDay(-3, 50);
  await addDay(-2, 70);
  await addDay(0, 50);
  const before = await snapshot();
  assert.equal(before.stats.current_streak, 1);
  assert.ok(before.repair_date);
  await assert.rejects(db.query("select public.repair_my_streak($1)", [before.repair_date]), /Insufficient/);
  assert.equal(await scalar("select count(*)::int from public.streak_days where user_id = $1 and source = 'repaired'", [user]), 0);
  await db.query("update public.student_stats set coin_balance = 240 where user_id = $1", [user]);
  const repair = await scalar("select public.repair_my_streak($1)", [before.repair_date]);
  assert.equal(repair.event_recorded, true);
  const result = await snapshot();
  assert.equal(result.stats.current_streak, 4);
  assert.equal(result.stats.coin_balance, 40);
  assert.equal(result.repair_date, null);
  assert.equal(result.today.xp_earned, 50);
  assert.equal((await scalar("select public.repair_my_streak($1)", [before.repair_date])).event_recorded, false);
  assert.equal((await snapshot()).stats.coin_balance, 40);
});

test("two missed days cannot be repaired and a previous streak does not silently continue", async () => {
  await student();
  await addDay(-3, 60);
  const result = await snapshot();
  assert.equal(result.stats.current_streak, 0);
  assert.equal(result.repair_date, null);
  await assert.rejects(db.query("select public.repair_my_streak($1::date - 1)", [today]));
});

test("today resets naturally and Monday-to-today XP excludes earlier weeks and future dates", async () => {
  await student();
  await db.query("insert into public.daily_activity (user_id, local_date, xp_earned) values ($1, date_trunc('week', $2::date)::date - 1, 999), ($1, date_trunc('week', $2::date)::date, 12), ($1, $2::date + 1, 888)", [user, today]);
  // Monday can also be today; update, rather than insert a duplicate.
  await addDay(0, 33);
  const expected = (await scalar("select extract(isodow from $1::date)::int", [today])) === 1 ? 33 : 45;
  assert.equal((await snapshot()).weekly_xp, expected);
  await student();
  await addDay(-1, 50);
  const fresh = await snapshot();
  assert.equal(fresh.today.xp_earned, 0);
  assert.equal(fresh.stats.current_streak, 1);
  assert.equal(fresh.qualified_today, false);
  assert.equal(fresh.celebrate, false);
});

test("timezone changes cannot claim a second day early; stale date submissions are rejected", async () => {
  await student("Pacific/Pago_Pago");
  const item = await challenge();
  await submit(item);
  await db.query("update public.profiles set timezone = 'Pacific/Kiritimati' where id = $1", [user]);
  const moved = await challenge();
  assert.equal(moved.locked, true);
  await assert.rejects(submit(moved));
  await assert.rejects(submit(item), /expired/);
  await assert.rejects(db.query("update public.profiles set timezone = 'UTC' where id = $1", [user]), /recently/);
  assert.equal((await snapshot()).stats.coin_balance, 20);
});

test("IANA local midnight handles DST short/long days and half-hour offsets", async () => {
  assert.equal(await scalar("select extract(epoch from (timestamp '2026-03-09' at time zone 'America/New_York') - (timestamp '2026-03-08' at time zone 'America/New_York'))::int"), 23 * 3600);
  assert.equal(await scalar("select extract(epoch from (timestamp '2026-11-02' at time zone 'America/New_York') - (timestamp '2026-11-01' at time zone 'America/New_York'))::int"), 25 * 3600);
  assert.equal(await scalar("select to_char(timestamp '2026-10-15' at time zone 'Asia/Kolkata' at time zone 'UTC', 'YYYY-MM-DD HH24:MI')"), '2026-10-14 18:30');
});

test("existing lab rewards and hint costs are unchanged, duplicate safe, nonnegative, and arcade never adds academic progress", async () => {
  await student();
  await db.query("update public.student_stats set coin_balance = 12 where user_id = $1", [user]);
  await scalar("select to_jsonb(r) from public.record_activity_event('decision:session1:question1:correct','decision','sports','correct_answer') r");
  await scalar("select to_jsonb(r) from public.record_activity_event('decision:session1:question1:hint','decision','sports','hint') r");
  await quant("q01", "hint");
  await quant("q01", "hint");
  await assert.rejects(quant("q02", "hint"), /Insufficient/);
  await quant("q01");
  await scalar("select to_jsonb(r) from public.record_activity_event('arcade:game1:session1:round1:correct','arcade','balloon-pop','arcade_correct') r");
  const result = await snapshot();
  assert.equal(result.stats.total_xp, 6);
  assert.equal(result.stats.coin_balance, 1);
  assert.equal(await scalar("select count(*)::int from public.module_progress where user_id = $1 and module = 'arcade'", [user]), 0);
  assert.equal(await scalar("select attempt_count from public.module_progress where user_id = $1 and module = 'quant'", [user]), 1);
});

test("simulation catalog guard still rejects unearned completion and grants only 10 XP once", async () => {
  await student();
  const award = () => scalar("select to_jsonb(r) from public.record_activity_event('simulation:entry-snack-budget:completed', 'simulation','entry-snack-budget','story_completed','{\"grade_level\":\"entry\",\"story_id\":\"entry-snack-budget\"}') r");
  await assert.rejects(award());
  await db.query("insert into public.simulation_progress (user_id,story_id,grade_level,current_step,response_history) values ($1,'entry-snack-budget','entry',5,$2)", [user, Array.from({ length: 5 }, () => ({ role: "student", content: "Answer" }))]);
  assert.equal((await award()).total_xp, 10);
  assert.equal((await award()).event_recorded, false);
  assert.equal(await scalar("select status from public.simulation_progress where user_id = $1", [user]), 'completed');
});

test("RLS isolates student records and denies direct award, answer-bank, and rule writes", async () => {
  await student();
  const own = user;
  await challenge();
  await student();
  await db.exec("set role authenticated");
  try {
    assert.equal(await scalar("select count(*)::int from public.daily_challenges where user_id = $1", [own]), 0);
    await assert.rejects(db.exec("select * from numora_private.challenge_bank"), /permission denied/);
    await assert.rejects(db.exec("select numora_private.award('fake:event', 'arcade', null, 'arcade_correct', '{}')"), /permission denied/);
    await assert.rejects(db.exec("update public.reward_rules set xp = 9999"), /permission denied/);
    await assert.rejects(db.exec("insert into public.streak_days values (auth.uid(),current_date,'qualified',null,now())"), /permission denied/);
    assert.equal((await snapshot()).stats.coin_balance, 0);
  } finally { await db.exec("reset role"); }
  await db.query("select set_config('request.jwt.claim.sub','',false)");
  await assert.rejects(snapshot(), /Authentication/);
});

test("migration rerun preserves earned balances and the setup verification reports zero missing", async () => {
  await student();
  await submit(await challenge());
  const prior = await snapshot();
  await db.exec(await readFile(new URL('../supabase/007_dashboard_economy.sql', import.meta.url), 'utf8'));
  const current = await snapshot();
  assert.equal(current.stats.coin_balance, prior.stats.coin_balance);
  assert.equal(current.stats.total_xp, prior.stats.total_xp);
  assert.equal((await challenge()).completed, true);
  const verification = await db.query(await readFile(new URL('../supabase/007_verify_dashboard.sql', import.meta.url), 'utf8'));
  assert.equal(verification.rows[0].missing, 0);
});
