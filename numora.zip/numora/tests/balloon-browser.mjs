import assert from 'node:assert/strict';
import {mkdtemp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {finalHarness} from './finalHarness.mjs';
import {installArcadeAudioProbe} from './arcadeAudioProbe.mjs';
const {db,uid,browser,page,base,calls,controls,errors}=await finalHarness();
await installArcadeAudioProbe(page);
const artifacts=await mkdtemp(join(tmpdir(),'numora-balloons-'));
const balloon=index=>page.locator(`[data-balloon-index="${index}"]`);
const lives=async()=> (await db.query('select lives from public.arcade_state where user_id=$1',[uid])).rows[0].lives;
const clickBody=index=>balloon(index).locator('.balloon-body').click({force:true});
try {
  await page.goto(`${base}/#/arcade`);
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.locator('[data-arcade-action="grade:entry"]').click();
  await page.locator('[data-arcade-action="choose-game:balloon-pop"]').click();
  await page.locator('[data-arcade-action="start-game"]').click();
  await page.locator('[data-arcade-action="balloon-launch"]').click();
  await page.locator('.arcade-balloons').scrollIntoViewIfNeeded();
  const start=await balloon(0).evaluate(el=>{
    const b=el.querySelector('.balloon-body').getBoundingClientRect(),stage=el.closest('.arcade-balloons').getBoundingClientRect();
    return {relativeTop:b.top-stage.top,height:stage.height,bottom:b.bottom-stage.bottom};
  });
  assert.ok(start.relativeTop>start.height-125,JSON.stringify(start));
  assert.ok(start.bottom<=0&&start.bottom>-45,JSON.stringify(start));
  assert.equal(await balloon(4).isVisible(),false);
  await page.waitForTimeout(1000);
  const moved=await balloon(0).evaluate(el=>el.querySelector('.balloon-body').getBoundingClientRect().top-el.closest('.arcade-balloons').getBoundingClientRect().top);
  assert.ok(moved<start.relativeTop-10);
  await page.locator('.arcade-balloons').screenshot({path:join(artifacts,'rising.png')});
  await clickBody(1);
  await page.waitForFunction(()=>document.querySelector('[data-balloon-cooldown]')?.textContent.includes('Cooldown'));
  assert.equal(await page.locator('.arcade-balloons.is-cooling-down').count(),1);
  assert.equal(await balloon(1).locator('.balloon-wrong-mark').isVisible(),true);
  assert.equal(await balloon(1).locator('.balloon-body').evaluate(el=>getComputedStyle(el).stroke),'rgb(255, 76, 98)');
  assert.match(await balloon(1).getAttribute('aria-label'),/wrong balloon/);
  assert.match(await page.locator('.arcade-feedback--incorrect').innerText(),/Wrong balloon/);
  assert.deepEqual(await page.evaluate(()=>window.__arcadeAudioStarts.map(n=>[n.type,n.state])),[['sawtooth','running']]);
  await balloon(0).evaluate(el=>el.click());
  assert.equal(await page.evaluate(()=>window.__arcadeAudioStarts.length),1,'blocked cooldown click cannot replay buzzer');
  assert.equal(calls.filter(c=>c.rpc==='record_activity_event').length,0);
  assert.equal(calls.filter(c=>c.rpc==='lose_arcade_life').length,0);
  assert.equal(await lives(),8);
  for (const digit of ['4','3','2','1']) {
    await page.waitForFunction(value=>document.querySelector('[data-balloon-countdown]')?.textContent===value,digit);
    assert.equal(await page.locator('[data-balloon-countdown-overlay]').isVisible(),true);
    if (digit==='4') await page.locator('.arcade-balloons').screenshot({path:join(artifacts,'cooldown-4.png')});
    if (digit==='2') {
      await page.setViewportSize({width:390,height:844});
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
      await page.locator('.arcade-balloons').screenshot({path:join(artifacts,'cooldown-mobile.png')});
    }
  }
  await page.waitForFunction(()=>document.querySelector('[data-balloon-index="0"]')?.getAttribute('aria-disabled')==='false');
  assert.equal(await page.locator('[data-balloon-countdown-overlay]').isVisible(),false);
  assert.equal(await page.locator('.arcade-balloons.is-cooling-down').count(),0);
  await page.setViewportSize({width:1440,height:1000});
  await clickBody(0);
  await page.locator('.balloon-pop-effect--correct').waitFor();
  assert.equal(await page.locator('.balloon-pop-shard').count(),10);
  assert.equal(await page.locator('.balloon-pop-ring').evaluate(el=>getComputedStyle(el).animationDuration),'3s');
  await page.waitForFunction(()=>document.querySelector('.arcade-game__progress')?.textContent.startsWith('1 correct'));
  await page.waitForTimeout(400);
  await page.locator('.arcade-balloons').screenshot({path:join(artifacts,'pop.png')});
  await page.waitForTimeout(1600);
  assert.equal(await page.locator('.balloon-pop-effect--correct').count(),1,'burst persists through reward rerenders');
  await page.locator('.balloon-pop-effect--correct').waitFor({state:'detached'});
  // A failed missed-balloon save pauses play and retries the same event key.
  controls.failRpc='lose_arcade_life';
  await page.locator('[data-arcade-action="retry-balloon-miss"]').waitFor({timeout:20000});
  assert.equal(await lives(),8);
  assert.equal(await page.locator('.balloon-pop-effect--missed').count(),1);
  const failedKey=calls.filter(c=>c.rpc==='lose_arcade_life').at(-1).args.p_event_key;
  controls.failRpc=null;
  await page.locator('[data-arcade-action="retry-balloon-miss"]').click();
  await page.waitForFunction(()=>document.querySelector('.arcade-hud__lives strong')?.textContent==='7/8');
  assert.equal(calls.filter(c=>c.rpc==='lose_arcade_life').at(-1).args.p_event_key,failedKey);
  await page.waitForFunction(()=>document.querySelector('.arcade-board__heading span')?.textContent==='Round 2 of 3',{},{timeout:15000});
  assert.equal(await lives(),6);
  assert.equal((await db.query('select count(*)::int as n from public.arcade_life_events where user_id=$1',[uid])).rows[0].n,2);
  assert.equal((await db.query('select coin_balance from public.student_stats where user_id=$1',[uid])).rows[0].coin_balance,1);
  assert.equal(await page.locator('.balloon-pop-effect').count(),0);
  // Phone layout, reduced motion, last-pop transition, and restart cleanup.
  await page.setViewportSize({width:390,height:844});
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.locator('[data-arcade-action="balloon-launch"]').click();
  await page.locator('.arcade-balloons').scrollIntoViewIfNeeded();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await clickBody(0);
  await page.locator('.balloon-pop-effect--correct').waitFor();
  await page.waitForFunction(()=>document.querySelector('.arcade-game__progress')?.textContent.startsWith('2 correct'));
  // Reward saving replaces the board; inspect the current connected node in
  // one browser task, not a handle that can become detached during that redraw.
  await page.waitForFunction(()=>{
    const word=document.querySelector('.balloon-pop-word');
    return word && getComputedStyle(word).animationName==='none';
  });
  await clickBody(2);
  await page.waitForFunction(()=>document.querySelector('.arcade-game__progress')?.textContent.startsWith('3 correct'));
  await page.waitForFunction(()=>!document.querySelector('[data-balloon-index="4"]')?.hidden);
  await clickBody(4);
  await page.locator('.balloon-pop-effect--correct').waitFor();
  assert.equal(await page.locator('.arcade-board__heading span').innerText(),'Round 2 of 3');
  await page.waitForTimeout(1600);
  assert.equal(await page.locator('.arcade-board__heading span').innerText(),'Round 2 of 3','final pop remains on its round');
  await page.waitForFunction(()=>document.querySelector('.arcade-board__heading span')?.textContent==='Round 3 of 3');
  await page.locator('.arcade-balloons').screenshot({path:join(artifacts,'mobile-ready.png')});
  await page.evaluate(()=>{location.hash='#/dashboard'});
  await page.locator('[data-summary]').waitFor();
  assert.equal(await page.locator('.balloon-pop-effect').count(),0);
  assert.deepEqual(errors,[]);
  console.log('Balloon browser checks passed: bottom start, upward travel, 3-second persistent bursts, visible 4–3–2–1 cooldown without life loss, missed-target life deductions, retry idempotency, phone layout, reduced motion, round transition and cleanup.');
  console.log('Screenshots:',artifacts);
} catch(error) {await page.screenshot({path:join(artifacts,'failure.png'),fullPage:true});console.error({artifacts,errors});throw error;}
finally {await browser.close();await db.close();}
