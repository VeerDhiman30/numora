import assert from 'node:assert/strict';
import {mkdtemp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {finalHarness} from './finalHarness.mjs';
import {installArcadeAudioProbe} from './arcadeAudioProbe.mjs';

const {db,uid,browser,page,base,calls,controls,errors}=await finalHarness({hasTouch:true});
await installArcadeAudioProbe(page);
const artifacts=await mkdtemp(join(tmpdir(),'numora-line-'));
const key=`numora:arcade-session:v1:${uid}`;
const session=()=>page.evaluate(k=>JSON.parse(sessionStorage.getItem(k)),key);
const grid=()=>page.locator('[data-line-grid]');
const lives=async()=> (await db.query('select lives from public.arcade_state where user_id=$1',[uid])).rows[0].lives;
const coins=async()=> (await db.query('select coin_balance from public.student_stats where user_id=$1',[uid])).rows[0].coin_balance;
const nextRound=index=>page.waitForFunction(({key,index})=>JSON.parse(sessionStorage.getItem(key))?.gameState.round===index,{key,index});
async function clickGrid(x,y,{touch=false}={}) {
  await grid().scrollIntoViewIfNeeded();
  const box=await grid().boundingBox();
  const position={x:(220+x*30)*box.width/440,y:(220-y*30)*box.height/440};
  if(touch) await page.touchscreen.tap(box.x+position.x,box.y+position.y);
  else await grid().click({position});
}
async function typePoint(x,y) {
  await page.getByLabel('x coordinate',{exact:true}).fill(String(x));
  await page.getByLabel('y coordinate',{exact:true}).fill(String(y));
  await page.getByRole('button',{name:'Plot point',exact:true}).click();
}
const reload=async()=>{await page.reload();await page.waitForFunction(()=>document.querySelector('[data-line-grid]')?.getAttribute('aria-disabled')==='false');};
try {
  await page.goto(`${base}/#/arcade`);
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.locator('[data-arcade-action="grade:middle"]').click();
  await page.locator('[data-arcade-action="choose-game:draw-the-line"]').click();
  assert.match(await page.locator('.arcade-instructions__notice').innerText(),/two different points/);
  await page.locator('[data-arcade-action="start-game"]').click();
  await grid().waitFor();
  assert.equal(await page.locator('[data-line-connection]').count(),0);
  assert.equal(await page.getByRole('button',{name:'Check line',exact:true}).isDisabled(),true);
  assert.equal(await page.locator('[data-arcade-action^="graph-slope"]').count(),0);
  // Pointer plotting and an alternative pair, not a fixed answer key.
  await clickGrid(-2,-4);
  assert.deepEqual((await session()).gameState.graph.points,[{x:-2,y:-4},null]);
  assert.equal(await page.locator('[data-line-connection]').count(),0);
  await clickGrid(2,2);
  assert.deepEqual((await session()).gameState.graph.points,[{x:-2,y:-4},{x:2,y:2}]);
  assert.equal(await page.locator('[data-line-connection]').getAttribute('x1'),'160');
  assert.equal(await page.locator('[data-line-connection]').getAttribute('y1'),'340');
  assert.equal(await page.locator('[data-line-connection]').getAttribute('x2'),'280');
  assert.equal(await page.locator('[data-line-connection]').getAttribute('y2'),'160');
  assert.equal(await coins(),0);assert.equal(await lives(),8);
  await page.locator('.line-board').screenshot({path:join(artifacts,'desktop-two-points.png')});
  // Placing/editing is free. Only checking the wrong line loses one life.
  await clickGrid(2,3);
  assert.equal(await lives(),8);
  await page.getByRole('button',{name:'Check line',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('.arcade-hud__lives strong')?.textContent==='7/8');
  assert.equal(await page.locator('.line-graph--incorrect').count(),1);
  assert.equal(await page.evaluate(()=>window.__arcadeAudioStarts.filter(n=>n.type==='sawtooth').length),1);
  await clickGrid(2,2);assert.equal(await page.locator('.line-graph--incorrect').count(),0);
  await reload();assert.deepEqual((await session()).gameState.graph.points,[{x:-2,y:-4},{x:2,y:2}]);

  // A lost reward response freezes the plotted answer and retries its event.
  controls.loseResponseOnceRpc='record_activity_event';
  await page.getByRole('button',{name:'Check line',exact:true}).click();
  await page.locator('.arcade-feedback--error').waitFor();
  assert.equal(await coins(),1);
  assert.equal(await page.getByLabel('x coordinate',{exact:true}).isDisabled(),true);
  await clickGrid(3,3,{touch:true});
  assert.deepEqual((await session()).gameState.graph.points,[{x:-2,y:-4},{x:2,y:2}]);
  await page.reload();await page.locator('[data-arcade-action="retry-reward"]').waitFor();
  await page.locator('[data-arcade-action="retry-reward"]').click();
  await nextRound(1);
  assert.equal(await coins(),1);assert.equal(await page.locator('[data-line-point]').count(),0);

  // Keyboard-only plotting keeps focus through renders.
  await grid().focus();
  for(let i=0;i<4;i++)await page.keyboard.press('ArrowUp');
  assert.equal(await grid().evaluate(el=>document.activeElement===el),true);
  await page.keyboard.press('Enter');
  assert.deepEqual((await session()).gameState.graph.points[0],{x:0,y:4});
  for(let i=0;i<2;i++)await page.keyboard.press('ArrowRight');
  for(let i=0;i<3;i++)await page.keyboard.press('ArrowDown');
  await page.keyboard.press('Space');
  assert.deepEqual((await session()).gameState.graph.points[1],{x:2,y:1});
  await page.getByRole('button',{name:'Check line',exact:true}).click();await nextRound(2);

  // Mobile touch plotting, exact decimal entry, duplicate prevention, and reset.
  await page.setViewportSize({width:390,height:844});
  await clickGrid(0,-3,{touch:true});
  assert.deepEqual((await session()).gameState.graph.points[0],{x:0,y:-3});
  await clickGrid(0,-3,{touch:true});
  assert.equal((await session()).gameState.graph.points[1],null);assert.equal(await lives(),7);
  await typePoint(3,4.5);
  await page.locator('[data-arcade-action="line-select:0"]').click();
  await typePoint(1,-.5);
  assert.deepEqual((await session()).gameState.graph.points,[{x:1,y:-.5},{x:3,y:4.5}]);
  await page.getByRole('button',{name:'Clear points',exact:true}).click();
  assert.equal(await page.locator('[data-line-connection]').count(),0);assert.equal(await lives(),7);
  await typePoint(1,-.5);
  await page.getByLabel('x coordinate',{exact:true}).fill('3');
  await page.getByLabel('y coordinate',{exact:true}).fill('4.5');
  await reload();
  assert.equal(await page.getByLabel('x coordinate',{exact:true}).inputValue(),'3');
  assert.equal(await page.getByLabel('y coordinate',{exact:true}).inputValue(),'4.5');
  await page.getByRole('button',{name:'Plot point',exact:true}).click();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.locator('.line-board').screenshot({path:join(artifacts,'mobile-two-points.png')});
  await page.getByRole('button',{name:'Check line',exact:true}).click();await page.locator('.arcade-complete').waitFor();
  assert.equal(await coins(),3);assert.equal(await lives(),7);
  assert.equal((await db.query('select count(*)::int as n from public.arcade_life_events where user_id=$1',[uid])).rows[0].n,1);
  assert.equal(calls.filter(c=>c.rpc==='record_activity_event').length,4,'three correct lines, one duplicate-safe retry');

  // Older saved slope/intercept drafts migrate without resetting earned coins.
  await page.locator('[data-arcade-action="restart-game"]').click();
  await page.evaluate(key=>{const saved=JSON.parse(sessionStorage.getItem(key));saved.gameState.graph={slope:1.5,intercept:-1};saved.gameState.round=1;sessionStorage.setItem(key,JSON.stringify(saved));},key);
  await reload();
  assert.equal((await session()).gameState.round,1);assert.equal((await session()).gameState.graph.version,2);
  assert.deepEqual((await session()).gameState.graph.points,[null,null]);assert.equal(await coins(),3);
  assert.deepEqual(errors,[]);
  console.log('Draw the Line browser checks passed: pointer and touch plotting, accurate connecting line, alternate/fractional answers, keyboard focus, point edits and resets, no life loss before checking, reload/legacy drafts, reward retry, three-round completion, and phone layout.');
  console.log('Screenshots:',artifacts);
} catch(error) {await page.screenshot({path:join(artifacts,'failure.png'),fullPage:true});console.error({artifacts,errors});throw error;}
finally {await browser.close();await db.close();}
