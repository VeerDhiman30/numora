import { test } from "node:test";
import { compactResponseHistory } from "../scripts/labs/simulation/storyEngine.js";
import assert from "node:assert/strict";
import { decisionQuestions, decisionModules } from "../scripts/data/decision/questions.js";
import { quantQuestions } from "../scripts/data/quant/questions.js";
import { isCorrectResponse, validateResponse, getInitialResponse, applyInteractiveAction } from "../scripts/labs/quant/questionEngine.js";
import { simulationStories } from "../scripts/data/simulation/stories.js";
import { createStoryState, getCurrentStoryStep, submitStoryResponse, restoreStoryState, evaluateStoryResponse } from "../scripts/labs/simulation/storyEngine.js";
import { arcadeGames, createGameState, evaluateGameAction, advanceGameState, renderGameBoard } from "../scripts/arcade/games.js";

function correctResponse(q) {
  const mappings = {
    "multiple-select": () => q.correctOptions,
    "complete-equation": () => Object.fromEntries(q.blanks.map(b => [b.id, b.answer])),
    "drag-drop": () => ({ placements: q.correctPlacements }),
    "arrange-order": () => ({ order: q.correctOrder, hasInteracted: true }),
    matching: () => ({ pairs: q.matches }),
    categorize: () => ({ placements: Object.entries(q.correctCategories).reduce((r,[id,c]) => ({ ...r, [c]: [...(r[c] || []), id] }), {}) }),
    "visual-label": () => ({ assignments: q.correctAssignments }),
    "build-expression": () => {
      const target = String(q.acceptedExpressions?.[0] ?? q.answer).replace(/\s/g, "");
      const build = (remaining, ids = []) => {
        if (!remaining) return ids;
        if (ids.length > 20) return null;
        for (const piece of q.pieces) {
          const token = String(piece.token ?? piece.label);
          if (remaining.startsWith(token)) { const result = build(remaining.slice(token.length), [...ids, piece.id]); if (result) return result; }
        }
        return null;
      };
      return { pieces: build(target) };
    }
  };
  return mappings[q.type]?.() ?? q.answer;
}

test("Decision banks cover every grade/module with evidence, a valid answer, and hints", () => {
  assert.equal(new Set(decisionQuestions.map(q => q.id)).size, decisionQuestions.length);
  for (const grade of ["entry", "middle", "high"]) for (const module of decisionModules) {
    assert.ok(decisionQuestions.some(q => q.gradeLevel === grade && q.module === module.id));
  }
  for (const q of decisionQuestions) {
    assert.ok(q.evidence.length && q.hint && q.explanation, q.id);
    assert.ok(q.options.some(option => option.id === q.correctOption), q.id);
  }
});

test("all Quant banks and all 12 interaction types accept their intended answers", () => {
  assert.equal(new Set(quantQuestions.map(q => q.type)).size, 12);
  for (const q of quantQuestions) {
    const answer = correctResponse(q);
    assert.equal(validateResponse(q, answer), null, `${q.id} validation`);
    assert.equal(isCorrectResponse(q, answer), true, `${q.id} correctness`);
    assert.ok(q.hint && q.explanation, q.id);
  }
});

test("Quant dragging interactions have tap/select/place alternatives", () => {
  for (const type of ["drag-drop", "matching", "categorize", "visual-label", "arrange-order"]) {
    const q = quantQuestions.find(q => q.type === type); let r = getInitialResponse(q);
    if (type === "drag-drop") for (const [targetId,itemId] of Object.entries(q.correctPlacements)) {
      r = applyInteractiveAction(q,r,{type:"select",itemId}); r = applyInteractiveAction(q,r,{type:"place",targetId});
    }
    if (type === "matching") for (const [leftId,rightId] of Object.entries(q.matches)) {
      r = applyInteractiveAction(q,r,{type:"select-left",leftId}); r = applyInteractiveAction(q,r,{type:"match",rightId});
    }
    if (type === "categorize") for (const [itemId,categoryId] of Object.entries(q.correctCategories)) {
      r = applyInteractiveAction(q,r,{type:"select",itemId}); r = applyInteractiveAction(q,r,{type:"place",categoryId});
    }
    if (type === "visual-label") for (const [targetId,labelId] of Object.entries(q.correctAssignments)) {
      r = applyInteractiveAction(q,r,{type:"select-label",labelId}); r = applyInteractiveAction(q,r,{type:"assign",targetId});
    }
    if (type === "arrange-order") {
      for (let index=0; index<q.correctOrder.length; index++) {
        const itemId=q.correctOrder[index];
        while (r.order.indexOf(itemId)>index) r=applyInteractiveAction(q,r,{type:"move",itemId,direction:-1});
      }
    }
    assert.equal(isCorrectResponse(q,r), true, type);
  }
});

test("all 15 Simulation stories complete, resume, and take a guided fallback branch", () => {
  assert.equal(simulationStories.length, 15);
  for (const story of simulationStories) {
    let state = createStoryState(story);
    state = submitStoryResponse(story,state,{noIdea:true});
    assert.equal(state.noIdeaCount, 1);
    assert.ok(state.messages.some(m => m.role === "coach"));
    for (let i=0; i<20 && !state.isComplete; i++) {
      const step = getCurrentStoryStep(story,state);
      const response = step.responseType === "written" ? step.acceptedPhrases[0] : step.correctAnswer;
      state = submitStoryResponse(story,state,{response});
      state = restoreStoryState(story,state);
    }
    assert.equal(state.isComplete, true, story.id);
    const coreCount = story.steps.filter(step => step.core !== false).length;
    const history = compactResponseHistory(state.messages, coreCount);
    assert.ok(history.length <= 12, story.id);
    assert.ok(history.filter(message => message.role === 'student').length >= coreCount, story.id);
  }
  assert.equal(evaluateStoryResponse({responseType:"numeric",correctAnswer:"5"},"5garbage"), false);
});

const repeat = (action, n) => Array.from({length:n}, () => action);
export const arcadeSolutions = {
  "balloon-pop": [["balloon-launch","balloon:0","balloon:2","balloon:4"], ["balloon-launch","balloon:0","balloon:2","balloon:4"], ["balloon-launch","balloon:1","balloon:2"]],
  "memory-match": state => [[...state.memory.cards.keys()].sort((a,b) => state.memory.cards[a].pairId - state.memory.cards[b].pairId).map(i=>`memory:${i}`)],
  "number-portal": [["portal-value:68","portal-target:match"],["portal-value:18","portal-target:match"],["portal-value:4","portal-target:match"]],
  "fruit-fractions": [5,4,7].map(n=>[...Array.from({length:n},(_,i)=>`fruit:${i}`),"fruit-check"]),
  "draw-the-line": [["line-plot:0:-1","line-plot:2:2","graph-check"],["line-plot:0:4","line-plot:2:1","graph-check"],["line-plot:0:-3","line-plot:2:2","graph-check"]],
  "algebra-circuit": [["circuit:10"],["circuit:13"],["circuit:18"]],
  "factor-forest": [["forest:composite"],["forest:12"],["forest:72"]],
  "ratio-builder": [[12,8],[9,15],[14,6]].map(([r,b])=>[...repeat("ratio:red:1",r),...repeat("ratio:blue:1",b),"ratio-check"]),
  "function-shift": [[...repeat("function-h:1",3),...repeat("function-k:-1",2),"function-a:-1","function-a:2","function-check"],[...repeat("function-h:-1",2),"function-k:1","function-a:0.5","function-check"],["function-h:1",...repeat("function-k:1",3),"function-a:-1","function-check"]],
  "trig-target": [["trig:36.2 m"],["trig:30° north of east"],["trig:618.8 m"]],
  "probability-lab": [["probability:$1.75"],["probability:1/15"],["probability:about 40"]],
  "optimization-challenge": [20,25,15].map(n=>[...repeat("optimization:1",n),"optimization-check"])
};
for (const game of arcadeGames) test(`Arcade ${game.title}: completes through its real input actions`, () => {
  const state = createGameState(game.id); let complete = false;
  assert.match(renderGameBoard(game,state), /button/);
  const solution = arcadeSolutions[game.id];
  for (const actions of typeof solution === "function" ? solution(state) : solution) for (const action of actions) {
    if (game.id === 'balloon-pop') state.balloon.elapsedMs = 8000;
    const outcome = evaluateGameAction(game,state,action);
    assert.notEqual(outcome.kind,"incorrect",`${game.id}: ${action}`);
    if (outcome.kind === "correct") { state.correctActions++; complete=outcome.complete; advanceGameState(game,state,outcome); }
  }
  assert.equal(complete,true);
  assert.ok(state.correctActions > 0);
});
