// Isolated test database only. Never connects to a Supabase project.
import { readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
const { PGlite } = await import(process.env.NUMORA_PGLITE_PATH || "@electric-sql/pglite");

export async function createFixture() {
  const db = new PGlite();
  await db.exec(`create role anon; create role authenticated; create schema auth;
    create table auth.users (id uuid primary key, raw_user_meta_data jsonb default '{}', email text);
    create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid$$;
    grant usage on schema auth to authenticated, anon;
    grant execute on function auth.uid() to authenticated, anon;`);
  for (const file of ["001_profiles.sql", "progress-schema.sql", "002_decision_lab_rewards.sql", "003_quant_lab_rewards.sql", "004_simulation_lab.sql", "005_simulation_security_hardening.sql", "006_arcade_state.sql", "007_dashboard_economy.sql", "008_weekly_leaderboard.sql", "009_weekly_reset.sql"]) {
    await db.exec(await readFile(new URL(`../supabase/${file}`, import.meta.url), "utf8"));
  }
  // Mimic ordinary Supabase read permissions; RLS must still isolate rows.
  await db.exec("grant select on public.profiles, public.daily_activity, public.student_stats, public.activity_events to authenticated");
  const scalar = async (sql, params = []) => Object.values((await db.query(sql, params)).rows[0])[0];
  const login = (id) => scalar("select set_config('request.jwt.claim.sub', $1, false)", [id || ""]);
  const student = async ({ first = "Test", last = "Student", zone = "UTC", id = randomUUID() } = {}) => {
    await db.query("insert into auth.users (id,raw_user_meta_data,email) values ($1,$2,$3)", [id, { first_name: first, last_name: last, grade_level: "high", timezone: zone }, `${id}@private.example`]);
    return id;
  };
  const addXp = (id, xp, date) => db.query(`insert into public.daily_activity (user_id,local_date,xp_earned)
    values ($1, coalesce($3::date, numora_private.local_day($1)), $2)
    on conflict (user_id,local_date) do update set xp_earned = excluded.xp_earned`, [id, xp, date ?? null]);
  const board = (limit = 10) => scalar("select public.get_weekly_leaderboard($1)", [limit]);
  return { db, scalar, login, student, addXp, board };
}
