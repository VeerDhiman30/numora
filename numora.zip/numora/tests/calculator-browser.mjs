// Real UI, isolated database/auth provider. Never changes the live project.
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { finalHarness } from './finalHarness.mjs';
const {db,uid,browser,page,base,calls,errors}=await finalHarness();
const artifacts=await mkdtemp(join(tmpdir(),'numora-calculator-'));
const mutations=()=>calls.filter(call=>['lose_arcade_life','record_activity_event','record_quant_activity_event'].includes(call.rpc)).length;
try {
  // Seven lives ensures the existing every-second Arcade render is exercised.
  await db.query('insert into public.arcade_state(user_id,lives,regeneration_started_at) values($1,7,now())',[uid]);
  await page.goto(`${base}/#/arcade`);
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.locator('[data-arcade-action="grade:high"]').click();
  await page.locator('[data-arcade-action="choose-game:trig-target"]').click();
  await page.locator('[data-arcade-action="start-game"]').click();
  const opener=page.getByRole('button',{name:'Open scientific calculator'});
  await opener.waitFor();
  assert.equal(await page.locator('.arcade-calculator-label svg').count(),1);
  await opener.focus();await page.keyboard.press('Enter');
  const dialog=page.getByRole('dialog',{name:'Scientific calculator'});
  const input=dialog.getByLabel('Your calculation');
  const result=dialog.locator('[data-calc-result]');
  assert.equal(await dialog.getByRole('button',{name:'DEG · Degrees',exact:true}).getAttribute('aria-pressed'),'true');
  const before=mutations();
  await input.fill('48 × ');
  await dialog.getByRole('button',{name:'Tangent',exact:true}).click();
  await dialog.getByRole('button',{name:'3',exact:true}).click();
  await dialog.getByRole('button',{name:'7',exact:true}).click();
  await dialog.getByRole('button',{name:'Close parenthesis',exact:true}).click();
  assert.equal(await input.inputValue(),'48 × tan(37)');
  await page.waitForTimeout(2200);
  assert.equal(await input.inputValue(),'48 × tan(37)');
  assert.equal(await input.evaluate(el=>el===document.activeElement),true);
  await page.keyboard.press('Enter');
  assert.match(await result.textContent(),/= 36\.170594/);
  await input.fill('asin(0.5)');await page.keyboard.press('Enter');assert.equal(await result.textContent(),'= 30');
  await dialog.getByRole('button',{name:'RAD · Radians',exact:true}).click();
  await input.fill('sin(pi/2)');await page.keyboard.press('Enter');assert.equal(await result.textContent(),'= 1');
  await dialog.getByRole('button',{name:'DEG · Degrees',exact:true}).click();
  await input.fill('1/0');await page.keyboard.press('Enter');assert.match(await result.textContent(),/divide by zero/);
  await dialog.getByRole('button',{name:'Clear calculation'}).click();
  await input.fill('250/tan(22)');await page.keyboard.press('Enter');assert.match(await result.textContent(),/= 618\.771713/);
  // Native modal traps focus; keyboard close returns to the current (re-rendered) opener.
  await dialog.getByRole('button',{name:'Close calculator'}).focus();
  for(let n=0;n<45;n++){await page.keyboard.press('Tab');assert.equal(await dialog.evaluate(el=>el.contains(document.activeElement)),true);}
  for(const width of [1440,768,390,320]) {
    await page.setViewportSize({width,height:844});
    await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    assert.equal(await page.locator('dialog[open]').count(),1);
    assert.equal(await dialog.evaluate(el=>el.scrollWidth<=el.clientWidth+1),true,`dialog overflow at ${width}`);
    assert.equal(await dialog.evaluate(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight+1}),true,`dialog bounds at ${width}`);
    assert.equal(await dialog.locator('button').evaluateAll(items=>items.every(el=>el.getBoundingClientRect().height>=44 && el.getBoundingClientRect().width>=44)),true);
    if(width===390||width===1440) {await dialog.evaluate(el=>{el.scrollTop=0});await page.screenshot({path:join(artifacts,`calculator-${width}.png`)});}
  }
  assert.equal(mutations(),before,'Calculator actions must not submit answers, spend lives, or award coins');
  await page.keyboard.press('Escape');
  await page.waitForFunction(()=>document.activeElement?.getAttribute('data-arcade-action')==='open-calculator');
  assert.equal(await opener.evaluate(el=>el===document.activeElement),true);
  await opener.click();assert.equal(await input.inputValue(),'250/tan(22)');
  await dialog.getByRole('button',{name:'Close calculator'}).click();
  await page.locator('[data-arcade-action="trig:36.2 m"]').click();
  await page.getByText('No calculator needed · use an exact trig ratio.').waitFor();
  assert.equal(await opener.count(),0);
  await page.locator('[data-arcade-action="trig:30° north of east"]').click();
  await opener.waitFor();await opener.click();
  // Route teardown removes the modal even when navigation happens outside its UI.
  await page.evaluate(()=>{location.hash='#/dashboard'});
  await page.locator('[data-summary]').waitFor();
  assert.equal(await page.locator('.scientific-calculator').count(),0);
  assert.deepEqual(errors,[]);
  console.log('Calculator browser checks passed: labels, keyboard/buttons, DEG/RAD, errors, live-timer persistence, focus trap/return, mobile sizing, no reward/life side effects, round gating and route cleanup.');
  console.log(`Screenshots: ${artifacts}`);
} catch(error) {
  await page.screenshot({path:join(artifacts,'failure.png'),fullPage:true});
  console.error({artifacts,errors});throw error;
} finally {await browser.close();await db.close();}
