import { test, before, beforeEach, after } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createFixture } from "./leaderboardFixture.mjs";
let db, scalar, login, student, addXp, board;
before(async () => { ({ db, scalar, login, student, addXp, board } = await createFixture()); });
beforeEach(async () => { await db.exec("truncate auth.users cascade"); });
after(async () => { await db?.close(); });

test("no fabricated students or ranks: only active real profiles, zero-XP self is unranked", async () => {
  const own = await student();
  await login(own);
  assert.deepEqual((await board()).entries, []);
  assert.deepEqual((await board()).current_student, { display_name: "Test Student", weekly_xp: 0, rank: null, is_current_user: true });
  await student({ first: "Inactive" });
  const active = await student({ first: "Real", last: "Full Last Name" });
  await addXp(active, 1);
  const data = await board();
  assert.equal(data.entries.length, 1);
  assert.equal(data.entries[0].display_name, "Real Full Last Name");
  assert.equal(data.entries[0].is_current_user, false);
  assert.equal(data.current_student.rank, null);
});

test("shared Monday-through-today date window matches Dashboard; prior/future days excluded", async () => {
  const own = await student({ zone: "America/New_York" });
  const other = await student({ zone: "Pacific/Kiritimati" });
  await login(own);
  const { week_start: monday, through_date: today } = await board();
  const before = await scalar("select ($1::date - 1)::text", [monday]);
  const future = await scalar("select ($1::date + 1)::text", [today]);
  for (const id of [own, other]) {
    await addXp(id, 999, before);
    await addXp(id, 12, monday);
    await addXp(id, 33, today);
    await addXp(id, 888, future);
  }
  const expected = monday === today ? 33 : 45;
  const result = await board();
  assert.equal(result.current_student.weekly_xp, expected);
  assert.ok(result.entries.every(row => row.weekly_xp === expected));
  assert.equal(await scalar("select public.get_my_weekly_xp()"), expected);
  assert.equal((await scalar("select public.get_my_economy_snapshot()")).weekly_xp, expected);
  assert.equal(result.week_start, monday);
  assert.equal(result.through_date, today);
});

test("calendar helper handles Sunday/Monday and DST without a browser clock", async () => {
  const own = await student({ zone: "America/New_York" });
  for (const [instant, start, end] of [
    ["2026-10-12T03:59:00Z", "2026-10-05", "2026-10-11"],
    ["2026-10-12T04:00:00Z", "2026-10-12", "2026-10-12"],
    ["2026-03-08T07:01:00Z", "2026-03-02", "2026-03-08"],
    ["2026-11-01T06:01:00Z", "2026-10-26", "2026-11-01"]
  ]) {
    const period = await scalar("select to_jsonb(w) from numora_private.weekly_window($1,$2) w", [own, instant]);
    assert.equal(period.week_start, start);
    assert.equal(period.through_date, end);
  }
});

test("all four XP sources count once, while Arcade coins and duplicate rewards do not", async () => {
  const own = await student();
  await login(own);
  const quant = () => scalar("select to_jsonb(r) from public.record_quant_activity_event('quant:weekly:correct','algebra','correct_answer','{\"grade_level\":\"high\"}') r");
  const decision = () => scalar("select to_jsonb(r) from public.record_activity_event('decision:weekly:question:correct','decision','weather','correct_answer','{\"grade_level\":\"high\"}') r");
  await quant(); await quant();
  await decision(); await decision();
  await db.query("insert into public.simulation_progress (user_id,story_id,grade_level,current_step,response_history) values ($1,'entry-snack-budget','entry',5,$2)", [own, Array.from({ length: 5 }, () => ({ role: "student", content: "Answer" }))]);
  const simulation = () => scalar("select to_jsonb(r) from public.record_activity_event('simulation:entry-snack-budget:completed','simulation','entry-snack-budget','story_completed','{\"grade_level\":\"entry\",\"story_id\":\"entry-snack-budget\"}') r");
  await simulation(); await simulation();
  const item = await scalar("select public.get_my_daily_challenge('high')");
  const answer = await scalar("select answer from numora_private.challenge_bank where id=$1", [item.id]);
  const submit = () => scalar("select public.submit_daily_challenge('high',$1,$2,$3)", [item.id, item.local_date, answer]);
  await submit(); await submit();
  assert.equal((await board()).current_student.weekly_xp, 36);
  const arcade = () => scalar("select to_jsonb(r) from public.record_activity_event('arcade:weekly:session:round:correct','arcade','optimization-challenge','arcade_correct') r");
  await arcade(); await arcade();
  assert.equal((await board()).current_student.weekly_xp, 36);
  const snapshot = await scalar("select public.get_my_economy_snapshot()");
  assert.equal(snapshot.weekly_xp, 36);
  assert.equal(snapshot.stats.coin_balance, 21);
});

test("Top 10 plus current rank below cutoff; bounded limits and deterministic name/ID ties", async () => {
  const own = await student({ first: "Zoe", last: "Outside" });
  await login(own);
  await addXp(own, 10);
  const ids = [];
  for (let i = 0; i < 12; i++) {
    const id = await student({ first: i < 2 ? "Same" : `Student ${String(i).padStart(2, "0")}`, last: "Name" });
    ids.push(id);
    await addXp(id, 100);
  }
  const a = await board();
  assert.equal(a.entries.length, 10);
  assert.equal(a.current_student.rank, 13);
  assert.equal(a.current_student.is_current_user, true);
  assert.equal(a.entries.filter(row => row.is_current_user).length, 0);
  assert.deepEqual(await board(), a);
  assert.deepEqual(a.entries.map(row => row.rank), [1,2,3,4,5,6,7,8,9,10]);
  assert.equal(a.entries[0].display_name, "Same Name");
  for (const id of ids.slice(0, 2)) {
    await login(id);
    assert.equal((await board()).current_student.rank, [...ids.slice(0,2)].sort().indexOf(id) + 1);
  }
  await login(own);
  assert.equal((await board(0)).entries.length, 1);
  assert.equal((await board(-10)).limit, 1);
  assert.equal((await board(999999)).limit, 50);
  assert.equal((await board(null)).limit, 10);
});

test("RPC returns only safe fields; own-row RLS and private helpers remain protected", async () => {
  const own = await student({ first: "Own", last: "Name" });
  const other = await student({ first: "Other", last: "Person" });
  await addXp(other, 10); await addXp(own, 5); await login(own);
  await db.exec("set role authenticated");
  try {
    const data = await board();
    assert.deepEqual(Object.keys(data).sort(), ["current_student", "entries", "limit", "through_date", "timezone", "week_start"]);
    for (const row of [...data.entries, data.current_student]) {
      assert.deepEqual(Object.keys(row).sort(), ["display_name", "is_current_user", "rank", "weekly_xp"]);
    }
    assert.ok(!JSON.stringify(data).includes(own) && !JSON.stringify(data).includes(other));
    assert.ok(!JSON.stringify(data).includes("@private.example"));
    assert.equal(await scalar("select count(*)::int from public.profiles"), 1);
    assert.equal(await scalar("select count(*)::int from public.daily_activity where user_id=$1", [other]), 0);
    assert.equal(await scalar("select public.get_my_weekly_xp()"), 5);
    await assert.rejects(db.exec("select * from numora_private.weekly_window(auth.uid())"), /permission denied/);
    await assert.rejects(db.exec("update public.daily_activity set xp_earned=999999"), /permission denied/);
  } finally { await db.exec("reset role"); }
  await db.exec("set role anon");
  try { await assert.rejects(board(), /permission denied/); }
  finally { await db.exec("reset role"); }
  await login(null);
  await assert.rejects(board(), /Authentication/);
  await login("00000000-0000-0000-0000-000000000099");
  await assert.rejects(board(), /profile/);
});

test("repeat migration preserves totals and both setup checks report missing zero", async () => {
  const own = await student(); await login(own); await addXp(own, 75);
  const before = await board();
  await db.exec(await readFile(new URL("../supabase/008_weekly_leaderboard.sql", import.meta.url), "utf8"));
  assert.deepEqual(await board(), before);
  for (const file of ["007_verify_dashboard.sql", "008_verify_leaderboard.sql"]) {
    const check = (await db.query(await readFile(new URL(`../supabase/${file}`, import.meta.url), "utf8"))).rows[0];
    assert.equal(check.missing, 0, check.failed_checks.join(", "));
  }
});
