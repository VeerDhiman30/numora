import assert from 'node:assert/strict';
import {mkdtemp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {finalHarness} from './finalHarness.mjs';
import {highDecisionQuestions} from '../scripts/data/decision/high.js';

const {db,uid,browser,page,base,errors}=await finalHarness();
const artifacts=await mkdtemp(join(tmpdir(),'numora-decision-high-'));
const key=`numora:decision-session:v1:${uid}`;
async function seed(q,activityId,contentVersion=2) {
  await page.evaluate(({key,q,activityId,contentVersion})=>sessionStorage.setItem(key,JSON.stringify({
    version:1, contentVersion, activityId, gradeLevel:'high', module:q.module,
    queue:Array(10).fill(q.id), position:0, questionId:q.id, selectedOption:null,
    isChecked:false, hintVisible:false, sessionComplete:false, checkedPositions:[],completedAnswerKeys:[],purchasedHintKeys:[],
    summary:{decisionsCompleted:0,correctDecisions:0,xpEarned:0,topics:[]}
  })),{key,q,activityId,contentVersion});
  await page.reload();
  await page.locator('input[name="decision-choice"]').first().waitFor();
}
try {
  await db.query('update public.student_stats set coin_balance=20 where user_id=$1',[uid]);
  await page.goto(`${base}/#/decision`);
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.locator('input[name="decision-choice"]').first().waitFor();
  // Previous high-school answer sessions must not attach to rewritten content.
  await seed(highDecisionQuestions[0],'obsolete-high-bank',1);
  assert.notEqual(await page.evaluate(key=>JSON.parse(sessionStorage.getItem(key)).activityId,key),'obsolete-high-bank');
  for(const [index,q] of highDecisionQuestions.entries()) {
    await seed(q,`high-content-test-${index}`);
    assert.equal(await page.locator('#decision-scenario-title').innerText(),q.title);
    assert.equal(await page.locator('.decision-assumptions li').count(),2);
    assert.equal(await page.locator('.decision-task-label').textContent(),'Your task');
    assert.equal(await page.locator('input[name="decision-choice"]').count(),4);
    assert.equal(await page.locator('.decision-solution-steps').count(),0);
    if(index===0) {
      await page.locator('[data-decision-hint]').click();
      await page.locator('.decision-hint').waitFor();
      assert.match(await page.locator('.decision-hint').innerText(),/two-point strategy/);
    }
    if([8,14,17].includes(index)) {
      for(const width of [1440,390,320]) {
        await page.setViewportSize({width,height:900});
        await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`${q.id} overflow ${width}`);
        if(width!==320) {
          await page.locator('#app-header').evaluate(el=>{el.style.visibility='hidden'});
          await page.locator('.decision-lab__workspace').screenshot({path:join(artifacts,`${q.id}-${width}.png`)});
          await page.locator('#app-header').evaluate(el=>{el.style.visibility=''});
        }
        if(index===14 && width===390) {
          const table=page.getByRole('region',{name:/scrollable data table/});
          assert.equal(await table.evaluate(el=>el.scrollWidth>el.clientWidth),true);
          await table.focus(); await page.keyboard.press('End');
          await table.evaluate(el=>{el.scrollLeft=el.scrollWidth});
          assert.equal(await table.evaluate(el=>el.scrollLeft>0),true);
        }
      }
      await page.setViewportSize({width:1440,height:1000});
    }
    await page.locator(`input[name="decision-choice"][value="${q.correctOption}"]`).check();
    await page.getByRole('button',{name:'Check Decision',exact:true}).click();
    await page.locator('.decision-feedback--correct').waitFor();
    assert.equal(await page.locator('.decision-solution-steps li').count(),3);
    assert.equal(await page.locator('.decision-solution-steps li').first().innerText(),q.solutionSteps[0]);
  }
  const stats=(await db.query('select total_xp,coin_balance from public.student_stats where user_id=$1',[uid])).rows[0];
  assert.equal(stats.total_xp,100); assert.equal(stats.coin_balance,10);
  await page.reload(); await page.locator('.decision-feedback--correct').waitFor();
  assert.equal((await db.query('select total_xp from public.student_stats where user_id=$1',[uid])).rows[0].total_xp,100);
  await page.locator('[data-decision-grade="middle"]').click();
  assert.equal(await page.locator('.decision-assumptions').count(),0);
  assert.equal(await page.locator('.decision-choice__copy small').count()>0,true);
  assert.deepEqual(errors,[]);
  console.log('Decision browser checks passed: all 20 questions, four options, rules/task labels, hints, worked feedback, 100 XP total, reload safety, old-session reset, unchanged middle-school format, and responsive tables.');
  console.log('Screenshots:',artifacts);
} catch(error) {await page.screenshot({path:join(artifacts,'failure.png'),fullPage:true});console.error(artifacts);throw error;}
finally {await browser.close();await db.close();}
