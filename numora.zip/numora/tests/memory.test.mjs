import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createGameState, evaluateGameAction, getArcadeGame} from '../scripts/arcade/games.js';
import {createMemoryBoard, evaluateMemoryAction, resetMemoryBoard, settleMemoryMismatch, renderMemoryBoard, MEMORY_FLIP_LIMIT, MEMORY_REVEAL_MS} from '../scripts/arcade/memoryGame.js';

const fresh = () => createGameState('memory-match');
const groups = state => [...new Set(state.memory.cards.map(c=>c.pairId))].map(id=>state.memory.cards.flatMap((card,i)=>card.pairId===id?[i]:[]));
const flip = (state,index) => evaluateMemoryAction(state,`memory:${index}`,1000);
function mismatch(state, a, b) {
  assert.equal(flip(state,a).kind,'select');
  assert.equal(flip(state,b).kind,'memory-mismatch');
  assert.equal(settleMemoryMismatch(state,1000+MEMORY_REVEAL_MS),true);
}

test('boards contain six unique cards, three equivalent pairs, and shuffled positions',()=>{
  const signatures = new Set();
  for (let i=0; i<100; i++) {
    const state=fresh(), board=state.memory;
    assert.equal(board.cards.length,6); assert.equal(new Set(board.cards.map(c=>c.label)).size,6);
    assert.ok(groups(state).every(pair=>pair.length===2)); assert.equal(groups(state).length,3);
    assert.equal(board.flips,0); assert.equal(board.status,'playing');
    signatures.add(board.cards.map(c=>c.pairId).join(','));
  }
  assert.ok(signatures.size>1);
  // Validate every generated representation, including fractions and money.
  const numeric = label => {
    if (label.startsWith('$')) return Number(label.slice(1));
    if (label.endsWith('¢')) return Number(label.slice(0,-1))/100;
    if (label.includes('/')) {const [a,b]=label.split('/').map(Number);return a/b;}
    if (label.includes('×')) return label.split('×').map(Number).reduce((a,b)=>a*b);
    if (label.includes('÷')) {const [a,b]=label.split('÷').map(Number);return a/b;}
    return Number(label);
  };
  for (let i=0; i<100; i++) {
    const state=fresh();
    for (const [a,b] of groups(state)) assert.equal(numeric(state.memory.cards[a].label),numeric(state.memory.cards[b].label));
    assert.equal(new Set(groups(state).map(([a])=>numeric(state.memory.cards[a].label))).size,3);
  }
});

test('each individual flip costs a try; repeated, matched, and invalid cards do not',()=>{
  const state=fresh(), [pair]=groups(state);
  assert.equal(evaluateGameAction(getArcadeGame('memory-match'),state,`memory:${pair[0]}`).kind,'select');
  assert.equal(state.memory.flips,1);
  assert.equal(flip(state,pair[0]).kind,'none');
  for(const action of ['memory:-1','memory:6','memory:NaN','memory:','memory:1.5','memory:00']) assert.equal(evaluateMemoryAction(state,action).kind,'none');
  assert.equal(state.memory.flips,1);
  assert.equal(flip(state,pair[1]).kind,'correct');
  assert.equal(state.memory.flips,2);
  assert.equal(flip(state,pair[0]).kind,'none');
  assert.equal(state.moves,2);
});

test('mismatches reveal briefly and lock other flips without emitting a life-loss action',()=>{
  const state=fresh(), [a,b,c]=groups(state);
  flip(state,a[0]); const outcome=flip(state,b[0]);
  assert.equal(outcome.kind,'memory-mismatch'); assert.equal(state.memory.flips,2);
  assert.equal(flip(state,c[0]).kind,'none'); assert.equal(state.selected.length,2);
  assert.equal(settleMemoryMismatch(state,1999),false);
  assert.equal(settleMemoryMismatch(state,2000),true);
  assert.equal(state.memory.status,'playing'); assert.deepEqual(state.selected,[]);
  assert.equal(state.memory.flips,2);
});

test('the board fails only after eight flips, and no ninth flip can be made',()=>{
  const state=fresh(), [a,b]=groups(state);
  for(let i=0;i<4;i++) {
    mismatch(state,a[0],b[0]);
    assert.equal(state.memory.status,i<3?'playing':'failed');
  }
  assert.equal(state.memory.flips,MEMORY_FLIP_LIMIT);
  assert.equal(flip(state,a[1]).kind,'none');
  assert.equal(settleMemoryMismatch(state,3000),false);
});

test('clearing on flip eight wins, while an incomplete match on flip eight fails',()=>{
  const win=fresh(), pairs=groups(win);
  mismatch(win,pairs[0][0],pairs[1][0]);
  let outcome;
  for(const pair of pairs) for(const index of pair) outcome=flip(win,index);
  assert.equal(win.memory.flips,8); assert.equal(outcome.complete,true); assert.equal(win.memory.status,'complete');
  const fail=fresh(), [a,b]=groups(fail);
  for(let i=0;i<3;i++) mismatch(fail,a[0],b[0]);
  flip(fail,a[0]); outcome=flip(fail,a[1]);
  assert.equal(outcome.kind,'correct'); assert.equal(outcome.complete,false); assert.equal(fail.memory.status,'failed');
});

test('failed boards refresh with all-new values, eight tries and distinct reward keys',()=>{
  const state=fresh(); let oldKey;
  for(let i=0;i<30;i++) {
    const [pair]=groups(state);flip(state,pair[0]); const outcome=flip(state,pair[1]);
    assert.notEqual(outcome.actionId,oldKey);oldKey=outcome.actionId;
    state.correctActions++;
    const labels=new Set(state.memory.cards.map(c=>c.label)), previousRound=state.round;
    resetMemoryBoard(state);
    assert.ok(state.memory.cards.every(c=>!labels.has(c.label)));
    assert.equal(state.round,previousRound+1);assert.equal(state.memory.flips,0);
    assert.deepEqual(state.matched,[]);assert.deepEqual(state.selected,[]);
    assert.equal(state.correctActions,i+1);
  }
  const [pair]=groups(state);flip(state,pair[0]);
  assert.equal(flip(state,pair[1]).complete,false,'previous boards cannot complete the new board');
});

test('JSON session restoration preserves flips, card order and mismatch deadline',()=>{
  let state=fresh(); const [a,b]=groups(state);
  mismatch(state,a[0],b[0]);flip(state,a[0]);flip(state,b[0]);
  const before=structuredClone(state);state=JSON.parse(JSON.stringify(state));
  assert.deepEqual(state,before);assert.equal(state.memory.flips,4);
  settleMemoryMismatch(state,3000);assert.equal(state.memory.flips,4);assert.equal(state.memory.status,'playing');
});

test('rendering exposes flip budget and accessible card positions without hidden answers',()=>{
  const state=fresh();state.memory=createMemoryBoard([],()=>0.5);
  const html=renderMemoryBoard(state);
  assert.match(html,/data-memory-flips>8</);assert.match(html,/Card 1, face down/);
  assert.match(html,/Every card flip uses one try/);assert.doesNotMatch(html,/data-pair-ids/);
  for(const card of state.memory.cards) assert.ok(!html.includes(`>${card.label}</button>`));
});
