import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateExpression as evaluate, formatCalculatorResult } from '../scripts/arcade/calculatorMath.js';
import { getArcadeGame, createGameState, isCalculatorRound, renderGameBoard } from '../scripts/arcade/games.js';
const near = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-10, `${actual} != ${expected}`);
test('degree-mode trig and both calculator word problems', () => {
  near(evaluate('sin(30)'), .5); near(evaluate('cos(60)'), .5); near(evaluate('tan(45)'), 1);
  assert.equal(evaluate('48 × tan(37°)').toFixed(1), '36.2');
  assert.equal(evaluate('250 ÷ tan(22)').toFixed(1), '618.8');
});
test('inverse trig gives degrees and supports the boat setup', () => {
  near(evaluate('asin(0.5)'), 30); near(evaluate('acos(0.5)'), 60);
  near(evaluate('atan(10/(10√(3)))'), 30);
});
test('radian mode is explicit and cannot silently discard a degree symbol', () => {
  near(evaluate('sin(pi/2)', {mode:'RAD'}), 1);
  near(evaluate('atan(1)', {mode:'RAD'}), Math.PI / 4);
  assert.throws(() => evaluate('tan(45°)', {mode:'RAD'}), /Switch to degrees/);
});
test('operator precedence, negative powers and right-associated exponentiation', () => {
  for (const [input,expected] of [['2+3*4',14],['(2+3)*4',20],['-2^2',-4],['(-2)^2',4],['2^-2',.25],['2^3^2',512],['12/3*2',8]]) assert.equal(evaluate(input),expected,input);
});
test('scientific notation, constants, implicit multiplication, roots, logs and factorial', () => {
  near(evaluate('2π'), 2*Math.PI); assert.equal(evaluate('2(3+4)'),14);
  assert.equal(evaluate('1e3 + .5'),1000.5); assert.equal(evaluate('(2)(3)'),6);
  assert.equal(evaluate('√(81)+3²+abs(-2)'),20); near(evaluate('ln(e)+log(100)'),3);
  assert.equal(evaluate('5!'),120); assert.equal(evaluate('0!'),1);
  assert.equal(evaluate('200*10%'),20);
});
test('Ans retains precision and display rounds separately', () => {
  const answer=evaluate('1/3'); assert.equal(evaluate('Ans*3',{answer}),1);
  assert.equal(formatCalculatorResult(answer),'0.333333333333');
  assert.equal(formatCalculatorResult(evaluate('-0')),'0');
});
test('invalid real domains, zero division and overflow return understandable errors', () => {
  for(const input of ['1/0','0/0','sqrt(-1)','log(0)','ln(-1)','asin(2)','acos(-2)','tan(90)','tan(270)','171!','(-1)!','2.5!','10^400']) assert.throws(()=>evaluate(input),Error,input);
});
test('malformed expressions and executable input are rejected without evaluation', () => {
  for(const input of ['', '1 2', 'sin30', 'sin()', '(1+2', '1+2)', '2+', 'sqrt(2))', 'globalThis.alert(1)', '1;alert(1)', 'constructor(1)', '[1]', '1**2', '2=2', '"hi"']) assert.throws(()=>evaluate(input),Error,input);
});
test('input and nesting are bounded', () => {
  assert.throws(()=>evaluate('1'.repeat(257)), /256/);
  assert.throws(()=>evaluate('('.repeat(65)+'1'+')'.repeat(65)), /nested/);
});
test('only calculator-designated Trig Target rounds show the tool', () => {
  const game=getArcadeGame('trig-target'), state=createGameState(game.id);
  for(const [round,enabled] of [[0,true],[1,false],[2,true]]) {
    state.round=round; assert.equal(isCalculatorRound(game.id,state),enabled);
    assert.equal(renderGameBoard(game,state).includes('data-arcade-action="open-calculator"'),enabled);
    assert.ok(renderGameBoard(game,state).includes(enabled?'Calculator question':'No calculator needed'));
  }
  assert.equal(isCalculatorRound('function-shift',state),false);
});
