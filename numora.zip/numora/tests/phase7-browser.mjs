// Optional browser integration check against an isolated DB and mocked auth.
// Run with NUMORA_PGLITE_PATH, NUMORA_PLAYWRIGHT_PATH, and Numora on port 3001.
import assert from "node:assert/strict";
import { readFile, mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
const { PGlite } = await import(process.env.NUMORA_PGLITE_PATH || "@electric-sql/pglite");
const { chromium } = await import(process.env.NUMORA_PLAYWRIGHT_PATH || "playwright");
const db = new PGlite();
const uid = '00000000-0000-0000-0000-000000000007';
const base = process.env.NUMORA_TEST_ORIGIN || 'http://localhost:3001';
const artifacts = process.env.NUMORA_TEST_ARTIFACTS || await mkdtemp(join(tmpdir(), 'numora-dashboard-'));
await db.exec(`create role anon; create role authenticated; create schema auth;
  create table auth.users (id uuid primary key, raw_user_meta_data jsonb default '{}');
  create function auth.uid() returns uuid language sql stable as $$select '${uid}'::uuid$$;
  grant usage on schema auth to authenticated;
  grant execute on function auth.uid() to authenticated;`);
for (const file of ["001_profiles.sql", "progress-schema.sql", "002_decision_lab_rewards.sql", "003_quant_lab_rewards.sql", "004_simulation_lab.sql", "005_simulation_security_hardening.sql", "006_arcade_state.sql", "007_dashboard_economy.sql", "008_weekly_leaderboard.sql", "009_weekly_reset.sql"]) {
  await db.exec(await readFile(new URL(`../supabase/${file}`, import.meta.url), 'utf8'));
}
await db.exec(`insert into auth.users values ('${uid}', '{"first_name":"Alex","grade_level":"high","timezone":"America/New_York"}');
  update public.student_stats set coin_balance = 240, total_xp = 155 where user_id = '${uid}';
  insert into public.daily_activity (user_id,local_date,xp_earned) values
    ('${uid}',numora_private.local_day('${uid}')-3,50), ('${uid}',numora_private.local_day('${uid}')-2,70), ('${uid}',numora_private.local_day('${uid}'),35);
  insert into public.module_progress (user_id,module,grade_level,topic,completed_count,correct_count,attempt_count)
    values ('${uid}','quant','high','algebra',12,9,12), ('${uid}','decision','high','weather',5,4,5);
  insert into public.simulation_progress (user_id,story_id,grade_level,current_step) values ('${uid}','high-laptop-comparison','high',2);`);

const browser = await chromium.launch({ headless: true, channel: "chrome" });
const page = await browser.newPage({ viewport: { width: 1365, height: 1050 } });
page.setDefaultTimeout(15000);
const errors = [];
page.on('pageerror', error => errors.push(error.message));
let failChallenges = false;
let failSnapshot = false;
let failArcadeResponseOnce = false;
const rpcArgs = {
  get_my_economy_snapshot: [], get_my_daily_challenge: ['p_grade_level'],
  submit_daily_challenge: ['p_grade_level','p_challenge_id','p_local_date','p_answer'],
  repair_my_streak: ['p_missed_date'], get_my_today_activity: [], get_my_weekly_xp: [],
  record_activity_event: ['p_event_key','p_module','p_topic','p_activity_type','p_metadata'],
  record_quant_activity_event: ['p_event_key','p_topic','p_activity_type','p_metadata'],
  get_my_arcade_state: [], lose_arcade_life: ['p_event_key']
};
await page.route('**/scripts/services/authService.js', route => route.fulfill({ contentType: 'text/javascript', body: `
  import { setAuthenticatedUser, setLoggedOut } from './appState.js';
  import { refreshStudentProgress } from './progressService.js';
  export class FriendlyAuthError extends Error {}
  export async function initializeAuthentication() { setAuthenticatedUser({id:'${uid}',firstName:'Alex',gradeLevel:'high',timezone:'America/New_York'}); await refreshStudentProgress(); }
  export async function signOut() { setLoggedOut(); }
  export const signUp = async () => ({}), signIn = async () => {}, sendPasswordRecovery = async () => {}, updatePassword = async () => {};
` }));
await page.route('**/scripts/services/supabase.js', route => route.fulfill({ contentType: 'text/javascript', body: `
  const call = (body) => fetch('/__phase7_test', {method:'POST',body:JSON.stringify(body)}).then(r=>r.json());
  export async function getSupabaseClient() { return {
    rpc: (name,args={}) => call({rpc:name,args}),
    from: (table) => { const options={table}; const query={select(){return query},eq(k,v){options.filter=[k,v];return query},order(){return query},limit(n){options.limit=n;return query},maybeSingle(){options.single=true;return query},then(resolve,reject){return call(options).then(resolve,reject)}}; return query; }
  }; }
` }));
await page.route('**/__phase7_test', async route => {
  try {
    const body = JSON.parse(route.request().postData());
    let data;
    if (body.rpc) {
      const args = rpcArgs[body.rpc];
      assert.ok(args, `Unknown RPC ${body.rpc}`);
      if ((body.rpc === 'get_my_daily_challenge' && failChallenges) || (body.rpc === 'get_my_economy_snapshot' && failSnapshot)) throw new Error('Simulated offline failure');
      const rows = (await db.query(`select to_jsonb(r) as wire from public.${body.rpc}(${args.map((_,i) => '$'+(i+1)).join(',')}) r`, args.map(key => body.args[key] ?? null))).rows.map(row => row.wire);
      const scalarRpc = ['get_my_economy_snapshot','get_my_weekly_xp','get_my_daily_challenge','submit_daily_challenge','repair_my_streak'].includes(body.rpc);
      data = rows[0]?.[body.rpc] ?? (scalarRpc ? rows[0] : rows);
      if (body.rpc === 'record_activity_event' && body.args.p_module === 'arcade' && failArcadeResponseOnce) {
        failArcadeResponseOnce = false;
        throw new Error('Response lost AFTER commit');
      }
    } else {
      assert.ok(['module_progress','activity_events','simulation_progress','student_stats'].includes(body.table));
      data = (await db.query(`select * from public.${body.table} where user_id = $1`, [uid])).rows;
      if (body.limit) data = data.slice(0, body.limit);
      if (body.single) data = data[0] ?? null;
    }
    await route.fulfill({ json: { data, error: null } });
  } catch (error) { await route.fulfill({ json: { data: null, error: { message: error.message } } }); }
});
try {
  await page.goto(`${base}/#/dashboard`);
  await page.getByRole('heading', {name:'Welcome back, Alex'}).waitFor();
  await page.locator('[data-challenge-form]').waitFor();
  assert.equal(await page.locator('.dashboard-module').count(), 3);
  assert.match(await page.locator('[data-summary]').innerText(), /35/);
  await page.getByRole('button',{name:'View topics'}).first().focus();
  await page.keyboard.press('Enter');
  assert.equal(await page.locator('[data-module="decision"]').getAttribute('aria-expanded'), 'true');
  assert.equal(await page.locator('#topics-decision').isVisible(), true);
  const originalQuestion = await page.locator('legend').innerText();
  await page.reload();
  await page.locator('legend').waitFor();
  assert.equal(await page.locator('legend').innerText(), originalQuestion);
  for (const level of ['entry','middle','high']) {
    await page.locator('[data-challenge-grade]').selectOption(level);
    await page.locator('legend').waitFor();
  }
  const item = (await db.query("select public.get_my_daily_challenge('high') as q")).rows[0].q;
  const answer = (await db.query('select answer from numora_private.challenge_bank where id=$1',[item.id])).rows[0].answer;
  const wrong = item.options.find(option => option !== answer);
  await page.getByRole('radio', {name:wrong,exact:true}).check();
  await page.getByRole('button',{name:'Check answer',exact:true}).click();
  await page.waitForFunction(() => document.querySelector('.dashboard-feedback')?.textContent.length > 10);
  assert.equal((await db.query(`select coin_balance from public.student_stats where user_id='${uid}'`)).rows[0].coin_balance, 240);
  await page.getByRole('radio', {name:answer,exact:true}).check();
  await page.getByRole('button',{name:'Check answer',exact:true}).click();
  await page.getByRole('heading',{name:'Daily Challenge complete ✓'}).waitFor();
  await page.waitForFunction(() => document.querySelector('[data-wallet] h2')?.textContent.includes('260'));
  assert.match(await page.locator('[data-streak]').innerText(), /Today's streak secured/);
  await page.locator('[data-challenge-grade]').selectOption('entry');
  await page.getByRole('heading',{name:'Daily Challenge complete ✓'}).waitFor();
  assert.equal(await page.locator('[data-challenge-form]').count(), 0);
  await page.getByRole('button',{name:/Repair streak/}).click();
  assert.equal(await page.locator('dialog').isVisible(), true);
  await page.keyboard.press('Escape');
  await page.locator('dialog').waitFor({state:'detached'});
  assert.equal(await page.locator('[data-dashboard="repair"]').evaluate(node => node === document.activeElement), true);
  await page.getByRole('button',{name:/Repair streak/}).click();
  await page.getByRole('button',{name:'Repair for 200 coins',exact:true}).click();
  await page.waitForFunction(() => /\b60 coins\b/.test(document.querySelector('[data-wallet] h2')?.textContent));
  assert.match(await page.locator('[data-streak] h2').innerText(), /4 day streak/);
  assert.match(await page.locator('.header-rewards').innerText(), /60/);
  await page.screenshot({path: join(artifacts, 'dashboard-desktop.png'), fullPage: true});
  await page.reload();
  await page.getByRole('heading', {name:'Welcome back, Alex'}).waitFor();
  assert.equal(await page.locator('.reward-toast--celebration').count(), 0);
  await page.setViewportSize({width:390,height:844});
  await page.emulateMedia({reducedMotion:'reduce'});
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.screenshot({path: join(artifacts, 'dashboard-mobile.png'), fullPage: true});
  failChallenges = true;
  await page.locator('[data-challenge-grade]').selectOption('middle');
  await page.getByRole('button',{name:'Try again',exact:true}).waitFor();
  failChallenges = false;
  await page.getByRole('button',{name:'Try again',exact:true}).click();
  await page.getByRole('heading',{name:'Daily Challenge complete ✓'}).waitFor();
  failSnapshot = true;
  await page.reload();
  await page.getByRole('heading',{name:'We couldn’t load your progress'}).waitFor();
  failSnapshot = false;
  await page.getByRole('button',{name:'Try again',exact:true}).click();
  await page.getByRole('heading', {name:'Welcome back, Alex'}).waitFor();
  await page.setViewportSize({width:1365,height:1050});
  assert.equal((await page.request.get(`${base}/supabase/007_dashboard_economy.sql`)).status(), 400);
  assert.equal((await page.request.get(`${base}/tests/phase7-browser.mjs`)).status(), 400);
  await page.evaluate(() => { window.location.hash = '#/arcade'; });
  await page.locator('[data-arcade-action="choose-game:optimization-challenge"]').click();
  await page.locator('[data-arcade-action="start-game"]').click();
  for (let index = 0; index < 20; index++) await page.locator('[data-arcade-action="optimization:1"]').click();
  failArcadeResponseOnce = true;
  await page.locator('[data-arcade-action="optimization-check"]').click();
  await page.waitForFunction(() => document.querySelector('.arcade-feedback--error'));
  await page.reload();
  await page.locator('[data-arcade-action="retry-reward"]').click();
  await page.waitForFunction(() => document.querySelector('.arcade-game__progress')?.textContent.startsWith('1 correct'));
  assert.equal((await db.query(`select coin_balance from public.student_stats where user_id='${uid}'`)).rows[0].coin_balance, 61);
  assert.equal((await db.query(`select count(*)::int as n from public.activity_events where user_id='${uid}' and module='arcade'`)).rows[0].n, 1);
  await page.evaluate(() => { window.location.hash = '#/dashboard'; });
  await page.getByRole('heading', {name:'Welcome back, Alex'}).waitFor();
  assert.match(await page.locator('[data-wallet] h2').innerText(), /61 coins/);
  await page.getByRole('button',{name:'Open account menu for Alex'}).click();
  await page.getByRole('menuitem',{name:'Sign Out',exact:true}).click();
  await page.locator('.header-rewards').waitFor({state:'detached'});
  assert.equal(await page.locator('[data-wallet]').count(), 0);
  assert.equal(errors.length, 0, errors.join('\n'));
  console.log('Dashboard browser checks passed: question stability, keyboard expansion, difficulty changes, wrong/correct answers, wallet/streak/header updates, repair dialog, no repeat celebration, errors/retries, mobile overflow, sign-out, private SQL protection, and Arcade lost-response retry after refresh without duplicate coins.');
  console.log(`Screenshots: ${artifacts}`);
} finally { await browser.close(); await db.close(); }
