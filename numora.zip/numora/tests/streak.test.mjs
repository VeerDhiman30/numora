// Real production migrations in an isolated database. Never writes to Supabase.
import { test, before, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createFixture } from './leaderboardFixture.mjs';
import { installTestClock } from './testClock.mjs';

let db, scalar, login, student, clock;
const snapshot = () => scalar('select public.get_my_economy_snapshot()');
const earn = key => scalar(`select to_jsonb(r) from public.record_quant_activity_event($1,'algebra','correct_answer') r`, [`quant:${key}:correct`]);
async function earnXp(count, prefix) {
  let reward;
  for (let index=0; index<count; index++) reward = await earn(`${prefix}-${index}`);
  return reward;
}
before(async () => {
  ({db, scalar, login, student} = await createFixture());
  clock = await installTestClock(db);
});
beforeEach(async () => {
  await db.exec('truncate auth.users cascade');
  await clock('2026-10-21T16:00:00Z');
  await login(await student({zone:'America/New_York'}));
});
after(async () => { await db?.close(); });

test('49 XP does not start a streak; exactly 50 starts one; 100 still credits only one day', async () => {
  assert.equal((await earnXp(49,'first')).current_streak, 0);
  assert.equal((await snapshot()).qualified_today, false);
  const reward = await earn('fiftieth');
  assert.equal(reward.today_xp, 50);
  assert.equal(reward.current_streak, 1);
  assert.equal((await snapshot()).celebrate, true);
  assert.equal((await snapshot()).celebrate, false);
  assert.equal((await earn('fiftieth')).event_recorded, false);
  assert.equal((await earnXp(50,'extra')).current_streak, 1);
  const result = await snapshot();
  assert.equal(result.stats.total_xp, 100);
  assert.equal(result.today.xp_earned, 100);
  assert.equal(await scalar('select count(*)::int from public.streak_days'), 1);
});

test('seven consecutive 50-XP days continue 1→7, retaining yesterday’s streak until today qualifies', async () => {
  for (let day=0; day<7; day++) {
    await clock(`2026-10-${21+day}T16:00:00Z`);
    const start = await snapshot();
    assert.equal(start.stats.current_streak, day);
    assert.equal(start.today.xp_earned, 0);
    assert.equal(start.qualified_today, false);
    assert.equal((await earnXp(49,`day-${day}`)).current_streak, day);
    assert.equal((await earn(`qualify-${day}`)).current_streak, day+1);
    assert.equal((await snapshot()).qualified_today, true);
  }
  assert.equal((await snapshot()).stats.total_xp, 350);
  assert.equal(await scalar('select count(*)::int from public.streak_days'), 7);
});

test('an unfinished 49-XP day breaks the streak at its local midnight; the next 50 restarts at one', async () => {
  await earnXp(50,'qualified');
  await clock('2026-10-22T16:00:00Z');
  await earnXp(49,'unfinished');
  assert.equal((await snapshot()).stats.current_streak, 1);
  await clock('2026-10-23T03:59:59Z'); // Still October 22 in New York.
  assert.equal((await snapshot()).stats.current_streak, 1);
  await clock('2026-10-23T04:00:00Z');
  const missed = await snapshot();
  assert.equal(missed.stats.current_streak, 0);
  assert.equal(missed.today.xp_earned, 0);
  assert.equal(missed.stats.total_xp, 99);
  assert.equal((await earnXp(50,'restart')).current_streak, 1);
});

test('XP from separate days cannot be combined to qualify', async () => {
  await earnXp(25,'yesterday');
  await clock('2026-10-22T16:00:00Z');
  await earnXp(25,'today');
  const result = await snapshot();
  assert.equal(result.stats.total_xp, 50);
  assert.equal(result.today.xp_earned, 25);
  assert.equal(result.stats.current_streak, 0);
  assert.equal(result.qualified_today, false);
});

test('extra XP is not banked for tomorrow, and Arcade coins do not qualify a day', async () => {
  await earnXp(100,'surplus');
  await clock('2026-10-22T16:00:00Z');
  for(let index=0;index<50;index++) await scalar(`select to_jsonb(r) from public.record_activity_event($1,'arcade','balloon-pop','arcade_correct') r`, [`arcade:streak-test-${index}:correct`]);
  const today = await snapshot();
  assert.equal(today.stats.coin_balance, 50);
  assert.equal(today.today.xp_earned, 0);
  assert.equal(today.qualified_today, false);
  assert.equal(today.stats.current_streak, 1);
  await clock('2026-10-23T16:00:00Z');
  assert.equal((await snapshot()).stats.current_streak, 0);
});
