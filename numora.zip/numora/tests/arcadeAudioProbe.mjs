// Observe real browser audio nodes without replacing their playback behavior.
export async function installArcadeAudioProbe(page) {
  await page.addInitScript(() => {
    const NativeAudioContext = window.AudioContext;
    window.__arcadeAudioStarts = [];
    window.AudioContext = class extends NativeAudioContext {
      createOscillator() {
        const oscillator = super.createOscillator(), start = oscillator.start.bind(oscillator);
        oscillator.start = (...args) => {
          window.__arcadeAudioStarts.push({type: oscillator.type, frequency: oscillator.frequency.value, state: this.state});
          return start(...args);
        };
        return oscillator;
      }
    };
  });
}
