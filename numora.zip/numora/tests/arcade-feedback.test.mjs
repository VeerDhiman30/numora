import {test} from 'node:test';
import assert from 'node:assert/strict';
import {playArcadeSound} from '../scripts/arcade/arcadeSession.js';
import {createGameState} from '../scripts/arcade/games.js';
import {evaluateBalloonAction} from '../scripts/arcade/balloonGame.js';
import {evaluateMemoryAction,renderMemoryBoard,settleMemoryMismatch} from '../scripts/arcade/memoryGame.js';

test('wrong-answer buzz is quiet, short, eased and descending; muting creates no audio',()=>{
  const sounds=[];
  class AudioContext {
    currentTime=10;
    constructor(){this.record={gain:[],pitch:[],closed:false};sounds.push(this.record);}
    createOscillator(){
      const record=this.record;
      return {frequency:{value:0,exponentialRampToValueAtTime:(value,time)=>record.pitch.push([value,time])},
        connect:()=>({connect(){}}),start(){record.type=this.type;record.frequency=this.frequency.value;},
        stop:time=>{record.stop=time;},addEventListener:(event,fn)=>{record.ended=fn;}};
    }
    createGain(){return {gain:{setValueAtTime:(...args)=>this.record.gain.push(['set',...args]),linearRampToValueAtTime:(...args)=>this.record.gain.push(['linear',...args]),exponentialRampToValueAtTime:(...args)=>this.record.gain.push(['exponential',...args])},connect(){}};}
    close(){this.record.closed=true;return Promise.resolve();}
  }
  const previous=globalThis.window;
  try {
    globalThis.window={AudioContext};
    playArcadeSound('incorrect',false);assert.equal(sounds.length,0);
    playArcadeSound('incorrect',true);
    assert.equal(sounds.length,1);
    const buzz=sounds[0];assert.equal(buzz.type,'sawtooth');assert.equal(buzz.frequency,180);
    assert.deepEqual(buzz.pitch,[[120,10.16]]);
    assert.deepEqual(buzz.gain,[['set',0.0001,10],['linear',0.018,10.012],['exponential',0.0001,10.17]]);
    assert.equal(buzz.stop,10.18);buzz.ended();assert.equal(buzz.closed,true);
    playArcadeSound('correct',true);assert.equal(sounds[1].type,'sine');assert.equal(sounds[1].frequency,660);
    assert.deepEqual(sounds[1].gain,[['set',0.035,10],['exponential',0.0001,10.11]]);
    globalThis.window={AudioContext:class{constructor(){throw Error('Audio unavailable');}}};
    assert.doesNotThrow(()=>playArcadeSound('incorrect',true));
  } finally {if(previous===undefined)delete globalThis.window;else globalThis.window=previous;}
});

test('only a new wrong balloon requests incorrect feedback; cooldown clicks stay silent',()=>{
  const state=createGameState('balloon-pop');
  assert.equal(evaluateBalloonAction(state,'balloon-launch').feedbackTone,undefined);
  const wrong=evaluateBalloonAction(state,'balloon:1');
  assert.equal(wrong.kind,'select');assert.equal(wrong.feedbackTone,'incorrect');
  assert.equal(evaluateBalloonAction(state,'balloon:1').kind,'none');
  assert.equal(evaluateBalloonAction(state,'balloon:0').kind,'none');
  state.balloon.elapsedMs=4000;
  assert.equal(evaluateBalloonAction(state,'balloon:0').kind,'correct');
});

test('only mismatched memory cards show red-cue class and non-color marker, then clear',()=>{
  const state=createGameState('memory-match');
  const first=0, second=state.memory.cards.findIndex(c=>c.pairId!==state.memory.cards[0].pairId);
  evaluateMemoryAction(state,`memory:${first}`,0);
  assert.doesNotMatch(renderMemoryBoard(state),/is-mismatch/);
  evaluateMemoryAction(state,`memory:${second}`,0);
  const html=renderMemoryBoard(state);
  assert.equal((html.match(/is-mismatch/g)||[]).length,2);
  assert.equal((html.match(/memory-wrong-mark/g)||[]).length,2);
  assert.equal((html.match(/not a match:/g)||[]).length,2);
  settleMemoryMismatch(state,1000);
  assert.doesNotMatch(renderMemoryBoard(state),/is-mismatch|memory-wrong-mark/);
  assert.equal(state.memory.flips,2);assert.equal(state.memory.status,'playing');
});
