import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { finalHarness } from "./finalHarness.mjs";
import { decisionQuestions } from "../scripts/data/decision/questions.js";
import { quantQuestions } from "../scripts/data/quant/questions.js";
import { arcadeGames } from "../scripts/arcade/games.js";
import { simulationStories } from "../scripts/data/simulation/stories.js";
const {db,scalar,addXp,clock,uid,browser,context,page,controls,calls,dbErrors,errors,base}=await finalHarness();
const artifacts=await mkdtemp(join(tmpdir(),'numora-final-'));
const route=async path=>{await page.evaluate(async p=>{
  const {navigateToRoute}=await import('/scripts/components/navigation.js');
  navigateToRoute(p,()=>dispatchEvent(new Event('hashchange')));
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
},path);await page.locator('#app-main h1').waitFor()};
const signin=async remember=>{
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByLabel('Remember me').setChecked(remember);
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('.header-rewards'));
};
const stats=()=>scalar('select public.get_my_economy_snapshot()');
try {
  await clock('2026-10-18T12:00:00Z');
  await page.goto(`${base}/#/leaderboard`);
  await page.waitForURL('**/#/signin');
  await signin(false);
  await page.waitForURL('**/#/leaderboard');
  await page.locator('[data-leaderboard-own-xp]').waitFor();
  assert.equal(await page.evaluate(()=>!!sessionStorage.getItem('numora-auth-session')),true);
  assert.equal(await page.evaluate(()=>!!localStorage.getItem('numora-auth-session')),false);
  await page.reload(); await page.locator('[data-leaderboard-own-xp]').waitFor();
  // A separately created tab has no session-only token; it must sign in.
  const other=await context.newPage(); await other.goto(`${base}/#/dashboard`); await other.waitForURL('**/#/signin'); await other.close();
  await page.evaluate(async()=>{await(await import('/scripts/services/authService.js')).signOut()});
  await page.waitForURL('**/#/signin'); await signin(true);
  assert.equal(await page.evaluate(()=>!!localStorage.getItem('numora-auth-session')),true);
  const remembered=await context.newPage(); await remembered.goto(`${base}/#/dashboard`); await remembered.getByRole('heading',{name:'Welcome back, Alex'}).waitFor(); await remembered.close();
  await page.evaluate(async()=>{await(await import('/scripts/services/authService.js')).signOut()});
  await route('#/signup');
  for(const [label,value] of [['First Name','Alex'],['Last Name','Morgan'],['Email','fixture@example.test'],['Password','test-password'],['Confirm Password','test-password']]) await page.getByLabel(label,{exact:true}).fill(value);
  await page.getByLabel('Grade Level').selectOption('high');
  await page.getByRole('button',{name:'Create Account',exact:true}).click(); await page.waitForURL('**/#/check-email');
  assert.equal(await page.evaluate(()=>new URL(window.__authTest.calls.find(c=>c.type==='signup').input.options.emailRedirectTo).searchParams.get('auth')),'confirmed');
  await page.goto(`${base}/?auth=confirmed`); await page.getByRole('heading',{name:'Sign in to Numora'}).waitFor();
  await route('#/forgot-password');
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByRole('button',{name:'Send Reset Instructions'}).click();
  await page.getByText('If an account uses that email, reset instructions are on the way.').waitFor();
  await page.goto(`${base}/?auth=reset`);
  await page.getByLabel('New Password',{exact:true}).fill('new-test-password');
  await page.getByLabel('Confirm New Password',{exact:true}).fill('new-test-password');
  await page.getByRole('button',{name:'Update Password',exact:true}).click();
  await page.getByText('Your password is updated. You can now sign in.').waitFor();
  await page.getByRole('link',{name:'Return to Sign In'}).click();
  await signin(true);
  console.log('Authentication UI/provider-contract checks passed (simulated delivery, real auth service/storage).');

  await addXp(uid,50,'2026-10-18');
  await db.query('update public.student_stats set total_xp=50,coin_balance=500 where user_id=$1',[uid]);
  await clock('2026-10-18T23:59:58Z'); await route('#/leaderboard');
  await page.waitForFunction(()=>document.querySelector('[data-leaderboard-own-xp]')?.textContent==='50 XP');
  assert.equal(await page.locator('[data-weekly-countdown]').innerText(),'Less than 1 minute');
  await clock('2026-10-19T00:00:00Z');
  await page.waitForFunction(()=>document.querySelector('[data-leaderboard-own-xp]')?.textContent==='0 XP');
  assert.match(await page.locator('[data-weekly-countdown]').innerText(),/[67]d/);
  assert.match(await page.locator('[data-leaderboard-period]').innerText(),/Oct 19/);
  const after=await stats(); assert.equal(after.stats.total_xp,50); assert.equal(after.stats.coin_balance,500); assert.equal(after.stats.current_streak,1);
  // Also cross local midnight with Dashboard already open.
  await clock('2026-10-18T23:59:58Z'); await route('#/dashboard');
  await page.waitForFunction(()=>/50\s*XP this week/.test(document.querySelector('.dashboard-xp')?.textContent));
  await clock('2026-10-19T00:00:00Z');
  await page.waitForFunction(()=>/0\s*XP this week/.test(document.querySelector('.dashboard-xp')?.textContent));
  await page.waitForFunction(async()=> (await import('/scripts/services/appState.js')).getAppState().economy.today.local_date==='2026-10-19');
  console.log('Open-page local Monday transition passed for Dashboard, challenge date, leaderboard, countdown and permanent balances.');

  await route('#/decision'); await page.locator('#decision-scenario-title').waitFor();
  const title=await page.locator('#decision-scenario-title').innerText();
  const decision=decisionQuestions.find(q=>q.title===title); assert.ok(decision,title);
  await page.locator('[data-decision-hint]').click();
  await page.waitForFunction(()=>document.querySelector('[data-decision-hint]')?.getAttribute('aria-expanded')==='true');
  assert.equal((await stats()).stats.coin_balance,490);
  await page.locator(`[data-decision-form] input[value="${decision.correctOption}"]`).check();
  await page.locator('[data-decision-form] button[type=submit]').click();
  await page.locator('[data-decision-feedback]').waitFor(); assert.equal((await stats()).weekly_xp,5);
  await route('#/quant'); await page.locator('#quant-question-title').waitFor();
  // Select a bank until a text/choice question is displayed, then use its real UI.
  let quant;
  for(let attempt=0;attempt<30;attempt++) {
    const prompt=await page.locator('#quant-question-title').innerText();
    quant=quantQuestions.find(q=>q.prompt===prompt);
    if(['written-answer','fill-in-the-blank','single-choice','true-false'].includes(quant?.type))break;
    const topics=page.locator('[data-quant-topic]:not(:disabled)');
    await topics.nth(attempt % await topics.count()).click();
  }
  assert.ok(quant);
  await page.locator('[data-quant-hint]').click();
  await page.waitForFunction(()=>document.querySelector('[data-quant-hint]')?.getAttribute('aria-expanded')==='true');
  assert.equal((await stats()).stats.coin_balance,488);
  if(await page.locator('[data-quant-text-answer]').count())await page.locator('[data-quant-text-answer]').fill(String(quant.answer));
  else await page.locator(`[name="quant-answer"][value="${quant.answer}"]`).check();
  await page.locator('[data-quant-check]').click();await page.locator('[data-quant-feedback]').waitFor();
  assert.equal((await stats()).weekly_xp,6);

  await route('#/simulation'); await page.locator('[data-simulation-grade="entry"]').click();
  await page.locator('[data-simulation-start="entry-snack-budget"]').click();
  const story=simulationStories.find(s=>s.id==='entry-snack-budget');
  for(const step of story.steps.filter(s=>s.core!==false)) {
    await page.getByText(step.coachMessage,{exact:true}).last().waitFor();
    if(step.responseType==='numeric'||step.responseType==='written')await page.locator('#simulation-response-input').fill(String(step.responseType==='written'?step.acceptedPhrases[0]:step.correctAnswer));
    else for(const value of Array.isArray(step.correctAnswer)?step.correctAnswer:[step.correctAnswer])await page.locator(`[name="simulation-response"][value="${value}"]`).check();
    await page.locator('[data-simulation-submit]').click();
  }
  await page.locator('[data-simulation-complete]').waitFor();
  await page.waitForFunction(()=>document.querySelector('[data-simulation-complete]')?.textContent.includes('10 XP'));
  assert.equal((await stats()).weekly_xp,16);
  // Provider-success contract and offline fallback are both exercised, with no live Gemini call.
  const coachRequest={storyId:story.id,gradeLevel:'entry',currentStep:story.steps[0].id,studentResponse:'Help me compare',interaction:'answer',guidanceLevel:0,conversationHistory:[]};
  controls.ai='success';
  assert.equal(await page.evaluate(async request=>(await(await import('/scripts/services/aiService.js')).sendSimulationResponse(request)).success,coachRequest),true);
  controls.ai='offline';
  assert.equal(await page.evaluate(async request=>(await(await import('/scripts/services/aiService.js')).sendSimulationResponse(request)).scriptedFallback,coachRequest),true);
  console.log('Decision/Quant hint spending and XP, full Simulation completion, and AI success/fallback contracts passed.');

  // Every route at four target widths. The actual gameplay boards are tested too.
  for(const width of [1440,1024,768,390]) {
    await page.setViewportSize({width,height:1000});
    for(const path of ['/','#/signin','#/signup','#/decision','#/quant','#/simulation','#/arcade','#/dashboard','#/leaderboard']) {
      await route(path);
      if(path==='#/dashboard')await page.locator('[data-summary]').waitFor();
      if(path==='#/leaderboard')await page.locator('[data-leaderboard-own-xp]').waitFor();
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`${path} overflow at ${width}`);
    }
    if(width===1440||width===390)await page.screenshot({path:join(artifacts,`weekly-${width}.png`),fullPage:true});
  }
  await page.emulateMedia({reducedMotion:'reduce'});
  await route('#/arcade');
  for(const game of arcadeGames) {
    if(await page.locator('[data-arcade-action="back-home"]').count())await page.locator('[data-arcade-action="back-home"]').first().click();
    await page.locator(`[data-arcade-action="grade:${game.gradeLevel}"]`).click();
    await page.locator(`[data-arcade-action="choose-game:${game.id}"]`).click();
    await page.locator('[data-arcade-action="start-game"]').click();
    await page.locator('.arcade-play-area').waitFor();
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,game.id);
    const button=page.locator('.arcade-play-area button').first();await button.focus();
    assert.equal(await button.evaluate(el=>el===document.activeElement),true);
  }
  // An incorrect optimization answer loses exactly one life; a correct one adds one coin.
  await page.locator('[data-arcade-action="optimization-check"]').click();
  await page.waitForFunction(()=>document.querySelector('.arcade-hud')?.textContent.includes('7/8'));
  for(let n=0;n<20;n++)await page.locator('[data-arcade-action="optimization:1"]').click();
  await page.locator('[data-arcade-action="optimization-check"]').click();
  await page.waitForFunction(()=>document.querySelector('.arcade-game__progress')?.textContent.startsWith('1 correct'));
  assert.equal((await stats()).stats.coin_balance,489);assert.equal((await stats()).weekly_xp,16);
  await page.reload();await page.waitForFunction(()=>document.querySelector('.arcade-hud')?.textContent.includes('7/8'));
  await db.query("update public.arcade_state set lives=0,regeneration_started_at=now() where user_id=$1",[uid]);
  await page.reload();await page.getByRole('heading',{name:'Your lives are regenerating'}).waitFor();
  assert.equal(await page.locator('.arcade-play-area').count(),0);
  console.log('Responsive routes (1440/1024/768/390), 12 mobile game boards, keyboard controls, Arcade loss/coin/persistence/zero-life checks passed.');

  // Malformed service replies must fail safely, not invent eight lives or zero balances.
  const prior=(await stats()).stats;
  controls.malformedRpc='get_my_arcade_state';
  assert.match(await page.evaluate(async()=>{try{await(await import('/scripts/arcade/arcadeService.js')).getArcadeState();return 'wrong'}catch(e){return e.message}}),/couldn't load/);
  await page.reload();await page.locator('[data-arcade-action="retry-lives"]').waitFor();
  assert.equal(await page.locator('.arcade-play-area').count(),0);
  controls.malformedRpc=null;
  await page.locator('[data-arcade-action="retry-lives"]').click();
  await page.getByRole('heading',{name:'Your lives are regenerating'}).waitFor();
  controls.malformedRpc='record_quant_activity_event';
  assert.match(await page.evaluate(async()=>{try{await(await import('/scripts/services/rewardService.js')).recordActivity({eventKey:'quant:malformed:correct',module:'quant',topic:'algebra',activityType:'correct_answer'});return 'wrong'}catch(e){return e.message}}),/couldn't save/);
  controls.malformedRpc=null;
  assert.equal((await stats()).stats.total_xp,prior.total_xp);assert.equal((await stats()).stats.coin_balance,prior.coin_balance);
  // Pending auth-profile refresh must not restore private views after sign-out.
  await route('#/dashboard');await page.locator('[data-summary]').waitFor();
  let release;controls.profileGate=new Promise(resolve=>{release=resolve});
  await page.evaluate(()=>window.__authTest.emit('TOKEN_REFRESHED'));
  await page.evaluate(async()=>{await(await import('/scripts/services/authService.js')).signOut()});
  release();controls.profileGate=null;
  await page.waitForURL('**/#/signin');await page.waitForTimeout(300);
  assert.equal(await page.locator('[data-summary],.header-rewards').count(),0);
  assert.equal(await page.evaluate(()=>localStorage.getItem('numora-auth-session')||sessionStorage.getItem('numora-auth-session')),null);
  await signin(true);await route('#/leaderboard');await page.locator('[data-leaderboard-own-xp]').waitFor();
  await page.evaluate(()=>window.__authTest.expire());await page.waitForURL('**/#/signin');
  assert.equal(await page.locator('.leaderboard').count(),0);
  // Inspect actual server responses (not the config/browser interception).
  const config=await(await page.request.get(`${base}/api/config`)).json();
  assert.deepEqual(Object.keys(config).sort(),['supabasePublishableKey','supabaseUrl']);
  for(const path of ['/.env','/server/services/geminiService.js','/supabase/009_weekly_reset.sql','/tests/finalHarness.mjs'])assert.equal((await page.request.get(base+path)).status(),400);
  assert.equal((await page.request.post(`${base}/api/ai/chat`,{data:{message:'test',context:{gradeLevel:'high'}}})).status(),401);
  assert.equal(errors.length,0,errors.join('\n'));
  console.log('Final browser checks passed. No unexpected page errors. Live provider delivery remains a separate acceptance check.');
  console.log(`Screenshots: ${artifacts}`);
} catch(error) {
  await page.screenshot({path:join(artifacts,'failure.png'),fullPage:true});
  console.error('Failure diagnostics:', {url:page.url(),pageErrors:errors,dbErrors:dbErrors.slice(-8),body:(await page.locator('#app-main').innerText()).slice(-2200),lastCalls:calls.slice(-8).map(c=>c.rpc||c.table),artifacts});
  throw error;
} finally { await browser.close(); await db.close(); }
