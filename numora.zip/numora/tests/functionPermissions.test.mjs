import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createFixture } from './leaderboardFixture.mjs';

test('reproduce five direct-grant failures; repair preserves balances and authenticated Arcade calls', async () => {
  const {db, student, login} = await createFixture();
  try {
    const uid = await student(); await login(uid);
    await db.query('update public.student_stats set total_xp=55,coin_balance=123 where user_id=$1', [uid]);
    // Reproduce grants that remain after the old migrations revoke only PUBLIC.
    await db.exec(`grant execute on function public.enforce_simulation_completion_reward(),
      public.enforce_simulation_progress_catalog(), public.refresh_arcade_lives(uuid),
      public.set_arcade_state_updated_at(), public.get_my_arcade_state() to anon, authenticated`);
    const audit = await readFile(new URL('../supabase/verify_all_phases.sql', import.meta.url), 'utf8');
    const before = (await db.query(audit)).rows[0];
    assert.equal(before.missing, 5, JSON.stringify(before.failed_checks));
    const repair = await readFile(new URL('../supabase/fix_function_permissions.sql', import.meta.url), 'utf8');
    await db.exec(repair); await db.exec(repair);
    const after = (await db.query(audit)).rows[0];
    assert.equal(after.missing, 0, JSON.stringify(after.failed_checks));
    assert.deepEqual((await db.query('select total_xp,coin_balance from public.student_stats where user_id=$1', [uid])).rows[0], {total_xp:55,coin_balance:123});
    await db.exec('set role authenticated');
    assert.equal((await db.query('select lives from public.get_my_arcade_state()')).rows[0].lives, 8);
    assert.equal((await db.query("select lives from public.lose_arcade_life('arcade:permissions:wrong')")).rows[0].lives, 7);
    await assert.rejects(db.query('select public.refresh_arcade_lives($1)', [uid]), /permission denied/);
    await db.exec('reset role; set role anon');
    await assert.rejects(db.query('select * from public.get_my_arcade_state()'), /permission denied/);
  } finally { await db.close(); }
});
