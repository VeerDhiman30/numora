// Real app, reward service and database; isolated test auth/data only.
import assert from 'node:assert/strict';
import { finalHarness } from './finalHarness.mjs';

const {db, uid, browser, page, base, clock, errors} = await finalHarness();
const seedDay = async (date, xp) => {
  await db.query(`insert into public.daily_activity(user_id,local_date,xp_earned) values ($1,$2,$3)
    on conflict(user_id,local_date) do update set xp_earned=excluded.xp_earned`, [uid,date,xp]);
  await db.query(`update public.student_stats set total_xp=(select sum(xp_earned) from public.daily_activity where user_id=$1) where user_id=$1`, [uid]);
};
const refresh = () => page.evaluate(async () => (await import('/scripts/services/economyService.js')).refreshEconomy());
const earn = key => page.evaluate(async key => (await import('/scripts/services/rewardService.js')).recordActivity({
  eventKey:`quant:${key}:correct`, module:'quant', topic:'algebra', activityType:'correct_answer'
}), key);
const waitStreak = (count, xp, qualified) => page.waitForFunction(({count,xp,qualified}) =>
  document.querySelector('.reward-counter--streak')?.getAttribute('aria-label') === `${count} day streak`
  && document.querySelector('.reward-counter--xp')?.getAttribute('aria-label') === `${xp} total XP`
  && document.querySelector('[data-streak]')?.textContent.includes(qualified ? "Today's streak secured" : 'XP to qualify today'), {count,xp,qualified});
try {
  await clock('2026-10-21T12:00:00Z');
  await seedDay('2026-10-21',49);
  await page.goto(`${base}/#/dashboard`);
  await page.getByLabel('Email',{exact:true}).fill('fixture@example.test');
  await page.getByLabel('Password',{exact:true}).fill('test-password');
  await page.getByRole('button',{name:'Sign In',exact:true}).click();
  await waitStreak(0,49,false);
  assert.match(await page.locator('[data-streak]').innerText(), /1 XP to qualify today/);
  await earn('streak-day-one');
  await waitStreak(1,50,true);
  assert.match(await page.locator('.reward-toast--celebration').innerText(), /1 day streak! You reached 50 XP today/);
  await page.reload();
  await waitStreak(1,50,true);
  assert.equal(await page.locator('.reward-toast--celebration').count(),0);

  await clock('2026-10-22T12:00:00Z');
  await refresh();
  await waitStreak(1,50,false);
  assert.match(await page.locator('[data-streak]').innerText(), /50 XP to qualify today/);
  await seedDay('2026-10-22',49);
  await refresh();
  await waitStreak(1,99,false);
  await earn('streak-day-two');
  await waitStreak(2,100,true);
  // Retrying the same saved answer neither increases the streak nor XP.
  await earn('streak-day-two');
  await waitStreak(2,100,true);

  await clock('2026-10-23T12:00:00Z');
  await seedDay('2026-10-23',49);
  await refresh();
  await waitStreak(2,149,false);
  await clock('2026-10-24T00:00:00Z');
  await refresh();
  await waitStreak(0,149,false);
  await seedDay('2026-10-24',49);
  await earn('streak-restart');
  await waitStreak(1,199,true);
  assert.deepEqual(errors,[]);
  console.log('Streak browser checks passed: header/dashboard update at 50 XP, single celebration, reload persistence, next-day continuity, duplicate safety, missed-day break, and restart.');
} finally {await browser.close();await db.close();}
