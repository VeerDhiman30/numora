import {test} from 'node:test';
import assert from 'node:assert/strict';
import {BALLOON_FLIGHT_MS,BALLOON_POP_MS,BALLOON_COOLDOWN_MS,BALLOON_WAVE_MS,balloonRounds,balloonProgress,balloonHasLaunched,balloonIsCorrect,balloonRoundDone,evaluateBalloonAction,renderBalloonBoard} from '../scripts/arcade/balloonGame.js';
import {createGameState,advanceGameState,getArcadeGame} from '../scripts/arcade/games.js';
test('15-second climbs, 3-second bursts, and staggered bottom launches',()=>{
  assert.equal(BALLOON_FLIGHT_MS,15000); assert.equal(BALLOON_POP_MS,3000);
  assert.equal(BALLOON_COOLDOWN_MS,4000);
  assert.equal(balloonProgress(0,0),0); assert.equal(balloonProgress(0,7500),.5); assert.equal(balloonProgress(0,15000),1);
  assert.equal(balloonHasLaunched(4,BALLOON_WAVE_MS-1),false);
  assert.equal(balloonProgress(4,BALLOON_WAVE_MS),0);
  assert.equal(balloonProgress(4,BALLOON_WAVE_MS+15000),1);
});
test('every question has 6–8 distinct choices and 2–3 correct answers',()=>{
  balloonRounds.forEach((round,index)=>{
    assert.ok(round.values.length>=6&&round.values.length<=8);
    assert.equal(new Set(round.values).size,round.values.length);
    assert.ok(round.answers.length>=2&&round.answers.length<=3);
    const state=createGameState('balloon-pop'); state.round=index;
    assert.equal(round.values.filter((_,i)=>balloonIsCorrect(state,i)).length,round.answers.length);
  });
});
test('wrong guesses impose a cooldown, never an incorrect/life-loss action; repeats are ignored',()=>{
  const state=createGameState('balloon-pop');
  assert.equal(evaluateBalloonAction(state,'balloon:0').kind,'none');
  evaluateBalloonAction(state,'balloon-launch');
  assert.equal(evaluateBalloonAction(state,'balloon:4').kind,'none');
  assert.equal(evaluateBalloonAction(state,'balloon:1').kind,'select');
  assert.equal(state.balloon.cooldownUntilMs,BALLOON_COOLDOWN_MS);
  assert.equal(evaluateBalloonAction(state,'balloon:0').kind,'none');
  state.balloon.elapsedMs=BALLOON_COOLDOWN_MS;
  assert.equal(evaluateBalloonAction(state,'balloon:0').kind,'correct');
  assert.equal(evaluateBalloonAction(state,'balloon:0').kind,'none');
  assert.equal(evaluateBalloonAction(state,'balloon:1').kind,'none');
  assert.equal(state.popped.length,1);
});
test('missed matches resolve the round but do not become coin rewards',()=>{
  const state=createGameState('balloon-pop');
  evaluateBalloonAction(state,'balloon-launch');state.balloon.elapsedMs=8000;
  evaluateBalloonAction(state,'balloon:0');state.balloon.missed.push(2);
  const outcome=evaluateBalloonAction(state,'balloon:4');
  assert.equal(outcome.advance,true);assert.equal(balloonRoundDone(state),true);
  advanceGameState(getArcadeGame('balloon-pop'),state,outcome);
  assert.equal(state.round,1);assert.equal(state.balloon.elapsedMs,0);assert.equal(state.balloon.running,false);
  assert.match(renderBalloonBoard(state),/15 seconds/);
  assert.match(renderBalloonBoard(state),/data-balloon-countdown-overlay hidden/);
  assert.match(renderBalloonBoard(state),/pause popping for 4 seconds/);
});
