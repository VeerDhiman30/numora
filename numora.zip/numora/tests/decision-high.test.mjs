import { test } from 'node:test';
import assert from 'node:assert/strict';
import { highDecisionQuestions as questions } from '../scripts/data/decision/high.js';
import { decisionContentVersions } from '../scripts/data/decision/questions.js';

const get = suffix => questions.find(q => q.id === `high-${suffix}`);
const near = (actual, expected) => assert.ok(Math.abs(actual-expected)<1e-8, `${actual} != ${expected}`);
const answer = (suffix, id, fragment) => {
  const q = get(suffix);
  assert.equal(q.correctOption, id, q.id);
  if(fragment) assert.ok(q.solutionSteps.join(' ').includes(fragment), q.id);
};
const best = (rows, maximize=false) => rows.sort((a,b) => (maximize ? -1:1)*(a[1]-b[1]))[0][0];

test('all 20 high-school decisions have four choices, explicit assumptions, and worked steps', () => {
  assert.equal(questions.length,20);
  assert.equal(decisionContentVersions.high,2);
  assert.equal(decisionContentVersions.entry,1);
  assert.equal(decisionContentVersions.middle,1);
  for(const module of ['sports','weather','business','technology','investment']) assert.equal(questions.filter(q=>q.module===module).length,4);
  for(const q of questions) {
    assert.equal(q.options.length,4,q.id);
    assert.equal(new Set(q.options.map(o=>o.id)).size,4,q.id);
    assert.ok(q.assumptions.length>=2 && q.solutionSteps.length>=3,q.id);
    assert.equal(q.options.filter(o=>o.id===q.correctOption).length,1,q.id);
    assert.ok(!q.confidenceData,q.id); // No precomputed solution charts.
    assert.ok(q.evidence.every(e=>e.type==='table' && e.rows.every(r=>r.length===e.columns.length)),q.id);
  }
});

test('sports answer keys follow the actual objective, rates, and deadline boundary', () => {
  near(.36-.60*.55,.03); answer('sports-shot','three','3 percentage points');
  const wins = (aces,faults,rate) => (aces+(40-aces-faults)*rate)/40*20;
  near(wins(8,2,.6)-wins(10,4,.5),1.5); answer('sports-serving','rae','1.5 expected points');
  near(20*.95*.07-20*.8*.08,.05); answer('sports-training','b','0.05 seconds');
  const routes=[['express',85,20,.05,28],['transfer',70,25,.2,20],['shuttle',80,10,.08,26]];
  const onTime=r=> (r[1]<=90?1-r[3]:0)+(r[1]+r[2]<=90?r[3]:0);
  near(onTime(routes[2]),1);
  answer('sports-tournament',best(routes.filter(r=>onTime(r)>=.9&&r[4]<=30).map(r=>[r[0],r[4]])));
});

test('weather answer keys include conditional costs, residual risk, deadlines and all nights', () => {
  near(.45*600-(80+.45*(120+60)),109); answer('weather-event-backup','reserve','$109');
  const loss=.3*200+.2*1000;
  near(loss,260); near(180+.2*loss,232); answer('weather-insurance','rent','$232');
  near(.6*25+.4*55,37); near(.6*35+.4*40,37);
  assert.ok(55>45 && 40<=45); answer('weather-route','b','100%');
  const gaps=[16,12,8,4,10].reduce((sum,t)=>sum+20-t,0);
  near(5*8+.45*gaps+6-(5*5+.8*gaps),3.5); answer('weather-heating','a','3.5 kWh');
});

test('business keys include discount boundaries, returns, pricing bands and profit constraints', () => {
  const a=n=>180+12*n, b=n=>60+.9*14*n;
  near(b(85),1131); near(a(200),b(200)); assert.ok(a(201)<b(201)); answer('business-catering','b','201');
  near(500*.08*.9*18-400,248); near(400*.1*.95*18-450,234); answer('business-ad','a','$14');
  near(40+1000*.05+800*.03,114); near(70+(1800-500)*.02,96); answer('business-printer','b','$18');
  const profits=[18,20,22,24].map(p=>[String(p),(p-4)*Math.min(120,180-6*(p-10))-300]);
  answer('business-pricing',best(profits,true),'$1,644');
});

test('technology keys apply conversions and multiple constraints without premature rounding', () => {
  const servers=[['a',99.4,32,0],['b',99.6,46,120],['c',99.7,52,0],['d',99.9,56,40]];
  answer('technology-server',best(servers.filter(r=>720*(1-r[1]/100)<=3.6).map(r=>[r[0],12*r[2]+r[3]])),'$624');
  const energy=9*6+1*18;
  const batteries=[['a',110,.8,72],['b',120,1,78],['c',140,1.2,70],['d',150,1.1,90]];
  answer('technology-battery',best(batteries.filter(r=>r[1]*.8*.8>=energy&&r[2]<=1.1).map(r=>[r[0],r[3]])),'76.8 Wh');
  const plans=[['a',400,45,0],['b',500,62,120],['c',600,68,0],['d',1000,80,0]];
  answer('technology-internet',best(plans.filter(r=>30*1000*8/(r[1]*.7)/60<=12).map(r=>[r[0],12*r[2]+r[3]])),'$816');
  const stored=640+6*60*.9;
  near(stored/.8,1205);
  const storage=[['a',1000,19],['b',1200,22],['c',1500,25],['d',2000,31]];
  answer('technology-cloud',best(storage.filter(r=>stored<=.8*r[1]).map(r=>[r[0],6*r[2]])),'$150');
});

test('savings keys account for time, interest rules, weighted fees and strict break-even', () => {
  const balances=[['a',2000*(1+.04*1.5)],['b',2000*(1+.05*1.5)-36*1.5],['c',2000*(1+.035*1.5)+30],['d',2000*(1+.045*1.5)-15]];
  answer('investment-club-fund',best(balances,true),'$2,135');
  const compound=[['a',1200*1.05**2],['b',1200*(1+2*.052)-6],['c',1200*1.045**2+12],['d',1200*(1+2*.048)+6]];
  near(compound[0][1]-compound[2][1],.57); answer('investment-compound',best(compound,true),'$0.57');
  near(2000*(.05-.002)-2000*(.6*.08+.4*.02-.01),4); answer('investment-portfolio','b','$4');
  const buy=m=>840+12*m-240, lease=m=>60+42*m;
  near(buy(18),lease(18)); assert.ok(buy(19)<lease(19)); near(lease(20)-buy(20),60); answer('investment-equipment','buy','19');
});

test('plan-selection options do not give away the calculated totals', () => {
  for(const id of ['business-pricing','technology-server','technology-battery','technology-internet','technology-cloud','investment-club-fund','investment-compound']) {
    const q=get(id);
    assert.ok(q.options.every(o=>!o.description),id);
    assert.ok(q.options.every(o=>!/(profit|balance|downtime|expected)/i.test(o.label)),id);
  }
});
