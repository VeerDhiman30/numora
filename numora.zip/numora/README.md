# Numora

Numora is a gamified mathematics learning platform for students, implemented
through Phase 8.2: Labs, Arcade, Dashboard, Wallet, Daily Challenge, streaks, and
the real Supabase Weekly Leaderboard with local-week reset and countdown.

## Technology

- Semantic HTML5, modern CSS, and vanilla JavaScript ES modules
- Native Node.js HTTP server
- Node.js 18 or later

## Structure

- `index.html` — semantic application shell
- `server.js` — client-asset server and authenticated AI routes
- `scripts/` — browser modules, Labs, Arcade, Dashboard, Leaderboard, and shared services
- `styles/` — design tokens and component, page, lab, and arcade styles
- `assets/` — images, icons, and sounds
- `supabase/` — ordered SQL migrations and setup checks (not served publicly)

## Development

Run the server:

```bash
npm start
```

Then visit http://localhost:3001.

Validate JavaScript syntax:

```bash
npm run check
```

## Database migrations

When connecting Supabase, run the SQL files in this order:

1. `supabase/001_profiles.sql`
2. `supabase/progress-schema.sql`
3. `supabase/002_decision_lab_rewards.sql`
4. `supabase/003_quant_lab_rewards.sql`
5. `supabase/004_simulation_lab.sql`
6. `supabase/005_simulation_security_hardening.sql`
7. `supabase/006_arcade_state.sql`
8. `supabase/007_dashboard_economy.sql`
9. `supabase/008_weekly_leaderboard.sql`
10. `supabase/009_weekly_reset.sql`

Existing projects only need migrations they have not applied. Phase 7 is not
active on a live Supabase project until migration 007 is run there. Its optional
read-only setup check is `supabase/007_verify_dashboard.sql` (expected missing: 0).

## Phase 7 implementation

The Dashboard route uses `dashboardService.js` to compose real `module_progress`,
`simulation_progress`, and `activity_events` with one database economy snapshot.
Today and Monday-through-today XP come from `daily_activity` using the stored
IANA timezone. The existing weekly-XP RPC remains the single weekly source.
The 250-XP ring is explicitly an optional motivation goal, not a grade.
Academic cards exclude Arcade. Topic labels use attempts and accuracy: fewer
than five answers is Just started; fewer than ten is Practicing; after that,
80%+ is Strong and 60%+ is Making progress. These are practice indicators, not
formal mastery assessments. Recommendations deterministically favor unfinished
stories, then less-practiced Quant topics, then Decision topics.

`reward_rules` is the authoritative database configuration: Decision +5 XP / hint
−10 coins; Quant +1 XP / hint −2 coins; Simulation +10 XP; Arcade +1 coin; Daily
Challenge +20 XP and +20 coins; repair −200 coins. All public reward paths call one
private transaction and lock the student's wallet. Existing event-key formats,
uniqueness, and Simulation completion guards are retained. UI compatibility labels
are centralized in `rewardDisplay.js`; database rules supersede them after load.
Confirmed rewards synchronize shared state, the header, wallet and Arcade HUD.
Focus, local-midnight checks, a one-minute foreground refresh, and cross-tab
notifications reconcile updates. No reward is displayed before server confirmation.

Daily Challenges use a private dedicated 12-question bank, four per level. Selection
is deterministic for user/date/grade. Answers are checked only by the database.
`daily_challenges` has a unique user/local-date key; its reward key deliberately
omits difficulty. Incorrect attempts cost nothing. The countdown uses server time
and the database's next local midnight, including DST, with a monotonic browser
clock between refreshes. Timezone changes are limited to once per seven days;
changing timezone cannot bypass the prior rewarded day's midnight or reuse an
earlier date. No raw timezone names are displayed.

`streak_days` records one qualification per local date at 50 XP. Arcade never
adds XP. Current streaks are recomputed from contiguous credited dates, so a
missed day cannot silently continue a chain. Only yesterday can be repaired,
and only if the preceding day was credited. Two missed days break the chain.
Repair requires a modal confirmation and sufficient coins; the repaired date,
event, and debit commit together. Each repair key is unique. Streak celebration
claims are stored in the database to prevent replay on refresh. Reduced-motion
users receive static feedback. RLS permits only own-row reads; writes go through
validated RPCs and private helper functions.

## Phase 7 checks

After installing dependencies, run:

```bash
npm run check
npm run test:phase7
npm start
```

`tests/phase7.test.mjs` executes all migrations in an isolated PostgreSQL runtime
(PGlite), including repeat migration, 49/50 XP, duplicate awards, insufficient
coins, repair rollback/continuity, timezone changes, DST, RLS and existing Lab
rewards. It never connects to live Supabase. `tests/phase7-browser.mjs` optionally
tests the real UI against that isolated database with mock authentication; it
requires Playwright and Chrome. `NUMORA_PGLITE_PATH` and `NUMORA_PLAYWRIGHT_PATH`
can point to externally installed test packages. Screenshots are written to a
temporary directory. Live account acceptance tests still require applying 007.

## Phase 8.1 implementation

The protected `#/leaderboard` route adds a dedicated navigation entry. Its view
and stylesheet live in `scripts/components/leaderboard/leaderboardView.js` and
`styles/pages/leaderboard.css`; `scripts/services/leaderboardService.js` requests
one narrow `get_weekly_leaderboard(10)` snapshot. No fixture users are shipped to
the app or installed by a migration. Only real profiles with positive weekly XP
receive a rank. An inactive student sees their own actual 0 XP, not a fake rank.

Migration 008 replaces the previously unused table-returning foundation RPC with
a JSON snapshot. `numora_private.weekly_window` supplies the same inclusive Monday
and today boundaries to that RPC and `get_my_weekly_xp`, which Dashboard already
uses through its economy snapshot. Both use saved `daily_activity.xp_earned`, not
a separate weekly counter or client-side activity history. Reward deduplication
and Arcade's zero XP remain unchanged. A date-first covering index supports the
weekly range scan. The snapshot returns at most Top 10 + the current student's
row (RPC limit capped at 50); aggregation and ranking happen inside PostgreSQL.

**Calendar contract:** the signed-in student's stored IANA timezone selects the
displayed Monday-through-today dates. Those exact date bounds apply to everyone's
saved local-date buckets. This keeps the current student's number identical to
Dashboard and avoids mixing different opponents' independently chosen weeks.
Students in different zones can see different date ranges/standings near midnight;
this is not a single UTC worldwide tournament. The page explains this rule. No
weekly countdown, reset animation, or final boundary-state polish is implemented.

Ranks are unique consecutive positions: XP descending, full name ascending
(case-insensitive first, explicit C collation), then exact name and internal UUID
for completely identical names. The UUID is never returned. Top 3 get medals with
screen-reader rank text; the rest show numbers. The current student's true row
has a border/background and visible “You” badge. Below Top 10 it appears in a
separate labeled table group without changing rank or duplicating a visible row.

The RPC requires authentication, uses a fixed empty search path with qualified
objects, and is executable only by authenticated users. It returns full display
name, weekly XP, rank, and current-user boolean, plus the caller's date-window
metadata. It grants no new profile/history/wallet table access. Existing own-row
RLS and private challenge/helper isolation remain intact. The service allowlists
response fields and the view escapes names; errors are always friendly.

Semantic table headers, screen-reader status, non-color “You,” keyboard-accessible
refresh/retry, static loading skeletons, and wrapping names support accessibility.
Rows stay compact on mobile. The header switches to its existing mobile menu
earlier to fit the additional route. Entering/returning to the view, manual refresh,
and confirmed XP changes refresh standings; focus/visibility refresh is coalesced
with a 15-second cooldown, not a polling loop. Leaving/signing out disposes listeners
and ignores in-flight results. Failed refreshes label retained standings as stale.

### Phase 8 checks and live setup

```bash
npm run check
npm run test:phase7
npm run test:phase8
npm start
```

`tests/phase8.test.mjs` checks real migrations, inclusive dates, Dashboard equality,
timezone/DST boundaries, all XP sources, coin exclusion, duplicate safety, tie
ordering, cutoff/current-user rows, bounded limits, RLS/anonymous access, safe
response fields, and migration reruns. Phase 7 regression tests also apply 008.
`tests/phase8-browser.mjs` optionally exercises the real UI with the same isolated
database and mocked sign-in (Playwright + Chrome, same environment options as the
Phase 7 browser suite). It covers states, refreshes, Dashboard consistency, keyboard,
medals, XSS-safe names, sign-out races, and layout from 320 to 1365 pixels.

Live Supabase setup remains manual: run the **contents** of migration 007 first if
it has not been applied, then 008 once. Saving the SQL Editor query is optional.
Run `supabase/008_verify_leaderboard.sql` afterward; expected `missing = 0`.
This checks installed objects/permissions, not real-account acceptance. Sign in
and open `http://localhost:3001/#/leaderboard` after applying the migration.
## Phase 8.2: weekly reset and final integration

Run the full contents of `supabase/009_weekly_reset.sql` **after 008**, then run
`supabase/009_verify_weekly_reset.sql` (expected missing 0). Saving a SQL Editor
query is optional. Do not rerun earlier migrations afterward. No live database
changes are made merely by updating this repository.

### Shared calendar and synchronization

`numora_private.calendar_window(user, now)` is the single calendar authority. It
uses the profile's stored IANA timezone to calculate current local date, Monday
week start, exclusive next-Monday end, next local midnight, and next weekly reset.
Local midnights are converted to timestamps independently, so DST weeks may be
167 or 169 hours, not a fixed 168. `weekly_window` and `local_day` delegate to it;
the existing weekly XP, daily rewards, challenge eligibility and streak helpers
therefore share its calendar. `get_my_today_activity` also uses it.

The new authenticated `get_weekly_tournament` wraps the unchanged 8.1 ranking and
adds calendar metadata. `get_my_economy_snapshot` returns the same calendar to
Dashboard. The 8.1 viewer-local date-window contract and tie ordering stay intact;
there is no globally imposed UTC week. Zero-XP students remain unranked, with a
clear invitation to complete an activity. No cron job, deletion, counter rewrite,
or permanent balance reset occurs on Monday. History is retained; only query
date boundaries change. Normal daily streak/missed-day rules still apply.

`scripts/utils/calendar.js` validates snapshots and provides shared countdown and
date formatting. The countdown is anchored to server time, then advanced using
elapsed monotonic/wall time (including device sleep). Browser clock changes can
trigger a refresh but never alter rewards or database boundaries. The UI displays
`2d 07h 18m` and “Ends Monday at midnight · your local time”; no raw timezone name
is shown. The timer does not announce every tick to screen readers.

The leaderboard updates its timer locally every second, without querying every
second. At the boundary it hides expired standings while loading the new period,
announces the new week once, and restarts from fresh server metadata. Transient
failures use bounded exponential backoff up to one minute and keep manual Retry.
Focus/visibility resync handles sleeping/background tabs. Shared economy refresh
updates Dashboard and its Daily Challenge on a date change. Expired challenge
forms cannot submit while waiting for fresh data. Reward notifications, Wallet,
header and Arcade continue to use confirmed server values and cross-tab signals.

### Integration fixes

- Migration 009 fixes the Phase 6 `lose_arcade_life` SQL/output-column ambiguity
  found by exercising incorrect answers. Life loss and its idempotent retries now
  execute successfully. An activity trigger also enforces zero-life coin blocking
  in the database, while allowing retries of previously committed rewards.
- Migration 009 also repairs catalog/conflict column ambiguity in
  `upsert_simulation_progress`, preserving validation, resumable saves and the
  server-only completion path. Completed stories cannot be downgraded by a save.
- `authService.js` ignores stale profile/session loads after sign-out and removes
  private UI immediately, even before the network request finishes.
- `rewardService.js` and `arcadeService.js` reject malformed responses instead of
  accepting missing balances or inventing eight lives. Arcade pauses gameplay
  until saved lives are confirmed and offers Retry when they cannot be loaded.
- Simulation numeric input rejects trailing nonnumeric text rather than accepting
  a numeric prefix. Existing story answers and guided fallback remain supported.
- Simulation saves keep enough student responses when trimming conversation
  history, so extra coaching messages cannot displace completion evidence.
- Dashboard/leaderboard views, economy/leaderboard services, leaderboard styles,
  test scripts, package commands, and migration documentation were updated. No new
  learning features or reward values were added.

### Final checks and limits

Changed-file map (paths relative to `numora/`):

- Database: `supabase/009_weekly_reset.sql`, `supabase/009_verify_weekly_reset.sql`.
  Main functions: `calendar_window`, `weekly_window`, `local_day`,
  `get_my_today_activity`, `get_weekly_tournament`, `get_my_economy_snapshot`,
  `guard_arcade_reward_lives`, `lose_arcade_life`, `upsert_simulation_progress`.
- Calendar/UI: `scripts/utils/calendar.js` (`readCalendar`, `secondsUntil`,
  `formatWeeklyCountdown`, `formatCalendarDate`),
  `scripts/components/dashboard/dashboardView.js`,
  `scripts/components/leaderboard/leaderboardView.js`, `styles/pages/leaderboard.css`.
- Integration: `scripts/services/{economyService,leaderboardService,authService,rewardService}.js`,
  `scripts/arcade/{arcadeService,arcadeLab}.js`,
  `scripts/labs/simulation/{storyEngine,simulationLab}.js` (including
  `compactResponseHistory`).
- Verification: `tests/{phase82.test,learning.test,phase82-browser,finalHarness,testClock,leaderboardFixture}.mjs`,
  plus updated `tests/{phase7.test,phase7-browser,phase8-browser}.mjs`;
  `package.json`, `README.md`, and `supabase/README.md`.

```bash
npm run check
npm run test:final
npm start
```

The 43 database/learning-engine tests include all reward values and duplicate
events/spending, every Quant interaction type and bank answer, all 15 scripted
Simulation stories (including guided branches/resume), all 12 Arcade games through
their real action handlers, 8 lives/3-minute regeneration/zero-life blocking,
week transitions, DST/half-hour zones, stable ties, preserved history/balances,
RLS/anonymous restrictions, and all migration setup checks. The test-clock wrapper
exists only under `tests/`; no production RPC accepts a client-supplied clock.

Optional browser suites (Playwright + Chrome, `NUMORA_PGLITE_PATH` and
`NUMORA_PLAYWRIGHT_PATH` as above; `NUMORA_TEST_ORIGIN` can select the test server):

- `tests/phase7-browser.mjs`: Dashboard, challenge completion, streak repair,
  wallet/header synchronization and lost-response Arcade reward retry.
- `tests/phase8-browser.mjs`: medals, stable Top 10/current rank, privacy, keyboard
  refresh, empty/error/retry, escaped long names, cross-tab updates and sign-out.
- `tests/phase82-browser.mjs`: real application auth service with a simulated SDK
  provider; signup/confirmation redirect, signin, Remember Me/session-only storage,
  refresh/new-tab behavior, recovery/reset, protected-route return, expiration and
  sign-out races; open-page Monday transition; actual Decision/Quant hint/reward UI
  and Simulation completion; simulated AI success/fallback; all page families at
  1440/1024/768/390 and all 12 mobile game boards; malformed-response protection,
  private-file denial, and no unexpected page errors.

These are isolated tests, not live-provider certification. Apply 007–009 if still
pending and perform real-account acceptance before deployment: confirmation and
reset emails, Supabase redirect allowlist/SMTP/session configuration, and a live
Gemini response. No real email/account was created and no live API key was used by
the suites. Full manual assistive-technology and device testing is still advised.

Security scope: reward amounts and spending are server-owned, direct private
table writes are denied, duplicates are blocked, challenge answers stay private,
and only leaderboard-safe fields are returned. Decision/Quant/Arcade correctness
is still assessed in the browser (as in earlier phases); this is not a server-side
anti-cheat system. Before using rankings for prizes or high-stakes assessment,
server-side grading/issued attempts would be required. Production readiness also
depends on deployment configuration and live acceptance, not just local tests.

## Learning-content and Arcade refinements

High School Decision Lab now has 20 multi-step decisions (four per topic), four
choices each, explicit scenario rules and a highlighted task. Worked calculations
appear only after checking. The revised bank covers conditional probability,
expected cost, tiered pricing, demand/profit, capacity constraints, and net returns.
Large evidence tables scroll on small screens. Content version 2 restarts only
obsolete high-school practice drafts; saved XP, coins, and lower-grade drafts are
unchanged. Tests: `npm run test:decision-high` and `tests/decision-high-browser.mjs`.

Balloon Pop has 6–8 choices and 2–3 matches per question. Balloons launch in two
waves, five seconds apart, with their bodies at the bottom and strings emerging
as they rise. Each climb lasts 15 seconds of active play. Correct pops and missed
matches have three-second bursts that survive reward-related redraws; the last
burst finishes before the next round. Wrong guesses cause a four-second cooldown,
with a large 4–3–2–1 countdown over the play area, not a life deduction. Each missed matching balloon costs one life through the
existing duplicate-safe RPC. Saving, retries, and a hidden tab pause the flight
clock. Reduced-motion mode uses stationary balloons with time labels and static
pop markers. Tests: `npm run test:balloons` and `tests/balloon-browser.mjs`.

Memory Match deals three shuffled pairs and allows eight individual card flips
per board. A mismatch stays visible for one second, then turns back over without
losing a life. An unfinished board after flip eight costs exactly one life through
the existing duplicate-safe RPC; the next board has entirely different values
and eight fresh flips. Finishing on the eighth flip succeeds. Flips, card order,
pending rewards, and pending life deductions survive reloads. A lost response
after a committed deduction can be retried without losing another life. Tests:
`npm run test:memory` and `tests/memory-browser.mjs`.

Arcade wrong answers give an immediate, quiet descending buzzer (respecting the
sound toggle) and a red message with an × marker. Wrong balloons get a red outline
and × badge, plus a red countdown panel/play-area border. Mismatched memory cards
briefly turn red with × marks before hiding again. These cues do not change lives,
flip budgets, or cooldown rules; blocked repeat clicks do not replay the buzzer.
Tests: `tests/arcade-feedback.test.mjs` and the Memory/Balloon browser suites.

Middle School Draw the Line now asks students to plot two distinct points from
each equation, then draws the connecting line automatically. A labeled −6 to 6
coordinate grid supports click/tap plotting, arrow keys plus Enter/Space, and
exact typed coordinates (including decimals). Students can select and move either
point or clear both before checking. Any two distinct points satisfying the
equation are accepted; only checking an incorrect line uses a life, and only a
correct submitted line earns a coin. Plots and input drafts resume after reload,
while older slope/intercept drafts reset just the plotting controls. Tests:
`npm run test:line` and `tests/line-browser.mjs`. No new SQL is required.

Calculator-designated Trig Target questions have a calculator badge and an
in-app scientific calculator with degree/radian modes, inverse trig, powers,
roots, logarithms, and keyboard input. Tests: `npm run test:calculator` and
`tests/calculator-browser.mjs`. These frontend changes require no new SQL.
