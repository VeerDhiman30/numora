# Supabase preparation

For one read-only database setup audit across all phases through 8.2, run the
entire contents of `verify_all_phases.sql` in SQL Editor as the default postgres
role. Expected: `missing = 0` and `failed_checks = []`. Missing tables/functions
are reported rather than causing the audit to stop. It checks required tables,
columns, primary/unique/user foreign keys, indexes, triggers, RLS/policy setup,
RPC/private permissions, and selected current implementation markers. It changes
no data. Phase 1 is frontend-only; seed-row contents, live email/Gemini, and actual
account/app behavior require separate checks. A zero count is not a production
or security certification. If issues appear, review the failed checks before
rerunning migrations, since older migrations can overwrite newer functions.

If the audit reports the four Phase 5/6 internal-function permission failures
and the `get_my_arcade_state()` permission failure, run
`fix_function_permissions.sql` as postgres, then rerun the audit. Older scripts
revoked PUBLIC execution without removing separately granted anon/authenticated
execution. This targeted repair changes only those execution grants, preserving
the authenticated Arcade entry point and all saved data; it is safe to rerun.

Run `001_profiles.sql` in the Supabase SQL Editor for the Phase 2.1 student
profile table, profile-creation trigger, timestamp trigger, and profile-only
Row Level Security policies.

Then run `progress-schema.sql` for the Phase 2.2 student wallet, activity
history, module progress, daily totals, secure reward RPC, weekly XP helpers,
and private Row Level Security policies.

The later migrations add the implemented learning and game experiences:

3. `002_decision_lab_rewards.sql` — Phase 3 Decision rewards and selected-grade tracking
4. `003_quant_lab_rewards.sql` — Phase 4.4 Quant Lab rewards and topic progress
5. `004_simulation_lab.sql` — Phase 5.4 Simulation Lab persistence and rewards
6. `005_simulation_security_hardening.sql` — Simulation completion hardening
7. `006_arcade_state.sql` — Phase 6 Arcade lives, regeneration, and idempotent life loss
8. `007_dashboard_economy.sql` — Phase 7 centralized rewards, Daily Challenges, local-day streaks, and repair
9. `008_weekly_leaderboard.sql` — Phase 8.1 real weekly ranking, Top 10 + current student, shared weekly date window
10. `009_weekly_reset.sql` — Phase 8.2 shared daily/weekly calendar, countdown metadata, final Arcade life and Simulation save fixes

Run the files in that order. The later migrations rely on the tables and
student rows created by the earlier ones.

If 001–006 were already applied, run only `007_dashboard_economy.sql` for Phase 7.
Copy the entire file contents into a new SQL Editor query and run once. Saving the
query is optional. The migration is transactional and safe to rerun; it preserves
existing XP, coins, and activity. Do not rerun older reward migrations afterward,
as those would replace the current reward functions.

Optionally run `007_verify_dashboard.sql` afterward. A missing count of zero checks
the required tables, functions, and RLS setup; it does not replace account testing.

Phase 7 adds `reward_rules`, `daily_challenges`, `streak_days`, and a private challenge
bank/helper schema. Direct client writes are forbidden. `get_my_economy_snapshot`
refreshes the current streak from saved daily XP; `get_my_daily_challenge` returns
only question data; `submit_daily_challenge` validates answers and grants at most
one +20 XP/+20 coins reward per local day; `repair_my_streak` validates yesterday's
eligibility and charges 200 coins atomically. Existing Lab RPC names still work.

## Phase 8.1

If 001–007 are already applied, run only the **entire contents** of
`008_weekly_leaderboard.sql` in a new SQL Editor query. Click Run; saving is optional.
If 007 is missing, run it first. The transactional migration preserves all student
data and is safe to rerun. It replaces the unused foundation leaderboard function's
return type; any unexpected external dependency causes a safe failure (no CASCADE).
Do not rerun `progress-schema.sql` afterward, as it contains the old RPC definition.

Run `008_verify_leaderboard.sql` for a read-only setup check. Expected: `missing = 0`
and `failed_checks = {}`. Then test the Leaderboard while signed in. This check
does not seed data or claim that real-account interactions have been verified.

Only registered profiles with positive weekly XP appear, with full first/last
names, rank, XP, and an own-user indicator. Top results plus the caller's row are
ranked in the database. An inactive caller receives rank null and XP 0. Anonymous
calls and direct private-helper access are denied; table RLS is unchanged.

The requesting student's saved timezone determines one Monday-through-today date
range used by both Dashboard and all leaderboard rows. Other timezones may see
different date bounds near midnight. Totals sum saved daily XP, not coins. Ties
use full-name ordering and an internal UUID fallback that never leaves the RPC.
Phase 8.2 adds the weekly reset/countdown behavior below.

## Phase 8.2

If 001–008 are already applied, copy the **entire contents** of
`009_weekly_reset.sql` into a new SQL Editor query and click Run. Otherwise run
the missing migrations in the order above first. Saving the query is optional.
Run the read-only `009_verify_weekly_reset.sql`; expected `missing = 0` and
`failed_checks = {}`. This checks setup, not live-provider/account behavior.

The migration is transactional and safe to rerun. It never deletes activity or
resets XP/coins/streak history. A private shared calendar computes local Monday
midnight to next local Monday midnight, including daylight-saving changes.
`get_weekly_tournament` adds reset metadata to the existing privacy-safe ranking;
Dashboard's economy snapshot uses the same dates. Old weekly XP disappears from
current rankings naturally through date filtering, not through destructive jobs.
Zero-XP students remain unranked until an XP-earning activity is completed.

The migration also repairs an ambiguous column in the existing Arcade life-loss
RPC and in Simulation progress saves, and enforces the existing zero-life reward block in the database. Reward
amounts, three-minute regeneration, retry keys and all previous balances remain.
See the main README's Phase 8.2 section for tests and live-acceptance limitations.
