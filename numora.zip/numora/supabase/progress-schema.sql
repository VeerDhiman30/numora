-- Numora Phase 2.2: secure progress and rewards foundation.
-- Prerequisite: run 001_profiles.sql first.
-- This migration deliberately does not create Lab, Dashboard, Daily Challenge, or
-- leaderboard interfaces. It creates only the database foundation they will use.

create table if not exists public.student_stats (
  user_id uuid primary key references auth.users(id) on delete cascade,
  total_xp integer not null default 0 check (total_xp >= 0),
  coin_balance integer not null default 0 check (coin_balance >= 0),
  current_streak integer not null default 0 check (current_streak >= 0),
  last_streak_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.activity_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  event_key text not null check (event_key ~ '^[a-z0-9][a-z0-9:_-]{2,180}$'),
  module text not null check (module in ('decision', 'quant', 'simulation', 'arcade', 'daily_challenge', 'streak')),
  topic text,
  activity_type text not null check (activity_type in ('correct_answer', 'incorrect_answer', 'hint', 'story_completed', 'arcade_correct', 'daily_challenge', 'streak_repair')),
  xp_delta integer not null default 0 check (xp_delta >= 0),
  coin_delta integer not null default 0,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  occurred_at timestamptz not null default now(),
  local_date date not null,
  created_at timestamptz not null default now(),
  unique (user_id, event_key)
);

create table if not exists public.module_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  module text not null check (module in ('decision', 'quant', 'simulation')),
  grade_level text not null check (grade_level in ('entry', 'middle', 'high')),
  topic text not null check (length(trim(topic)) > 0),
  completed_count integer not null default 0 check (completed_count >= 0),
  correct_count integer not null default 0 check (correct_count >= 0),
  attempt_count integer not null default 0 check (attempt_count >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id, module, grade_level, topic)
);

create table if not exists public.daily_activity (
  user_id uuid not null references auth.users(id) on delete cascade,
  local_date date not null,
  xp_earned integer not null default 0 check (xp_earned >= 0),
  coins_earned integer not null default 0 check (coins_earned >= 0),
  activities_completed integer not null default 0 check (activities_completed >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id, local_date)
);

create index if not exists activity_events_user_occurred_at_idx
on public.activity_events (user_id, occurred_at desc);

create index if not exists daily_activity_user_local_date_idx
on public.daily_activity (user_id, local_date desc);

create or replace function public.set_numora_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists student_stats_set_updated_at on public.student_stats;
create trigger student_stats_set_updated_at
before update on public.student_stats
for each row execute procedure public.set_numora_updated_at();

drop trigger if exists module_progress_set_updated_at on public.module_progress;
create trigger module_progress_set_updated_at
before update on public.module_progress
for each row execute procedure public.set_numora_updated_at();

drop trigger if exists daily_activity_set_updated_at on public.daily_activity;
create trigger daily_activity_set_updated_at
before update on public.daily_activity
for each row execute procedure public.set_numora_updated_at();

-- Profiles are created by the Phase 2.1 auth trigger. This trigger gives every
-- profile exactly one zeroed wallet/progress row without frontend setup calls.
create or replace function public.initialize_student_stats()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.student_stats (user_id)
  values (new.id)
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists profiles_initialize_student_stats on public.profiles;
create trigger profiles_initialize_student_stats
after insert on public.profiles
for each row execute procedure public.initialize_student_stats();

-- Backfill students who created their profile before this migration was applied.
insert into public.student_stats (user_id)
select id from public.profiles
on conflict (user_id) do nothing;

alter table public.student_stats enable row level security;
alter table public.activity_events enable row level security;
alter table public.module_progress enable row level security;
alter table public.daily_activity enable row level security;

drop policy if exists "Students can view their own stats" on public.student_stats;
create policy "Students can view their own stats"
on public.student_stats for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "Students can view their own activity events" on public.activity_events;
create policy "Students can view their own activity events"
on public.activity_events for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "Students can view their own module progress" on public.module_progress;
create policy "Students can view their own module progress"
on public.module_progress for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "Students can view their own daily activity" on public.daily_activity;
create policy "Students can view their own daily activity"
on public.daily_activity for select
to authenticated
using ((select auth.uid()) = user_id);

-- There are intentionally no direct client insert, update, or delete policies on
-- these progress tables. The RPC below is the only award path.
create or replace function public.record_activity_event(
  p_event_key text,
  p_module text,
  p_topic text default null,
  p_activity_type text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns table (
  event_id uuid,
  event_recorded boolean,
  total_xp integer,
  coin_balance integer,
  current_streak integer,
  local_date date,
  today_xp integer,
  today_coins_earned integer,
  today_activities_completed integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_timezone text;
  v_profile_grade_level text;
  v_activity_grade_level text;
  v_local_date date;
  v_xp_delta integer := 0;
  v_coin_delta integer := 0;
  v_event_id uuid;
  v_stats public.student_stats%rowtype;
  v_today public.daily_activity%rowtype;
  v_attempt_increment integer := 0;
  v_correct_increment integer := 0;
  v_completed_increment integer := 0;
  v_daily_completion_increment integer := 0;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  if p_event_key is null or p_event_key !~ '^[a-z0-9][a-z0-9:_-]{2,180}$' then
    raise exception using errcode = '22023', message = 'Invalid activity event key.';
  end if;

  if p_metadata is null or jsonb_typeof(p_metadata) <> 'object' then
    raise exception using errcode = '22023', message = 'Invalid activity metadata.';
  end if;

  select timezone, grade_level
  into v_timezone, v_profile_grade_level
  from public.profiles
  where id = v_user_id;

  if not found then
    raise exception using errcode = '22023', message = 'Student profile is unavailable.';
  end if;

  v_activity_grade_level := v_profile_grade_level;
  if p_module = 'decision' then
    v_activity_grade_level := coalesce(nullif(p_metadata ->> 'grade_level', ''), v_profile_grade_level);
    if v_activity_grade_level not in ('entry', 'middle', 'high') then
      raise exception using errcode = '22023', message = 'Invalid decision grade level.';
    end if;
  end if;

  v_local_date := (now() at time zone coalesce(nullif(v_timezone, ''), 'UTC'))::date;

  if p_module in ('decision', 'quant', 'simulation', 'arcade')
    and p_event_key !~ ('^' || p_module || ':') then
    raise exception using errcode = '22023', message = 'Activity key does not match its module.';
  end if;

  if p_module = 'decision' and p_activity_type = 'correct_answer'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:correct$' then
    raise exception using errcode = '22023', message = 'Invalid decision completion key.';
  end if;

  if p_module = 'decision' and p_activity_type = 'incorrect_answer'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:incorrect$' then
    raise exception using errcode = '22023', message = 'Invalid decision completion key.';
  end if;

  if p_module = 'decision' and p_activity_type = 'hint'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:hint$' then
    raise exception using errcode = '22023', message = 'Invalid decision hint key.';
  end if;

  -- The client selects a semantic event only. It never supplies XP or coin totals.
  case
    when p_module = 'decision' and p_activity_type = 'correct_answer' then
      v_xp_delta := 5;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'decision' and p_activity_type = 'incorrect_answer' then
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'decision' and p_activity_type = 'hint' then
      v_coin_delta := -10;
    when p_module = 'quant' and p_activity_type = 'correct_answer' then
      v_xp_delta := 1;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'quant' and p_activity_type = 'hint' then
      v_coin_delta := -2;
      v_attempt_increment := 1;
    when p_module = 'simulation' and p_activity_type = 'story_completed' then
      v_xp_delta := 10;
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'arcade' and p_activity_type = 'arcade_correct' then
      v_coin_delta := 1;
      v_daily_completion_increment := 1;
    when p_module = 'daily_challenge' and p_activity_type = 'daily_challenge' then
      v_xp_delta := 20;
      v_coin_delta := 20;
      v_daily_completion_increment := 1;
      if p_event_key <> 'daily:' || to_char(v_local_date, 'YYYY-MM-DD') then
        raise exception using errcode = '22023', message = 'Daily activity key does not match the student date.';
      end if;
    when p_module = 'streak' and p_activity_type = 'streak_repair' then
      v_coin_delta := -200;
      if p_event_key !~ '^streak:repair:[0-9]{4}-[0-9]{2}-[0-9]{2}$' then
        raise exception using errcode = '22023', message = 'Invalid streak repair key.';
      end if;
    else
      raise exception using errcode = '22023', message = 'Invalid Numora reward activity.';
  end case;

  if p_module in ('decision', 'quant', 'simulation')
    and (p_topic is null or length(trim(p_topic)) = 0) then
    raise exception using errcode = '22023', message = 'A learning topic is required.';
  end if;

  insert into public.student_stats (user_id)
  values (v_user_id)
  on conflict (user_id) do nothing;

  -- Lock the wallet row before checking the event key. Concurrent retries for the
  -- same student therefore serialize: the second call returns a safe duplicate
  -- result instead of inserting or awarding twice.
  select *
  into v_stats
  from public.student_stats
  where user_id = v_user_id
  for update;

  select id
  into v_event_id
  from public.activity_events
  where user_id = v_user_id
    and event_key = p_event_key;

  if found then
    select *
    into v_today
    from public.daily_activity
    where user_id = v_user_id
      and local_date = v_local_date;

    return query select
      v_event_id,
      false,
      v_stats.total_xp,
      v_stats.coin_balance,
      v_stats.current_streak,
      v_local_date,
      coalesce(v_today.xp_earned, 0),
      coalesce(v_today.coins_earned, 0),
      coalesce(v_today.activities_completed, 0);
    return;
  end if;

  if v_stats.coin_balance + v_coin_delta < 0 then
    raise exception using errcode = '22023', message = 'Insufficient coins.';
  end if;

  insert into public.activity_events (
    user_id,
    event_key,
    module,
    topic,
    activity_type,
    xp_delta,
    coin_delta,
    metadata,
    occurred_at,
    local_date
  ) values (
    v_user_id,
    p_event_key,
    p_module,
    nullif(trim(p_topic), ''),
    p_activity_type,
    v_xp_delta,
    v_coin_delta,
    p_metadata,
    now(),
    v_local_date
  ) returning id into v_event_id;

  update public.student_stats
  set total_xp = total_xp + v_xp_delta,
      coin_balance = coin_balance + v_coin_delta
  where user_id = v_user_id
  returning * into v_stats;

  insert into public.daily_activity (
    user_id,
    local_date,
    xp_earned,
    coins_earned,
    activities_completed
  ) values (
    v_user_id,
    v_local_date,
    v_xp_delta,
    greatest(v_coin_delta, 0),
    v_daily_completion_increment
  ) on conflict (user_id, local_date) do update
  set xp_earned = public.daily_activity.xp_earned + excluded.xp_earned,
      coins_earned = public.daily_activity.coins_earned + excluded.coins_earned,
      activities_completed = public.daily_activity.activities_completed + excluded.activities_completed
  returning * into v_today;

  if p_module in ('decision', 'quant', 'simulation') then
    insert into public.module_progress (
      user_id,
      module,
      grade_level,
      topic,
      completed_count,
      correct_count,
      attempt_count
    ) values (
      v_user_id,
      p_module,
      v_activity_grade_level,
      trim(p_topic),
      v_completed_increment,
      v_correct_increment,
      v_attempt_increment
    ) on conflict (user_id, module, grade_level, topic) do update
    set completed_count = public.module_progress.completed_count + excluded.completed_count,
        correct_count = public.module_progress.correct_count + excluded.correct_count,
        attempt_count = public.module_progress.attempt_count + excluded.attempt_count;
  end if;

  return query select
    v_event_id,
    true,
    v_stats.total_xp,
    v_stats.coin_balance,
    v_stats.current_streak,
    v_local_date,
    v_today.xp_earned,
    v_today.coins_earned,
    v_today.activities_completed;
end;
$$;

-- Current-student foundations use RLS, while the future leaderboard has a narrow
-- security-definer RPC that returns display data only—never email or activity rows.
create or replace function public.get_my_today_activity()
returns table (
  local_date date,
  xp_earned integer,
  coins_earned integer,
  activities_completed integer
)
language sql
stable
set search_path = public
as $$
  select
    daily.local_date,
    daily.xp_earned,
    daily.coins_earned,
    daily.activities_completed
  from public.daily_activity as daily
  join public.profiles as profile on profile.id = daily.user_id
  where daily.user_id = auth.uid()
    and daily.local_date = (now() at time zone coalesce(nullif(profile.timezone, ''), 'UTC'))::date;
$$;

create or replace function public.get_my_weekly_xp()
returns integer
language sql
stable
set search_path = public
as $$
  select coalesce(sum(daily.xp_earned), 0)::integer
  from public.daily_activity as daily
  join public.profiles as profile on profile.id = daily.user_id
  where daily.user_id = auth.uid()
    and daily.local_date >= date_trunc(
      'week',
      (now() at time zone coalesce(nullif(profile.timezone, ''), 'UTC'))::date
    )::date
    and daily.local_date <= (now() at time zone coalesce(nullif(profile.timezone, ''), 'UTC'))::date;
$$;

create or replace function public.get_weekly_leaderboard(p_limit integer default 50)
returns table (
  display_name text,
  weekly_xp integer,
  rank integer
)
language sql
stable
security definer
set search_path = public
as $$
  with weekly_totals as (
    select
      profile.id,
      concat_ws(' ', nullif(trim(profile.first_name), ''), nullif(left(trim(profile.last_name), 1), '') || '.') as display_name,
      coalesce(sum(daily.xp_earned) filter (
        where daily.local_date >= date_trunc(
          'week',
          (now() at time zone coalesce(nullif(profile.timezone, ''), 'UTC'))::date
        )::date
        and daily.local_date <= (now() at time zone coalesce(nullif(profile.timezone, ''), 'UTC'))::date
      ), 0)::integer as weekly_xp
    from public.profiles as profile
    left join public.daily_activity as daily on daily.user_id = profile.id
    group by profile.id, profile.first_name, profile.last_name, profile.timezone
  ), ranked as (
    select
      display_name,
      weekly_xp,
      dense_rank() over (order by weekly_xp desc) as rank
    from weekly_totals
  )
  select
    coalesce(nullif(display_name, ''), 'Numora student'),
    weekly_xp,
    rank::integer
  from ranked
  order by rank, display_name
  limit greatest(1, least(coalesce(p_limit, 50), 100));
$$;

revoke all on function public.record_activity_event(text, text, text, text, jsonb) from public;
revoke all on function public.get_my_today_activity() from public;
revoke all on function public.get_my_weekly_xp() from public;
revoke all on function public.get_weekly_leaderboard(integer) from public;

grant execute on function public.record_activity_event(text, text, text, text, jsonb) to authenticated;
grant execute on function public.get_my_today_activity() to authenticated;
grant execute on function public.get_my_weekly_xp() to authenticated;
grant execute on function public.get_weekly_leaderboard(integer) to authenticated;
