-- Phase 8.1. Run AFTER 007_dashboard_economy.sql. No rewards or history are reset.
begin;

-- One calendar-window definition for Dashboard and Leaderboard. The requesting
-- student's saved zone selects Monday-through-today, inclusive. The leaderboard
-- applies those SAME date bounds to every student's saved local-date XP buckets;
-- it never mixes each opponent's independently selected week into one board.
create or replace function numora_private.weekly_window(
  p_user_id uuid, p_now timestamptz default now()
)
returns table (week_start date, through_date date, timezone text)
language sql stable set search_path = '' as $$
  select date_trunc('week', day.local_date)::date, day.local_date, profile.timezone
  from public.profiles profile
  cross join lateral (select (p_now at time zone profile.timezone)::date as local_date) day
  where profile.id = p_user_id;
$$;
revoke all on function numora_private.weekly_window(uuid, timestamptz) from public, anon, authenticated;

create or replace function public.get_my_weekly_xp()
returns integer language sql stable security definer set search_path = '' as $$
  select coalesce(sum(daily.xp_earned), 0)::integer
  from numora_private.weekly_window(auth.uid()) period
  join public.daily_activity daily
    on daily.user_id = auth.uid()
    and daily.local_date between period.week_start and period.through_date;
$$;
revoke all on function public.get_my_weekly_xp() from public, anon;
grant execute on function public.get_my_weekly_xp() to authenticated;

-- Supports the bounded date-range scan rather than reading every historical day.
create index if not exists daily_activity_weekly_idx
  on public.daily_activity (local_date, user_id) include (xp_earned);

-- The unused foundation endpoint returned a table. Replace it atomically with
-- a small snapshot containing Top N + the caller's row, even below the cutoff.
-- No CASCADE: an unexpected external dependency will safely stop the migration.
drop function if exists public.get_weekly_leaderboard(integer);
create function public.get_weekly_leaderboard(p_limit integer default 10)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare
  v_user_id uuid := auth.uid();
  v_period record;
  v_limit integer := greatest(1, least(coalesce(p_limit, 10), 50));
  v_result jsonb;
begin
  if v_user_id is null then raise exception 'Authentication required'; end if;
  select * into v_period from numora_private.weekly_window(v_user_id);
  if not found then raise exception 'Student profile required'; end if;

  with totals as (
    select daily.user_id, sum(daily.xp_earned)::bigint as weekly_xp
    from public.daily_activity daily
    where daily.local_date between v_period.week_start and v_period.through_date
    group by daily.user_id
    having sum(daily.xp_earned) > 0
  ), named as (
    select profile.id as user_id, totals.weekly_xp,
      coalesce(nullif(concat_ws(' ', nullif(btrim(profile.first_name), ''),
        nullif(btrim(profile.last_name), '')), ''), 'Numora student') as display_name
    from totals join public.profiles profile on profile.id = totals.user_id
  ), ranked as materialized (
    select user_id, display_name, weekly_xp,
      row_number() over (order by weekly_xp desc, lower(display_name) collate "C",
        display_name collate "C", user_id) as rank
    from named
  ), safe_rows as (
    select rank, user_id = v_user_id as is_current_user,
      jsonb_build_object('display_name', display_name, 'weekly_xp', weekly_xp,
        'rank', rank, 'is_current_user', user_id = v_user_id) as row_data
    from ranked where rank <= v_limit or user_id = v_user_id
  )
  select jsonb_build_object(
    'week_start', v_period.week_start, 'through_date', v_period.through_date,
    'timezone', v_period.timezone, 'limit', v_limit,
    'entries', coalesce((select jsonb_agg(row_data order by rank) from safe_rows where rank <= v_limit), '[]'::jsonb),
    'current_student', coalesce((select row_data from safe_rows where is_current_user),
      jsonb_build_object('display_name', (select coalesce(nullif(concat_ws(' ',
        nullif(btrim(first_name), ''), nullif(btrim(last_name), '')), ''), 'Numora student')
        from public.profiles where id = v_user_id),
        'weekly_xp', 0, 'rank', null, 'is_current_user', true))
  ) into v_result;
  return v_result;
end;
$$;
revoke all on function public.get_weekly_leaderboard(integer) from public, anon;
grant execute on function public.get_weekly_leaderboard(integer) to authenticated;

-- No direct cross-student table access is granted; existing own-row RLS stays.
commit;
