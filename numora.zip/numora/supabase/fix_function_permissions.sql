-- Targeted repair for the five Phase 5/6 permission failures in the setup audit.
-- Run as postgres after the existing migrations. Safe to rerun.
-- Only function execution permissions change; no student data or bodies change.
begin;

-- Internal helpers must not be callable directly by browser clients. Revoking
-- PUBLIC alone does not remove separate anon/authenticated role grants.
revoke execute on function
  public.enforce_simulation_completion_reward(),
  public.enforce_simulation_progress_catalog(),
  public.refresh_arcade_lives(uuid),
  public.set_arcade_state_updated_at()
from public, anon, authenticated;

-- The browser may read only its own Arcade state through the authenticated API.
revoke execute on function public.get_my_arcade_state()
from public, anon;
grant execute on function public.get_my_arcade_state()
to authenticated;

commit;
