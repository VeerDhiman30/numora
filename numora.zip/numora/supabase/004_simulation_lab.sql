-- Numora Phase 5.4: private Simulation Lab persistence and completion rewards.
-- Run this migration after 001_profiles.sql, progress-schema.sql,
-- 002_decision_lab_rewards.sql, and 003_quant_lab_rewards.sql.

-- This private catalog is the server-owned list of real Simulation stories.
-- It prevents clients from inventing story IDs or grade combinations when they
-- save progress or request a completion reward.
create table if not exists public.simulation_story_catalog (
  story_id text primary key check (story_id ~ '^[a-z0-9][a-z0-9-]{1,120}$'),
  grade_level text not null check (grade_level in ('entry', 'middle', 'high')),
  required_completion_step integer not null check (required_completion_step between 1 and 100)
);

insert into public.simulation_story_catalog (story_id, grade_level, required_completion_step) values
  ('entry-snack-budget', 'entry', 5),
  ('entry-recipe-double', 'entry', 5),
  ('entry-allowance-goal', 'entry', 5),
  ('entry-field-trip-time', 'entry', 5),
  ('entry-garden-plan', 'entry', 5),
  ('middle-subscription-choice', 'middle', 5),
  ('middle-basketball-strategy', 'middle', 5),
  ('middle-festival-budget', 'middle', 5),
  ('middle-weather-plan', 'middle', 5),
  ('middle-food-truck-pricing', 'middle', 5),
  ('high-laptop-comparison', 'high', 5),
  ('high-savings-decision', 'high', 5),
  ('high-concert-break-even', 'high', 5),
  ('high-water-use-trend', 'high', 5),
  ('high-data-plan-comparison', 'high', 5)
on conflict (story_id) do update
set grade_level = excluded.grade_level,
    required_completion_step = excluded.required_completion_step;

alter table public.simulation_story_catalog enable row level security;
revoke all on table public.simulation_story_catalog from anon, authenticated;

create table if not exists public.simulation_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  story_id text not null check (story_id ~ '^[a-z0-9][a-z0-9-]{1,120}$'),
  grade_level text not null check (grade_level in ('entry', 'middle', 'high')),
  status text not null default 'in_progress' check (status in ('in_progress', 'completed')),
  current_step integer not null default 0 check (current_step >= 0 and current_step <= 100),
  attempts integer not null default 0 check (attempts >= 0 and attempts <= 1000),
  help_uses integer not null default 0 check (help_uses >= 0 and help_uses <= 1000),
  guidance_level integer not null default 0 check (guidance_level >= 0 and guidance_level <= 3),
  response_history jsonb not null default '[]'::jsonb check (
    case
      when jsonb_typeof(response_history) = 'array'
        then jsonb_array_length(response_history) <= 12
      else false
    end
  ),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, story_id),
  check (
    (status = 'in_progress' and completed_at is null)
    or (status = 'completed' and completed_at is not null)
  )
);

create index if not exists simulation_progress_user_status_updated_at_idx
on public.simulation_progress (user_id, status, updated_at desc);

drop trigger if exists simulation_progress_set_updated_at on public.simulation_progress;
create trigger simulation_progress_set_updated_at
before update on public.simulation_progress
for each row execute procedure public.set_numora_updated_at();

alter table public.simulation_progress enable row level security;

drop policy if exists "Students can view their own simulation progress" on public.simulation_progress;
create policy "Students can view their own simulation progress"
on public.simulation_progress for select
to authenticated
using ((select auth.uid()) = user_id);

-- Progress writes are intentionally routed through the narrowly validated RPC
-- below. Students have read access to their own rows but cannot write arbitrary
-- completion state directly through the table API.
revoke all on table public.simulation_progress from anon, authenticated;
grant select on table public.simulation_progress to authenticated;

create or replace function public.enforce_simulation_progress_catalog()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_catalog_grade_level text;
  v_required_completion_step integer;
begin
  select grade_level, required_completion_step
  into v_catalog_grade_level, v_required_completion_step
  from public.simulation_story_catalog
  where story_id = new.story_id;

  if not found or new.grade_level <> v_catalog_grade_level then
    raise exception using errcode = '22023', message = 'Unknown Simulation story or grade level.';
  end if;

  if new.current_step > v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation progress is beyond this story.';
  end if;

  return new;
end;
$$;

revoke all on function public.enforce_simulation_progress_catalog() from public;

drop trigger if exists simulation_progress_catalog_guard on public.simulation_progress;
create trigger simulation_progress_catalog_guard
before insert or update on public.simulation_progress
for each row execute procedure public.enforce_simulation_progress_catalog();

-- A second guard runs inside the existing atomic rewards function. It requires
-- a known story, its final core step, and a minimally shaped student transcript
-- before an event can award +10 XP.
create or replace function public.enforce_simulation_completion_reward()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_required_completion_step integer;
  v_progress public.simulation_progress%rowtype;
  v_student_response_count integer;
begin
  if new.module <> 'simulation' then
    return new;
  end if;

  if new.activity_type <> 'story_completed' then
    raise exception using errcode = '22023', message = 'Invalid Simulation activity.';
  end if;

  select required_completion_step
  into v_required_completion_step
  from public.simulation_story_catalog
  where story_id = new.topic
    and grade_level = (new.metadata ->> 'grade_level');

  if not found
    or coalesce(new.metadata ->> 'story_id', '') <> new.topic
    or new.event_key <> 'simulation:' || new.topic || ':completed' then
    raise exception using errcode = '22023', message = 'Invalid Simulation completion details.';
  end if;

  select *
  into v_progress
  from public.simulation_progress
  where user_id = new.user_id
    and story_id = new.topic;

  if not found
    or v_progress.status <> 'in_progress'
    or v_progress.grade_level <> (new.metadata ->> 'grade_level')
    or v_progress.current_step < v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation story is not ready to complete.';
  end if;

  select count(*)
  into v_student_response_count
  from jsonb_array_elements(v_progress.response_history) as history_item
  where history_item ->> 'role' = 'student';

  if v_student_response_count < v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation story is not ready to complete.';
  end if;

  return new;
end;
$$;

revoke all on function public.enforce_simulation_completion_reward() from public;

drop trigger if exists simulation_completion_reward_guard on public.activity_events;
create trigger simulation_completion_reward_guard
before insert on public.activity_events
for each row execute procedure public.enforce_simulation_completion_reward();

create or replace function public.upsert_simulation_progress(
  p_story_id text,
  p_grade_level text,
  p_current_step integer,
  p_attempts integer default 0,
  p_help_uses integer default 0,
  p_guidance_level integer default 0,
  p_response_history jsonb default '[]'::jsonb
)
returns table (
  story_id text,
  grade_level text,
  status text,
  current_step integer,
  attempts integer,
  help_uses integer,
  guidance_level integer,
  response_history jsonb,
  completed_at timestamptz,
  updated_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_catalog_grade_level text;
  v_required_completion_step integer;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  if p_story_id is null or p_story_id !~ '^[a-z0-9][a-z0-9-]{1,120}$' then
    raise exception using errcode = '22023', message = 'Invalid Simulation story.';
  end if;

  if p_grade_level not in ('entry', 'middle', 'high') then
    raise exception using errcode = '22023', message = 'Invalid Simulation grade level.';
  end if;

  select grade_level, required_completion_step
  into v_catalog_grade_level, v_required_completion_step
  from public.simulation_story_catalog
  where story_id = p_story_id;

  if not found or p_grade_level <> v_catalog_grade_level then
    raise exception using errcode = '22023', message = 'Invalid Simulation story or grade level.';
  end if;

  if p_current_step is null or p_current_step < 0 or p_current_step > 100
    or p_attempts is null or p_attempts < 0 or p_attempts > 1000
    or p_help_uses is null or p_help_uses < 0 or p_help_uses > 1000
    or p_guidance_level is null or p_guidance_level < 0 or p_guidance_level > 3 then
    raise exception using errcode = '22023', message = 'Invalid Simulation progress.';
  end if;

  if p_current_step > v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation progress is beyond this story.';
  end if;

  if p_response_history is null or jsonb_typeof(p_response_history) <> 'array' then
    raise exception using errcode = '22023', message = 'Simulation response history must be a list.';
  end if;

  if jsonb_array_length(p_response_history) > 12
    or octet_length(p_response_history::text) > 12000 then
    raise exception using errcode = '22023', message = 'Simulation response history is too large.';
  end if;

  if exists (
    select 1
    from jsonb_array_elements(p_response_history) as history_item
    where jsonb_typeof(history_item) <> 'object'
      or octet_length(history_item::text) > 1200
  ) then
    raise exception using errcode = '22023', message = 'Simulation response history is invalid.';
  end if;

  -- A completion is only written by record_activity_event after it records the
  -- idempotent completion event. This call is deliberately limited to resumable
  -- in-progress state, and never downgrades an already completed story.
  insert into public.simulation_progress as progress (
    user_id,
    story_id,
    grade_level,
    status,
    current_step,
    attempts,
    help_uses,
    guidance_level,
    response_history
  ) values (
    v_user_id,
    p_story_id,
    p_grade_level,
    'in_progress',
    p_current_step,
    p_attempts,
    p_help_uses,
    p_guidance_level,
    p_response_history
  ) on conflict (user_id, story_id) do update
  set grade_level = excluded.grade_level,
      current_step = excluded.current_step,
      attempts = excluded.attempts,
      help_uses = excluded.help_uses,
      guidance_level = excluded.guidance_level,
      response_history = excluded.response_history
  where progress.status = 'in_progress'
  returning
    progress.story_id,
    progress.grade_level,
    progress.status,
    progress.current_step,
    progress.attempts,
    progress.help_uses,
    progress.guidance_level,
    progress.response_history,
    progress.completed_at,
    progress.updated_at
  into
    story_id,
    grade_level,
    status,
    current_step,
    attempts,
    help_uses,
    guidance_level,
    response_history,
    completed_at,
    updated_at;

  if not found then
    select
      progress.story_id,
      progress.grade_level,
      progress.status,
      progress.current_step,
      progress.attempts,
      progress.help_uses,
      progress.guidance_level,
      progress.response_history,
      progress.completed_at,
      progress.updated_at
    into
      story_id,
      grade_level,
      status,
      current_step,
      attempts,
      help_uses,
      guidance_level,
      response_history,
      completed_at,
      updated_at
    from public.simulation_progress as progress
    where progress.user_id = v_user_id
      and progress.story_id = p_story_id;
  end if;

  return next;
end;
$$;

-- Simulation completions use the existing single secure rewards function, but
-- must now reference an existing in-progress row and an exact stable story key.
-- This keeps the +10 XP update, daily totals, and module progress update in the
-- same transaction as the completion-state transition.
create or replace function public.record_activity_event(
  p_event_key text,
  p_module text,
  p_topic text default null,
  p_activity_type text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns table (
  event_id uuid,
  event_recorded boolean,
  total_xp integer,
  coin_balance integer,
  current_streak integer,
  local_date date,
  today_xp integer,
  today_coins_earned integer,
  today_activities_completed integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_timezone text;
  v_profile_grade_level text;
  v_activity_grade_level text;
  v_local_date date;
  v_xp_delta integer := 0;
  v_coin_delta integer := 0;
  v_event_id uuid;
  v_stats public.student_stats%rowtype;
  v_today public.daily_activity%rowtype;
  v_simulation_progress public.simulation_progress%rowtype;
  v_simulation_story_id text;
  v_simulation_required_completion_step integer;
  v_attempt_increment integer := 0;
  v_correct_increment integer := 0;
  v_completed_increment integer := 0;
  v_daily_completion_increment integer := 0;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  if p_event_key is null or p_event_key !~ '^[a-z0-9][a-z0-9:_-]{2,180}$' then
    raise exception using errcode = '22023', message = 'Invalid activity event key.';
  end if;

  if p_metadata is null or jsonb_typeof(p_metadata) <> 'object' then
    raise exception using errcode = '22023', message = 'Invalid activity metadata.';
  end if;

  select timezone, grade_level
  into v_timezone, v_profile_grade_level
  from public.profiles
  where id = v_user_id;

  if not found then
    raise exception using errcode = '22023', message = 'Student profile is unavailable.';
  end if;

  v_activity_grade_level := v_profile_grade_level;
  if p_module = 'decision' then
    v_activity_grade_level := coalesce(nullif(p_metadata ->> 'grade_level', ''), v_profile_grade_level);
    if v_activity_grade_level not in ('entry', 'middle', 'high') then
      raise exception using errcode = '22023', message = 'Invalid decision grade level.';
    end if;
  elsif p_module = 'simulation' then
    v_activity_grade_level := nullif(trim(p_metadata ->> 'grade_level'), '');
    if v_activity_grade_level not in ('entry', 'middle', 'high') then
      raise exception using errcode = '22023', message = 'Invalid Simulation grade level.';
    end if;
  end if;

  v_local_date := (now() at time zone coalesce(nullif(v_timezone, ''), 'UTC'))::date;

  if p_module in ('decision', 'quant', 'simulation', 'arcade')
    and p_event_key !~ ('^' || p_module || ':') then
    raise exception using errcode = '22023', message = 'Activity key does not match its module.';
  end if;

  if p_module = 'decision' and p_activity_type = 'correct_answer'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:correct$' then
    raise exception using errcode = '22023', message = 'Invalid decision completion key.';
  end if;

  if p_module = 'decision' and p_activity_type = 'incorrect_answer'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:incorrect$' then
    raise exception using errcode = '22023', message = 'Invalid decision completion key.';
  end if;

  if p_module = 'decision' and p_activity_type = 'hint'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:hint$' then
    raise exception using errcode = '22023', message = 'Invalid decision hint key.';
  end if;

  if p_module = 'simulation' then
    if p_activity_type <> 'story_completed'
      or p_event_key !~ '^simulation:[a-z0-9][a-z0-9-]{1,120}:completed$' then
      raise exception using errcode = '22023', message = 'Invalid Simulation completion key.';
    end if;

    v_simulation_story_id := substring(
      p_event_key from '^simulation:([a-z0-9][a-z0-9-]{1,120}):completed$'
    );

    if nullif(trim(p_topic), '') <> v_simulation_story_id
      or nullif(trim(p_metadata ->> 'story_id'), '') <> v_simulation_story_id then
      raise exception using errcode = '22023', message = 'Simulation story details do not match.';
    end if;

    select required_completion_step
    into v_simulation_required_completion_step
    from public.simulation_story_catalog
    where story_id = v_simulation_story_id
      and grade_level = v_activity_grade_level;

    if not found then
      raise exception using errcode = '22023', message = 'Unknown Simulation story or grade level.';
    end if;
  end if;

  -- The client selects a semantic event only. It never supplies XP or coin totals.
  case
    when p_module = 'decision' and p_activity_type = 'correct_answer' then
      v_xp_delta := 5;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'decision' and p_activity_type = 'incorrect_answer' then
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'decision' and p_activity_type = 'hint' then
      v_coin_delta := -10;
    when p_module = 'quant' and p_activity_type = 'correct_answer' then
      v_xp_delta := 1;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'quant' and p_activity_type = 'hint' then
      v_coin_delta := -2;
      v_attempt_increment := 1;
    when p_module = 'simulation' and p_activity_type = 'story_completed' then
      v_xp_delta := 10;
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'arcade' and p_activity_type = 'arcade_correct' then
      v_coin_delta := 1;
      v_daily_completion_increment := 1;
    when p_module = 'daily_challenge' and p_activity_type = 'daily_challenge' then
      v_xp_delta := 20;
      v_coin_delta := 20;
      v_daily_completion_increment := 1;
      if p_event_key <> 'daily:' || to_char(v_local_date, 'YYYY-MM-DD') then
        raise exception using errcode = '22023', message = 'Daily activity key does not match the student date.';
      end if;
    when p_module = 'streak' and p_activity_type = 'streak_repair' then
      v_coin_delta := -200;
      if p_event_key !~ '^streak:repair:[0-9]{4}-[0-9]{2}-[0-9]{2}$' then
        raise exception using errcode = '22023', message = 'Invalid streak repair key.';
      end if;
    else
      raise exception using errcode = '22023', message = 'Invalid Numora reward activity.';
  end case;

  if p_module in ('decision', 'quant', 'simulation')
    and (p_topic is null or length(trim(p_topic)) = 0) then
    raise exception using errcode = '22023', message = 'A learning topic is required.';
  end if;

  insert into public.student_stats (user_id)
  values (v_user_id)
  on conflict (user_id) do nothing;

  -- Lock the wallet row before checking the event key. Concurrent retries for the
  -- same student therefore serialize: the second call returns a safe duplicate
  -- result instead of inserting or awarding twice.
  select *
  into v_stats
  from public.student_stats
  where user_id = v_user_id
  for update;

  select id
  into v_event_id
  from public.activity_events
  where user_id = v_user_id
    and event_key = p_event_key;

  if found then
    select *
    into v_today
    from public.daily_activity
    where user_id = v_user_id
      and local_date = v_local_date;

    return query select
      v_event_id,
      false,
      v_stats.total_xp,
      v_stats.coin_balance,
      v_stats.current_streak,
      v_local_date,
      coalesce(v_today.xp_earned, 0),
      coalesce(v_today.coins_earned, 0),
      coalesce(v_today.activities_completed, 0);
    return;
  end if;

  if p_module = 'simulation' then
    select *
    into v_simulation_progress
    from public.simulation_progress
    where user_id = v_user_id
      and story_id = v_simulation_story_id
    for update;

    if not found
      or v_simulation_progress.status <> 'in_progress'
      or v_simulation_progress.grade_level <> v_activity_grade_level
      or v_simulation_progress.current_step < v_simulation_required_completion_step then
      raise exception using errcode = '22023', message = 'Simulation story is not ready to complete.';
    end if;
  end if;

  if v_stats.coin_balance + v_coin_delta < 0 then
    raise exception using errcode = '22023', message = 'Insufficient coins.';
  end if;

  insert into public.activity_events (
    user_id,
    event_key,
    module,
    topic,
    activity_type,
    xp_delta,
    coin_delta,
    metadata,
    occurred_at,
    local_date
  ) values (
    v_user_id,
    p_event_key,
    p_module,
    nullif(trim(p_topic), ''),
    p_activity_type,
    v_xp_delta,
    v_coin_delta,
    p_metadata,
    now(),
    v_local_date
  ) returning id into v_event_id;

  update public.student_stats
  set total_xp = total_xp + v_xp_delta,
      coin_balance = coin_balance + v_coin_delta
  where user_id = v_user_id
  returning * into v_stats;

  insert into public.daily_activity (
    user_id,
    local_date,
    xp_earned,
    coins_earned,
    activities_completed
  ) values (
    v_user_id,
    v_local_date,
    v_xp_delta,
    greatest(v_coin_delta, 0),
    v_daily_completion_increment
  ) on conflict (user_id, local_date) do update
  set xp_earned = public.daily_activity.xp_earned + excluded.xp_earned,
      coins_earned = public.daily_activity.coins_earned + excluded.coins_earned,
      activities_completed = public.daily_activity.activities_completed + excluded.activities_completed
  returning * into v_today;

  if p_module in ('decision', 'quant', 'simulation') then
    insert into public.module_progress (
      user_id,
      module,
      grade_level,
      topic,
      completed_count,
      correct_count,
      attempt_count
    ) values (
      v_user_id,
      p_module,
      v_activity_grade_level,
      trim(p_topic),
      v_completed_increment,
      v_correct_increment,
      v_attempt_increment
    ) on conflict (user_id, module, grade_level, topic) do update
    set completed_count = public.module_progress.completed_count + excluded.completed_count,
        correct_count = public.module_progress.correct_count + excluded.correct_count,
        attempt_count = public.module_progress.attempt_count + excluded.attempt_count;
  end if;

  if p_module = 'simulation' then
    update public.simulation_progress
    set status = 'completed',
        completed_at = coalesce(completed_at, now())
    where user_id = v_user_id
      and story_id = v_simulation_story_id;
  end if;

  return query select
    v_event_id,
    true,
    v_stats.total_xp,
    v_stats.coin_balance,
    v_stats.current_streak,
    v_local_date,
    v_today.xp_earned,
    v_today.coins_earned,
    v_today.activities_completed;
end;
$$;

revoke all on function public.upsert_simulation_progress(text, text, integer, integer, integer, integer, jsonb) from public;
revoke all on function public.record_activity_event(text, text, text, text, jsonb) from public;

grant execute on function public.upsert_simulation_progress(text, text, integer, integer, integer, integer, jsonb) to authenticated;
grant execute on function public.record_activity_event(text, text, text, text, jsonb) to authenticated;
