-- Numora database SETUP audit through Phase 8.2. Run in SQL Editor as postgres.
-- Read-only: no accounts, rewards, rows, functions, or permissions are changed.
-- Works even when required tables/functions are missing. Expected: missing = 0.
-- Phase 1 is frontend-only. This is not a live behavior/security certification;
-- it does not validate seed-row contents, email settings, Gemini, or app screens.
with
tables(phase, name, columns, pk) as (values
 ('2', 'public.profiles', 'id,first_name,last_name,grade_level,timezone,created_at,updated_at,timezone_changed_at', 'id'),
 ('2', 'public.student_stats', 'user_id,total_xp,coin_balance,current_streak,last_streak_date,created_at,updated_at,last_streak_checked_date', 'user_id'),
 ('2', 'public.activity_events', 'id,user_id,event_key,module,topic,activity_type,xp_delta,coin_delta,metadata,occurred_at,local_date,created_at', 'id'),
 ('2', 'public.module_progress', 'user_id,module,grade_level,topic,completed_count,correct_count,attempt_count,updated_at', 'user_id,module,grade_level,topic'),
 ('2', 'public.daily_activity', 'user_id,local_date,xp_earned,coins_earned,activities_completed,updated_at', 'user_id,local_date'),
 ('5', 'public.simulation_story_catalog', 'story_id,grade_level,required_completion_step', 'story_id'),
 ('5', 'public.simulation_progress', 'user_id,story_id,grade_level,status,current_step,attempts,help_uses,guidance_level,response_history,completed_at,created_at,updated_at', 'user_id,story_id'),
 ('6', 'public.arcade_state', 'user_id,lives,regeneration_started_at,updated_at', 'user_id'),
 ('6', 'public.arcade_life_events', 'user_id,event_key,created_at', 'user_id,event_key'),
 ('7', 'public.reward_rules', 'event_type,module,activity_type,xp,coins', 'event_type'),
 ('7', 'public.streak_days', 'user_id,local_date,source,celebrated_at,created_at', 'user_id,local_date'),
 ('7', 'public.daily_challenges', 'user_id,local_date,challenge_id,grade_level,timezone,completed,completed_at,attempt_count,created_at,updated_at', 'user_id,local_date'),
 ('7', 'numora_private.challenge_bank', 'id,grade_level,topic,question,options,answer,hint,explanation', 'id')
), functions(phase, signature, kind) as (values
 ('2', 'public.set_profile_updated_at()', 'trigger'),
 ('2', 'public.handle_new_user()', 'trigger'),
 ('2', 'public.set_numora_updated_at()', 'trigger'),
 ('2', 'public.initialize_student_stats()', 'trigger'),
 ('3', 'public.record_activity_event(text,text,text,text,jsonb)', 'rpc'),
 ('4', 'public.record_quant_activity_event(text,text,text,jsonb)', 'rpc'),
 ('5', 'public.upsert_simulation_progress(text,text,integer,integer,integer,integer,jsonb)', 'rpc'),
 ('5', 'public.enforce_simulation_progress_catalog()', 'private'),
 ('5', 'public.enforce_simulation_completion_reward()', 'private'),
 ('6', 'public.set_arcade_state_updated_at()', 'private'),
 ('6', 'public.refresh_arcade_lives(uuid)', 'private'),
 ('6', 'public.get_my_arcade_state()', 'rpc'),
 ('6', 'public.lose_arcade_life(text)', 'rpc'),
 ('7', 'numora_private.guard_timezone()', 'private'),
 ('7', 'numora_private.local_day(uuid)', 'private'),
 ('7', 'numora_private.sync_streak(uuid)', 'private'),
 ('7', 'numora_private.award(text,text,text,text,jsonb)', 'private'),
 ('7', 'numora_private.challenge_for(uuid,date,text)', 'private'),
 ('7', 'numora_private.challenge_available_at(uuid)', 'private'),
 ('7', 'public.get_my_today_activity()', 'rpc'),
 ('7', 'public.get_my_economy_snapshot()', 'rpc'),
 ('7', 'public.get_my_daily_challenge(text)', 'rpc'),
 ('7', 'public.submit_daily_challenge(text,text,date,text)', 'rpc'),
 ('7', 'public.repair_my_streak(date)', 'rpc'),
 ('8.1', 'numora_private.weekly_window(uuid,timestamp with time zone)', 'private'),
 ('8.1', 'public.get_my_weekly_xp()', 'rpc'),
 ('8.1', 'public.get_weekly_leaderboard(integer)', 'rpc'),
 ('8.2', 'numora_private.calendar_window(uuid,timestamp with time zone)', 'private'),
 ('8.2', 'numora_private.guard_arcade_reward_lives()', 'private'),
 ('8.2', 'public.get_weekly_tournament(integer)', 'rpc')
), triggers(phase, relation, name, function_name, trigger_type) as (values
 ('2', 'auth.users', 'on_auth_user_created', 'public.handle_new_user()', 5),
 ('2', 'public.profiles', 'profiles_set_updated_at', 'public.set_profile_updated_at()', 19),
 ('2', 'public.profiles', 'profiles_initialize_student_stats', 'public.initialize_student_stats()', 5),
 ('2', 'public.student_stats', 'student_stats_set_updated_at', 'public.set_numora_updated_at()', 19),
 ('2', 'public.module_progress', 'module_progress_set_updated_at', 'public.set_numora_updated_at()', 19),
 ('2', 'public.daily_activity', 'daily_activity_set_updated_at', 'public.set_numora_updated_at()', 19),
 ('5', 'public.simulation_progress', 'simulation_progress_set_updated_at', 'public.set_numora_updated_at()', 19),
 ('5', 'public.simulation_progress', 'simulation_progress_catalog_guard', 'public.enforce_simulation_progress_catalog()', 23),
 ('5', 'public.activity_events', 'simulation_completion_reward_guard', 'public.enforce_simulation_completion_reward()', 7),
 ('6', 'public.arcade_state', 'arcade_state_set_updated_at', 'public.set_arcade_state_updated_at()', 19),
 ('7', 'public.profiles', 'profiles_guard_timezone', 'numora_private.guard_timezone()', 23),
 ('8.2', 'public.activity_events', 'activity_events_arcade_lives', 'numora_private.guard_arcade_reward_lives()', 7)
), policies(relation, name, command, own_row) as (values
 ('public.profiles', 'Students can view their own profile', 'r', true),
 ('public.profiles', 'Students can create their own profile', 'a', true),
 ('public.profiles', 'Students can update their own profile', 'w', true),
 ('public.student_stats', 'Students can view their own stats', 'r', true),
 ('public.activity_events', 'Students can view their own activity events', 'r', true),
 ('public.module_progress', 'Students can view their own module progress', 'r', true),
 ('public.daily_activity', 'Students can view their own daily activity', 'r', true),
 ('public.simulation_progress', 'Students can view their own simulation progress', 'r', true),
 ('public.arcade_state', 'Students can view their own Arcade state', 'r', true),
 ('public.reward_rules', 'Read reward rules', 'r', false),
 ('public.streak_days', 'Read own streak days', 'r', true),
 ('public.daily_challenges', 'Read own daily challenges', 'r', true)
), versions(phase, signature, required_text) as (values
 ('7', 'public.record_activity_event(text,text,text,text,jsonb)', 'numora_private.award'),
 ('7', 'public.record_quant_activity_event(text,text,text,jsonb)', 'record_activity_event'),
 ('7', 'numora_private.award(text,text,text,text,jsonb)', 'reward_rules'),
 ('7', 'public.submit_daily_challenge(text,text,date,text)', 'numora_private.award'),
 ('7', 'public.repair_my_streak(date)', 'numora_private.award'),
 ('8.1', 'public.get_my_weekly_xp()', 'weekly_window'),
 ('8.1', 'public.get_weekly_leaderboard(integer)', 'weekly_window'),
 ('8.2', 'numora_private.weekly_window(uuid,timestamp with time zone)', 'calendar_window'),
 ('8.2', 'numora_private.local_day(uuid)', 'calendar_window'),
 ('8.2', 'public.get_my_today_activity()', 'calendar_window'),
 ('8.2', 'public.get_my_economy_snapshot()', 'calendar_window'),
 ('8.2', 'public.get_weekly_tournament(integer)', 'calendar_window'),
 ('8.2', 'public.lose_arcade_life(text)', 'lives = s.lives - 1'),
 ('8.2', 'public.upsert_simulation_progress(text,text,integer,integer,integer,integer,jsonb)', 'on conflict on constraint simulation_progress_pkey')
), unique_keys(relation, columns) as (values
 ('public.activity_events', 'user_id,event_key'),
 ('public.reward_rules', 'module,activity_type')
), indexes(name) as (values
 ('public.activity_events_user_occurred_at_idx'), ('public.daily_activity_user_local_date_idx'),
 ('public.simulation_progress_user_status_updated_at_idx'), ('public.daily_activity_weekly_idx')
), checks(phase, item, ok) as (
 select phase, 'Table: ' || name, exists (select 1 from pg_class where oid = to_regclass(name) and relkind in ('r','p')) from tables
 union all
 select phase, 'Column: ' || name || '.' || col, exists (select 1 from pg_attribute where attrelid = to_regclass(name) and attname = col and attnum > 0 and not attisdropped)
 from tables cross join lateral unnest(string_to_array(columns, ',')) col
 union all
 select phase, 'RLS enabled: ' || name, (select relrowsecurity from pg_class where oid = to_regclass(name)) from tables where name like 'public.%'
 union all
 select phase, 'Primary key: ' || name, exists (select 1 from pg_constraint c where c.conrelid = to_regclass(name) and c.contype = 'p'
   and (select string_agg(a.attname, ',' order by k.n) from unnest(c.conkey) with ordinality k(id,n) join pg_attribute a on a.attrelid = c.conrelid and a.attnum = k.id) = pk) from tables
 union all
 select phase, 'User foreign key: ' || name, exists (select 1 from pg_constraint c
   join pg_attribute a on a.attrelid = c.conrelid and c.conkey = array[a.attnum]
   join pg_attribute b on b.attrelid = c.confrelid and c.confkey = array[b.attnum]
   where c.conrelid = to_regclass(name) and c.contype = 'f' and c.confrelid = to_regclass('auth.users') and c.confdeltype = 'c'
   and b.attname = 'id' and a.attname = case when name = 'public.profiles' then 'id' else 'user_id' end)
 from tables where name = 'public.profiles' or columns like 'user_id,%' or name = 'public.activity_events'
 union all
 select phase, 'Function: ' || signature, to_regprocedure(signature) is not null from functions
 union all
 select phase, 'RPC permissions: ' || signature,
   has_function_privilege('authenticated', to_regprocedure(signature), 'EXECUTE')
   and not has_function_privilege('anon', to_regprocedure(signature), 'EXECUTE')
   and (select prosecdef and proconfig is not null from pg_proc where oid = to_regprocedure(signature)) from functions where kind = 'rpc'
 union all
 select phase, 'Internal function private: ' || signature,
   not has_function_privilege('authenticated', to_regprocedure(signature), 'EXECUTE')
   and not has_function_privilege('anon', to_regprocedure(signature), 'EXECUTE') from functions where kind = 'private'
 union all
 select phase, 'Trigger: ' || name, exists (select 1 from pg_trigger where tgrelid = to_regclass(relation) and tgname = name
   and tgenabled in ('O','A') and tgfoid = to_regprocedure(function_name) and tgtype = trigger_type) from triggers
 union all
 select 'Security', 'Policy: ' || e.relation || ' / ' || e.name, exists (select 1 from pg_policy p
   where p.polrelid = to_regclass(e.relation) and p.polname = e.name and p.polcmd::text = e.command
   and p.polroles = array[(select oid from pg_roles where rolname = 'authenticated')]
   and (not e.own_row or (case when e.command = 'a' then pg_get_expr(p.polwithcheck,p.polrelid) else pg_get_expr(p.polqual,p.polrelid) end) like '%auth.uid()%')
   and (e.command <> 'w' or pg_get_expr(p.polwithcheck,p.polrelid) like '%auth.uid()%')) from policies e
 union all
 select 'Security', 'Unexpected policy: ' || t.name || ' / ' || p.polname, false from tables t join pg_policy p on p.polrelid = to_regclass(t.name)
 where not exists (select 1 from policies e where to_regclass(e.relation) = p.polrelid and e.name = p.polname)
 union all
 select phase, 'Current implementation: ' || signature || ' [' || required_text || ']',
   (select position(required_text in prosrc) > 0 from pg_proc where oid = to_regprocedure(signature)) from versions
 union all
 select 'Security', 'Unique key: ' || relation || '(' || columns || ')', exists (select 1 from pg_constraint c where c.conrelid = to_regclass(relation) and c.contype in ('p','u')
   and (select string_agg(a.attname, ',' order by k.n) from unnest(c.conkey) with ordinality k(id,n) join pg_attribute a on a.attrelid = c.conrelid and a.attnum = k.id) = columns) from unique_keys
 union all
 select 'Performance', 'Index: ' || name, exists (select 1 from pg_index where indexrelid = to_regclass(name) and indisvalid and indisready) from indexes
 union all
 select 'Security', 'Private schema blocks client access', not has_schema_privilege('authenticated', to_regnamespace('numora_private'), 'USAGE')
   and not has_schema_privilege('anon', to_regnamespace('numora_private'), 'USAGE')
 union all
 select 'Security', 'Internal table private: ' || name,
   not has_table_privilege('authenticated', to_regclass(name), 'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER')
   and not has_table_privilege('anon', to_regclass(name), 'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER')
 from tables where name in ('numora_private.challenge_bank','public.simulation_story_catalog','public.arcade_life_events')
 union all
 select '8.1', 'Leaderboard returns JSON snapshot', (select prorettype = 'jsonb'::regtype from pg_proc where oid = to_regprocedure('public.get_weekly_leaderboard(integer)'))
)
select count(*)::integer as checks_run,
 count(*) filter (where not coalesce(ok,false))::integer as missing,
 coalesce(jsonb_agg(jsonb_build_object('phase',phase,'check',item) order by phase,item)
   filter (where not coalesce(ok,false)), '[]'::jsonb) as failed_checks,
 'Setup checks only; seed contents, live accounts, email, Gemini and app behavior need separate testing.' as scope
from checks;
