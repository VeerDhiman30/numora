-- Numora Phase 3.3: Decision Lab rewards and academic-progress events.
-- Run this after 001_profiles.sql and progress-schema.sql in the Supabase SQL editor.

alter table public.activity_events
drop constraint if exists activity_events_activity_type_check;

alter table public.activity_events
add constraint activity_events_activity_type_check
check (activity_type in ('correct_answer', 'incorrect_answer', 'hint', 'story_completed', 'arcade_correct', 'daily_challenge', 'streak_repair'));

create or replace function public.record_activity_event(
  p_event_key text,
  p_module text,
  p_topic text default null,
  p_activity_type text default null,
  p_metadata jsonb default '{}'::jsonb
)
returns table (
  event_id uuid,
  event_recorded boolean,
  total_xp integer,
  coin_balance integer,
  current_streak integer,
  local_date date,
  today_xp integer,
  today_coins_earned integer,
  today_activities_completed integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_timezone text;
  v_profile_grade_level text;
  v_activity_grade_level text;
  v_local_date date;
  v_xp_delta integer := 0;
  v_coin_delta integer := 0;
  v_event_id uuid;
  v_stats public.student_stats%rowtype;
  v_today public.daily_activity%rowtype;
  v_attempt_increment integer := 0;
  v_correct_increment integer := 0;
  v_completed_increment integer := 0;
  v_daily_completion_increment integer := 0;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  if p_event_key is null or p_event_key !~ '^[a-z0-9][a-z0-9:_-]{2,180}$' then
    raise exception using errcode = '22023', message = 'Invalid activity event key.';
  end if;

  if p_metadata is null or jsonb_typeof(p_metadata) <> 'object' then
    raise exception using errcode = '22023', message = 'Invalid activity metadata.';
  end if;

  select timezone, grade_level
  into v_timezone, v_profile_grade_level
  from public.profiles
  where id = v_user_id;

  if not found then
    raise exception using errcode = '22023', message = 'Student profile is unavailable.';
  end if;

  v_activity_grade_level := v_profile_grade_level;
  if p_module = 'decision' then
    v_activity_grade_level := coalesce(nullif(p_metadata ->> 'grade_level', ''), v_profile_grade_level);
    if v_activity_grade_level not in ('entry', 'middle', 'high') then
      raise exception using errcode = '22023', message = 'Invalid decision grade level.';
    end if;
  end if;

  v_local_date := (now() at time zone coalesce(nullif(v_timezone, ''), 'UTC'))::date;

  if p_module in ('decision', 'quant', 'simulation', 'arcade')
    and p_event_key !~ ('^' || p_module || ':') then
    raise exception using errcode = '22023', message = 'Activity key does not match its module.';
  end if;

  if p_module = 'decision' and p_activity_type = 'correct_answer'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:correct$' then
    raise exception using errcode = '22023', message = 'Invalid decision completion key.';
  end if;

  if p_module = 'decision' and p_activity_type = 'incorrect_answer'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:incorrect$' then
    raise exception using errcode = '22023', message = 'Invalid decision completion key.';
  end if;

  if p_module = 'decision' and p_activity_type = 'hint'
    and p_event_key !~ '^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:hint$' then
    raise exception using errcode = '22023', message = 'Invalid decision hint key.';
  end if;

  case
    when p_module = 'decision' and p_activity_type = 'correct_answer' then
      v_xp_delta := 5;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'decision' and p_activity_type = 'incorrect_answer' then
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'decision' and p_activity_type = 'hint' then
      v_coin_delta := -10;
    when p_module = 'quant' and p_activity_type = 'correct_answer' then
      v_xp_delta := 1;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'quant' and p_activity_type = 'hint' then
      v_coin_delta := -2;
      v_attempt_increment := 1;
    when p_module = 'simulation' and p_activity_type = 'story_completed' then
      v_xp_delta := 10;
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_module = 'arcade' and p_activity_type = 'arcade_correct' then
      v_coin_delta := 1;
      v_daily_completion_increment := 1;
    when p_module = 'daily_challenge' and p_activity_type = 'daily_challenge' then
      v_xp_delta := 20;
      v_coin_delta := 20;
      v_daily_completion_increment := 1;
      if p_event_key <> 'daily:' || to_char(v_local_date, 'YYYY-MM-DD') then
        raise exception using errcode = '22023', message = 'Daily activity key does not match the student date.';
      end if;
    when p_module = 'streak' and p_activity_type = 'streak_repair' then
      v_coin_delta := -200;
      if p_event_key !~ '^streak:repair:[0-9]{4}-[0-9]{2}-[0-9]{2}$' then
        raise exception using errcode = '22023', message = 'Invalid streak repair key.';
      end if;
    else
      raise exception using errcode = '22023', message = 'Invalid Numora reward activity.';
  end case;

  if p_module in ('decision', 'quant', 'simulation')
    and (p_topic is null or length(trim(p_topic)) = 0) then
    raise exception using errcode = '22023', message = 'A learning topic is required.';
  end if;

  insert into public.student_stats (user_id)
  values (v_user_id)
  on conflict (user_id) do nothing;

  select * into v_stats
  from public.student_stats
  where user_id = v_user_id
  for update;

  select id into v_event_id
  from public.activity_events
  where user_id = v_user_id and event_key = p_event_key;

  if found then
    select * into v_today
    from public.daily_activity
    where user_id = v_user_id and local_date = v_local_date;

    return query select
      v_event_id, false, v_stats.total_xp, v_stats.coin_balance, v_stats.current_streak,
      v_local_date, coalesce(v_today.xp_earned, 0), coalesce(v_today.coins_earned, 0),
      coalesce(v_today.activities_completed, 0);
    return;
  end if;

  if v_stats.coin_balance + v_coin_delta < 0 then
    raise exception using errcode = '22023', message = 'Insufficient coins.';
  end if;

  insert into public.activity_events (
    user_id, event_key, module, topic, activity_type, xp_delta, coin_delta, metadata, occurred_at, local_date
  ) values (
    v_user_id, p_event_key, p_module, nullif(trim(p_topic), ''), p_activity_type,
    v_xp_delta, v_coin_delta, p_metadata, now(), v_local_date
  ) returning id into v_event_id;

  update public.student_stats
  set total_xp = total_xp + v_xp_delta,
      coin_balance = coin_balance + v_coin_delta
  where user_id = v_user_id
  returning * into v_stats;

  insert into public.daily_activity (
    user_id, local_date, xp_earned, coins_earned, activities_completed
  ) values (
    v_user_id, v_local_date, v_xp_delta, greatest(v_coin_delta, 0), v_daily_completion_increment
  ) on conflict (user_id, local_date) do update
  set xp_earned = public.daily_activity.xp_earned + excluded.xp_earned,
      coins_earned = public.daily_activity.coins_earned + excluded.coins_earned,
      activities_completed = public.daily_activity.activities_completed + excluded.activities_completed
  returning * into v_today;

  if p_module in ('decision', 'quant', 'simulation') then
    insert into public.module_progress (
      user_id, module, grade_level, topic, completed_count, correct_count, attempt_count
    ) values (
      v_user_id, p_module, v_activity_grade_level, trim(p_topic),
      v_completed_increment, v_correct_increment, v_attempt_increment
    ) on conflict (user_id, module, grade_level, topic) do update
    set completed_count = public.module_progress.completed_count + excluded.completed_count,
        correct_count = public.module_progress.correct_count + excluded.correct_count,
        attempt_count = public.module_progress.attempt_count + excluded.attempt_count;
  end if;

  return query select
    v_event_id, true, v_stats.total_xp, v_stats.coin_balance, v_stats.current_streak,
    v_local_date, v_today.xp_earned, v_today.coins_earned, v_today.activities_completed;
end;
$$;

revoke all on function public.record_activity_event(text, text, text, text, jsonb) from public;
grant execute on function public.record_activity_event(text, text, text, text, jsonb) to authenticated;
