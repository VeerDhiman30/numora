-- Numora Phase 6: persistent Arcade lives and safe, timestamp-based regeneration.
-- Run after 005_simulation_security_hardening.sql.

begin;

create table if not exists public.arcade_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  lives integer not null default 8 check (lives between 0 and 8),
  regeneration_started_at timestamptz,
  updated_at timestamptz not null default now(),
  check (
    (lives = 8 and regeneration_started_at is null)
    or (lives < 8 and regeneration_started_at is not null)
  )
);

create table if not exists public.arcade_life_events (
  user_id uuid not null references auth.users(id) on delete cascade,
  event_key text not null check (event_key ~ '^arcade:[a-z0-9][a-z0-9:_-]{2,180}$'),
  created_at timestamptz not null default now(),
  primary key (user_id, event_key)
);

alter table public.arcade_state enable row level security;
alter table public.arcade_life_events enable row level security;

revoke all on table public.arcade_state from anon, authenticated;
revoke all on table public.arcade_life_events from anon, authenticated;

drop policy if exists "Students can view their own Arcade state" on public.arcade_state;
create policy "Students can view their own Arcade state"
on public.arcade_state for select
to authenticated
using ((select auth.uid()) = user_id);

create or replace function public.set_arcade_state_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists arcade_state_set_updated_at on public.arcade_state;
create trigger arcade_state_set_updated_at
before update on public.arcade_state
for each row execute procedure public.set_arcade_state_updated_at();

create or replace function public.refresh_arcade_lives(p_user_id uuid)
returns public.arcade_state
language plpgsql
security definer
set search_path = public
as $$
declare
  v_state public.arcade_state%rowtype;
  v_regenerated integer := 0;
begin
  insert into public.arcade_state (user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;

  select *
  into v_state
  from public.arcade_state
  where user_id = p_user_id
  for update;

  if v_state.lives < 8 and v_state.regeneration_started_at is not null then
    v_regenerated := floor(extract(epoch from (now() - v_state.regeneration_started_at)) / 180)::integer;

    if v_regenerated > 0 then
      update public.arcade_state
      set lives = least(8, lives + v_regenerated),
          regeneration_started_at = case
            when lives + v_regenerated >= 8 then null
            else regeneration_started_at + make_interval(secs => v_regenerated * 180)
          end
      where user_id = p_user_id
      returning * into v_state;
    end if;
  end if;

  return v_state;
end;
$$;

create or replace function public.get_my_arcade_state()
returns table (
  lives integer,
  next_regeneration_at timestamptz,
  updated_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_state public.arcade_state%rowtype;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  v_state := public.refresh_arcade_lives(v_user_id);

  return query select
    v_state.lives,
    case
      when v_state.lives < 8 then v_state.regeneration_started_at + interval '3 minutes'
      else null
    end,
    v_state.updated_at;
end;
$$;

create or replace function public.lose_arcade_life(p_event_key text)
returns table (
  life_lost boolean,
  lives integer,
  next_regeneration_at timestamptz,
  updated_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_state public.arcade_state%rowtype;
  v_recorded boolean := false;
  v_life_lost boolean := false;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  if p_event_key is null or p_event_key !~ '^arcade:[a-z0-9][a-z0-9:_-]{2,180}$' then
    raise exception using errcode = '22023', message = 'Invalid Arcade action.';
  end if;

  v_state := public.refresh_arcade_lives(v_user_id);

  insert into public.arcade_life_events (user_id, event_key)
  values (v_user_id, p_event_key)
  on conflict (user_id, event_key) do nothing;
  v_recorded := found;

  if v_recorded and v_state.lives > 0 then
    update public.arcade_state
    set lives = lives - 1,
        regeneration_started_at = case
          when lives = 8 then now()
          else regeneration_started_at
        end
    where user_id = v_user_id
    returning * into v_state;
    v_life_lost := true;
  end if;

  return query select
    v_life_lost,
    v_state.lives,
    case
      when v_state.lives < 8 then v_state.regeneration_started_at + interval '3 minutes'
      else null
    end,
    v_state.updated_at;
end;
$$;

revoke all on function public.refresh_arcade_lives(uuid) from public;
revoke all on function public.set_arcade_state_updated_at() from public;
revoke all on function public.get_my_arcade_state() from public;
revoke all on function public.lose_arcade_life(text) from public;

grant execute on function public.get_my_arcade_state() to authenticated;
grant execute on function public.lose_arcade_life(text) to authenticated;

commit;
