-- Optional READ-ONLY setup check after migration 008. Expected missing = 0.
-- This does not create users or award XP, or replace signed-in acceptance testing.
with functions as (
  select * from pg_proc where oid = to_regprocedure('public.get_weekly_leaderboard(integer)')
), checks(name, ok) as (
  values
    ('leaderboard JSON snapshot', (select prorettype = 'jsonb'::regtype from functions)),
    ('fixed-search-path definer', (select prosecdef and array_to_string(proconfig, ',') like '%search_path=""%' from functions)),
    ('authenticated execute only', coalesce(has_function_privilege('authenticated', to_regprocedure('public.get_weekly_leaderboard(integer)'), 'EXECUTE'), false)
      and not coalesce(has_function_privilege('anon', to_regprocedure('public.get_weekly_leaderboard(integer)'), 'EXECUTE'), true)),
    ('shared weekly window', to_regprocedure('numora_private.weekly_window(uuid,timestamp with time zone)') is not null),
    ('private helpers inaccessible', not coalesce(has_schema_privilege('authenticated', to_regnamespace('numora_private'), 'USAGE'), true)),
    ('weekly date index', to_regclass('public.daily_activity_weekly_idx') is not null),
    ('Dashboard prerequisite', to_regprocedure('public.get_my_economy_snapshot()') is not null),
    ('profiles RLS', (select relrowsecurity from pg_class where oid = to_regclass('public.profiles'))),
    ('daily XP RLS', (select relrowsecurity from pg_class where oid = to_regclass('public.daily_activity')))
)
select count(*) filter (where not coalesce(ok, false))::integer as missing,
  coalesce(array_agg(name) filter (where not coalesce(ok, false)), array[]::text[]) as failed_checks
from checks;
