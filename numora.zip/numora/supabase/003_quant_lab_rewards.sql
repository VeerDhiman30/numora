-- Numora Phase 4.4: secure Quant Lab reward and topic-progress events.
-- Run after 001_profiles.sql, progress-schema.sql, and 002_decision_lab_rewards.sql.
-- Quant events use this dedicated RPC so selected Quant grade levels are recorded
-- precisely while XP and coin balances remain server controlled.

create or replace function public.record_quant_activity_event(
  p_event_key text,
  p_topic text,
  p_activity_type text,
  p_metadata jsonb default '{}'::jsonb
)
returns table (
  event_id uuid,
  event_recorded boolean,
  total_xp integer,
  coin_balance integer,
  current_streak integer,
  local_date date,
  today_xp integer,
  today_coins_earned integer,
  today_activities_completed integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_timezone text;
  v_grade_level text;
  v_local_date date;
  v_xp_delta integer := 0;
  v_coin_delta integer := 0;
  v_attempt_increment integer := 0;
  v_correct_increment integer := 0;
  v_completed_increment integer := 0;
  v_daily_completion_increment integer := 0;
  v_event_id uuid;
  v_stats public.student_stats%rowtype;
  v_today public.daily_activity%rowtype;
begin
  if v_user_id is null then
    raise exception using errcode = '28000', message = 'Authentication is required.';
  end if;

  if p_event_key is null or p_event_key !~ '^quant:[a-z0-9][a-z0-9-]{1,120}:(correct|incorrect|hint)$' then
    raise exception using errcode = '22023', message = 'Invalid Quant activity key.';
  end if;

  if p_topic is null or length(trim(p_topic)) = 0 then
    raise exception using errcode = '22023', message = 'A Quant topic is required.';
  end if;

  if p_metadata is null or jsonb_typeof(p_metadata) <> 'object' then
    raise exception using errcode = '22023', message = 'Invalid Quant activity metadata.';
  end if;

  v_grade_level := nullif(p_metadata ->> 'grade_level', '');
  if v_grade_level not in ('entry', 'middle', 'high') then
    raise exception using errcode = '22023', message = 'Invalid Quant grade level.';
  end if;

  select timezone
  into v_timezone
  from public.profiles
  where id = v_user_id;

  if not found then
    raise exception using errcode = '22023', message = 'Student profile is unavailable.';
  end if;

  v_local_date := (now() at time zone coalesce(nullif(v_timezone, ''), 'UTC'))::date;

  case
    when p_activity_type = 'correct_answer' and p_event_key ~ ':correct$' then
      v_xp_delta := 1;
      v_attempt_increment := 1;
      v_correct_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_activity_type = 'incorrect_answer' and p_event_key ~ ':incorrect$' then
      v_attempt_increment := 1;
      v_completed_increment := 1;
      v_daily_completion_increment := 1;
    when p_activity_type = 'hint' and p_event_key ~ ':hint$' then
      v_coin_delta := -2;
    else
      raise exception using errcode = '22023', message = 'Invalid Quant activity.';
  end case;

  insert into public.student_stats (user_id)
  values (v_user_id)
  on conflict (user_id) do nothing;

  select * into v_stats
  from public.student_stats
  where user_id = v_user_id
  for update;

  select id into v_event_id
  from public.activity_events
  where user_id = v_user_id and event_key = p_event_key;

  if found then
    select * into v_today
    from public.daily_activity
    where user_id = v_user_id and local_date = v_local_date;

    return query select
      v_event_id, false, v_stats.total_xp, v_stats.coin_balance, v_stats.current_streak,
      v_local_date, coalesce(v_today.xp_earned, 0), coalesce(v_today.coins_earned, 0),
      coalesce(v_today.activities_completed, 0);
    return;
  end if;

  if v_stats.coin_balance + v_coin_delta < 0 then
    raise exception using errcode = '22023', message = 'Insufficient coins.';
  end if;

  insert into public.activity_events (
    user_id, event_key, module, topic, activity_type, xp_delta, coin_delta,
    metadata, occurred_at, local_date
  ) values (
    v_user_id, p_event_key, 'quant', trim(p_topic), p_activity_type, v_xp_delta,
    v_coin_delta, p_metadata, now(), v_local_date
  ) returning id into v_event_id;

  update public.student_stats
  set total_xp = total_xp + v_xp_delta,
      coin_balance = coin_balance + v_coin_delta
  where user_id = v_user_id
  returning * into v_stats;

  insert into public.daily_activity (
    user_id, local_date, xp_earned, coins_earned, activities_completed
  ) values (
    v_user_id, v_local_date, v_xp_delta, greatest(v_coin_delta, 0), v_daily_completion_increment
  ) on conflict (user_id, local_date) do update
  set xp_earned = public.daily_activity.xp_earned + excluded.xp_earned,
      coins_earned = public.daily_activity.coins_earned + excluded.coins_earned,
      activities_completed = public.daily_activity.activities_completed + excluded.activities_completed
  returning * into v_today;

  if p_activity_type in ('correct_answer', 'incorrect_answer') then
    insert into public.module_progress (
      user_id, module, grade_level, topic, completed_count, correct_count, attempt_count
    ) values (
      v_user_id, 'quant', v_grade_level, trim(p_topic), v_completed_increment,
      v_correct_increment, v_attempt_increment
    ) on conflict (user_id, module, grade_level, topic) do update
    set completed_count = public.module_progress.completed_count + excluded.completed_count,
        correct_count = public.module_progress.correct_count + excluded.correct_count,
        attempt_count = public.module_progress.attempt_count + excluded.attempt_count;
  end if;

  return query select
    v_event_id, true, v_stats.total_xp, v_stats.coin_balance, v_stats.current_streak,
    v_local_date, v_today.xp_earned, v_today.coins_earned, v_today.activities_completed;
end;
$$;

revoke all on function public.record_quant_activity_event(text, text, text, jsonb) from public;
grant execute on function public.record_quant_activity_event(text, text, text, jsonb) to authenticated;
