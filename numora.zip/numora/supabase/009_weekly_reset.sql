-- Phase 8.2. Run after 008. Additive, transactional, safe to rerun.
-- No XP, coins, streak days, challenges, or historical activities are deleted.
begin;

-- The single calendar authority. Convert LOCAL calendar midnights to instants;
-- adding 604800 seconds would be wrong during daylight-saving transitions.
-- p_now is private and only supports deterministic tests; clients cannot set it.
create or replace function numora_private.calendar_window(p_user_id uuid, p_now timestamptz default now())
returns table (local_date date, week_start date, week_end date,
  next_midnight timestamptz, next_weekly_reset timestamptz, server_now timestamptz, timezone text)
language sql stable set search_path = '' as $$
  select day.local_date, week.start_date, week.start_date + 7,
    (day.local_date + 1)::timestamp at time zone profile.timezone,
    (week.start_date + 7)::timestamp at time zone profile.timezone,
    p_now, profile.timezone
  from public.profiles profile
  cross join lateral (select (p_now at time zone profile.timezone)::date as local_date) day
  cross join lateral (select date_trunc('week', day.local_date)::date as start_date) week
  where profile.id = p_user_id;
$$;
revoke all on function numora_private.calendar_window(uuid,timestamptz) from public, anon, authenticated;

-- Preserve the Phase 8.1 API while sharing its dates with daily features.
create or replace function numora_private.weekly_window(p_user_id uuid, p_now timestamptz default now())
returns table (week_start date, through_date date, timezone text)
language sql stable set search_path = '' as $$
  select c.week_start, c.local_date, c.timezone from numora_private.calendar_window(p_user_id, p_now) c;
$$;
create or replace function numora_private.local_day(p_user uuid)
returns date language sql stable security definer set search_path = '' as $$
  select c.local_date from numora_private.calendar_window(p_user) c;
$$;
revoke all on function numora_private.weekly_window(uuid,timestamptz), numora_private.local_day(uuid) from public, anon, authenticated;

create or replace function public.get_my_today_activity()
returns table (local_date date, xp_earned integer, coins_earned integer, activities_completed integer)
language sql stable security definer set search_path = '' as $$
  select d.local_date, d.xp_earned, d.coins_earned, d.activities_completed
  from public.daily_activity d join numora_private.calendar_window(auth.uid()) c on c.local_date = d.local_date
  where d.user_id = auth.uid();
$$;

-- Keep existing ranking/ties, and return the same calendar used by Dashboard.
-- All ranking fields remain allowlisted by get_weekly_leaderboard.
create or replace function public.get_weekly_tournament(p_limit integer default 10)
returns jsonb language sql stable security definer set search_path = '' as $$
  select public.get_weekly_leaderboard(p_limit) || jsonb_build_object(
    'calendar', (select to_jsonb(c) from numora_private.calendar_window(auth.uid()) c));
$$;

create or replace function public.get_my_economy_snapshot()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid(); v_today date; v_calendar record; v_stats public.student_stats%rowtype;
  v_daily public.daily_activity%rowtype; v_repair date; v_celebrate boolean := false; v_rules jsonb;
begin
  if v_user is null then raise exception using errcode = '28000', message = 'Authentication required'; end if;
  select * into v_calendar from numora_private.calendar_window(v_user);
  if not found then raise exception 'Student profile required'; end if;
  v_today := v_calendar.local_date;
  perform numora_private.sync_streak(v_user);
  select * into v_stats from public.student_stats where user_id = v_user;
  select * into v_daily from public.daily_activity where user_id = v_user and local_date = v_today;
  if not exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today - 1)
    and exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today - 2) then v_repair := v_today - 1; end if;
  update public.streak_days set celebrated_at = now() where user_id = v_user and local_date = v_today and source = 'qualified' and celebrated_at is null;
  v_celebrate := found;
  select jsonb_object_agg(event_type, jsonb_build_object('xp', xp, 'coins', coins)) into v_rules from public.reward_rules;
  return jsonb_build_object('stats', to_jsonb(v_stats), 'today', jsonb_build_object('local_date', v_today,
    'xp_earned', coalesce(v_daily.xp_earned, 0), 'coins_earned', coalesce(v_daily.coins_earned, 0), 'activities_completed', coalesce(v_daily.activities_completed, 0)),
    'weekly_xp', public.get_my_weekly_xp(), 'rules', v_rules, 'repair_date', v_repair,
    'qualified_today', exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today),
    'celebrate', v_celebrate, 'server_now', v_calendar.server_now, 'next_midnight', v_calendar.next_midnight,
    'calendar', to_jsonb(v_calendar));
end;
$$;
revoke all on function public.get_my_today_activity(), public.get_weekly_tournament(integer), public.get_my_economy_snapshot() from public, anon;
grant execute on function public.get_my_today_activity(), public.get_weekly_tournament(integer), public.get_my_economy_snapshot() to authenticated;

-- Final integration: enforce the existing zero-life rule on the server too.
-- Recorded rewards are checked for idempotency before insertion, so retrying a
-- previously committed coin remains safe even if lives have since reached zero.
create or replace function numora_private.guard_arcade_reward_lives()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_state public.arcade_state%rowtype;
begin
  if new.module = 'arcade' and new.activity_type = 'arcade_correct' then
    v_state := public.refresh_arcade_lives(new.user_id);
    if v_state.lives <= 0 then raise exception 'Arcade life required'; end if;
  end if;
  return new;
end;
$$;
revoke all on function numora_private.guard_arcade_reward_lives() from public, anon, authenticated;
drop trigger if exists activity_events_arcade_lives on public.activity_events;
create trigger activity_events_arcade_lives before insert on public.activity_events
for each row execute function numora_private.guard_arcade_reward_lives();

-- Final regression found a Phase 6 output-column/SQL-column name collision.
-- Qualify the update columns so incorrect actions can actually deduct a life.
create or replace function public.lose_arcade_life(p_event_key text)
returns table (life_lost boolean, lives integer, next_regeneration_at timestamptz, updated_at timestamptz)
language plpgsql security definer set search_path = '' as $$
declare v_user_id uuid := auth.uid(); v_state public.arcade_state%rowtype; v_life_lost boolean := false;
begin
  if v_user_id is null then raise exception using errcode = '28000', message = 'Authentication is required.'; end if;
  if p_event_key is null or p_event_key !~ '^arcade:[a-z0-9][a-z0-9:_-]{2,180}$' then
    raise exception using errcode = '22023', message = 'Invalid Arcade action.';
  end if;
  v_state := public.refresh_arcade_lives(v_user_id);
  insert into public.arcade_life_events (user_id, event_key) values (v_user_id, p_event_key)
    on conflict (user_id, event_key) do nothing;
  if found and v_state.lives > 0 then
    update public.arcade_state s set lives = s.lives - 1,
      regeneration_started_at = case when s.lives = 8 then now() else s.regeneration_started_at end
    where s.user_id = v_user_id returning s.* into v_state;
    v_life_lost := true;
  end if;
  return query select v_life_lost, v_state.lives,
    case when v_state.lives < 8 then v_state.regeneration_started_at + interval '3 minutes' else null end,
    v_state.updated_at;
end;
$$;
revoke all on function public.lose_arcade_life(text) from public, anon;
grant execute on function public.lose_arcade_life(text) to authenticated;

-- The same output-variable collision blocked Simulation saves. Keep the existing
-- validation and completion guard, but qualify catalog columns and the conflict.
create or replace function public.upsert_simulation_progress(
  p_story_id text, p_grade_level text, p_current_step integer,
  p_attempts integer default 0, p_help_uses integer default 0,
  p_guidance_level integer default 0, p_response_history jsonb default '[]'::jsonb
)
returns table (story_id text, grade_level text, status text, current_step integer,
  attempts integer, help_uses integer, guidance_level integer, response_history jsonb,
  completed_at timestamptz, updated_at timestamptz)
language plpgsql security definer set search_path = '' as $$
declare
  v_user_id uuid := auth.uid(); v_catalog_grade text; v_required_step integer;
begin
  if v_user_id is null then raise exception using errcode = '28000', message = 'Authentication is required.'; end if;
  if p_story_id is null or p_story_id !~ '^[a-z0-9][a-z0-9-]{1,120}$' then
    raise exception using errcode = '22023', message = 'Invalid Simulation story.';
  end if;
  select c.grade_level, c.required_completion_step into v_catalog_grade, v_required_step
    from public.simulation_story_catalog c where c.story_id = p_story_id;
  if not found or p_grade_level is null or p_grade_level <> v_catalog_grade then
    raise exception using errcode = '22023', message = 'Invalid Simulation story or grade level.';
  end if;
  if p_current_step is null or p_current_step < 0 or p_current_step > v_required_step
    or p_attempts is null or p_attempts < 0 or p_attempts > 1000
    or p_help_uses is null or p_help_uses < 0 or p_help_uses > 1000
    or p_guidance_level is null or p_guidance_level < 0 or p_guidance_level > 3 then
    raise exception using errcode = '22023', message = 'Invalid Simulation progress.';
  end if;
  if p_response_history is null or jsonb_typeof(p_response_history) <> 'array' then
    raise exception using errcode = '22023', message = 'Simulation response history must be a list.';
  end if;
  if jsonb_array_length(p_response_history) > 12 or octet_length(p_response_history::text) > 12000 then
    raise exception using errcode = '22023', message = 'Simulation response history is too large.';
  end if;
  if exists (select 1 from jsonb_array_elements(p_response_history) item
    where jsonb_typeof(item) <> 'object' or octet_length(item::text) > 1200) then
    raise exception using errcode = '22023', message = 'Simulation response history is invalid.';
  end if;
  -- Completion is still written only by the idempotent reward path.
  insert into public.simulation_progress as progress
    (user_id, story_id, grade_level, status, current_step, attempts, help_uses, guidance_level, response_history)
  values (v_user_id, p_story_id, p_grade_level, 'in_progress', p_current_step,
    p_attempts, p_help_uses, p_guidance_level, p_response_history)
  on conflict on constraint simulation_progress_pkey do update
    set grade_level = excluded.grade_level, current_step = excluded.current_step,
      attempts = excluded.attempts, help_uses = excluded.help_uses,
      guidance_level = excluded.guidance_level, response_history = excluded.response_history
    where progress.status = 'in_progress';
  return query select p.story_id, p.grade_level, p.status, p.current_step,
    p.attempts, p.help_uses, p.guidance_level, p.response_history, p.completed_at, p.updated_at
    from public.simulation_progress p where p.user_id = v_user_id and p.story_id = p_story_id;
end;
$$;
revoke all on function public.upsert_simulation_progress(text,text,integer,integer,integer,integer,jsonb) from public, anon;
grant execute on function public.upsert_simulation_progress(text,text,integer,integer,integer,integer,jsonb) to authenticated;
commit;
