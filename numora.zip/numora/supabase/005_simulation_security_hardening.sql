-- Numora Simulation Lab security hardening.
-- Run after 004_simulation_lab.sql on projects where Phase 5.4 was already applied.

begin;

create table if not exists public.simulation_story_catalog (
  story_id text primary key check (story_id ~ '^[a-z0-9][a-z0-9-]{1,120}$'),
  grade_level text not null check (grade_level in ('entry', 'middle', 'high')),
  required_completion_step integer not null check (required_completion_step between 1 and 100)
);

insert into public.simulation_story_catalog (story_id, grade_level, required_completion_step) values
  ('entry-snack-budget', 'entry', 5),
  ('entry-recipe-double', 'entry', 5),
  ('entry-allowance-goal', 'entry', 5),
  ('entry-field-trip-time', 'entry', 5),
  ('entry-garden-plan', 'entry', 5),
  ('middle-subscription-choice', 'middle', 5),
  ('middle-basketball-strategy', 'middle', 5),
  ('middle-festival-budget', 'middle', 5),
  ('middle-weather-plan', 'middle', 5),
  ('middle-food-truck-pricing', 'middle', 5),
  ('high-laptop-comparison', 'high', 5),
  ('high-savings-decision', 'high', 5),
  ('high-concert-break-even', 'high', 5),
  ('high-water-use-trend', 'high', 5),
  ('high-data-plan-comparison', 'high', 5)
on conflict (story_id) do update
set grade_level = excluded.grade_level,
    required_completion_step = excluded.required_completion_step;

alter table public.simulation_story_catalog enable row level security;
revoke all on table public.simulation_story_catalog from anon, authenticated;

create or replace function public.enforce_simulation_progress_catalog()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_catalog_grade_level text;
  v_required_completion_step integer;
begin
  select grade_level, required_completion_step
  into v_catalog_grade_level, v_required_completion_step
  from public.simulation_story_catalog
  where story_id = new.story_id;

  if not found or new.grade_level <> v_catalog_grade_level then
    raise exception using errcode = '22023', message = 'Unknown Simulation story or grade level.';
  end if;

  if new.current_step > v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation progress is beyond this story.';
  end if;

  return new;
end;
$$;

revoke all on function public.enforce_simulation_progress_catalog() from public;

drop trigger if exists simulation_progress_catalog_guard on public.simulation_progress;
create trigger simulation_progress_catalog_guard
before insert or update on public.simulation_progress
for each row execute procedure public.enforce_simulation_progress_catalog();

create or replace function public.enforce_simulation_completion_reward()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_required_completion_step integer;
  v_progress public.simulation_progress%rowtype;
  v_student_response_count integer;
begin
  if new.module <> 'simulation' then
    return new;
  end if;

  if new.activity_type <> 'story_completed' then
    raise exception using errcode = '22023', message = 'Invalid Simulation activity.';
  end if;

  select required_completion_step
  into v_required_completion_step
  from public.simulation_story_catalog
  where story_id = new.topic
    and grade_level = (new.metadata ->> 'grade_level');

  if not found
    or coalesce(new.metadata ->> 'story_id', '') <> new.topic
    or new.event_key <> 'simulation:' || new.topic || ':completed' then
    raise exception using errcode = '22023', message = 'Invalid Simulation completion details.';
  end if;

  select *
  into v_progress
  from public.simulation_progress
  where user_id = new.user_id
    and story_id = new.topic;

  if not found
    or v_progress.status <> 'in_progress'
    or v_progress.grade_level <> (new.metadata ->> 'grade_level')
    or v_progress.current_step < v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation story is not ready to complete.';
  end if;

  select count(*)
  into v_student_response_count
  from jsonb_array_elements(v_progress.response_history) as history_item
  where history_item ->> 'role' = 'student';

  if v_student_response_count < v_required_completion_step then
    raise exception using errcode = '22023', message = 'Simulation story is not ready to complete.';
  end if;

  return new;
end;
$$;

revoke all on function public.enforce_simulation_completion_reward() from public;

drop trigger if exists simulation_completion_reward_guard on public.activity_events;
create trigger simulation_completion_reward_guard
before insert on public.activity_events
for each row execute procedure public.enforce_simulation_completion_reward();

commit;
