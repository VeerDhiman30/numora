-- Read-only setup verification. Expected missing = 0, failed_checks = {}.
with checks(name, ok) as (
  values
    ('calendar authority', to_regprocedure('numora_private.calendar_window(uuid,timestamp with time zone)') is not null),
    ('tournament snapshot', to_regprocedure('public.get_weekly_tournament(integer)') is not null),
    ('authenticated tournament permission', coalesce(has_function_privilege('authenticated', to_regprocedure('public.get_weekly_tournament(integer)'), 'EXECUTE'), false)),
    ('anonymous tournament forbidden', not coalesce(has_function_privilege('anon', to_regprocedure('public.get_weekly_tournament(integer)'), 'EXECUTE'), true)),
    ('private helpers inaccessible', not coalesce(has_schema_privilege('authenticated', to_regnamespace('numora_private'), 'USAGE'), true)),
    ('economy includes calendar', coalesce((select prosrc like '%calendar_window%' and prosrc like '%calendar%' from pg_proc where oid = to_regprocedure('public.get_my_economy_snapshot()')), false)),
    ('weekly helper shares calendar', coalesce((select prosrc like '%calendar_window%' from pg_proc where oid = to_regprocedure('numora_private.weekly_window(uuid,timestamp with time zone)')), false)),
    ('daily helper shares calendar', coalesce((select prosrc like '%calendar_window%' from pg_proc where oid = to_regprocedure('numora_private.local_day(uuid)')), false)),
    ('Arcade life-loss fix', coalesce((select prosrc like '%lives = s.lives - 1%' from pg_proc where oid = to_regprocedure('public.lose_arcade_life(text)')), false)),
    ('Simulation save fix', coalesce((select prosrc like '%on conflict on constraint simulation_progress_pkey%' from pg_proc where oid = to_regprocedure('public.upsert_simulation_progress(text,text,integer,integer,integer,integer,jsonb)')), false)),
    ('Arcade life guard', exists (select 1 from pg_trigger where tgname = 'activity_events_arcade_lives' and tgrelid = to_regclass('public.activity_events') and tgenabled <> 'D'))
)
select count(*) filter (where not coalesce(ok, false))::integer as missing,
  coalesce(array_agg(name) filter (where not coalesce(ok, false)), array[]::text[]) as failed_checks from checks;
