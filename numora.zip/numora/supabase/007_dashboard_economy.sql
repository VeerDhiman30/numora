-- Numora Phase 7.1–7.4. Run AFTER migrations 001–006 and progress-schema.sql.
-- Atomic, rerunnable migration. No existing student totals are reset.
begin;

create schema if not exists numora_private;
revoke all on schema numora_private from public, anon, authenticated;

create table if not exists public.reward_rules (
  event_type text primary key,
  module text not null,
  activity_type text not null,
  xp integer not null check (xp >= 0),
  coins integer not null,
  unique (module, activity_type)
);
insert into public.reward_rules values
  ('decision_correct', 'decision', 'correct_answer', 5, 0),
  ('decision_incorrect', 'decision', 'incorrect_answer', 0, 0),
  ('decision_hint', 'decision', 'hint', 0, -10),
  ('quant_correct', 'quant', 'correct_answer', 1, 0),
  ('quant_incorrect', 'quant', 'incorrect_answer', 0, 0),
  ('quant_hint', 'quant', 'hint', 0, -2),
  ('simulation_complete', 'simulation', 'story_completed', 10, 0),
  ('arcade_correct', 'arcade', 'arcade_correct', 0, 1),
  ('daily_challenge', 'daily_challenge', 'daily_challenge', 20, 20),
  ('streak_repair', 'streak', 'streak_repair', 0, -200)
on conflict (event_type) do update set xp = excluded.xp, coins = excluded.coins;
alter table public.reward_rules enable row level security;
revoke all on public.reward_rules from anon, authenticated;
grant select on public.reward_rules to authenticated;
drop policy if exists "Read reward rules" on public.reward_rules;
create policy "Read reward rules" on public.reward_rules for select to authenticated using (true);

create table if not exists public.streak_days (
  user_id uuid not null references auth.users(id) on delete cascade,
  local_date date not null,
  source text not null check (source in ('qualified', 'repaired')),
  celebrated_at timestamptz,
  created_at timestamptz not null default now(),
  primary key (user_id, local_date)
);
create table if not exists public.daily_challenges (
  user_id uuid not null references auth.users(id) on delete cascade,
  local_date date not null,
  challenge_id text not null,
  grade_level text not null check (grade_level in ('entry', 'middle', 'high')),
  timezone text not null,
  completed boolean not null default false,
  completed_at timestamptz,
  attempt_count integer not null default 0 check (attempt_count >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, local_date),
  check (completed = (completed_at is not null))
);
alter table public.streak_days enable row level security;
alter table public.daily_challenges enable row level security;
revoke all on public.streak_days, public.daily_challenges from anon, authenticated;
grant select on public.streak_days, public.daily_challenges to authenticated;
drop policy if exists "Read own streak days" on public.streak_days;
create policy "Read own streak days" on public.streak_days for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "Read own daily challenges" on public.daily_challenges;
create policy "Read own daily challenges" on public.daily_challenges for select to authenticated using ((select auth.uid()) = user_id);

alter table public.profiles add column if not exists timezone_changed_at timestamptz;
alter table public.student_stats add column if not exists last_streak_checked_date date;

create or replace function numora_private.guard_timezone()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if not exists (select 1 from pg_timezone_names where name = new.timezone) then
    raise exception 'Invalid timezone';
  end if;
  if tg_op = 'UPDATE' then
    new.timezone_changed_at := old.timezone_changed_at;
    if new.timezone is distinct from old.timezone then
      if old.timezone_changed_at > now() - interval '7 days' then
        raise exception 'Timezone was recently updated';
      end if;
      new.timezone_changed_at := now();
    end if;
  else
    new.timezone_changed_at := null;
  end if;
  return new;
end;
$$;
drop trigger if exists profiles_guard_timezone on public.profiles;
create trigger profiles_guard_timezone before insert or update on public.profiles
for each row execute function numora_private.guard_timezone();

create or replace function numora_private.local_day(p_user uuid)
returns date language sql stable security definer set search_path = public, pg_temp as $$
  select (now() at time zone p.timezone)::date from public.profiles p where p.id = p_user;
$$;

-- Dates, rather than elapsed hours, define continuity. A repair is allowed only
-- for yesterday, when the preceding day was credited. Two missed days break it.
create or replace function numora_private.sync_streak(p_user uuid)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_today date := numora_private.local_day(p_user);
  v_cursor date;
  v_count integer := 0;
begin
  perform 1 from public.student_stats where user_id = p_user for update;
  insert into public.streak_days (user_id, local_date, source, celebrated_at)
  select p_user, d.local_date, 'qualified', case when d.local_date < v_today then now() else null end
  from public.daily_activity d where d.user_id = p_user and d.xp_earned >= 50 and d.local_date <= v_today
  on conflict (user_id, local_date) do nothing;
  v_cursor := case when exists (select 1 from public.streak_days where user_id = p_user and local_date = v_today)
    then v_today else v_today - 1 end;
  while exists (select 1 from public.streak_days where user_id = p_user and local_date = v_cursor) loop
    v_count := v_count + 1;
    v_cursor := v_cursor - 1;
  end loop;
  update public.student_stats set current_streak = v_count,
    last_streak_date = (select max(local_date) from public.streak_days where user_id = p_user and local_date <= v_today),
    last_streak_checked_date = v_today
  where user_id = p_user;
end;
$$;

-- All modules use this one internal award transaction. It is NOT callable by a
-- browser. Public wrappers validate their own activity, challenge or repair.
create or replace function numora_private.award(
  p_event_key text, p_module text, p_topic text, p_activity_type text, p_metadata jsonb
)
returns table (event_id uuid, event_recorded boolean, total_xp integer, coin_balance integer,
  current_streak integer, local_date date, today_xp integer, today_coins_earned integer, today_activities_completed integer)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_user uuid := auth.uid();
  v_date date;
  v_grade text;
  v_rule public.reward_rules%rowtype;
  v_stats public.student_stats%rowtype;
  v_daily public.daily_activity%rowtype;
  v_event uuid;
  v_recorded boolean := false;
  v_attempt integer;
  v_correct integer;
begin
  if v_user is null then raise exception using errcode = '28000', message = 'Authentication required'; end if;
  if p_event_key is null or p_event_key !~ '^[a-z0-9][a-z0-9:_-]{2,180}$'
    or p_metadata is null or jsonb_typeof(p_metadata) <> 'object' then raise exception 'Invalid activity'; end if;
  select * into v_rule from public.reward_rules r where r.module = p_module and r.activity_type = p_activity_type;
  if not found then raise exception 'Invalid reward type'; end if;
  select coalesce(nullif(p_metadata->>'grade_level', ''), p.grade_level) into v_grade from public.profiles p where p.id = v_user;
  if v_grade is null or v_grade not in ('entry', 'middle', 'high') then raise exception 'Invalid grade'; end if;
  v_date := numora_private.local_day(v_user);
  insert into public.student_stats (user_id) values (v_user) on conflict (user_id) do nothing;
  select * into v_stats from public.student_stats s where s.user_id = v_user for update;
  select e.id into v_event from public.activity_events e where e.user_id = v_user and e.event_key = p_event_key;
  if not found then
    if v_stats.coin_balance + v_rule.coins < 0 then raise exception 'Insufficient coins'; end if;
    insert into public.activity_events (user_id, event_key, module, topic, activity_type, xp_delta, coin_delta, metadata, local_date)
    values (v_user, p_event_key, p_module, p_topic, p_activity_type, v_rule.xp, v_rule.coins, p_metadata, v_date)
    returning id into v_event;
    update public.student_stats s set total_xp = s.total_xp + v_rule.xp, coin_balance = s.coin_balance + v_rule.coins where s.user_id = v_user;
    insert into public.daily_activity as d (user_id, local_date, xp_earned, coins_earned, activities_completed)
    values (v_user, v_date, v_rule.xp, greatest(0, v_rule.coins), case when p_activity_type in ('hint', 'streak_repair') then 0 else 1 end)
    on conflict on constraint daily_activity_pkey do update set xp_earned = d.xp_earned + excluded.xp_earned,
      coins_earned = d.coins_earned + excluded.coins_earned, activities_completed = d.activities_completed + excluded.activities_completed;
    if p_module in ('decision', 'quant', 'simulation') and p_activity_type <> 'hint' then
      v_attempt := 1;
      v_correct := case when p_activity_type = 'correct_answer' then 1 else 0 end;
      insert into public.module_progress as m (user_id, module, grade_level, topic, completed_count, correct_count, attempt_count)
      values (v_user, p_module, v_grade, p_topic, 1, v_correct, v_attempt)
      on conflict (user_id, module, grade_level, topic) do update set completed_count = m.completed_count + 1,
        correct_count = m.correct_count + excluded.correct_count, attempt_count = m.attempt_count + 1;
    end if;
    if p_module = 'simulation' then
      update public.simulation_progress set status = 'completed', completed_at = now() where user_id = v_user and story_id = p_topic;
    end if;
    v_recorded := true;
  end if;
  perform numora_private.sync_streak(v_user);
  select * into v_stats from public.student_stats s where s.user_id = v_user;
  select * into v_daily from public.daily_activity d where d.user_id = v_user and d.local_date = v_date;
  return query select v_event, v_recorded, v_stats.total_xp, v_stats.coin_balance, v_stats.current_streak,
    v_date, coalesce(v_daily.xp_earned, 0), coalesce(v_daily.coins_earned, 0), coalesce(v_daily.activities_completed, 0);
end;
$$;

create or replace function public.record_activity_event(
  p_event_key text, p_module text, p_topic text default null, p_activity_type text default null, p_metadata jsonb default '{}'::jsonb
)
returns table (event_id uuid, event_recorded boolean, total_xp integer, coin_balance integer,
  current_streak integer, local_date date, today_xp integer, today_coins_earned integer, today_activities_completed integer)
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_suffix text;
begin
  if p_module is null or p_module not in ('decision', 'quant', 'simulation', 'arcade') then
    raise exception 'Use the dedicated challenge or repair action';
  end if;
  v_suffix := case p_activity_type when 'correct_answer' then 'correct' when 'incorrect_answer' then 'incorrect' when 'hint' then 'hint' end;
  if p_module = 'decision' and (v_suffix is null or p_event_key !~ ('^decision:[a-z0-9][a-z0-9-]{1,120}:[a-z0-9][a-z0-9-]{1,120}:' || v_suffix || '$')) then raise exception 'Invalid Decision key'; end if;
  if p_module = 'quant' and (v_suffix is null or p_event_key !~ ('^quant:[a-z0-9][a-z0-9-]{1,120}:' || v_suffix || '$')) then raise exception 'Invalid Quant key'; end if;
  if p_module = 'arcade' and (p_activity_type <> 'arcade_correct' or p_event_key !~ '^arcade:') then raise exception 'Invalid Arcade event'; end if;
  if p_module in ('decision', 'quant', 'simulation') and coalesce(trim(p_topic), '') = '' then raise exception 'Topic required'; end if;
  -- The Phase 5 catalog/transcript BEFORE INSERT guard is preserved; retries skip
  -- insertion and therefore never turn a completed story back into an active one.
  if p_module = 'simulation' and (p_activity_type <> 'story_completed' or p_event_key <> 'simulation:' || p_topic || ':completed') then raise exception 'Invalid Simulation key'; end if;
  return query select * from numora_private.award(p_event_key, p_module, trim(p_topic), p_activity_type, p_metadata);
end;
$$;

create or replace function public.record_quant_activity_event(p_event_key text, p_topic text, p_activity_type text, p_metadata jsonb default '{}'::jsonb)
returns table (event_id uuid, event_recorded boolean, total_xp integer, coin_balance integer,
  current_streak integer, local_date date, today_xp integer, today_coins_earned integer, today_activities_completed integer)
language sql security definer set search_path = public, pg_temp as $$
  select * from public.record_activity_event(p_event_key, 'quant', p_topic, p_activity_type, p_metadata);
$$;

create table if not exists numora_private.challenge_bank (
  id text primary key, grade_level text not null, topic text not null,
  question text not null, options jsonb not null, answer text not null, hint text not null, explanation text not null
);
insert into numora_private.challenge_bank values
  ('entry-picnic', 'entry', 'Fractions', 'A class has 24 sandwiches. Three eighths are cheese; half of the rest are egg. How many are egg?', '["6","7","7.5","9"]', '7.5', 'Find the cheese share first, then take half of the remaining amount.', 'Three eighths of 24 is 9. That leaves 15; half is 7.5 sandwiches.'),
  ('entry-tickets', 'entry', 'Money', 'Four museum tickets cost $6 each. You pay with $30 and buy a $2 postcard. How much change remains?', '["$2","$4","$6","$8"]', '$4', 'Find the total ticket cost, then include the postcard.', '4 × $6 + $2 = $26, so $30 − $26 = $4.'),
  ('entry-garden', 'entry', 'Measurement', 'A rectangular garden is 9 m long and 5 m wide. A 2 m opening needs no fence. How much fence is needed?', '["26 m","28 m","43 m","45 m"]', '26 m', 'Find the distance around all four sides, then subtract the opening.', '2 × (9 + 5) − 2 = 26 m.'),
  ('entry-recipe', 'entry', 'Fractions', 'One batch uses 3/4 cup of oats. You make two batches and already have 1/2 cup. How much more do you need?', '["1/4 cup","3/4 cup","1 cup","1.5 cups"]', '1 cup', 'Double the recipe amount, then subtract what you have.', 'Two batches need 1.5 cups; 1.5 − 0.5 = 1 cup more.'),
  ('middle-discount', 'middle', 'Percentages', 'An $80 jacket is reduced by 25%. An 8% sales tax is then applied to the sale price. What is the total?', '["$60.00","$64.80","$66.40","$68.00"]', '$64.80', 'Apply the discount first. Tax is calculated on the reduced price.', '$80 × 0.75 = $60; $60 × 1.08 = $64.80.'),
  ('middle-ratio', 'middle', 'Ratios', 'Red and blue beads are in a 3:5 ratio. After adding 6 red beads, there are equal numbers of each. How many beads were there originally?', '["18","24","30","48"]', '24', 'The difference between the original shares is two ratio parts.', 'Two parts equal 6, so each part is 3. Eight original parts total 24.'),
  ('middle-equation', 'middle', 'Equations', 'A taxi charges $4 plus $2.50 per kilometre. Your trip costs $24 before a $3 tip. How far did you travel?', '["6.8 km","8 km","9.2 km","9.6 km"]', '8 km', 'The stated fare is before the tip. Remove the fixed charge first.', '($24 − $4) ÷ $2.50 = 8 km. The tip does not affect distance.'),
  ('middle-probability', 'middle', 'Probability', 'A bag has 3 red and 2 blue counters. Two are drawn without replacement. What is the probability both are red?', '["3/10","9/25","2/5","3/5"]', '3/10', 'After drawing one red, both the red count and total count decrease.', '(3/5) × (2/4) = 3/10.'),
  ('high-function', 'high', 'Functions', 'A ball has height h(t) = −5t² + 20t + 1 metres. What is its maximum height?', '["20 m","21 m","41 m","81 m"]', '21 m', 'Find the time at the vertex, then substitute it into the height function.', 'The vertex occurs at t = −20/(2 × −5) = 2; h(2) = 21 m.'),
  ('high-interest', 'high', 'Financial Mathematics', 'You deposit $800 at 5% annual compound interest for two years, then withdraw $100. What remains?', '["$780","$782","$840","$882"]', '$782', 'Compound for both years before subtracting the withdrawal.', '$800 × 1.05² − $100 = $782.'),
  ('high-statistics', 'high', 'Statistics', 'Four quiz scores have a mean of 72. A fifth quiz raises the overall mean to 76. What was the fifth score?', '["76","80","88","92"]', '92', 'Compare the total points for four quizzes with those for five.', '5 × 76 − 4 × 72 = 380 − 288 = 92.'),
  ('high-algebra', 'high', 'Algebra', 'A club sells tickets for $12. Venue hire costs $180 plus $3 per attendee. How many tickets must it sell to make a $90 profit?', '["20","23","30","90"]', '30', 'Revenue minus both fixed and per-person costs must equal the target profit.', '12n − (180 + 3n) = 90, so 9n = 270 and n = 30.')
on conflict (id) do nothing;

create or replace function numora_private.challenge_for(p_user uuid, p_date date, p_grade text)
returns numora_private.challenge_bank language sql stable security definer set search_path = public, pg_temp as $$
  select b from numora_private.challenge_bank b where b.grade_level = p_grade order by b.id
  offset ((p_date - date '2026-01-01' + abs(hashtext(p_user::text)::bigint)) %
    greatest(1, (select count(*) from numora_private.challenge_bank where grade_level = p_grade))) limit 1;
$$;

-- A timezone change cannot move an already claimed day forward or bypass the
-- previous timezone's next midnight. Normal 23/25-hour DST days still work.
create or replace function numora_private.challenge_available_at(p_user uuid)
returns timestamptz language sql stable security definer set search_path = public, pg_temp as $$
  select ((d.local_date + 1)::timestamp at time zone d.timezone)
  from public.daily_challenges d where d.user_id = p_user and d.completed order by d.completed_at desc limit 1;
$$;

create or replace function public.get_my_daily_challenge(p_grade_level text)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_user uuid := auth.uid(); v_date date; v_zone text; v_next timestamptz;
  v_question numora_private.challenge_bank; v_row public.daily_challenges%rowtype; v_locked boolean;
begin
  if v_user is null then raise exception using errcode = '28000', message = 'Authentication required'; end if;
  if p_grade_level is null or p_grade_level not in ('entry', 'middle', 'high') then raise exception 'Invalid difficulty'; end if;
  perform 1 from public.student_stats where user_id = v_user for update;
  select timezone into v_zone from public.profiles where id = v_user;
  v_date := numora_private.local_day(v_user);
  v_question := numora_private.challenge_for(v_user, v_date, p_grade_level);
  if v_question.id is null then raise exception 'Challenge unavailable'; end if;
  insert into public.daily_challenges (user_id, local_date, challenge_id, grade_level, timezone)
  values (v_user, v_date, v_question.id, p_grade_level, v_zone) on conflict (user_id, local_date) do nothing;
  select * into v_row from public.daily_challenges where user_id = v_user and local_date = v_date;
  v_next := numora_private.challenge_available_at(v_user);
  v_locked := not v_row.completed and (coalesce(now() < v_next, false) or exists (
    select 1 from public.daily_challenges where user_id = v_user and completed and local_date > v_date));
  return jsonb_build_object('id', v_question.id, 'grade_level', p_grade_level, 'topic', v_question.topic,
    'question', v_question.question, 'options', v_question.options, 'local_date', v_date,
    'completed', v_row.completed, 'attempt_count', v_row.attempt_count, 'locked', v_locked,
    'server_now', now(), 'next_midnight', ((v_date + 1)::timestamp at time zone v_zone));
end;
$$;

create or replace function public.submit_daily_challenge(p_grade_level text, p_challenge_id text, p_local_date date, p_answer text)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare v_view jsonb; v_user uuid := auth.uid(); v_question numora_private.challenge_bank; v_reward record;
begin
  v_view := public.get_my_daily_challenge(p_grade_level); -- acquires the same wallet lock as every reward
  if p_local_date is distinct from numora_private.local_day(v_user) or p_challenge_id is distinct from v_view->>'id' then raise exception 'Challenge expired'; end if;
  if (v_view->>'completed')::boolean then return jsonb_build_object('correct', true, 'event_recorded', false, 'message', 'Your daily reward is already saved.'); end if;
  if (v_view->>'locked')::boolean then raise exception 'Daily reward is waiting for the next eligible day'; end if;
  v_question := numora_private.challenge_for(v_user, p_local_date, p_grade_level);
  if p_answer is null or not (v_question.options ? p_answer) then raise exception 'Choose a listed answer'; end if;
  update public.daily_challenges set attempt_count = attempt_count + 1, challenge_id = v_question.id,
    grade_level = p_grade_level, updated_at = now() where user_id = v_user and local_date = p_local_date;
  if p_answer <> v_question.answer then return jsonb_build_object('correct', false, 'event_recorded', false, 'message', v_question.hint); end if;
  select * into v_reward from numora_private.award('daily_challenge:' || p_local_date::text, 'daily_challenge', v_question.topic,
    'daily_challenge', jsonb_build_object('grade_level', p_grade_level, 'challenge_id', v_question.id));
  update public.daily_challenges set completed = true, completed_at = now(), updated_at = now()
    where user_id = v_user and local_date = p_local_date;
  return jsonb_build_object('correct', true, 'event_recorded', v_reward.event_recorded, 'message', v_question.explanation);
end;
$$;

create or replace function public.repair_my_streak(p_missed_date date)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare v_user uuid := auth.uid(); v_today date; v_reward record;
begin
  if v_user is null then raise exception using errcode = '28000', message = 'Authentication required'; end if;
  perform 1 from public.student_stats where user_id = v_user for update;
  if exists (select 1 from public.activity_events where user_id = v_user and event_key = 'streak_repair:' || p_missed_date::text) then
    return jsonb_build_object('event_recorded', false);
  end if;
  perform numora_private.sync_streak(v_user);
  v_today := numora_private.local_day(v_user);
  if p_missed_date is distinct from v_today - 1
    or exists (select 1 from public.streak_days where user_id = v_user and local_date = p_missed_date)
    or not exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today - 2) then raise exception 'Streak is not eligible for repair'; end if;
  insert into public.streak_days (user_id, local_date, source, celebrated_at) values (v_user, p_missed_date, 'repaired', now());
  select * into v_reward from numora_private.award('streak_repair:' || p_missed_date::text, 'streak', null, 'streak_repair', '{}'::jsonb);
  -- Insufficient funds roll back BOTH the repaired day and the event.
  return jsonb_build_object('event_recorded', v_reward.event_recorded);
end;
$$;

create or replace function public.get_my_economy_snapshot()
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_user uuid := auth.uid(); v_today date; v_zone text; v_stats public.student_stats%rowtype;
  v_daily public.daily_activity%rowtype; v_repair date; v_celebrate boolean := false; v_rules jsonb;
begin
  if v_user is null then raise exception using errcode = '28000', message = 'Authentication required'; end if;
  perform numora_private.sync_streak(v_user);
  v_today := numora_private.local_day(v_user);
  select timezone into v_zone from public.profiles where id = v_user;
  select * into v_stats from public.student_stats where user_id = v_user;
  select * into v_daily from public.daily_activity where user_id = v_user and local_date = v_today;
  if not exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today - 1)
    and exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today - 2) then v_repair := v_today - 1; end if;
  update public.streak_days set celebrated_at = now() where user_id = v_user and local_date = v_today and source = 'qualified' and celebrated_at is null;
  v_celebrate := found;
  select jsonb_object_agg(event_type, jsonb_build_object('xp', xp, 'coins', coins)) into v_rules from public.reward_rules;
  return jsonb_build_object('stats', to_jsonb(v_stats), 'today', jsonb_build_object('local_date', v_today,
    'xp_earned', coalesce(v_daily.xp_earned, 0), 'coins_earned', coalesce(v_daily.coins_earned, 0), 'activities_completed', coalesce(v_daily.activities_completed, 0)),
    'weekly_xp', public.get_my_weekly_xp(), 'rules', v_rules, 'repair_date', v_repair,
    'qualified_today', exists (select 1 from public.streak_days where user_id = v_user and local_date = v_today),
    'celebrate', v_celebrate, 'server_now', now(), 'next_midnight', ((v_today + 1)::timestamp at time zone v_zone));
end;
$$;

-- Explicit permissions: neither answers nor the internal award helper are public.
revoke all on all functions in schema numora_private from public, anon, authenticated;
revoke all on all tables in schema numora_private from public, anon, authenticated;
revoke all on function public.record_activity_event(text,text,text,text,jsonb), public.record_quant_activity_event(text,text,text,jsonb),
  public.get_my_daily_challenge(text), public.submit_daily_challenge(text,text,date,text), public.repair_my_streak(date), public.get_my_economy_snapshot() from public, anon;
grant execute on function public.record_activity_event(text,text,text,text,jsonb), public.record_quant_activity_event(text,text,text,jsonb),
  public.get_my_daily_challenge(text), public.submit_daily_challenge(text,text,date,text), public.repair_my_streak(date), public.get_my_economy_snapshot() to authenticated;

commit;
