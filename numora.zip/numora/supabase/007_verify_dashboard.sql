-- Optional read-only check after applying 007_dashboard_economy.sql.
-- Expected: missing = 0, failed_checks = {}. This verifies setup, not live user behavior.
with checks(name, ok) as (
  values
    ('reward rules table', to_regclass('public.reward_rules') is not null),
    ('daily challenge persistence', to_regclass('public.daily_challenges') is not null),
    ('streak day persistence', to_regclass('public.streak_days') is not null),
    ('private challenge bank', to_regclass('numora_private.challenge_bank') is not null),
    ('economy snapshot', to_regprocedure('public.get_my_economy_snapshot()') is not null),
    ('daily challenge fetch', to_regprocedure('public.get_my_daily_challenge(text)') is not null),
    ('daily challenge submit', to_regprocedure('public.submit_daily_challenge(text,text,date,text)') is not null),
    ('streak repair', to_regprocedure('public.repair_my_streak(date)') is not null),
    ('arcade lives prerequisite', to_regclass('public.arcade_state') is not null),
    ('private helpers inaccessible', not coalesce(has_schema_privilege('authenticated', to_regnamespace('numora_private'), 'USAGE'), true))
), policies as (
  select 'RLS and own-user policy: ' || t.name as name,
    coalesce(c.relrowsecurity, false) and exists (select 1 from pg_policy p where p.polrelid = c.oid) as ok
  from (values ('daily_challenges'), ('streak_days'), ('reward_rules')) t(name)
  left join pg_class c on c.oid = to_regclass('public.' || t.name)
), all_checks as (select * from checks union all select * from policies)
select count(*) filter (where not coalesce(ok, false))::integer as missing,
  coalesce(array_agg(name) filter (where not coalesce(ok, false)), array[]::text[]) as failed_checks
from all_checks;
