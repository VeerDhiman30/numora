import { getAppState } from "./appState.js";
import { getActivityHistory, getModuleProgress as readModuleProgress } from "./progressService.js";
import { getSimulationProgress } from "./simulationProgressService.js";
import { refreshEconomy } from "./economyService.js";
import { decisionModules } from "../data/decision/questions.js";
import { getQuantTopics } from "../data/quant/topics.js";
import { getSimulationStory, getSimulationStories } from "../data/simulation/stories.js";
import { getArcadeGame } from "../arcade/games.js";

export function masteryLabel(attempts, correct) {
  if (!attempts) return "Not started";
  if (attempts < 5) return "Just started";
  if (attempts < 10) return "Practicing";
  return correct / attempts >= 0.8 ? "Strong" : correct / attempts >= 0.6 ? "Making progress" : "Practicing";
}

export function topicLabel(module, topic, grade = "middle") {
  if (module === "decision") return decisionModules.find((item) => item.id === topic)?.title ?? "Decision practice";
  if (module === "quant") return getQuantTopics(grade).find((item) => item.id === topic)?.title
    ?? ["entry", "middle", "high"].flatMap(getQuantTopics).find((item) => item.id === topic)?.title ?? "Math practice";
  if (module === "simulation") return getSimulationStory(topic)?.title ?? "Story practice";
  if (module === "arcade") return getArcadeGame(topic)?.title ?? "Arcade game";
  return module === "daily_challenge" ? topic || "Daily Challenge" : "Streak Repair";
}

export function buildModuleCards(progress, simulations, grade) {
  return ["decision", "quant", "simulation"].map((module) => {
    const rows = progress.filter((row) => row.module === module);
    const completed = rows.reduce((sum, row) => sum + row.completedCount, 0);
    const correct = rows.reduce((sum, row) => sum + row.correctCount, 0);
    const attempts = rows.reduce((sum, row) => sum + row.attemptCount, 0);
    const known = module === "decision" ? decisionModules.map((item) => ({ id: item.id, title: item.title }))
      : module === "quant" ? getQuantTopics(grade).filter((item) => item.id !== "mix")
        : getSimulationStories(grade).map((story) => ({ id: story.id, title: story.title }));
    const details = [...rows.map((row) => ({ ...row, label: topicLabel(module, row.topic, row.gradeLevel),
      mastery: masteryLabel(row.attemptCount, row.correctCount) })),
    ...known.filter((item) => !rows.some((row) => row.topic === item.id)).map((item) => ({
      module, topic: item.id, label: item.title, gradeLevel: grade, attemptCount: 0, correctCount: 0, completedCount: 0, mastery: "Not started"
    }))];
    return { module, completed, correct, attempts, details,
      stories: module === "simulation" ? simulations.map((row) => ({ ...row,
        title: getSimulationStory(row.storyId)?.title ?? "Simulation story",
        concepts: getSimulationStory(row.storyId)?.mathConcepts ?? [] })) : [] };
  });
}

export function recommendPractice(cards, simulations, grade) {
  const active = simulations.find((story) => story.status === "in_progress");
  if (active) return { title: `Continue ${getSimulationStory(active.storyId)?.title ?? "your story"}`,
    description: "Your saved story is waiting in Simulation Lab.", route: "#/simulation" };
  const quant = cards.find((card) => card.module === "quant");
  const weakest = quant.details.filter((row) => row.gradeLevel === grade)
    .sort((a, b) => (a.attemptCount ? a.correctCount / a.attemptCount : -1) - (b.attemptCount ? b.correctCount / b.attemptCount : -1)
      || a.attemptCount - b.attemptCount || a.label.localeCompare(b.label))[0];
  if (weakest && (weakest.attemptCount < 10 || weakest.correctCount / weakest.attemptCount < 0.8)) return {
    title: `Practice ${weakest.label}`, description: weakest.attemptCount ? "Build on a topic that could use more practice." : "Try a topic you haven't practiced at this level yet.", route: "#/quant"
  };
  const decision = [...cards.find((card) => card.module === "decision").details].sort((a, b) => a.completedCount - b.completedCount)[0];
  return { title: `Explore ${decision?.label ?? "Decision Lab"}`, description: "Put your math to work in a real decision.", route: "#/decision" };
}

export const getModuleProgress = readModuleProgress;
export const getRecentActivity = (limit = 8) => getActivityHistory(limit);
export async function getTodayXp() { return (await refreshEconomy())?.today.xp_earned ?? null; }
export async function getWeeklyXp() { return (await refreshEconomy())?.weekly_xp ?? null; }

export async function getDashboardSummary() {
  const user = getAppState().user;
  if (!user) throw new Error("Sign in to view your Dashboard.");
  const [economy, progress, simulations, history] = await Promise.all([
    refreshEconomy(), getModuleProgress(), getSimulationProgress(), getActivityHistory(100)
  ]);
  if (!economy || getAppState().user?.id !== user.id) throw new Error("Your session changed. Please sign in again.");
  const cards = buildModuleCards(progress, simulations, user.gradeLevel);
  return { user, economy, cards, recent: history.slice(0, 8), rewards: history.filter((event) => event.xpDelta || event.coinDelta).slice(0, 5),
    recommendation: recommendPractice(cards, simulations, user.gradeLevel) };
}
