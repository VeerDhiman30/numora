import { getSupabaseClient } from "./supabase.js";

const supportedGradeLevels = new Set(["entry", "middle", "high"]);
const storyIdPattern = /^[a-z0-9][a-z0-9-]{1,120}$/;
const maxHistoryEntries = 12;
const maxHistoryBytes = 12000;
const maxHistoryEntryBytes = 1200;

export class FriendlySimulationProgressError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = "FriendlySimulationProgressError";
    this.cause = cause;
  }
}

export class SimulationProgressAuthenticationError extends FriendlySimulationProgressError {
  constructor(cause) {
    super("Your sign-in has expired. Sign in again to keep saving your Simulation story.", cause);
    this.name = "SimulationProgressAuthenticationError";
  }
}

function isBoundedInteger(value, minimum, maximum) {
  return Number.isInteger(value) && value >= minimum && value <= maximum;
}

function byteLength(value) {
  return new TextEncoder().encode(value).length;
}

function assertProgressInput({
  storyId,
  gradeLevel,
  currentStep,
  attempts = 0,
  helpUses = 0,
  guidanceLevel = 0,
  responseHistory = []
}) {
  if (!storyIdPattern.test(storyId ?? "") || !supportedGradeLevels.has(gradeLevel)) {
    throw new FriendlySimulationProgressError("That story progress could not be saved. Please try again.");
  }

  if (!isBoundedInteger(currentStep, 0, 100)
    || !isBoundedInteger(attempts, 0, 1000)
    || !isBoundedInteger(helpUses, 0, 1000)
    || !isBoundedInteger(guidanceLevel, 0, 3)) {
    throw new FriendlySimulationProgressError("That story progress could not be saved. Please try again.");
  }

  if (!Array.isArray(responseHistory) || responseHistory.length > maxHistoryEntries) {
    throw new FriendlySimulationProgressError("That story progress could not be saved. Please try again.");
  }

  let serializedHistory;
  try {
    serializedHistory = JSON.stringify(responseHistory);
  } catch (error) {
    throw new FriendlySimulationProgressError("That story progress could not be saved. Please try again.", error);
  }

  const hasInvalidHistoryItem = responseHistory.some((item) => {
    if (!item || Array.isArray(item) || typeof item !== "object") {
      return true;
    }

    try {
      return byteLength(JSON.stringify(item)) > maxHistoryEntryBytes;
    } catch {
      return true;
    }
  });

  if (hasInvalidHistoryItem || byteLength(serializedHistory) > maxHistoryBytes) {
    throw new FriendlySimulationProgressError("That story progress could not be saved. Please try again.");
  }
}

function mapProgress(row) {
  if (!row || !storyIdPattern.test(row.story_id ?? "") || !supportedGradeLevels.has(row.grade_level)) {
    throw new Error("Simulation progress returned an invalid record.");
  }

  return {
    storyId: row.story_id,
    gradeLevel: row.grade_level,
    status: row.status === "completed" ? "completed" : "in_progress",
    currentStep: Number.isInteger(row.current_step) ? row.current_step : 0,
    attempts: Number.isInteger(row.attempts) ? row.attempts : 0,
    helpUses: Number.isInteger(row.help_uses) ? row.help_uses : 0,
    guidanceLevel: Number.isInteger(row.guidance_level) ? row.guidance_level : 0,
    responseHistory: Array.isArray(row.response_history) ? row.response_history : [],
    completedAt: row.completed_at ?? null,
    updatedAt: row.updated_at ?? null
  };
}

function toFriendlyError(error, fallbackMessage) {
  if (error instanceof FriendlySimulationProgressError) {
    return error;
  }

  const status = Number(error?.status ?? error?.statusCode ?? error?.code);
  const code = String(error?.code ?? "").toUpperCase();
  const message = String(error?.message ?? "");
  const isAuthenticationFailure = status === 401
    || status === 403
    || code === "PGRST301"
    || /(?:jwt|authentication|not authenticated|unauthorized|forbidden)/i.test(message);

  if (isAuthenticationFailure) {
    return new SimulationProgressAuthenticationError(error);
  }

  console.error("Numora Simulation progress request failed:", error);
  return new FriendlySimulationProgressError(fallbackMessage, error);
}

export async function getSimulationProgress() {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client
      .from("simulation_progress")
      .select("story_id, grade_level, status, current_step, attempts, help_uses, guidance_level, response_history, completed_at, updated_at")
      .order("updated_at", { ascending: false });

    if (error) {
      throw error;
    }

    return (data ?? []).map(mapProgress);
  } catch (error) {
    throw toFriendlyError(error, "We couldn't load your Simulation stories right now. Please try again shortly.");
  }
}

export async function saveSimulationProgress(progress) {
  assertProgressInput(progress);

  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("upsert_simulation_progress", {
      p_story_id: progress.storyId,
      p_grade_level: progress.gradeLevel,
      p_current_step: progress.currentStep,
      p_attempts: progress.attempts ?? 0,
      p_help_uses: progress.helpUses ?? 0,
      p_guidance_level: progress.guidanceLevel ?? 0,
      p_response_history: progress.responseHistory ?? []
    });

    if (error) {
      throw error;
    }

    const row = Array.isArray(data) ? data[0] : data;
    return mapProgress(row);
  } catch (error) {
    throw toFriendlyError(error, "We couldn't save this story right now. Your work is still kept on this device.");
  }
}
