import { getAppState, setStudentProgressSummary } from "./appState.js";
import { announceReward, broadcastEconomyChange, refreshEconomy } from "./economyService.js";
import { FriendlyProgressError, toStudentStats, toTodayActivity } from "./progressService.js";
import { getSupabaseClient } from "./supabase.js";

const allowedActivities = new Set([
  "decision:correct_answer",
  "decision:incorrect_answer",
  "decision:hint",
  "quant:correct_answer",
  "quant:incorrect_answer",
  "quant:hint",
  "simulation:story_completed",
  "arcade:arcade_correct",
]);

function validateActivityInput({ eventKey, module, topic = null, activityType, metadata = {} }) {
  if (!/^[a-z0-9][a-z0-9:_-]{2,180}$/.test(eventKey ?? "")) {
    throw new FriendlyProgressError("That activity could not be saved. Please try again.");
  }

  if (!allowedActivities.has(`${module}:${activityType}`)) {
    throw new FriendlyProgressError("That learning activity is not available yet.");
  }

  if (["decision", "quant", "simulation"].includes(module) && !String(topic ?? "").trim()) {
    throw new FriendlyProgressError("Choose a learning topic before saving this activity.");
  }

  if (metadata === null || Array.isArray(metadata) || typeof metadata !== "object") {
    throw new FriendlyProgressError("That activity could not be saved. Please try again.");
  }
}

function mapActivityResult(row) {
  if (typeof row.event_recorded !== "boolean" || typeof row.event_id !== "string"
    || ![row.total_xp, row.coin_balance, row.current_streak, row.today_xp, row.today_coins_earned, row.today_activities_completed]
      .every(value => Number.isSafeInteger(value) && value >= 0)
    || !/^\d{4}-\d{2}-\d{2}$/.test(row.local_date)) {
    throw new Error("Reward response is incomplete.");
  }
  return {
    eventId: row.event_id,
    eventRecorded: Boolean(row.event_recorded),
    stats: toStudentStats({
      total_xp: row.total_xp,
      coin_balance: row.coin_balance,
      current_streak: row.current_streak,
      last_streak_date: null
    }),
    todayActivity: toTodayActivity({
      local_date: row.local_date,
      xp_earned: row.today_xp,
      coins_earned: row.today_coins_earned,
      activities_completed: row.today_activities_completed
    })
  };
}

export async function recordActivity({ eventKey, module, topic = null, activityType, metadata = {} }) {
  const userId = getAppState().user?.id;
  validateActivityInput({ eventKey, module, topic, activityType, metadata });

  try {
    const client = await getSupabaseClient();
    const rpcName = module === "quant" ? "record_quant_activity_event" : "record_activity_event";
    const rpcArguments = module === "quant"
      ? {
        p_event_key: eventKey,
        p_topic: topic?.trim() || null,
        p_activity_type: activityType,
        p_metadata: metadata
      }
      : {
        p_event_key: eventKey,
        p_module: module,
        p_topic: topic?.trim() || null,
        p_activity_type: activityType,
        p_metadata: metadata
      };
    const { data, error } = await client.rpc(rpcName, rpcArguments);

    if (error) {
      throw error;
    }

    const row = Array.isArray(data) ? data[0] : data;
    if (!row) {
      throw new Error("Reward RPC returned no summary.");
    }

    const result = mapActivityResult(row);
    if (getAppState().user?.id === userId) {
      setStudentProgressSummary(result.stats, result.todayActivity);
      // A failed follow-up read must not turn a committed reward into a failure.
      try { await refreshEconomy(); } catch { /* Keep the confirmed RPC totals. */ }
      if (getAppState().user?.id === userId) {
        const ruleName = module === "simulation" ? "simulation_complete" : module === "arcade" ? "arcade_correct"
          : `${module}_${activityType === "correct_answer" ? "correct" : activityType === "incorrect_answer" ? "incorrect" : "hint"}`;
        announceReward(ruleName, result.eventRecorded);
        broadcastEconomyChange();
      }
    }
    return result;
  } catch (error) {
    if (error instanceof FriendlyProgressError) {
      throw error;
    }

    console.error("Numora reward request failed:", error);
    const isInsufficientCoins = /insufficient coins/i.test(error?.message ?? "");
    throw new FriendlyProgressError(
      isInsufficientCoins
        ? "You don't have enough coins for that yet."
        : "We couldn't save this learning activity. Please try again.",
      error
    );
  }
}
