import { getSupabaseClient } from "./supabase.js";
import { getAppState, setEconomySnapshot, subscribeToAppState } from "./appState.js";
import { readCalendar, secondsUntil } from "../utils/calendar.js";

let queue = Promise.resolve();
let channel;

export function rewardRule(name) {
  return getAppState().economy?.rules?.[name] ?? null;
}

export function announceReward(ruleName, recorded) {
  const rule = rewardRule(ruleName);
  if (!recorded || !rule || (!rule.xp && !rule.coins)) return;
  window.dispatchEvent(new CustomEvent("numora:reward", { detail: rule }));
}

export function refreshEconomy() {
  const userId = getAppState().user?.id;
  const request = async () => {
    if (!userId || getAppState().user?.id !== userId) return null;
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("get_my_economy_snapshot");
    if (error || !data?.stats || !data?.today || !data?.rules || !Number.isFinite(Date.parse(data.next_midnight))) {
      throw new Error("We couldn't load your progress right now. Please try again.");
    }
    if (getAppState().user?.id !== userId) return null;
    const snapshot = { ...data, receivedAt: performance.now(), calendar: data.calendar ? readCalendar(data.calendar) : null };
    setEconomySnapshot(snapshot);
    if (data.celebrate) window.dispatchEvent(new CustomEvent("numora:streak", {
      detail: { count: data.stats.current_streak }
    }));
    return snapshot;
  };
  const next = queue.catch(() => {}).then(request);
  queue = next;
  return next;
}

export function secondsToMidnight(snapshot) {
  if (!snapshot) return null;
  if (snapshot.calendar) return secondsUntil(snapshot.calendar, "nextMidnight");
  const duration = Date.parse(snapshot.next_midnight) - Date.parse(snapshot.server_now);
  const elapsed = performance.now() - snapshot.receivedAt;
  return Number.isFinite(duration) ? Math.max(0, Math.ceil((duration - elapsed) / 1000)) : null;
}

export function formatDayCountdown(seconds) {
  if (seconds === null) return "Checking the next reset…";
  return [Math.floor(seconds / 3600), Math.floor(seconds % 3600 / 60), seconds % 60]
    .map((part) => String(part).padStart(2, "0")).join(":");
}

export function broadcastEconomyChange() {
  channel?.postMessage({ userId: getAppState().user?.id });
}

export function startEconomySynchronization() {
  let pending = false;
  let lastCheck = 0;
  let retryDelay = 5000;
  const refresh = async () => {
    if (pending || getAppState().authStatus !== "authenticated") return;
    pending = true;
    lastCheck = performance.now();
    try { await refreshEconomy(); retryDelay = 5000; }
    catch { retryDelay = Math.min(60000, retryDelay * 2); /* Retain confirmed data; back off while offline. */ }
    finally { pending = false; }
  };
  try {
    channel = new BroadcastChannel("numora-economy");
    channel.addEventListener("message", (event) => {
      if (event.data?.userId === getAppState().user?.id) void refresh();
    });
  } catch { /* Focus and interval refresh also synchronize tabs. */ }
  window.addEventListener("focus", refresh);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) void refresh(); });
  window.setInterval(() => {
    if (document.hidden) return;
    const remaining = secondsToMidnight(getAppState().economy);
    const weekly = secondsUntil(getAppState().economy?.calendar, "nextWeeklyReset");
    if (performance.now() - lastCheck >= 60000 || ((remaining === 0 || weekly === 0) && performance.now() - lastCheck >= retryDelay)) void refresh();
  }, 1000);
  let userId = null;
  subscribeToAppState((state) => {
    if (state.user?.id !== userId) {
      userId = state.user?.id ?? null;
      lastCheck = performance.now();
      retryDelay = 5000;
    }
  });
}
