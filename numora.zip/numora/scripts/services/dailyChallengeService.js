import { getSupabaseClient } from "./supabase.js";
import { getAppState } from "./appState.js";
import { announceReward, broadcastEconomyChange, refreshEconomy } from "./economyService.js";

export async function getDailyChallenge(gradeLevel) {
  const client = await getSupabaseClient();
  const { data, error } = await client.rpc("get_my_daily_challenge", { p_grade_level: gradeLevel });
  if (error || !data?.id || !Array.isArray(data.options) || data.options.length < 2) {
    throw new Error("We couldn't load today's challenge. Please try again.");
  }
  return data;
}

export async function submitDailyChallenge(challenge, answer) {
  const userId = getAppState().user?.id;
  const client = await getSupabaseClient();
  const { data, error } = await client.rpc("submit_daily_challenge", {
    p_grade_level: challenge.grade_level, p_challenge_id: challenge.id,
    p_local_date: challenge.local_date, p_answer: answer
  });
  if (error || !data) throw new Error(/expired/i.test(error?.message ?? "")
    ? "A new day has started. Reload the challenge to try today's question."
    : "We couldn't check that answer. Please try again; a saved reward won't be awarded twice.");
  if (data.correct && getAppState().user?.id === userId) {
    try { await refreshEconomy(); } catch { /* The confirmed completion remains valid. */ }
    if (getAppState().user?.id === userId) {
      announceReward("daily_challenge", data.event_recorded);
      broadcastEconomyChange();
    }
  }
  return data;
}

export async function repairStreak(missedDate) {
  const userId = getAppState().user?.id;
  const client = await getSupabaseClient();
  const { data, error } = await client.rpc("repair_my_streak", { p_missed_date: missedDate });
  if (error || !data) throw new Error(/insufficient/i.test(error?.message ?? "")
    ? "You need 200 coins to repair your streak."
    : "We couldn't repair that day. Refresh your progress and try again.");
  if (getAppState().user?.id === userId) {
    try {
      const snapshot = await refreshEconomy();
      if (data.event_recorded && snapshot) window.dispatchEvent(new CustomEvent("numora:streak", {
        detail: { count: snapshot.stats.current_streak, repaired: true }
      }));
    } catch { /* Retrying the same date is safe. */ }
    if (getAppState().user?.id === userId) {
      announceReward("streak_repair", data.event_recorded);
      broadcastEconomyChange();
    }
  }
  return data;
}
