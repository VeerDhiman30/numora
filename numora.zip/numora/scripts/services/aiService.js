import { getLocalCoachFallback } from "../data/aiFallbacks.js";
import { getSupabaseClient } from "./supabase.js";

const supportedGradeLevels = new Set(["entry", "middle", "high"]);
const maxCoachMessageLength = 1200;
const maxSimulationResponseLength = 700;
const maxSimulationHistoryTurns = 6;
const maxSimulationHistoryMessageLength = 600;
const simulationRequestTimeoutMs = 10000;
const simulationStatuses = new Set(["correct", "incorrect", "guided", "uncertain"]);
const unavailableMessage = "Numora's coach is temporarily unavailable. Please try again.";
const activeSimulationRequests = new Map();

function createUnavailableResult(message, coachMessage) {
  return {
    success: false,
    message,
    fallbackMessage: getLocalCoachFallback(coachMessage),
    reason: "unavailable"
  };
}

function createInvalidResult(message) {
  return { success: false, message, fallbackMessage: null, reason: "invalid_request" };
}

function getSafeServerMessage(payload) {
  return typeof payload?.message === "string" && payload.message.trim()
    ? payload.message.trim()
    : unavailableMessage;
}

function normalizeContext(context) {
  const gradeLevel = context?.gradeLevel ?? "middle";

  if (!supportedGradeLevels.has(gradeLevel)) {
    return null;
  }

  return {
    gradeLevel,
    ...(context?.mode === "test" ? { mode: "test" } : {})
  };
}

function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isValidSimulationIdentifier(value) {
  return typeof value === "string"
    && value.length > 0
    && value.length <= 96
    && /^[a-z0-9][a-z0-9-]*$/.test(value);
}

function createSimulationUnavailableResult(message = unavailableMessage) {
  return {
    success: false,
    status: null,
    coachMessage: null,
    guidanceLevel: null,
    message,
    scriptedFallback: true,
    reason: "unavailable"
  };
}

function createSimulationInvalidResult(message) {
  return {
    success: false,
    status: null,
    coachMessage: null,
    guidanceLevel: null,
    message,
    scriptedFallback: false,
    reason: "invalid_request"
  };
}

function createSimulationAuthenticationResult(message) {
  return {
    success: false,
    status: null,
    coachMessage: null,
    guidanceLevel: null,
    message,
    scriptedFallback: false,
    reason: "authentication"
  };
}

function normalizeSimulationHistory(history) {
  if (history === undefined) {
    return [];
  }
  if (!Array.isArray(history) || history.length > maxSimulationHistoryTurns) {
    return null;
  }

  const normalized = [];
  for (const turn of history) {
    if (!isPlainObject(turn) || !["student", "coach"].includes(turn.role)
      || typeof turn.content !== "string") {
      return null;
    }

    const content = turn.content.trim();
    if (!content || content.length > maxSimulationHistoryMessageLength) {
      return null;
    }
    normalized.push({ role: turn.role, content });
  }

  return normalized;
}

function normalizeSimulationRequest(request) {
  if (!isPlainObject(request)) {
    return { error: "Use a valid Simulation coaching request." };
  }

  if (!isValidSimulationIdentifier(request.storyId)
    || !supportedGradeLevels.has(request.gradeLevel)
    || !isValidSimulationIdentifier(request.currentStep)) {
    return { error: "Use a valid Simulation story and step." };
  }

  const interaction = request.interaction === undefined ? "answer" : request.interaction;
  if (!["answer", "no_idea"].includes(interaction)) {
    return { error: "Use a valid Simulation response type." };
  }
  if (typeof request.studentResponse !== "string") {
    return { error: "Enter a Simulation response to continue." };
  }

  const studentResponse = request.studentResponse.trim();
  if ((interaction === "answer" && !studentResponse) || studentResponse.length > maxSimulationResponseLength) {
    return { error: "Keep your Simulation response under 700 characters." };
  }

  const guidanceLevel = request.guidanceLevel === undefined ? 0 : request.guidanceLevel;
  if (!Number.isInteger(guidanceLevel) || guidanceLevel < 0 || guidanceLevel > 3) {
    return { error: "Use a valid Simulation guidance level." };
  }

  const conversationHistory = normalizeSimulationHistory(request.conversationHistory);
  if (!conversationHistory) {
    return { error: "Use up to six valid recent Simulation conversation turns." };
  }

  return {
    value: {
      storyId: request.storyId,
      gradeLevel: request.gradeLevel,
      currentStep: request.currentStep,
      studentResponse: studentResponse || "I have no idea yet.",
      interaction,
      guidanceLevel,
      conversationHistory
    }
  };
}

function isSimulationSuccess(payload) {
  return payload?.success === true
    && simulationStatuses.has(payload.status)
    && typeof payload.coachMessage === "string"
    && payload.coachMessage.trim().length > 0
    && payload.coachMessage.trim().length <= 700
    && Number.isInteger(payload.guidanceLevel)
    && payload.guidanceLevel >= 0
    && payload.guidanceLevel <= 3;
}

async function getAuthenticatedAccessToken() {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.auth.getSession();

    if (error || !data.session?.access_token) {
      return { error: createSimulationAuthenticationResult("Please sign in to use Numora's coach.") };
    }

    return { value: data.session.access_token };
  } catch {
    return { error: createSimulationUnavailableResult() };
  }
}

async function postSimulationResponse(payload, accessToken) {
  const controller = typeof AbortController === "function" ? new AbortController() : null;
  const timeoutId = controller ? globalThis.setTimeout(() => controller.abort(), simulationRequestTimeoutMs) : null;

  let response;
  try {
    response = await fetch("/api/ai/simulation", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload),
      ...(controller ? { signal: controller.signal } : {})
    });
  } catch {
    return createSimulationUnavailableResult();
  } finally {
    if (timeoutId !== null) {
      globalThis.clearTimeout(timeoutId);
    }
  }

  let responsePayload;
  try {
    responsePayload = await response.json();
  } catch {
    return createSimulationUnavailableResult();
  }

  if (response.ok && isSimulationSuccess(responsePayload)) {
    return {
      success: true,
      status: responsePayload.status,
      coachMessage: responsePayload.coachMessage.trim(),
      guidanceLevel: responsePayload.guidanceLevel,
      message: responsePayload.coachMessage.trim(),
      scriptedFallback: false,
      reason: null
    };
  }

  const serverMessage = getSafeServerMessage(responsePayload);
  if (response.status === 401) {
    return createSimulationAuthenticationResult(serverMessage);
  }
  if (response.status >= 400 && response.status < 500 && response.status !== 429) {
    return createSimulationInvalidResult(serverMessage);
  }

  return createSimulationUnavailableResult(serverMessage);
}

export async function sendCoachMessage(message, context = {}) {
  if (typeof message !== "string") {
    return createInvalidResult("Enter a coaching question to continue.");
  }

  const trimmedMessage = message.trim();
  if (!trimmedMessage) {
    return createInvalidResult("Enter a coaching question to continue.");
  }
  if (trimmedMessage.length > maxCoachMessageLength) {
    return createInvalidResult("Keep your coaching question under 1,200 characters.");
  }

  const safeContext = normalizeContext(context);
  if (!safeContext) {
    return createInvalidResult("Choose a supported Numora learning level.");
  }

  let accessToken;
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.auth.getSession();

    if (error || !data.session?.access_token) {
      return { success: false, message: "Please sign in to use Numora's coach.", fallbackMessage: null, reason: "authentication" };
    }

    accessToken = data.session.access_token;
  } catch {
    return createUnavailableResult(unavailableMessage, trimmedMessage);
  }

  let response;
  try {
    response = await fetch("/api/ai/chat", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message: trimmedMessage, context: safeContext })
    });
  } catch {
    return createUnavailableResult(unavailableMessage, trimmedMessage);
  }

  let payload;
  try {
    payload = await response.json();
  } catch {
    return createUnavailableResult(unavailableMessage, trimmedMessage);
  }

  if (response.ok && payload?.success === true && typeof payload.message === "string" && payload.message.trim()) {
    return { success: true, message: payload.message.trim(), fallbackMessage: null, reason: null };
  }

  const serverMessage = getSafeServerMessage(payload);
  if (response.status === 401) {
    return { success: false, message: serverMessage, fallbackMessage: null, reason: "authentication" };
  }
  if (response.status >= 400 && response.status < 500) {
    return { success: false, message: serverMessage, fallbackMessage: null, reason: "invalid_request" };
  }

  return createUnavailableResult(serverMessage, trimmedMessage);
}

export function sendSimulationResponse(request) {
  const normalizedRequest = normalizeSimulationRequest(request);
  if (normalizedRequest.error) {
    return Promise.resolve(createSimulationInvalidResult(normalizedRequest.error));
  }

  const payload = normalizedRequest.value;
  const requestKey = JSON.stringify(payload);
  const activeRequest = activeSimulationRequests.get(requestKey);
  if (activeRequest) {
    return activeRequest;
  }

  const requestPromise = (async () => {
    const authentication = await getAuthenticatedAccessToken();
    if (authentication.error) {
      return authentication.error;
    }

    return postSimulationResponse(payload, authentication.value);
  })().finally(() => {
    activeSimulationRequests.delete(requestKey);
  });

  activeSimulationRequests.set(requestKey, requestPromise);
  return requestPromise;
}
