// Shared client-side presentation state. Supabase remains the source of truth for
// student progress; these fields are only the currently displayed server snapshot.
const state = {
  authStatus: "checking",
  user: null,
  totalXp: null,
  coins: null,
  streak: null,
  dailyXp: null,
  dailyCoins: null,
  dailyActivities: null,
  economy: null,
  soundEnabled: true,
  postAuthRoute: null
};

const listeners = new Set();
const soundPreferenceKey = "numora-sound-enabled";

function notify() {
  listeners.forEach((listener) => listener(getAppState()));
}

function loadSoundPreference() {
  try {
    const savedValue = window.localStorage.getItem(soundPreferenceKey);
    return savedValue === null ? state.soundEnabled : savedValue === "true";
  } catch {
    return state.soundEnabled;
  }
}

state.soundEnabled = loadSoundPreference();

export function getAppState() {
  return {
    ...state,
    user: state.user ? { ...state.user } : null
  };
}

export function subscribeToAppState(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function setAuthChecking() {
  state.authStatus = "checking";
  notify();
}

export function setAuthenticatedUser(user) {
  const isDifferentStudent = state.user?.id !== user.id;

  state.authStatus = "authenticated";
  state.user = {
    id: user.id,
    email: user.email ?? "",
    firstName: user.firstName ?? "",
    lastName: user.lastName ?? "",
    gradeLevel: user.gradeLevel ?? "middle",
    timezone: user.timezone ?? "UTC"
  };

  if (isDifferentStudent) {
    state.economy = null;
    state.totalXp = null;
    state.coins = null;
    state.streak = null;
    state.dailyXp = null;
    state.dailyCoins = null;
    state.dailyActivities = null;
  }

  notify();
}

export function setLoggedOut() {
  state.economy = null;
  state.authStatus = "anonymous";
  state.user = null;
  state.totalXp = null;
  state.coins = null;
  state.streak = null;
  state.dailyXp = null;
  state.dailyCoins = null;
  state.dailyActivities = null;
  state.postAuthRoute = null;
  notify();
}

export function setStudentProgressSummary(stats, todayActivity = null) {
  state.totalXp = Number.isInteger(stats?.totalXp) ? stats.totalXp : null;
  state.coins = Number.isInteger(stats?.coinBalance) ? stats.coinBalance : null;
  state.streak = Number.isInteger(stats?.currentStreak) ? stats.currentStreak : null;
  state.dailyXp = Number.isInteger(todayActivity?.xpEarned) ? todayActivity.xpEarned : null;
  state.dailyCoins = Number.isInteger(todayActivity?.coinsEarned) ? todayActivity.coinsEarned : null;
  state.dailyActivities = Number.isInteger(todayActivity?.activitiesCompleted)
    ? todayActivity.activitiesCompleted
    : null;
  notify();
}

export function setEconomySnapshot(snapshot) {
  state.economy = snapshot;
  setStudentProgressSummary({ totalXp: snapshot.stats.total_xp, coinBalance: snapshot.stats.coin_balance,
    currentStreak: snapshot.stats.current_streak }, { xpEarned: snapshot.today.xp_earned,
    coinsEarned: snapshot.today.coins_earned, activitiesCompleted: snapshot.today.activities_completed });
}

export function setPostAuthRoute(route) {
  state.postAuthRoute = route;
}

export function consumePostAuthRoute() {
  const route = state.postAuthRoute;
  state.postAuthRoute = null;
  return route;
}

export function setSoundEnabled(isEnabled) {
  state.soundEnabled = Boolean(isEnabled);

  try {
    window.localStorage.setItem(soundPreferenceKey, String(state.soundEnabled));
  } catch {
    // Sound preference remains available for this session when storage is unavailable.
  }

  notify();
  return state.soundEnabled;
}
