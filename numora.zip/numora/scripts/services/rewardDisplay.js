import { getAppState } from "./appState.js";

// Presentation-only compatibility for installations awaiting migration 007.
// Once loaded, every display uses the database rule; clients never award deltas.
const legacyLabels = Object.freeze({
  decision_correct: { xp: 5, coins: 0 }, decision_hint: { xp: 0, coins: -10 },
  quant_correct: { xp: 1, coins: 0 }, quant_hint: { xp: 0, coins: -2 },
  simulation_complete: { xp: 10, coins: 0 }, arcade_correct: { xp: 0, coins: 1 }
});
export function displayReward(name) {
  return getAppState().economy?.rules?.[name] ?? legacyLabels[name];
}
