// Numora is served as vanilla browser modules, so this ESM build avoids requiring
// a bundler while the same package remains pinned in package.json for development.
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.116.0/+esm";

const authStorageKey = "numora-auth-session";
const rememberPreferenceKey = "numora-remember-session";
let clientPromise;

export class SupabaseConfigurationError extends Error {
  constructor(message) {
    super(message);
    this.name = "SupabaseConfigurationError";
  }
}

function getPersistentStorage() {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function getSessionStorage() {
  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
}

function shouldRememberSession() {
  return getPersistentStorage()?.getItem(rememberPreferenceKey) === "true";
}

const adaptiveAuthStorage = {
  getItem(key) {
    return (shouldRememberSession() ? getPersistentStorage() : getSessionStorage())?.getItem(key) ?? null;
  },
  setItem(key, value) {
    const target = shouldRememberSession() ? getPersistentStorage() : getSessionStorage();
    const other = shouldRememberSession() ? getSessionStorage() : getPersistentStorage();
    target?.setItem(key, value);
    other?.removeItem(key);
  },
  removeItem(key) {
    getPersistentStorage()?.removeItem(key);
    getSessionStorage()?.removeItem(key);
  }
};

async function loadPublicConfig() {
  let response;

  try {
    response = await fetch("/api/config", { cache: "no-store" });
  } catch (error) {
    console.error("Numora could not load its public configuration:", error);
    throw new SupabaseConfigurationError("Numora could not connect right now. Please try again shortly.");
  }

  if (!response.ok) {
    throw new SupabaseConfigurationError("Numora could not connect right now. Please try again shortly.");
  }

  const config = await response.json();
  if (!config.supabaseUrl || !config.supabasePublishableKey) {
    throw new SupabaseConfigurationError("Numora sign-in is not ready yet. Please check back soon.");
  }

  return config;
}

export function setSessionPersistence(rememberSession) {
  const persistentStorage = getPersistentStorage();
  const sessionStorage = getSessionStorage();

  if (rememberSession) {
    persistentStorage?.setItem(rememberPreferenceKey, "true");
    sessionStorage?.removeItem(authStorageKey);
  } else {
    persistentStorage?.removeItem(rememberPreferenceKey);
    persistentStorage?.removeItem(authStorageKey);
    sessionStorage?.removeItem(authStorageKey);
  }
}

export function clearStoredSession() {
  getPersistentStorage()?.removeItem(rememberPreferenceKey);
  adaptiveAuthStorage.removeItem(authStorageKey);
}

export async function getSupabaseClient() {
  if (!clientPromise) {
    clientPromise = loadPublicConfig()
      .then(({ supabaseUrl, supabasePublishableKey }) => createClient(supabaseUrl, supabasePublishableKey, {
        auth: {
          autoRefreshToken: true,
          detectSessionInUrl: true,
          persistSession: true,
          storage: adaptiveAuthStorage,
          storageKey: authStorageKey
        }
      }))
      .catch((error) => {
        clientPromise = undefined;
        throw error;
      });
  }

  return clientPromise;
}
