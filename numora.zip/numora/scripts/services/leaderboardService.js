import { getSupabaseClient } from "./supabase.js";
import { getAppState } from "./appState.js";
import { readCalendar } from "../utils/calendar.js";

const friendlyError = () => new Error("We couldn’t load the leaderboard. Please try again.");
const validInteger = (value) => Number.isSafeInteger(value) && value >= 0;

// Only allow leaderboard-safe fields into the view. Ranking stays in PostgreSQL.
function studentRow(row, allowUnranked = false) {
  if (!row || typeof row.display_name !== "string" || !validInteger(row.weekly_xp)
    || typeof row.is_current_user !== "boolean"
    || !(Number.isSafeInteger(row.rank) && row.rank > 0 || allowUnranked && row.rank === null && row.weekly_xp === 0)) {
    throw friendlyError();
  }
  return { displayName: row.display_name, weeklyXp: row.weekly_xp, rank: row.rank, isCurrentUser: row.is_current_user };
}

export async function getWeeklyLeaderboard() {
  const userId = getAppState().user?.id;
  if (!userId) throw friendlyError();
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("get_weekly_tournament", { p_limit: 10 });
    if (getAppState().user?.id !== userId) return null;
    if (error || !data || !Array.isArray(data.entries) || data.entries.length > 10
      || data.limit !== 10 || typeof data.timezone !== "string"
      || !/^\d{4}-\d{2}-\d{2}$/.test(data.week_start) || !/^\d{4}-\d{2}-\d{2}$/.test(data.through_date)) {
      throw friendlyError();
    }
    const currentStudent = studentRow(data.current_student, true);
    if (!currentStudent.isCurrentUser) throw friendlyError();
    const calendar = readCalendar(data.calendar);
    if (calendar.weekStart !== data.week_start || calendar.localDate !== data.through_date) throw friendlyError();
    return {
      weekStart: data.week_start, throughDate: data.through_date, timezone: data.timezone,
      entries: data.entries.map((row) => studentRow(row)), currentStudent, calendar
    };
  } catch {
    // Never display database errors, request details, or credentials to students.
    throw friendlyError();
  }
}
