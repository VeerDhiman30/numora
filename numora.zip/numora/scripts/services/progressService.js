import { getAppState, setStudentProgressSummary } from "./appState.js";
import { getSupabaseClient } from "./supabase.js";

export class FriendlyProgressError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = "FriendlyProgressError";
    this.cause = cause;
  }
}

function asNonNegativeInteger(value, fallback = 0) {
  const number = Number(value);
  return Number.isInteger(number) && number >= 0 ? number : fallback;
}

function toStudentStats(row) {
  return {
    totalXp: asNonNegativeInteger(row.total_xp),
    coinBalance: asNonNegativeInteger(row.coin_balance),
    currentStreak: asNonNegativeInteger(row.current_streak),
    lastStreakDate: row.last_streak_date ?? null
  };
}

function toTodayActivity(row = {}) {
  return {
    localDate: row.local_date ?? null,
    xpEarned: asNonNegativeInteger(row.xp_earned),
    coinsEarned: asNonNegativeInteger(row.coins_earned),
    activitiesCompleted: asNonNegativeInteger(row.activities_completed)
  };
}

export function getTopicMastery(progress = {}) {
  const attempts = asNonNegativeInteger(progress.attemptCount);
  const correct = asNonNegativeInteger(progress.correctCount);

  if (!attempts) {
    return null;
  }

  return Math.round((correct / attempts) * 100);
}

function throwFriendlyProgressError(message, error) {
  console.error("Numora progress request failed:", error);
  throw new FriendlyProgressError(message, error);
}

export async function getStudentStats() {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client
      .from("student_stats")
      .select("total_xp, coin_balance, current_streak, last_streak_date")
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      throw new Error("Student stats row is missing.");
    }

    return toStudentStats(data);
  } catch (error) {
    if (error instanceof FriendlyProgressError) {
      throw error;
    }
    throwFriendlyProgressError("We couldn't load your learning summary right now. Please try again shortly.", error);
  }
}

export async function getTodayActivity() {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("get_my_today_activity");

    if (error) {
      throw error;
    }

    return toTodayActivity(Array.isArray(data) ? data[0] : data);
  } catch (error) {
    if (error instanceof FriendlyProgressError) {
      throw error;
    }
    throwFriendlyProgressError("We couldn't load today's activity right now. Please try again shortly.", error);
  }
}

export async function getWeeklyXp() {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("get_my_weekly_xp");

    if (error) {
      throw error;
    }

    return asNonNegativeInteger(data);
  } catch (error) {
    if (error instanceof FriendlyProgressError) {
      throw error;
    }
    throwFriendlyProgressError("We couldn't load this week's activity right now. Please try again shortly.", error);
  }
}

export async function getModuleProgress({ module, topic } = {}) {
  try {
    const client = await getSupabaseClient();
    let query = client
      .from("module_progress")
      .select("module, grade_level, topic, completed_count, correct_count, attempt_count, updated_at")
      .order("updated_at", { ascending: false });

    if (module) {
      query = query.eq("module", module);
    }
    if (topic) {
      query = query.eq("topic", topic);
    }

    const { data, error } = await query;
    if (error) {
      throw error;
    }

    return (data ?? []).map((row) => {
      const completedCount = asNonNegativeInteger(row.completed_count);
      const correctCount = asNonNegativeInteger(row.correct_count);
      const attemptCount = asNonNegativeInteger(row.attempt_count);

      return {
        module: row.module,
        gradeLevel: row.grade_level,
        topic: row.topic,
        completedCount,
        correctCount,
        attemptCount,
        mastery: getTopicMastery({ correctCount, attemptCount }),
        updatedAt: row.updated_at
      };
    });
  } catch (error) {
    if (error instanceof FriendlyProgressError) {
      throw error;
    }
    throwFriendlyProgressError("We couldn't load your module progress right now. Please try again shortly.", error);
  }
}

export async function getActivityHistory(limit = 30) {
  try {
    const client = await getSupabaseClient();
    const safeLimit = Math.min(Math.max(Number.parseInt(limit, 10) || 30, 1), 100);
    const { data, error } = await client
      .from("activity_events")
      .select("id, event_key, module, topic, activity_type, xp_delta, coin_delta, occurred_at, local_date")
      .order("occurred_at", { ascending: false })
      .limit(safeLimit);

    if (error) {
      throw error;
    }

    return (data ?? []).map((row) => ({
      id: row.id,
      eventKey: row.event_key,
      module: row.module,
      topic: row.topic,
      activityType: row.activity_type,
      xpDelta: asNonNegativeInteger(row.xp_delta),
      coinDelta: Number.isInteger(Number(row.coin_delta)) ? Number(row.coin_delta) : 0,
      occurredAt: row.occurred_at,
      localDate: row.local_date
    }));
  } catch (error) {
    if (error instanceof FriendlyProgressError) {
      throw error;
    }
    throwFriendlyProgressError("We couldn't load your activity history right now. Please try again shortly.", error);
  }
}

export async function refreshStudentProgress() {
  const userId = getAppState().user?.id;
  try {
    const { refreshEconomy } = await import("./economyService.js");
    const snapshot = await refreshEconomy();
    if (snapshot) return { stats: toStudentStats(snapshot.stats), todayActivity: toTodayActivity(snapshot.today) };
  } catch {
    // Older installations keep their existing Labs while the Phase 7 migration is pending.
  }
  const stats = await getStudentStats();
  let todayActivity;

  try {
    todayActivity = await getTodayActivity();
  } catch (error) {
    console.error("Numora could not refresh today's activity:", error);
  }

  if (getAppState().user?.id === userId) setStudentProgressSummary(stats, todayActivity);
  return { stats, todayActivity: todayActivity ?? null };
}

export { toStudentStats, toTodayActivity };
