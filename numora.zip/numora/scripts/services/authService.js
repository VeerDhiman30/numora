import { clearStoredSession, getSupabaseClient, setSessionPersistence } from "./supabase.js";
import { setAuthenticatedUser, setAuthChecking, setLoggedOut } from "./appState.js";
import { refreshStudentProgress } from "./progressService.js";

let authSubscription;
let recoveryListener;
let sessionRevision = 0;
let signingOut = false;

export class FriendlyAuthError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = "FriendlyAuthError";
    this.cause = cause;
  }
}

function getBrowserTimezone() {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
}

function getValidGradeLevel(gradeLevel) {
  return ["entry", "middle", "high"].includes(gradeLevel) ? gradeLevel : "middle";
}

function getRedirectUrl(mode) {
  const url = new URL(window.location.href);
  url.hash = "";
  url.search = "";
  url.searchParams.set("auth", mode);
  return url.toString();
}

function toProfile(user, profile) {
  const metadata = user.user_metadata ?? {};
  return {
    id: user.id,
    email: user.email,
    firstName: profile?.first_name ?? metadata.first_name ?? "",
    lastName: profile?.last_name ?? metadata.last_name ?? "",
    gradeLevel: getValidGradeLevel(profile?.grade_level ?? metadata.grade_level),
    timezone: profile?.timezone ?? metadata.timezone ?? "UTC"
  };
}

async function loadProfile(client, user) {
  const { data, error } = await client
    .from("profiles")
    .select("id, first_name, last_name, grade_level, timezone")
    .eq("id", user.id)
    .maybeSingle();

  if (error) {
    console.error("Numora could not load the student profile:", error);
    return null;
  }

  return data;
}

async function synchronizeProfile(client, user, details = {}) {
  const metadata = user.user_metadata ?? {};
  const profile = {
    id: user.id,
    first_name: details.firstName ?? metadata.first_name ?? "",
    last_name: details.lastName ?? metadata.last_name ?? "",
    grade_level: getValidGradeLevel(details.gradeLevel ?? metadata.grade_level),
    timezone: details.timezone ?? metadata.timezone ?? getBrowserTimezone()
  };
  const { error } = await client.from("profiles").upsert(profile, { onConflict: "id" });

  if (error) {
    console.error("Numora could not synchronize the student profile:", error);
  }
}

async function synchronizeProfileTimezone(client, user, profile) {
  const timezone = getBrowserTimezone();

  if (!profile || profile.timezone === timezone) {
    return profile;
  }

  const { error } = await client
    .from("profiles")
    .update({ timezone })
    .eq("id", user.id);

  if (error) {
    console.error("Numora could not update the student timezone:", error);
    return profile;
  }

  return { ...profile, timezone };
}

async function synchronizeSession(session, details) {
  if (signingOut) return null;
  const revision = ++sessionRevision;
  const current = () => revision === sessionRevision && !signingOut;
  if (!session?.user) {
    setLoggedOut();
    return null;
  }

  setAuthChecking();
  const client = await getSupabaseClient();
  if (!current()) return null;
  let profile = await loadProfile(client, session.user);
  if (!current()) return null;

  if (details || !profile) {
    await synchronizeProfile(client, session.user, details);
    if (!current()) return null;
    profile = await loadProfile(client, session.user);
    if (!current()) return null;
  }

  profile = await synchronizeProfileTimezone(client, session.user, profile);
  if (!current()) return null;
  setAuthenticatedUser(toProfile(session.user, profile));

  try {
    await refreshStudentProgress();
  } catch (error) {
    console.error("Numora could not load the student progress summary:", error);
  }

  return profile;
}

function throwFriendlyError(message, error) {
  console.error("Numora authentication request failed:", error);
  throw new FriendlyAuthError(message, error);
}

export async function initializeAuthentication({ onPasswordRecovery } = {}) {
  const revision = ++sessionRevision;
  recoveryListener = onPasswordRecovery;
  setAuthChecking();

  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.auth.getSession();
    if (revision !== sessionRevision || signingOut) return;

    if (error) {
      throw error;
    }

    await synchronizeSession(data.session);

    if (!authSubscription) {
      const { data: listener } = client.auth.onAuthStateChange((event, session) => {
        if (event === "PASSWORD_RECOVERY") {
          recoveryListener?.();
        }

        if (event === "SIGNED_OUT") {
          sessionRevision++;
          setLoggedOut();
          return;
        }

        if (session && ["SIGNED_IN", "TOKEN_REFRESHED", "USER_UPDATED", "PASSWORD_RECOVERY"].includes(event)) {
          void synchronizeSession(session).catch(() => {
            // A failed refresh must never produce an unhandled auth rejection.
            if (!signingOut) { sessionRevision++; setLoggedOut(); }
          });
        }
      });
      authSubscription = listener.subscription;
    }
  } catch (error) {
    console.error("Numora could not restore authentication:", error);
    setLoggedOut();
  }
}

export async function signUp({ firstName, lastName, email, password, gradeLevel }) {
  try {
    setSessionPersistence(true);
    const client = await getSupabaseClient();
    const timezone = getBrowserTimezone();
    const { data, error } = await client.auth.signUp({
      email,
      password,
      options: {
        data: {
          first_name: firstName,
          last_name: lastName,
          grade_level: gradeLevel,
          timezone
        },
        emailRedirectTo: getRedirectUrl("confirmed")
      }
    });

    if (error) {
      throwFriendlyError("We couldn't create your account. Please check your information and try again.", error);
    }

    if (data.session) {
      await synchronizeSession(data.session, { firstName, lastName, gradeLevel, timezone });
    }

    return { requiresEmailConfirmation: !data.session };
  } catch (error) {
    if (error instanceof FriendlyAuthError) {
      throw error;
    }
    throwFriendlyError("We couldn't create your account. Please try again.", error);
  }
}

export async function signIn({ email, password, rememberMe }) {
  try {
    setSessionPersistence(rememberMe);
    const client = await getSupabaseClient();
    const { data, error } = await client.auth.signInWithPassword({ email, password });

    if (error || !data.session) {
      throwFriendlyError("We couldn't sign you in. Please check your information and try again.", error);
    }

    await synchronizeSession(data.session);
  } catch (error) {
    if (error instanceof FriendlyAuthError) {
      throw error;
    }
    throwFriendlyError("We couldn't sign you in. Please try again.", error);
  }
}

export async function sendPasswordRecovery(email) {
  try {
    const client = await getSupabaseClient();
    const { error } = await client.auth.resetPasswordForEmail(email, {
      redirectTo: getRedirectUrl("reset")
    });

    if (error) {
      throwFriendlyError("We couldn't send reset instructions right now. Please try again.", error);
    }
  } catch (error) {
    if (error instanceof FriendlyAuthError) {
      throw error;
    }
    throwFriendlyError("We couldn't send reset instructions right now. Please try again.", error);
  }
}

export async function updatePassword(password) {
  try {
    const client = await getSupabaseClient();
    const { error } = await client.auth.updateUser({ password });

    if (error) {
      throwFriendlyError("We couldn't update your password. Please try again.", error);
    }
  } catch (error) {
    if (error instanceof FriendlyAuthError) {
      throw error;
    }
    throwFriendlyError("We couldn't update your password. Please try again.", error);
  }
}

export async function signOut() {
  signingOut = true;
  sessionRevision++;
  setLoggedOut(); // Remove private views immediately, even if the network is down.
  try {
    const client = await getSupabaseClient();
    const { error } = await client.auth.signOut();

    if (error) {
      console.error("Numora could not sign out through Supabase:", error);
    }
  } finally {
    sessionRevision++;
    clearStoredSession();
    setLoggedOut();
    signingOut = false;
  }
}
