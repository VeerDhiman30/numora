// Calendar boundaries are calculated once in PostgreSQL using the stored IANA
// zone. Browser clocks only animate the distance to those authoritative instants.
const datePattern = /^\d{4}-\d{2}-\d{2}$/;
export function readCalendar(data, monotonicNow = performance.now(), wallNow = Date.now()) {
  if (!data || ![data.local_date, data.week_start, data.week_end].every(value => datePattern.test(value))
    || ![data.server_now, data.next_midnight, data.next_weekly_reset].every(value => Number.isFinite(Date.parse(value)))
    || data.week_start > data.local_date || data.local_date >= data.week_end
    || Date.parse(data.next_midnight) <= Date.parse(data.server_now)
    || Date.parse(data.next_weekly_reset) < Date.parse(data.next_midnight)) {
    throw new Error("Calendar data is unavailable. Please refresh.");
  }
  return {
    localDate: data.local_date, weekStart: data.week_start, weekEnd: data.week_end,
    nextMidnight: data.next_midnight, nextWeeklyReset: data.next_weekly_reset,
    serverNow: data.server_now, receivedAt: monotonicNow, receivedWallAt: wallNow
  };
}

export function secondsUntil(calendar, boundary, monotonicNow = performance.now(), wallNow = Date.now()) {
  if (!calendar) return null;
  const duration = Date.parse(calendar[boundary]) - Date.parse(calendar.serverNow);
  // Wall elapsed handles sleep on platforms where performance.now pauses. A
  // clock adjustment can trigger a read, but cannot change authoritative XP.
  const elapsed = Math.max(0, monotonicNow - calendar.receivedAt, wallNow - calendar.receivedWallAt);
  return Number.isFinite(duration) && Number.isFinite(elapsed) ? Math.max(0, Math.ceil((duration - elapsed) / 1000)) : null;
}

export function formatWeeklyCountdown(seconds) {
  if (seconds === null) return "Checking reset time…";
  if (seconds === 0) return "Updating this week…";
  if (seconds < 60) return "Less than 1 minute";
  const days = Math.floor(seconds / 86400);
  const hours = String(Math.floor(seconds % 86400 / 3600)).padStart(2, "0");
  const minutes = String(Math.floor(seconds % 3600 / 60)).padStart(2, "0");
  return `${days}d ${hours}h ${minutes}m`;
}

export function formatCalendarDate(value) {
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" })
    .format(new Date(`${value}T12:00:00Z`));
}
