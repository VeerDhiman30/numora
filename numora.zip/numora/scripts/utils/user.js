export function getInitials(firstName, lastName) {
  const first = typeof firstName === "string" ? firstName.trim() : "";
  const last = typeof lastName === "string" ? lastName.trim() : "";
  const firstInitial = first ? first.charAt(0).toUpperCase() : "";
  const lastInitial = last ? last.charAt(0).toUpperCase() : "";

  return `${firstInitial}${lastInitial}`.slice(0, 2) || "?";
}

export function getFullName(firstName, lastName) {
  return [firstName, lastName]
    .filter((name) => typeof name === "string" && name.trim())
    .map((name) => name.trim())
    .join(" ") || "Student";
}

export function formatGradeLevel(gradeLevel) {
  const gradeLabels = {
    entry: "Entry Level · Grades 3–5",
    middle: "Middle School · Grades 6–8",
    high: "High School · Grades 9–12"
  };

  return gradeLabels[gradeLevel] ?? "Learning level to be selected";
}
