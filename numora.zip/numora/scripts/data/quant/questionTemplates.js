function asText(value) {
  return String(value);
}

function baseQuestion({ id, gradeLevel, topic, instruction, prompt, explanation, hint }) {
  return { id, gradeLevel, topic, instruction, prompt, explanation, hint };
}

export function createNumericQuestion({
  id,
  gradeLevel,
  topic,
  prompt,
  answer,
  explanation,
  hint,
  instruction = "Enter your answer as a number.",
  answerLabel = "Your answer",
  inputMode = "numeric",
  acceptedAnswers = [],
  percentage = false,
  tolerance
}) {
  return {
    ...baseQuestion({ id, gradeLevel, topic, instruction, prompt, explanation, hint }),
    type: "written-answer",
    data: { inputMode, answerLabel },
    answer: asText(answer),
    acceptedAnswers: acceptedAnswers.map(asText),
    answerFormat: "numeric",
    ...(percentage ? { percentage: true } : {}),
    ...(Number.isFinite(tolerance) ? { tolerance } : {})
  };
}

export function createFractionQuestion({
  id,
  gradeLevel,
  topic,
  prompt,
  answer,
  explanation,
  hint,
  instruction = "Enter your answer as a simplified fraction.",
  answerLabel = "Your answer",
  acceptedAnswers = []
}) {
  return {
    ...baseQuestion({ id, gradeLevel, topic, instruction, prompt, explanation, hint }),
    type: "written-answer",
    data: { inputMode: "text", answerLabel },
    answer,
    acceptedAnswers,
    answerFormat: "fraction",
    requireSimplified: true
  };
}

export function createChoiceQuestion({
  id,
  gradeLevel,
  topic,
  prompt,
  answer,
  options,
  explanation,
  hint,
  instruction = "Choose the best answer."
}) {
  return {
    ...baseQuestion({ id, gradeLevel, topic, instruction, prompt, explanation, hint }),
    type: "single-choice",
    options,
    answer,
  };
}

export function createTrueFalseQuestion({
  id,
  gradeLevel,
  topic,
  prompt,
  answer,
  explanation,
  hint,
  instruction = "Choose whether the statement is true or false."
}) {
  return {
    ...baseQuestion({ id, gradeLevel, topic, instruction, prompt, explanation, hint }),
    type: "true-false",
    answer: answer ? "true" : "false"
  };
}

export function createMultipleSelectQuestion({
  id,
  gradeLevel,
  topic,
  prompt,
  options,
  correctOptions,
  explanation,
  hint,
  instruction = "Select every answer that is correct."
}) {
  return {
    ...baseQuestion({ id, gradeLevel, topic, instruction, prompt, explanation, hint }),
    type: "multiple-select",
    options,
    correctOptions
  };
}
