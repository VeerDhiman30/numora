export const quantGradeLevels = [
  { id: "entry", title: "Entry Level", description: "Grades 3–5" },
  { id: "middle", title: "Middle School", description: "Grades 6–8" },
  { id: "high", title: "High School", description: "Grades 9–12" }
];

const topicsByGrade = {
  entry: [
    ["addition-subtraction", "Addition & Subtraction"],
    ["multiplication-division", "Multiplication & Division"],
    ["place-value", "Place Value"],
    ["fractions", "Fractions"],
    ["measurement", "Measurement"],
    ["geometry", "Geometry"],
    ["time-money", "Time & Money"],
    ["patterns", "Patterns"],
    ["data", "Data"]
  ],
  middle: [
    ["ratios-proportions", "Ratios & Proportions"],
    ["percentages", "Percentages"],
    ["fractions-decimals", "Fractions & Decimals"],
    ["expressions-equations", "Expressions & Equations"],
    ["factors-multiples", "Factors & Multiples"],
    ["geometry", "Geometry"],
    ["probability", "Probability"],
    ["statistics", "Statistics"],
    ["coordinate-graphs", "Coordinate Graphs"],
    ["intro-functions", "Intro Functions"]
  ],
  high: [
    ["algebra", "Algebra"],
    ["linear-functions", "Linear Functions"],
    ["quadratic-functions", "Quadratic Functions"],
    ["systems-equations", "Systems of Equations"],
    ["geometry", "Geometry"],
    ["trigonometry", "Trigonometry"],
    ["probability-statistics", "Probability & Statistics"],
    ["exponents-logarithms", "Exponents & Logarithms"],
    ["sequences", "Sequences"],
    ["financial-mathematics", "Financial Mathematics"],
    ["precalculus", "Precalculus"]
  ]
};

export function getQuantTopics(gradeLevel) {
  const topics = topicsByGrade[gradeLevel] ?? [];
  return [
    { id: "mix", title: "Mix", description: "Practice a variety of topics" },
    ...topics.map(([id, title]) => ({ id, title, description: title }))
  ];
}

export function getQuantTopic(gradeLevel, topicId) {
  return getQuantTopics(gradeLevel).find((topic) => topic.id === topicId) ?? null;
}
