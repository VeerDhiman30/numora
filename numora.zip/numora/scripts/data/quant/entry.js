import { entryExtendedQuestions } from "./extendedBanks.js";

export const entryQuantQuestions = [
  {
    id: "entry-addition-notebooks",
    gradeLevel: "entry",
    topic: "addition-subtraction",
    type: "written-answer",
    instruction: "Enter the total number of notebooks as a number.",
    prompt: "A store sold 18 notebooks in the morning and 27 notebooks in the afternoon. How many notebooks did it sell altogether?",
    data: { inputMode: "numeric", answerLabel: "Total notebooks" },
    answer: "45",
    acceptedAnswers: ["45.0"],
    answerFormat: "numeric",
    explanation: "Add the two parts: 18 + 27 = 45 notebooks.",
    hint: "Combine the morning total and the afternoon total."
  },
  {
    id: "entry-multiplication-missing-factor",
    gradeLevel: "entry",
    topic: "multiplication-division",
    type: "fill-in-the-blank",
    instruction: "Fill in the missing number.",
    prompt: "Complete the multiplication fact.",
    data: { before: "7 × ", after: " = 56", inputMode: "numeric", answerLabel: "Missing factor" },
    answer: "8",
    answerFormat: "numeric",
    explanation: "56 ÷ 7 = 8, so 7 × 8 = 56.",
    hint: "Think of the multiplication fact that makes 56 with 7."
  },
  {
    id: "entry-fractions-half",
    gradeLevel: "entry",
    topic: "fractions",
    type: "true-false",
    instruction: "Choose whether the statement is true or false.",
    prompt: "One half of 12 is 6.",
    answer: "true",
    explanation: "A half means split into 2 equal groups. 12 ÷ 2 = 6, so the statement is true.",
    hint: "Divide 12 into 2 equal groups."
  },
  {
    id: "entry-measurement-ribbon",
    gradeLevel: "entry",
    topic: "measurement",
    type: "single-choice",
    instruction: "Choose the length that is equal to 3 meters.",
    prompt: "A ribbon is 3 meters long. Which length is the same?",
    options: [
      { id: "a", label: "30 centimeters" },
      { id: "b", label: "300 centimeters" },
      { id: "c", label: "3,000 centimeters" }
    ],
    answer: "b",
    explanation: "One meter equals 100 centimeters. 3 × 100 = 300 centimeters.",
    hint: "First remember how many centimeters are in 1 meter."
  },
  {
    id: "entry-time-money-change",
    gradeLevel: "entry",
    topic: "time-money",
    type: "written-answer",
    instruction: "Enter the amount of change in dollars, using numbers only.",
    prompt: "Mia pays with $10 for a $6 snack. How many dollars in change should she receive?",
    data: { inputMode: "decimal", answerLabel: "Change in dollars" },
    answer: "4",
    acceptedAnswers: ["4.0", "$4", "$4.00"],
    answerFormat: "numeric",
    explanation: "Subtract the cost from the amount paid: $10 − $6 = $4.",
    hint: "Start at the price and count up to the amount Mia paid."
  },
  {
    id: "entry-fractions-equivalent-half",
    gradeLevel: "entry",
    topic: "fractions",
    type: "multiple-select",
    instruction: "Select all values that are equal to one half.",
    prompt: "Which values are equivalent to 1/2?",
    options: [
      { id: "decimal-half", label: "0.5" },
      { id: "fraction-two-fourths", label: "2/4" },
      { id: "percent-fifty", label: "50%" },
      { id: "fraction-one-fourth", label: "1/4" }
    ],
    correctOptions: ["decimal-half", "fraction-two-fourths", "percent-fifty"],
    explanation: "0.5, 2/4, and 50% each name one half. One fourth is smaller than one half.",
    hint: "Convert each option to a fraction, decimal, or percent that you know represents one half."
  },
  {
    id: "entry-addition-equation-completion",
    gradeLevel: "entry",
    topic: "addition-subtraction",
    type: "complete-equation",
    instruction: "Fill in the missing value to complete the equation.",
    prompt: "Complete the addition equation.",
    segments: ["12 + ", { blank: "missing-addend" }, " = 20"],
    blanks: [
      { id: "missing-addend", label: "Missing addend", answer: "8", answerFormat: "numeric" }
    ],
    explanation: "Count from 12 up to 20. The difference is 8, so 12 + 8 = 20.",
    hint: "Ask what number must be added to 12 to reach 20."
  },
  {
    id: "entry-build-equal-groups-expression",
    gradeLevel: "entry",
    topic: "multiplication-division",
    type: "build-expression",
    instruction: "Use the tiles to build an expression for the total number of marbles.",
    prompt: "Mia has 4 bags with 6 marbles in each bag. Build an expression that represents the total number of marbles.",
    pieces: [
      { id: "four", label: "4", token: "4" },
      { id: "six", label: "6", token: "6" },
      { id: "multiply", label: "×", token: "×" },
      { id: "add", label: "+", token: "+" },
      { id: "divide", label: "÷", token: "÷" }
    ],
    acceptedExpressions: ["4 × 6", "6 × 4"],
    explanation: "There are 4 equal groups of 6, so multiplication represents the total: 4 × 6.",
    hint: "Equal groups are represented by multiplication."
  },
  {
    id: "entry-fraction-pizza-left",
    gradeLevel: "entry",
    topic: "fractions",
    type: "written-answer",
    instruction: "Enter the fraction of pizza left in simplest form.",
    prompt: "A pizza is cut into 8 equal slices. Three slices are eaten. What fraction of the pizza is left?",
    data: { inputMode: "text", answerLabel: "Fraction left" },
    answer: "5/8",
    answerFormat: "fraction",
    requireSimplified: true,
    explanation: "Five of the eight equal slices remain, so the fraction left is 5/8.",
    hint: "Subtract the number eaten from the total number of equal slices."
  },
  {
    id: "entry-drag-fractions-to-decimals",
    gradeLevel: "entry",
    topic: "fractions",
    type: "drag-drop",
    instruction: "Place each fraction with its equivalent decimal.",
    prompt: "Match every fraction to the decimal with the same value.",
    items: [
      { id: "one-half", label: "1/2" },
      { id: "one-quarter", label: "1/4" },
      { id: "three-quarters", label: "3/4" }
    ],
    targets: [
      { id: "decimal-quarter", label: "0.25" },
      { id: "decimal-half", label: "0.5" },
      { id: "decimal-three-quarters", label: "0.75" }
    ],
    correctPlacements: {
      "decimal-quarter": "one-quarter",
      "decimal-half": "one-half",
      "decimal-three-quarters": "three-quarters"
    },
    explanation: "One quarter is 0.25, one half is 0.5, and three quarters is 0.75.",
    hint: "Think of a dollar: one quarter is 25 cents and one half is 50 cents."
  },
  {
    id: "entry-arrange-money-values",
    gradeLevel: "entry",
    topic: "time-money",
    type: "arrange-order",
    instruction: "Arrange the money values from least to greatest.",
    prompt: "Put these amounts in order from least to greatest.",
    items: [
      { id: "fifty-cents", label: "50¢" },
      { id: "seventy-five-cents", label: "75¢" },
      { id: "one-dollar", label: "$1.00" }
    ],
    initialOrder: ["one-dollar", "fifty-cents", "seventy-five-cents"],
    correctOrder: ["fifty-cents", "seventy-five-cents", "one-dollar"],
    explanation: "50¢ is less than 75¢, and both are less than $1.00, which equals 100¢.",
    hint: "Write one dollar as 100 cents before comparing the amounts."
  },
  {
    id: "entry-match-shapes-to-sides",
    gradeLevel: "entry",
    topic: "geometry",
    type: "matching",
    instruction: "Match each shape to its number of sides.",
    prompt: "Connect every polygon to the correct number of sides.",
    leftItems: [
      { id: "triangle", label: "Triangle" },
      { id: "quadrilateral", label: "Quadrilateral" },
      { id: "pentagon", label: "Pentagon" }
    ],
    rightItems: [
      { id: "three", label: "3 sides" },
      { id: "four", label: "4 sides" },
      { id: "five", label: "5 sides" }
    ],
    matches: { triangle: "three", quadrilateral: "four", pentagon: "five" },
    explanation: "The names help: a triangle has 3 sides, a quadrilateral has 4 sides, and a pentagon has 5 sides.",
    hint: "Count the straight sides of each polygon."
  },
  {
    id: "entry-label-fraction-parts",
    gradeLevel: "entry",
    topic: "fractions",
    type: "visual-label",
    instruction: "Assign each label to the correct part of the fraction.",
    prompt: "Label the numerator and denominator in the fraction 3/5.",
    visual: { type: "fraction", numerator: "3", denominator: "5" },
    labels: [
      { id: "numerator", label: "Numerator" },
      { id: "denominator", label: "Denominator" }
    ],
    targets: [
      { id: "top-number", label: "Top number" },
      { id: "bottom-number", label: "Bottom number" }
    ],
    correctAssignments: { "top-number": "numerator", "bottom-number": "denominator" },
    explanation: "The numerator is above the fraction bar and tells how many parts are chosen. The denominator is below the bar and tells how many equal parts there are altogether.",
    hint: "Remember: numerator is on top; denominator is down below."
  },
  ...entryExtendedQuestions
];
