import { entryQuantQuestions } from "./entry.js";
import { highQuantQuestions } from "./high.js";
import { middleQuantQuestions } from "./middle.js";
import { getQuantTopic, getQuantTopics, quantGradeLevels } from "./topics.js";

export const quantSessionLength = 10;
export const quantQuestions = [...entryQuantQuestions, ...middleQuantQuestions, ...highQuantQuestions];

export { getQuantTopic, getQuantTopics, quantGradeLevels };

export function getQuantQuestions(gradeLevel, topic = "mix") {
  return quantQuestions.filter((question) => question.gradeLevel === gradeLevel
    && (topic === "mix" || question.topic === topic));
}

export function getAvailableQuantTopicIds(gradeLevel) {
  return new Set(getQuantQuestions(gradeLevel).map((question) => question.topic));
}
