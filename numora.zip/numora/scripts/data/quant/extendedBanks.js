import {
  createChoiceQuestion,
  createFractionQuestion,
  createMultipleSelectQuestion,
  createNumericQuestion,
  createTrueFalseQuestion
} from "./questionTemplates.js";

function numeric(gradeLevel, topic, id, prompt, answer, explanation, hint, options = {}) {
  return createNumericQuestion({ id, gradeLevel, topic, prompt, answer, explanation, hint, ...options });
}

function fraction(gradeLevel, topic, id, prompt, answer, explanation, hint, options = {}) {
  return createFractionQuestion({ id, gradeLevel, topic, prompt, answer, explanation, hint, ...options });
}

function choice(gradeLevel, topic, id, prompt, answer, options, explanation, hint) {
  return createChoiceQuestion({ id, gradeLevel, topic, prompt, answer, options, explanation, hint });
}

function truth(gradeLevel, topic, id, prompt, answer, explanation, hint) {
  return createTrueFalseQuestion({ id, gradeLevel, topic, prompt, answer, explanation, hint });
}

function multiple(gradeLevel, topic, id, prompt, options, correctOptions, explanation, hint) {
  return createMultipleSelectQuestion({ id, gradeLevel, topic, prompt, options, correctOptions, explanation, hint });
}

const entry = "entry";
const middle = "middle";
const high = "high";

export const entryExtendedQuestions = [
  numeric(entry, "addition-subtraction", "entry-addition-library-books", "A class has 36 library books and receives 19 more. How many books does it have now?", 55, "Add the books already there and the books received: 36 + 19 = 55.", "Add the ones, then add the tens."),
  numeric(entry, "addition-subtraction", "entry-subtraction-bus-riders", "There are 72 students on buses. If 28 students get off, how many students remain?", 44, "Subtract the students who got off: 72 − 28 = 44.", "Count back 28 from 72, or subtract tens and ones."),
  numeric(entry, "multiplication-division", "entry-multiplication-sticker-sheets", "Four sticker sheets have 9 stickers each. How many stickers are there altogether?", 36, "Four equal groups of 9 make 4 × 9 = 36.", "Use multiplication for equal groups."),
  numeric(entry, "multiplication-division", "entry-division-apple-bags", "Thirty apples are shared equally among 5 bags. How many apples go in each bag?", 6, "30 divided into 5 equal groups is 6 in each group.", "Ask which number times 5 equals 30."),
  choice(entry, "place-value", "entry-place-value-digit", "In 4,582, what is the value of the digit 5?", "hundreds", [
    { id: "ones", label: "5 ones" }, { id: "tens", label: "5 tens" }, { id: "hundreds", label: "5 hundreds" }
  ], "The 5 is in the hundreds place, so it represents 500.", "Read the place names from right to left: ones, tens, hundreds."),
  numeric(entry, "place-value", "entry-place-value-expanded", "Write the value of 3 thousands in the number 3,406.", 3000, "The digit 3 is in the thousands place, so its value is 3,000.", "The thousands place is four places to the left of the ones place."),
  truth(entry, "place-value", "entry-place-value-compare", "The number 6,209 is greater than 6,290.", false, "The thousands and hundreds match. Compare the tens: 0 tens is less than 9 tens, so 6,209 is smaller.", "Compare digits from left to right until they are different."),
  multiple(entry, "place-value", "entry-place-value-even-numbers", "Which numbers have a 7 in the tens place?", [
    { id: "a", label: "1,274" }, { id: "b", label: "3,742" }, { id: "c", label: "970" }, { id: "d", label: "7,009" }
  ], ["a", "c"], "In 1,274 the tens digit is 7; in 970 the tens digit is also 7. The other 7s are in different places.", "The tens place is the second digit from the right."),
  choice(entry, "fractions", "entry-fractions-shaded-parts", "A shape has 6 equal parts and 4 are shaded. Which fraction names the shaded part?", "four-sixths", [
    { id: "two-sixths", label: "2/6" }, { id: "four-sixths", label: "4/6" }, { id: "six-fourths", label: "6/4" }
  ], "The numerator counts shaded parts and the denominator counts all equal parts: 4/6.", "Put shaded parts on top and total equal parts on the bottom."),
  numeric(entry, "fractions", "entry-fractions-quarter-of-amount", "What is one fourth of 20?", 5, "Split 20 into 4 equal groups: 20 ÷ 4 = 5.", "A fourth means divide by 4."),
  numeric(entry, "measurement", "entry-measurement-centimeter-sum", "A pencil is 13 centimeters long and an eraser is 4 centimeters long. What is their combined length in centimeters?", 17, "Add the two lengths: 13 + 4 = 17 centimeters.", "The lengths are already in the same unit, so add them."),
  choice(entry, "measurement", "entry-measurement-best-unit", "Which unit is best for measuring the length of a classroom?", "meters", [
    { id: "millimeters", label: "millimeters" }, { id: "meters", label: "meters" }, { id: "kilometers", label: "kilometers" }
  ], "Meters are a useful size for a classroom. Millimeters are too small and kilometers are much too large.", "Think about a unit that is about the length of a long step."),
  truth(entry, "measurement", "entry-measurement-grams", "A watermelon is more likely to weigh 4 kilograms than 4 grams.", true, "A watermelon is much heavier than a few grams, so kilograms are reasonable.", "A paper clip weighs about a gram; compare that to a watermelon."),
  numeric(entry, "geometry", "entry-geometry-rectangle-perimeter", "A rectangle is 6 units long and 3 units wide. What is its perimeter?", 18, "Add all four sides: 6 + 3 + 6 + 3 = 18 units.", "A rectangle has two lengths and two widths."),
  choice(entry, "geometry", "entry-geometry-right-angle", "Which shape always has four right angles?", "rectangle", [
    { id: "triangle", label: "Triangle" }, { id: "rectangle", label: "Rectangle" }, { id: "pentagon", label: "Pentagon" }
  ], "A rectangle has four square corners, or right angles.", "Look for a shape with four corners that are all square."),
  multiple(entry, "geometry", "entry-geometry-three-sides", "Select every shape with exactly three sides.", [
    { id: "triangle", label: "Triangle" }, { id: "square", label: "Square" }, { id: "right-triangle", label: "Right triangle" }, { id: "hexagon", label: "Hexagon" }
  ], ["triangle", "right-triangle"], "Both kinds of triangle have three sides. A square has four and a hexagon has six.", "The word triangle includes tri, meaning three."),
  numeric(entry, "time-money", "entry-time-money-elapsed", "A movie starts at 2:15 and ends at 3:00. How many minutes long is it?", 45, "From 2:15 to 3:00 is 45 minutes.", "Count forward from 15 minutes past the hour to the next hour."),
  choice(entry, "time-money", "entry-time-money-coin-total", "What is the value of 3 quarters?", "seventy-five", [
    { id: "fifty", label: "50¢" }, { id: "seventy-five", label: "75¢" }, { id: "one-dollar", label: "$1.00" }
  ], "Each quarter is 25¢, and 3 × 25¢ = 75¢.", "A quarter is worth 25 cents."),
  numeric(entry, "patterns", "entry-patterns-add-four", "Find the next number: 6, 10, 14, 18, ___.", 22, "The pattern adds 4 each time, so 18 + 4 = 22.", "Compare each number to the number before it."),
  choice(entry, "patterns", "entry-patterns-shapes", "A pattern repeats circle, square, triangle. What comes after circle, square, triangle, circle?", "square", [
    { id: "circle", label: "circle" }, { id: "square", label: "square" }, { id: "triangle", label: "triangle" }
  ], "The three-shape cycle restarts after triangle. After circle comes square.", "Group the shapes into repeating sets of three."),
  truth(entry, "patterns", "entry-patterns-double", "The rule for 3, 6, 12, 24 is “double each number.”", true, "Each value is two times the one before it: 3 to 6 to 12 to 24.", "Check whether each number is multiplied by the same amount."),
  numeric(entry, "patterns", "entry-patterns-growing-table", "A plant grows 2 centimeters each week. It is 5 centimeters tall now. How tall will it be after 3 weeks?", 11, "It grows 2 centimeters for each of 3 weeks: 5 + 3 × 2 = 11 centimeters.", "Find how much it grows in three weeks, then add the starting height."),
  choice(entry, "data", "entry-data-most-votes", "A class vote shows cats: 8, dogs: 11, fish: 5. Which pet received the most votes?", "dogs", [
    { id: "cats", label: "Cats" }, { id: "dogs", label: "Dogs" }, { id: "fish", label: "Fish" }
  ], "Dogs have 11 votes, which is more than 8 and 5.", "Find the greatest number in the data."),
  numeric(entry, "data", "entry-data-total-students", "A pictograph shows 4 students chose red, 6 chose blue, and 3 chose green. How many students responded?", 13, "Add all groups: 4 + 6 + 3 = 13 students.", "A total includes every category."),
  truth(entry, "data", "entry-data-difference", "If 9 students choose apples and 6 choose bananas, 3 more students choose apples.", true, "Subtract 6 from 9 to find the difference: 9 − 6 = 3.", "A “how many more” question asks for a difference."),
  multiple(entry, "data", "entry-data-less-than-seven", "A table shows 5 red balloons, 7 blue balloons, 3 green balloons, and 8 yellow balloons. Select colors with fewer than 7 balloons.", [
    { id: "red", label: "Red" }, { id: "blue", label: "Blue" }, { id: "green", label: "Green" }, { id: "yellow", label: "Yellow" }
  ], ["red", "green"], "Red has 5 and green has 3, both below 7. Blue equals 7 and yellow is above it.", "“Fewer than 7” means 6 or less."),
  numeric(entry, "data", "entry-data-average-simple", "Three friends read 2, 4, and 6 books. If shared equally, how many books is that per friend?", 4, "There are 12 books total. 12 ÷ 3 = 4 books per friend.", "Add the books, then divide by the number of friends.")
];

export const middleExtendedQuestions = [
  numeric(middle, "ratios-proportions", "middle-ratio-recipe-scale", "A recipe uses 3 cups of flour for 2 batches. How many cups are needed for 5 batches?", 7.5, "One batch uses 3 ÷ 2 = 1.5 cups. Five batches use 5 × 1.5 = 7.5 cups.", "Find the amount for one batch first.", { inputMode: "decimal" }),
  choice(middle, "ratios-proportions", "middle-ratio-equivalent", "Which ratio is equivalent to 4:5?", "eight-ten", [
    { id: "eight-ten", label: "8:10" }, { id: "five-four", label: "5:4" }, { id: "eight-five", label: "8:5" }
  ], "Multiply both terms of 4:5 by 2 to get 8:10.", "Equivalent ratios multiply or divide both parts by the same number."),
  numeric(middle, "percentages", "middle-percent-of-number", "What is 14% of 50?", 7, "14% is 0.14, and 0.14 × 50 = 7.", "Change the percent to a decimal before multiplying."),
  numeric(middle, "percentages", "middle-percent-sale-price", "A $80 jacket is discounted by 30%. What is the sale price?", 56, "Thirty percent of 80 is 24. Subtract 24 from 80 to get 56.", "Find the discount first, then subtract it from the original price."),
  numeric(middle, "percentages", "middle-percent-part-whole", "Eighteen of 60 students join a club. What percent joined?", 30, "18 ÷ 60 = 0.3, which is 30%.", "Divide the part by the whole, then convert to a percent.", { percentage: true, inputMode: "decimal", acceptedAnswers: ["30%"] }),
  numeric(middle, "fractions-decimals", "middle-fraction-to-decimal", "Write 2/5 as a decimal.", 0.4, "Divide 2 by 5 to get 0.4.", "A fraction bar means division.", { inputMode: "decimal" }),
  numeric(middle, "fractions-decimals", "middle-decimal-subtraction", "Calculate 1.25 − 0.50.", 0.75, "Line up the decimals: 1.25 − 0.50 = 0.75.", "Keep each digit in its place value column.", { inputMode: "decimal" }),
  fraction(middle, "fractions-decimals", "middle-fraction-addition", "Calculate 3/4 + 1/8.", "7/8", "Rewrite 3/4 as 6/8, then add: 6/8 + 1/8 = 7/8.", "Use eighths as a common denominator."),
  numeric(middle, "expressions-equations", "middle-equation-four-x", "Solve 4x − 6 = 18.", 6, "Add 6 to both sides to get 4x = 24. Divide by 4: x = 6.", "Undo subtraction before dividing."),
  numeric(middle, "expressions-equations", "middle-expression-substitution", "Evaluate 2a + 3 when a = 5.", 13, "Substitute 5: 2(5) + 3 = 10 + 3 = 13.", "Replace the variable with its given value."),
  choice(middle, "expressions-equations", "middle-expression-distribute", "Which expression is equal to 3(x + 2)?", "three-x-plus-six", [
    { id: "three-x-plus-six", label: "3x + 6" }, { id: "three-x-plus-two", label: "3x + 2" }, { id: "five-x", label: "5x" }
  ], "Distribute 3 to both terms: 3 × x + 3 × 2 = 3x + 6.", "Multiply 3 by every term inside the parentheses."),
  numeric(middle, "factors-multiples", "middle-factors-lcm", "What is the least common multiple of 6 and 8?", 24, "Multiples of 6 include 6, 12, 18, 24. Multiples of 8 include 8, 16, 24. The first shared multiple is 24.", "List multiples of both numbers until you find the first one they share."),
  numeric(middle, "factors-multiples", "middle-factors-gcf", "What is the greatest common factor of 20 and 30?", 10, "The common factors are 1, 2, 5, and 10. The greatest is 10.", "List factors of both numbers and choose the largest match."),
  truth(middle, "factors-multiples", "middle-factors-composite", "The number 36 is composite.", true, "36 has factors besides 1 and itself, such as 2, 3, 4, and 6, so it is composite.", "A composite number has more than two positive factors."),
  numeric(middle, "geometry", "middle-geometry-rectangle-area", "Find the area of a rectangle with length 7 units and width 4 units.", 28, "Area of a rectangle is length × width: 7 × 4 = 28 square units.", "Multiply the two side lengths."),
  numeric(middle, "geometry", "middle-geometry-rectangle-perimeter", "Find the perimeter of a rectangle that is 5 units by 3 units.", 16, "Add all sides: 5 + 3 + 5 + 3 = 16 units.", "A rectangle has two of each side length."),
  numeric(middle, "geometry", "middle-geometry-triangle-area", "Find the area of a triangle with base 10 units and height 6 units.", 30, "Triangle area is one half times base times height: 1/2 × 10 × 6 = 30.", "Find the rectangle area first, then take half."),
  numeric(middle, "geometry", "middle-geometry-triangle-angle", "Two angles in a triangle are 55° and 65°. What is the third angle?", 60, "Triangle angles total 180°. 180 − 55 − 65 = 60 degrees.", "Subtract the known angles from 180."),
  numeric(middle, "geometry", "middle-geometry-prism-volume", "Find the volume of a rectangular prism that is 3 units by 2 units by 4 units.", 24, "Volume is length × width × height: 3 × 2 × 4 = 24 cubic units.", "Multiply all three dimensions."),
  fraction(middle, "probability", "middle-probability-green", "A spinner has 4 green, 3 blue, and 3 yellow equal sections. What is the probability of landing on green?", "2/5", "There are 10 equal sections and 4 are green. 4/10 simplifies to 2/5.", "Put favorable sections over all sections, then simplify."),
  fraction(middle, "probability", "middle-probability-complement", "A bag has 7 red and 3 blue counters. What is the probability of not picking red?", "3/10", "Not red means blue. There are 3 blue counters out of 10 total.", "Count the outcomes that are not red."),
  numeric(middle, "probability", "middle-probability-decimal", "A game has a 1/4 chance of a bonus. Write that chance as a decimal.", 0.25, "One fourth equals 0.25.", "Divide 1 by 4.", { inputMode: "decimal" }),
  choice(middle, "probability", "middle-probability-likely", "A box has 9 orange tiles and 1 purple tile. Which color is more likely to be chosen?", "orange", [
    { id: "orange", label: "Orange" }, { id: "purple", label: "Purple" }, { id: "same", label: "They are equally likely" }
  ], "Orange appears on 9 of the 10 tiles, so it is more likely than purple.", "More favorable outcomes means a greater chance."),
  numeric(middle, "statistics", "middle-statistics-mean", "Find the mean of 5, 7, and 9.", 7, "The total is 21. Divide by 3 values: 21 ÷ 3 = 7.", "Add the values, then divide by how many there are."),
  numeric(middle, "statistics", "middle-statistics-median", "Find the median of 3, 8, 9, 12, and 15.", 9, "The values are ordered, and 9 is the middle value.", "The median is the middle value after ordering the data."),
  numeric(middle, "statistics", "middle-statistics-range", "Find the range of 12, 18, 14, and 20.", 8, "Subtract the least value from the greatest: 20 − 12 = 8.", "Range is largest minus smallest."),
  truth(middle, "statistics", "middle-statistics-outlier", "In the data set 4, 5, 5, 6, 30, the value 30 could be an outlier.", true, "30 is much farther from the rest of the values, which are between 4 and 6.", "Look for a value far away from the main cluster."),
  choice(middle, "coordinate-graphs", "middle-coordinate-quadrant", "In which quadrant is the point (−3, 4)?", "quadrant-two", [
    { id: "quadrant-one", label: "Quadrant I" }, { id: "quadrant-two", label: "Quadrant II" }, { id: "quadrant-three", label: "Quadrant III" }
  ], "The x-coordinate is negative and the y-coordinate is positive, which places the point in Quadrant II.", "Read the sign of x first, then the sign of y."),
  numeric(middle, "coordinate-graphs", "middle-coordinate-horizontal-distance", "What is the horizontal distance between (2, 5) and (9, 5)?", 7, "The y-values are equal, so subtract x-values: 9 − 2 = 7 units.", "Only the x-coordinate changes."),
  choice(middle, "coordinate-graphs", "middle-coordinate-reflection", "Reflect (4, −2) across the y-axis. What is the new point?", "negative-four-negative-two", [
    { id: "negative-four-negative-two", label: "(−4, −2)" }, { id: "four-two", label: "(4, 2)" }, { id: "negative-four-two", label: "(−4, 2)" }
  ], "A reflection across the y-axis changes the sign of x only, so (4, −2) becomes (−4, −2).", "Across the y-axis means left/right flips while up/down stays the same."),
  truth(middle, "coordinate-graphs", "middle-coordinate-origin", "The point (0, 0) is called the origin.", true, "The origin is where the x-axis and y-axis meet, at (0, 0).", "Think of the center of the coordinate plane."),
  numeric(middle, "intro-functions", "middle-function-input-output", "For f(x) = 2x + 1, find f(6).", 13, "Substitute 6: 2(6) + 1 = 13.", "Replace x with 6."),
  numeric(middle, "intro-functions", "middle-function-table-rule", "A table follows the rule y = x + 4. What is y when x = 9?", 13, "Add 4 to the input: 9 + 4 = 13.", "Use the rule on the input."),
  choice(middle, "intro-functions", "middle-function-variable-role", "In y = 5x, which variable is the input?", "x", [
    { id: "x", label: "x" }, { id: "y", label: "y" }, { id: "five", label: "5" }
  ], "By convention, x is the input and y changes based on x.", "The input is the value you choose before the rule is applied."),
  truth(middle, "intro-functions", "middle-function-one-output", "A function can assign two different outputs to the same input.", false, "A function gives exactly one output for every input. Two outputs for one input would not be a function.", "Each input needs one clear result."),
  numeric(middle, "intro-functions", "middle-function-pattern-rule", "The inputs 1, 2, 3 have outputs 4, 7, 10. What output belongs with input 4 if the pattern continues?", 13, "The outputs increase by 3 each time, so after 10 comes 13.", "Compare the change between consecutive outputs.")
];

export const highExtendedQuestions = [
  numeric(high, "algebra", "high-algebra-distribute-solve", "Solve 5(x − 2) = 20.", 6, "Divide by 5 to get x − 2 = 4, then add 2. x = 6.", "Undo multiplication by 5 before undoing subtraction."),
  choice(high, "quadratic-functions", "high-quadratic-factor-roots", "Which pair solves x² − 5x + 6 = 0?", "two-three", [
    { id: "two-three", label: "x = 2 and x = 3" }, { id: "one-six", label: "x = 1 and x = 6" }, { id: "negative-two-negative-three", label: "x = −2 and x = −3" }
  ], "Factor x² − 5x + 6 as (x − 2)(x − 3), so the roots are 2 and 3.", "Find two numbers that multiply to 6 and add to −5."),
  numeric(high, "quadratic-functions", "high-quadratic-vertex-value", "For y = x² − 4x + 3, what is y when x = 2?", -1, "Substitute 2: 2² − 4(2) + 3 = 4 − 8 + 3 = −1.", "Replace x with 2 and follow order of operations."),
  numeric(high, "systems-equations", "high-systems-addition", "Solve the system: x + y = 10 and x − y = 2. What is x?", 6, "Add the equations to eliminate y: 2x = 12, so x = 6.", "Add the equations because y and −y cancel."),
  choice(high, "systems-equations", "high-systems-intersection", "What is the solution to y = 2x and y = x + 3?", "three-six", [
    { id: "three-six", label: "(3, 6)" }, { id: "two-four", label: "(2, 4)" }, { id: "six-three", label: "(6, 3)" }
  ], "Set 2x equal to x + 3. Then x = 3 and y = 6.", "At an intersection, both expressions have the same y-value."),
  truth(high, "systems-equations", "high-systems-parallel", "The lines y = 3x + 1 and y = 3x − 4 have no solution as a system.", true, "They have the same slope but different y-intercepts, so they are parallel and never meet.", "Lines with equal slopes and different intercepts are parallel."),
  numeric(high, "geometry", "high-geometry-pythagorean", "A right triangle has legs 6 and 8. What is the length of the hypotenuse?", 10, "6² + 8² = 36 + 64 = 100, and the square root of 100 is 10.", "Use a² + b² = c²."),
  numeric(high, "geometry", "high-geometry-circle-circumference", "Use π ≈ 3.14. What is the circumference of a circle with diameter 10?", 31.4, "Circumference is πd. 3.14 × 10 = 31.4.", "The diameter is already given, so multiply it by π.", { inputMode: "decimal", tolerance: 0.01 }),
  numeric(high, "geometry", "high-geometry-exterior-angle", "A regular pentagon has five equal exterior angles. What is the measure of one exterior angle?", 72, "Exterior angles total 360°. 360 ÷ 5 = 72 degrees.", "Divide a full turn, 360°, by the number of sides."),
  numeric(high, "geometry", "high-geometry-similar-scale", "Two similar triangles have a scale factor of 3 from small to large. If a small side is 4, what is the matching large side?", 12, "Multiply the small side by the scale factor: 4 × 3 = 12.", "Use the scale factor as a multiplier."),
  choice(high, "geometry", "high-geometry-congruent", "Which statement is true about congruent figures?", "same-size-shape", [
    { id: "same-size-shape", label: "They have the same size and shape." }, { id: "same-area-only", label: "They only have the same area." }, { id: "same-perimeter-only", label: "They only have the same perimeter." }
  ], "Congruent figures match exactly in both size and shape.", "Think of one figure fitting perfectly on top of the other."),
  numeric(high, "trigonometry", "high-trig-sine-ratio", "In a right triangle, the side opposite an angle is 3 and the hypotenuse is 5. What is sin of the angle? Enter a decimal.", 0.6, "Sine is opposite over hypotenuse: 3/5 = 0.6.", "SOH: sine equals opposite divided by hypotenuse.", { inputMode: "decimal" }),
  numeric(high, "trigonometry", "high-trig-cosine-ratio", "In a right triangle, the adjacent side is 12 and the hypotenuse is 13. What is cos of the angle? Enter a decimal rounded to the nearest hundredth.", 0.92, "Cosine is adjacent over hypotenuse: 12/13 ≈ 0.92.", "CAH: cosine equals adjacent divided by hypotenuse.", { inputMode: "decimal", tolerance: 0.01 }),
  choice(high, "trigonometry", "high-trig-right-angle", "Which angle measure makes a triangle a right triangle?", "ninety", [
    { id: "forty-five", label: "45°" }, { id: "sixty", label: "60°" }, { id: "ninety", label: "90°" }
  ], "A right angle measures 90 degrees.", "A right angle looks like the corner of a square."),
  truth(high, "trigonometry", "high-trig-tangent", "Tangent of an angle in a right triangle is opposite divided by adjacent.", true, "TOA: tangent equals opposite over adjacent.", "Use the SOH-CAH-TOA reminder."),
  numeric(high, "trigonometry", "high-trig-pythagorean-leg", "A right triangle has hypotenuse 13 and one leg 5. What is the other leg?", 12, "The other leg squared is 13² − 5² = 169 − 25 = 144, so the leg is 12.", "Use a² + b² = c² and solve for the missing leg."),
  numeric(high, "probability-statistics", "high-stats-mean", "Find the mean of 10, 12, 14, and 20.", 14, "The total is 56. Divide by 4 values: 56 ÷ 4 = 14.", "Add all values, then divide by the count."),
  numeric(high, "probability-statistics", "high-probability-independent", "A fair coin is flipped twice. What is the probability of getting heads both times? Enter a decimal.", 0.25, "Each heads result has probability 1/2. Multiply independent events: 1/2 × 1/2 = 1/4 = 0.25.", "Multiply the probabilities for independent events.", { inputMode: "decimal" }),
  numeric(high, "probability-statistics", "high-stats-expected-value", "A game pays $4 with probability 0.5 and $0 with probability 0.5. What is the expected payout?", 2, "Expected value is 4(0.5) + 0(0.5) = 2 dollars.", "Multiply each outcome by its probability, then add."),
  choice(high, "probability-statistics", "high-stats-correlation", "A scatter plot rises from left to right. What kind of association does it show?", "positive", [
    { id: "positive", label: "Positive association" }, { id: "negative", label: "Negative association" }, { id: "none", label: "No association" }
  ], "When x tends to increase as y increases, the association is positive.", "Imagine the trend line moving uphill from left to right."),
  truth(high, "probability-statistics", "high-stats-sample", "A random sample is usually more useful than asking only volunteers when estimating a whole population.", true, "Random sampling reduces the chance that one type of person is overrepresented.", "Think about whether every member has a fair chance to be selected."),
  numeric(high, "exponents-logarithms", "high-exponents-power", "Calculate 2⁵.", 32, "2 × 2 × 2 × 2 × 2 = 32.", "An exponent tells how many times to multiply the base by itself."),
  numeric(high, "exponents-logarithms", "high-logarithms-base-ten", "Evaluate log₁₀(1000).", 3, "10³ = 1000, so log base 10 of 1000 is 3.", "Ask what power of 10 makes 1000."),
  choice(high, "exponents-logarithms", "high-exponents-product-rule", "Which expression is equal to x³ · x⁴?", "x-seven", [
    { id: "x-seven", label: "x⁷" }, { id: "x-twelve", label: "x¹²" }, { id: "x-one", label: "x" }
  ], "When multiplying powers with the same base, add exponents: 3 + 4 = 7.", "The bases match, so add the exponents."),
  numeric(high, "exponents-logarithms", "high-exponents-quotient-rule", "Simplify 3⁶ ÷ 3².", 81, "Subtract exponents: 3⁴ = 81.", "For division with the same base, subtract exponents first."),
  numeric(high, "exponents-logarithms", "high-exponents-scientific-notation", "Write 4.2 × 10³ as a regular number.", 4200, "Multiplying by 10³ moves the decimal three places right: 4,200.", "A positive power of 10 moves the decimal right."),
  numeric(high, "sequences", "high-sequences-arithmetic-next", "Find the next term: 5, 9, 13, 17, ___.", 21, "This arithmetic sequence adds 4 each time, so 17 + 4 = 21.", "Find the constant difference between terms."),
  numeric(high, "sequences", "high-sequences-geometric-next", "Find the next term: 3, 6, 12, 24, ___.", 48, "This geometric sequence doubles each time, so 24 × 2 = 48.", "Find the constant multiplier between terms."),
  numeric(high, "sequences", "high-sequences-arithmetic-term", "An arithmetic sequence begins at 7 and adds 3 each term. What is the fourth term?", 16, "The terms are 7, 10, 13, 16. The fourth term is 16.", "Add 3 repeatedly from the first term."),
  choice(high, "sequences", "high-sequences-identify", "Which list is geometric?", "two-four-eight", [
    { id: "two-four-eight", label: "2, 4, 8, 16" }, { id: "two-five-eight", label: "2, 5, 8, 11" }, { id: "one-four-nine", label: "1, 4, 9, 16" }
  ], "Each term in 2, 4, 8, 16 is multiplied by 2, so it is geometric.", "A geometric sequence has the same multiplier each time."),
  truth(high, "sequences", "high-sequences-common-difference", "The sequence 11, 8, 5, 2 has a common difference of −3.", true, "Each term is 3 less than the prior term, so the difference is −3.", "Subtract one term from the next term."),
  numeric(high, "financial-mathematics", "high-finance-compound-interest", "An account has $1,000 and grows by 10% each year for 2 years. What is the balance?", 1210, "After one year it is 1,000 × 1.10 = 1,100. After two years it is 1,100 × 1.10 = 1,210.", "Multiply by 1.10 once for each year."),
  numeric(high, "financial-mathematics", "high-finance-unit-price", "A 12-ounce box costs $3.60. What is the cost per ounce?", 0.3, "Divide cost by ounces: 3.60 ÷ 12 = 0.30 dollars per ounce.", "A unit price is total cost divided by number of units.", { inputMode: "decimal", tolerance: 0.01 }),
  choice(high, "precalculus", "high-precalc-domain-square-root", "What is the domain of f(x) = √x over the real numbers?", "nonnegative", [
    { id: "all-real", label: "All real numbers" }, { id: "nonnegative", label: "x ≥ 0" }, { id: "nonpositive", label: "x ≤ 0" }
  ], "A real square root needs a nonnegative value inside it, so x must be at least 0.", "Ask which inputs avoid taking a square root of a negative number."),
  numeric(high, "precalculus", "high-precalc-composition", "If f(x) = x + 2 and g(x) = 3x, find f(g(4)).", 14, "First g(4) = 12. Then f(12) = 12 + 2 = 14.", "Apply the inside function first."),
  numeric(high, "precalculus", "high-precalc-inverse", "If f(x) = x + 7, what is f⁻¹(12)?", 5, "The inverse undoes adding 7. 12 − 7 = 5.", "Reverse the operation in the original rule."),
  truth(high, "precalculus", "high-precalc-unit-circle", "On the unit circle, every point is 1 unit from the origin.", true, "A unit circle is defined as a circle with radius 1 centered at the origin.", "The word unit means one." )
];
