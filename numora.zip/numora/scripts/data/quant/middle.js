import { middleExtendedQuestions } from "./extendedBanks.js";

export const middleQuantQuestions = [
  {
    id: "middle-ratios-paint",
    gradeLevel: "middle",
    topic: "ratios-proportions",
    type: "written-answer",
    instruction: "Enter the number of cups of blue paint as a number.",
    prompt: "A paint mixture uses 2 cups of blue paint for every 3 cups of yellow paint. If you use 12 cups of yellow paint, how many cups of blue paint are needed?",
    data: { inputMode: "numeric", answerLabel: "Cups of blue paint" },
    answer: "8",
    answerFormat: "numeric",
    explanation: "12 is 4 groups of 3. Use 4 groups of 2 blue cups: 4 × 2 = 8.",
    hint: "Find how many groups of 3 are in 12."
  },
  {
    id: "middle-percentage-discount",
    gradeLevel: "middle",
    topic: "percentages",
    type: "fill-in-the-blank",
    instruction: "Fill in the sale price in dollars.",
    prompt: "A $40 backpack is 25% off.",
    data: { before: "Sale price: $", after: "", inputMode: "decimal", answerLabel: "Sale price" },
    answer: "30",
    acceptedAnswers: ["30.0", "30.00", "$30"],
    answerFormat: "numeric",
    explanation: "25% of $40 is $10. Subtract the discount: $40 − $10 = $30.",
    hint: "25% is one fourth. Find one fourth of $40 first."
  },
  {
    id: "middle-decimals-equivalence",
    gradeLevel: "middle",
    topic: "fractions-decimals",
    type: "true-false",
    instruction: "Choose whether the statement is true or false.",
    prompt: "0.75 is equal to 3/4.",
    answer: "true",
    explanation: "0.75 is 75 hundredths. Both 75/100 and 3/4 simplify to the same value.",
    hint: "Write 0.75 as 75/100, then simplify it."
  },
  {
    id: "middle-equation-solve",
    gradeLevel: "middle",
    topic: "expressions-equations",
    type: "single-choice",
    instruction: "Choose the value of x that makes the equation true.",
    prompt: "Solve 3x + 5 = 20.",
    options: [
      { id: "a", label: "x = 5" },
      { id: "b", label: "x = 15" },
      { id: "c", label: "x = 25" }
    ],
    answer: "a",
    explanation: "Subtract 5 from both sides to get 3x = 15. Then divide by 3, so x = 5.",
    hint: "Undo the +5 before dividing by 3."
  },
  {
    id: "middle-probability-marbles",
    gradeLevel: "middle",
    topic: "probability",
    type: "written-answer",
    instruction: "Enter the probability as a simplified fraction.",
    prompt: "A bag has 3 red marbles, 2 blue marbles, and 1 green marble. What is the probability of drawing a blue marble?",
    data: { inputMode: "text", answerLabel: "Probability of blue" },
    answer: "1/3",
    acceptedAnswers: ["2/6"],
    explanation: "There are 6 marbles total and 2 are blue. 2/6 simplifies to 1/3.",
    hint: "Count all of the marbles, then place the number of blue marbles over that total."
  },
  {
    id: "middle-percent-equivalent-values",
    gradeLevel: "middle",
    topic: "percentages",
    type: "multiple-select",
    instruction: "Select all values that are equivalent to 75%.",
    prompt: "Which values represent 75%?",
    options: [
      { id: "decimal", label: "0.75" },
      { id: "fraction", label: "3/4" },
      { id: "percent", label: "75%" },
      { id: "quarter", label: "0.25" }
    ],
    correctOptions: ["decimal", "fraction", "percent"],
    explanation: "75% means 75 out of 100, which is 0.75 and simplifies to 3/4. The value 0.25 is only 25%.",
    hint: "Write 75% as a decimal, then simplify 75/100."
  },
  {
    id: "middle-equation-missing-constant",
    gradeLevel: "middle",
    topic: "expressions-equations",
    type: "complete-equation",
    instruction: "Fill in the missing value that makes the equation true when x = 4.",
    prompt: "Complete the equation when x = 4.",
    segments: ["3x + ", { blank: "constant" }, " = 15"],
    blanks: [
      { id: "constant", label: "Missing constant", answer: "3", answerFormat: "numeric" }
    ],
    explanation: "When x = 4, 3x is 12. Adding 3 gives 15, so the missing constant is 3.",
    hint: "Substitute 4 for x first, then find what must be added to 12."
  },
  {
    id: "middle-build-unit-rate-expression",
    gradeLevel: "middle",
    topic: "ratios-proportions",
    type: "build-expression",
    instruction: "Use the tiles to build an expression for the total number of markers.",
    prompt: "Five packs hold 8 markers each. Build an expression that represents the total number of markers.",
    pieces: [
      { id: "five", label: "5", token: "5" },
      { id: "eight", label: "8", token: "8" },
      { id: "multiply", label: "×", token: "×" },
      { id: "add", label: "+", token: "+" },
      { id: "divide", label: "÷", token: "÷" }
    ],
    acceptedExpressions: ["5 × 8", "8 × 5"],
    explanation: "Five equal packs of 8 markers are represented by multiplication: 5 × 8.",
    hint: "A number of equal groups times the amount in each group gives a total."
  },
  {
    id: "middle-decimal-approximation",
    gradeLevel: "middle",
    topic: "statistics",
    type: "written-answer",
    instruction: "Enter a decimal rounded to the nearest hundredth.",
    prompt: "A calculator gives 3.14159. What is this number rounded to the nearest hundredth?",
    data: { inputMode: "decimal", answerLabel: "Rounded decimal" },
    answer: "3.14",
    answerFormat: "numeric",
    tolerance: 0.01,
    explanation: "The hundredths digit is 4 and the next digit is 1, so the value rounds to 3.14.",
    hint: "Look at the third digit after the decimal to decide whether the hundredths digit changes."
  },
  {
    id: "middle-prime-number-text",
    gradeLevel: "middle",
    topic: "factors-multiples",
    type: "written-answer",
    instruction: "Enter the math term that describes a number with exactly two positive factors.",
    prompt: "What do we call a whole number greater than 1 with exactly two positive factors?",
    data: { inputMode: "text", answerLabel: "Math term" },
    answer: "prime",
    acceptedAnswers: ["prime number"],
    explanation: "A prime number has exactly two positive factors: 1 and itself.",
    hint: "Think of the term used for numbers like 2, 3, 5, and 7."
  },
  {
    id: "middle-categorize-prime-composite",
    gradeLevel: "middle",
    topic: "factors-multiples",
    type: "categorize",
    instruction: "Place each number in the Prime or Composite category.",
    prompt: "Classify every number as prime or composite.",
    items: [
      { id: "seven", label: "7" },
      { id: "nine", label: "9" },
      { id: "eleven", label: "11" },
      { id: "fifteen", label: "15" }
    ],
    categories: [
      { id: "prime", label: "Prime" },
      { id: "composite", label: "Composite" }
    ],
    correctCategories: { seven: "prime", nine: "composite", eleven: "prime", fifteen: "composite" },
    explanation: "7 and 11 have exactly two factors, so they are prime. 9 has factors 1, 3, and 9; 15 has factors 1, 3, 5, and 15, so both are composite.",
    hint: "A prime number has only 1 and itself as positive factors."
  },
  {
    id: "middle-arrange-decimal-values",
    gradeLevel: "middle",
    topic: "fractions-decimals",
    type: "arrange-order",
    instruction: "Arrange the values from least to greatest.",
    prompt: "Put these rational numbers in order from least to greatest.",
    items: [
      { id: "half", label: "1/2" },
      { id: "six-tenths", label: "0.6" },
      { id: "three-quarters", label: "3/4" }
    ],
    initialOrder: ["three-quarters", "half", "six-tenths"],
    correctOrder: ["half", "six-tenths", "three-quarters"],
    explanation: "1/2 is 0.5, so 0.5 < 0.6 < 0.75. Three fourths is 0.75.",
    hint: "Convert the fractions to decimals before comparing them."
  },
  {
    id: "middle-match-ratios-to-decimals",
    gradeLevel: "middle",
    topic: "ratios-proportions",
    type: "matching",
    instruction: "Match each ratio to its equivalent decimal.",
    prompt: "Connect each ratio to the decimal it represents.",
    leftItems: [
      { id: "one-to-two", label: "1 : 2" },
      { id: "three-to-four", label: "3 : 4" },
      { id: "one-to-four", label: "1 : 4" }
    ],
    rightItems: [
      { id: "half", label: "0.5" },
      { id: "three-quarters", label: "0.75" },
      { id: "quarter", label: "0.25" }
    ],
    matches: { "one-to-two": "half", "three-to-four": "three-quarters", "one-to-four": "quarter" },
    explanation: "A ratio a : b can be written as a/b. Dividing gives 1/2 = 0.5, 3/4 = 0.75, and 1/4 = 0.25.",
    hint: "Rewrite each ratio as a fraction, then divide the numerator by the denominator."
  },
  {
    id: "middle-label-coordinate-points",
    gradeLevel: "middle",
    topic: "coordinate-graphs",
    type: "visual-label",
    instruction: "Assign each ordered pair to the point it names.",
    prompt: "Label points A and B on the coordinate plane.",
    visual: {
      type: "coordinate-plane",
      points: [
        { id: "A", x: 2, y: 3 },
        { id: "B", x: -1, y: 2 }
      ]
    },
    labels: [
      { id: "two-three", label: "(2, 3)" },
      { id: "negative-one-two", label: "(−1, 2)" }
    ],
    targets: [
      { id: "point-a", label: "Point A" },
      { id: "point-b", label: "Point B" }
    ],
    correctAssignments: { "point-a": "two-three", "point-b": "negative-one-two" },
    explanation: "Point A is 2 units right and 3 units up, so it is (2, 3). Point B is 1 unit left and 2 units up, so it is (−1, 2).",
    hint: "Read the horizontal x-coordinate first, then the vertical y-coordinate."
  },
  ...middleExtendedQuestions
];
