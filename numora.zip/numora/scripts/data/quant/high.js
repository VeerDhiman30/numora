import { highExtendedQuestions } from "./extendedBanks.js";

export const highQuantQuestions = [
  {
    id: "high-algebra-exponent",
    gradeLevel: "high",
    topic: "algebra",
    type: "written-answer",
    instruction: "Enter the value of x as a number.",
    prompt: "Solve 2x − 7 = 19.",
    data: { inputMode: "numeric", answerLabel: "Value of x" },
    answer: "13",
    answerFormat: "numeric",
    explanation: "Add 7 to both sides: 2x = 26. Divide both sides by 2 to get x = 13.",
    hint: "Undo subtraction first, then undo multiplication."
  },
  {
    id: "high-linear-slope",
    gradeLevel: "high",
    topic: "linear-functions",
    type: "fill-in-the-blank",
    instruction: "Fill in the y-value as a number.",
    prompt: "For y = 3x − 2, find y when x = 4.",
    data: { before: "y = ", after: "", inputMode: "numeric", answerLabel: "Value of y" },
    answer: "10",
    answerFormat: "numeric",
    explanation: "Substitute 4 for x: y = 3(4) − 2 = 12 − 2 = 10.",
    hint: "Replace x with 4 before doing the multiplication."
  },
  {
    id: "high-quadratic-roots",
    gradeLevel: "high",
    topic: "quadratic-functions",
    type: "true-false",
    instruction: "Choose whether the statement is true or false.",
    prompt: "The equation x² − 9 = 0 has the solutions x = 3 and x = −3.",
    answer: "true",
    explanation: "x² = 9. Both 3² and (−3)² equal 9, so both values solve the equation.",
    hint: "Think of both numbers whose square is 9."
  },
  {
    id: "high-systems-solution",
    gradeLevel: "high",
    topic: "systems-equations",
    type: "single-choice",
    instruction: "Choose the ordered pair that solves both equations.",
    prompt: "Solve the system: y = x + 1 and y = 5 − x.",
    options: [
      { id: "a", label: "(2, 3)" },
      { id: "b", label: "(3, 2)" },
      { id: "c", label: "(2, 2)" }
    ],
    answer: "a",
    explanation: "Set x + 1 equal to 5 − x. Then 2x = 4, so x = 2 and y = 3.",
    hint: "Both expressions equal y, so set them equal to each other."
  },
  {
    id: "high-financial-interest",
    gradeLevel: "high",
    topic: "financial-mathematics",
    type: "written-answer",
    instruction: "Enter the interest earned in dollars, using numbers only.",
    prompt: "A savings account has $500 and earns simple interest at 4% for 1 year. How much interest does it earn?",
    data: { inputMode: "decimal", answerLabel: "Interest earned" },
    answer: "20",
    acceptedAnswers: ["20.0", "20.00", "$20"],
    answerFormat: "numeric",
    explanation: "Simple interest is principal × rate × time: 500 × 0.04 × 1 = 20.",
    hint: "Change 4% to 0.04, then multiply by $500."
  },
  {
    id: "high-equation-two-blanks",
    gradeLevel: "high",
    topic: "algebra",
    type: "complete-equation",
    instruction: "Fill in both missing values to make the equation true when x = 3.",
    prompt: "Complete the equation when x = 3.",
    segments: [{ blank: "coefficient" }, "x + ", { blank: "constant" }, " = 14"],
    blanks: [
      { id: "coefficient", label: "Coefficient of x", answer: "4", answerFormat: "numeric" },
      { id: "constant", label: "Constant term", answer: "2", answerFormat: "numeric" }
    ],
    explanation: "Four groups of 3 make 12, and 12 + 2 = 14. The completed equation is 4x + 2 = 14.",
    hint: "Choose a coefficient that makes 12 when multiplied by 3, then find what adds to 14."
  },
  {
    id: "high-build-linear-cost-expression",
    gradeLevel: "high",
    topic: "linear-functions",
    type: "build-expression",
    instruction: "Use the tiles to build an expression for the total cost.",
    prompt: "A bike rental costs $8 per hour for t hours plus a $15 starting fee. Build an expression for the total cost.",
    pieces: [
      { id: "eight", label: "8", token: "8" },
      { id: "hours", label: "t", token: "t" },
      { id: "fifteen", label: "15", token: "15" },
      { id: "multiply", label: "×", token: "×" },
      { id: "add", label: "+", token: "+" },
      { id: "divide", label: "÷", token: "÷" }
    ],
    acceptedExpressions: ["8 × t + 15", "15 + 8 × t"],
    explanation: "The hourly portion is 8 × t. The one-time fee is added, giving 8 × t + 15.",
    hint: "Multiply the hourly rate by the number of hours, then add the starting fee."
  },
  {
    id: "high-percent-return",
    gradeLevel: "high",
    topic: "financial-mathematics",
    type: "written-answer",
    instruction: "Enter the percent return. You may include the percent sign.",
    prompt: "An investment earns $15 on an original amount of $60. What is the percent return?",
    data: { inputMode: "decimal", answerLabel: "Percent return" },
    answer: "25",
    acceptedAnswers: ["25%"],
    answerFormat: "numeric",
    percentage: true,
    explanation: "Divide the gain by the original amount: 15 ÷ 60 = 0.25, which is 25%.",
    hint: "Divide the gain by the original amount, then change the decimal to a percent."
  },
  {
    id: "high-quadratic-solution-selection",
    gradeLevel: "high",
    topic: "quadratic-functions",
    type: "multiple-select",
    instruction: "Select all values of x that solve the equation.",
    prompt: "Which values solve x² = 16?",
    options: [
      { id: "positive-four", label: "4" },
      { id: "negative-four", label: "−4" },
      { id: "positive-sixteen", label: "16" },
      { id: "zero", label: "0" }
    ],
    correctOptions: ["positive-four", "negative-four"],
    explanation: "Both 4² and (−4)² equal 16. Neither 16 nor 0 squares to 16.",
    hint: "Look for both the positive and negative number whose square is 16."
  },
  {
    id: "high-categorize-linear-functions",
    gradeLevel: "high",
    topic: "linear-functions",
    type: "categorize",
    instruction: "Place each rule in the Linear or Nonlinear category.",
    prompt: "Classify every function rule as linear or nonlinear.",
    items: [
      { id: "two-x-plus-one", label: "y = 2x + 1" },
      { id: "x-squared", label: "y = x²" },
      { id: "negative-three-x", label: "y = −3x + 4" },
      { id: "absolute-x", label: "y = |x|" }
    ],
    categories: [
      { id: "linear", label: "Linear" },
      { id: "nonlinear", label: "Nonlinear" }
    ],
    correctCategories: { "two-x-plus-one": "linear", "x-squared": "nonlinear", "negative-three-x": "linear", "absolute-x": "nonlinear" },
    explanation: "Linear functions have a constant rate of change and can be written in the form y = mx + b. Squaring x or taking |x| changes the rate of change, so those rules are nonlinear.",
    hint: "Look for x only to the first power, with no absolute-value bars."
  },
  {
    id: "high-arrange-algebra-values",
    gradeLevel: "high",
    topic: "algebra",
    type: "arrange-order",
    instruction: "Arrange the expressions by their value when x = 2, from least to greatest.",
    prompt: "For x = 2, put these expressions in order from least to greatest.",
    items: [
      { id: "x-squared", label: "x²" },
      { id: "two-x-plus-one", label: "2x + 1" },
      { id: "three-x", label: "3x" }
    ],
    initialOrder: ["three-x", "x-squared", "two-x-plus-one"],
    correctOrder: ["x-squared", "two-x-plus-one", "three-x"],
    explanation: "When x = 2, x² = 4, 2x + 1 = 5, and 3x = 6. Therefore 4 < 5 < 6.",
    hint: "Substitute 2 for x in each expression before comparing."
  },
  {
    id: "high-match-lines-to-slopes",
    gradeLevel: "high",
    topic: "linear-functions",
    type: "matching",
    instruction: "Match each linear equation to its slope.",
    prompt: "Connect each equation to the slope of its graph.",
    leftItems: [
      { id: "positive-two", label: "y = 2x + 1" },
      { id: "negative-one", label: "y = −x + 4" },
      { id: "horizontal", label: "y = 3" }
    ],
    rightItems: [
      { id: "slope-two", label: "Slope 2" },
      { id: "slope-negative-one", label: "Slope −1" },
      { id: "slope-zero", label: "Slope 0" }
    ],
    matches: { "positive-two": "slope-two", "negative-one": "slope-negative-one", horizontal: "slope-zero" },
    explanation: "In y = mx + b, m is the slope. The equations have slopes 2, −1, and 0 respectively; y = 3 is a horizontal line.",
    hint: "The coefficient of x is the slope. A constant rule has no x-term, so its slope is zero."
  },
  {
    id: "high-label-linear-graph-features",
    gradeLevel: "high",
    topic: "linear-functions",
    type: "visual-label",
    instruction: "Assign each graph feature to its correct label.",
    prompt: "Label the slope and y-intercept of the graph y = 2x − 1.",
    visual: { type: "function-line", equation: "y = 2x − 1" },
    labels: [
      { id: "slope-two", label: "Slope = 2" },
      { id: "intercept-negative-one", label: "y-intercept = −1" }
    ],
    targets: [
      { id: "line-steepness", label: "Steepness of the line" },
      { id: "y-axis-crossing", label: "Where the line crosses the y-axis" }
    ],
    correctAssignments: { "line-steepness": "slope-two", "y-axis-crossing": "intercept-negative-one" },
    explanation: "The slope tells how much y rises when x increases by 1. The y-intercept is the value of y when x is 0, so this graph crosses the y-axis at −1.",
    hint: "Read the coefficient of x for slope, and then look for the constant term."
  },
  ...highExtendedQuestions
];
