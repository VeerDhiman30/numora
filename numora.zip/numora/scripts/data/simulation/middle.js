function coreStep(step) {
  return {
    core: true,
    incorrectStep: step.id,
    unsureStep: step.id,
    progressiveHints: [step.hint],
    strongHint: step.strongHint ?? step.hint,
    ...step
  };
}

export const middleSimulationStories = [
  {
    id: "middle-subscription-choice",
    gradeLevel: "middle",
    title: "Pick a study subscription",
    description: "Compare two study platforms over a full year before recommending one.",
    character: { name: "Avery", role: "Student council planner", visual: "▤" },
    mathConcepts: ["Rates", "Annual cost", "Comparison", "Savings"],
    estimatedSteps: 5,
    initialStepId: "select-yearly-facts",
    openingMessage: "Student council can fund one study platform for the year. Let’s look beyond the monthly price and compare the full cost.",
    conclusion: "Comparing both plans for the same 12 months showed that the annual plan saves the council money.",
    completionSummary: {
      decision: "Choose the $72 annual plan.",
      whyItWorked: "The monthly plan costs $96 over 12 months, which is $24 more.",
      mathUsed: "Multiplication and subtraction with rates.",
      realWorld: "Fair comparisons use the same amount of time for each option.",
      lesson: "A lower monthly number is not always the lower yearly cost."
    },
    evidence: {
      title: "Study-platform offers",
      description: "Both plans include the same core study tools.",
      columns: ["Plan", "Price"],
      rows: [["Focus Monthly", "$8 each month"], ["Focus Annual", "$72 for one year"], ["School year", "12 months"]]
    },
    steps: [
      coreStep({
        id: "select-yearly-facts",
        coachMessage: "Which two facts are needed to turn the monthly plan into a yearly cost?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "monthly-price", label: "$8 each month", description: "The repeating monthly rate" },
          { id: "annual-price", label: "$72 for one year", description: "Already a yearly total" },
          { id: "months", label: "12 months", description: "Number of monthly payments" }
        ],
        correctAnswer: ["monthly-price", "months"],
        nextStep: "monthly-yearly-total",
        explanation: "To find a yearly monthly-plan cost, multiply $8 per month by 12 months.",
        incorrectGuidance: "Look for the repeating monthly amount and the number of times it repeats in a year.",
        noIdeaGuidance: "Ask: What number is paid each month, and how many months are in the school year?",
        hint: "Choose one price and one time count."
      }),
      coreStep({
        id: "monthly-yearly-total",
        coachMessage: "What does Focus Monthly cost over 12 months at $8 each month?",
        responseType: "numeric",
        answerLabel: "Yearly cost in dollars",
        correctAnswer: "96",
        nextStep: "find-savings",
        explanation: "12 × $8 = $96 for a full year.",
        incorrectGuidance: "Multiply the monthly price by all 12 months, not by only one month.",
        noIdeaGuidance: "Try 8 × 10 = 80, then add 8 × 2 = 16.",
        hint: "80 + 16 = ?"
      }),
      coreStep({
        id: "find-savings",
        coachMessage: "How many dollars does the $72 annual plan save compared with the $96 monthly total?",
        responseType: "numeric",
        answerLabel: "Dollars saved",
        correctAnswer: "24",
        nextStep: "recommend-plan",
        explanation: "$96 − $72 = $24 in savings.",
        incorrectGuidance: "Subtract the lower yearly cost from the higher yearly cost.",
        noIdeaGuidance: "Count from 72 to 96: 72 to 80, then 80 to 96.",
        hint: "96 − 72 = ?"
      }),
      coreStep({
        id: "recommend-plan",
        coachMessage: "Which plan should student council recommend for a full school year?",
        responseType: "recommendation",
        options: [
          { id: "monthly", label: "Focus Monthly", description: "$96 for 12 months" },
          { id: "annual", label: "Focus Annual", description: "$72 for one year" }
        ],
        correctAnswer: "annual",
        nextStep: "explain-fair-comparison",
        explanation: "The annual plan provides the same year of service for $24 less.",
        incorrectGuidance: "Compare the two yearly totals, $96 and $72, rather than the payment schedules alone.",
        noIdeaGuidance: "Which yearly total is smaller?",
        hint: "$72 is less than $96."
      }),
      coreStep({
        id: "explain-fair-comparison",
        coachMessage: "Write a short reason why comparing both plans over 12 months is fair.",
        responseType: "written",
        answerLabel: "Your comparison reason",
        acceptedPhrases: ["same time", "same number of months", "12 months", "yearly cost", "full year"],
        correctAnswer: "same time",
        nextStep: null,
        explanation: "Comparing the same length of time makes the prices meaningful side by side.",
        incorrectGuidance: "Mention that each plan was measured for a full year or 12 months.",
        noIdeaGuidance: "Start with: It is fair because both plans...",
        hint: "Use same time or 12 months."
      })
    ]
  },
  {
    id: "middle-basketball-strategy",
    gradeLevel: "middle",
    title: "Final-minute basketball plan",
    description: "Use recent shooting percentages to suggest a smart final play.",
    character: { name: "Coach Morgan", role: "Basketball coach", visual: "◉" },
    mathConcepts: ["Percentages", "Rates", "Evidence", "Data interpretation"],
    estimatedSteps: 5,
    initialStepId: "find-nia-rate",
    openingMessage: "We have one last possession. I want the choice supported by recent practice data, not just a guess.",
    conclusion: "Jordan’s 90% practice rate made the final-minute recommendation stronger than a choice based on a feeling.",
    completionSummary: {
      decision: "Give Jordan the final shot opportunity.",
      whyItWorked: "Jordan made 18 of 20 shots, or 90%, compared with Nia’s 70%.",
      mathUsed: "Fractions, percentages, and comparing rates.",
      realWorld: "Teams use recent data to make choices under pressure.",
      lesson: "A rate is most useful when the attempts are compared too."
    },
    evidence: {
      title: "Recent shooting practice",
      description: "Both players took the same type of shot during practice.",
      columns: ["Player", "Made", "Attempts"],
      rows: [["Nia", "14", "20"], ["Jordan", "18", "20"]]
    },
    steps: [
      coreStep({
        id: "find-nia-rate",
        coachMessage: "Nia made 14 of 20 shots. What percentage is that?",
        responseType: "numeric",
        answerLabel: "Nia’s percentage",
        correctAnswer: "70",
        nextStep: "find-jordan-rate",
        explanation: "14 ÷ 20 = 0.70, which is 70%.",
        incorrectGuidance: "First think of 14 out of 20, then change the decimal to a percent.",
        noIdeaGuidance: "Half of 20 is 10, or 50%. Nia made 4 more than 10.",
        hint: "14/20 = 70/100."
      }),
      coreStep({
        id: "find-jordan-rate",
        coachMessage: "Jordan made 18 of 20 shots. What percentage is that?",
        responseType: "numeric",
        answerLabel: "Jordan’s percentage",
        correctAnswer: "90",
        nextStep: "choose-comparison-evidence",
        explanation: "18 ÷ 20 = 0.90, which is 90%.",
        incorrectGuidance: "Both fractions are out of 20. Think how close 18 is to all 20 shots.",
        noIdeaGuidance: "If Jordan missed 2 out of 20, what percent did Jordan make?",
        hint: "18/20 = 90/100."
      }),
      coreStep({
        id: "choose-comparison-evidence",
        coachMessage: "Which evidence makes the player comparison especially fair?",
        responseType: "evidence-selection",
        selectionMode: "single",
        requiredSelections: 1,
        options: [
          { id: "same-attempts", label: "Both players took 20 attempts", description: "Same denominator" },
          { id: "names", label: "The players have different names", description: "Not a math comparison" },
          { id: "final-minute", label: "The game is in the final minute", description: "Context, not rate evidence" }
        ],
        correctAnswer: "same-attempts",
        nextStep: "choose-player",
        explanation: "Because both players took 20 attempts, their made-shot totals can be compared directly.",
        incorrectGuidance: "Choose the fact that tells whether the two shooting samples are measured in the same way.",
        noIdeaGuidance: "Look for the fact about the number of tries each player had.",
        hint: "Fair rate comparisons use matching attempts."
      }),
      coreStep({
        id: "choose-player",
        coachMessage: "Who has the stronger recent shooting percentage for this play?",
        responseType: "recommendation",
        options: [
          { id: "nia", label: "Nia", description: "70% recent shooting" },
          { id: "jordan", label: "Jordan", description: "90% recent shooting" }
        ],
        correctAnswer: "jordan",
        nextStep: "explain-data-choice",
        explanation: "Jordan’s 90% is greater than Nia’s 70%, so Jordan has the higher recent rate.",
        incorrectGuidance: "Compare the two percentages you found, not just the number of shots made.",
        noIdeaGuidance: "Which is bigger: 70% or 90%?",
        hint: "90 is greater than 70."
      }),
      coreStep({
        id: "explain-data-choice",
        coachMessage: "Write a short reason for the recommendation using the word percentage or rate.",
        responseType: "written",
        answerLabel: "Reason for the play",
        acceptedPhrases: ["higher percentage", "higher rate", "90%", "90 percent"],
        correctAnswer: "higher percentage",
        nextStep: null,
        explanation: "A recommendation is strongest when it names Jordan’s 90% recent shooting percentage.",
        incorrectGuidance: "Point to the measured result rather than saying only that one player is better.",
        noIdeaGuidance: "Use this frame: Jordan has the higher ___ because...",
        hint: "Mention 90% or a higher rate."
      })
    ]
  },
  {
    id: "middle-festival-budget",
    gradeLevel: "middle",
    title: "Community festival plan",
    description: "Check whether ticket sales can cover a neighborhood festival budget.",
    character: { name: "Leila", role: "Community event volunteer", visual: "✹" },
    mathConcepts: ["Multiplication", "Budgeting", "Revenue", "Equations"],
    estimatedSteps: 5,
    initialStepId: "choose-revenue-facts",
    openingMessage: "Our neighborhood wants a small music and games festival. Before we promise anything, we need to see whether ticket sales can cover the costs.",
    conclusion: "Selling 120 tickets at $6 brings in exactly $720, enough to cover the festival’s planned costs.",
    completionSummary: {
      decision: "Use the 120-ticket plan at $6 per ticket.",
      whyItWorked: "Ticket revenue is $720, which matches the total cost.",
      mathUsed: "Multiplication, addition, and comparing totals.",
      realWorld: "Event planners estimate revenue before committing to expenses.",
      lesson: "A budget works when expected income covers planned costs."
    },
    evidence: {
      title: "Festival planning notes",
      description: "The volunteer team expects to sell all planned tickets.",
      columns: ["Item", "Amount"],
      rows: [["Tickets to sell", "120"], ["Ticket price", "$6"], ["Stage and sound", "$420"], ["Games and supplies", "$300"]]
    },
    steps: [
      coreStep({
        id: "choose-revenue-facts",
        coachMessage: "Which two pieces of evidence are needed to find ticket-sale revenue?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "tickets", label: "120 tickets to sell", description: "How many tickets" },
          { id: "price", label: "$6 ticket price", description: "Price for each ticket" },
          { id: "stage", label: "$420 stage and sound", description: "A cost, not revenue" },
          { id: "games", label: "$300 games and supplies", description: "A cost, not revenue" }
        ],
        correctAnswer: ["tickets", "price"],
        nextStep: "find-ticket-revenue",
        explanation: "Revenue comes from how many tickets are sold times the price of each ticket.",
        incorrectGuidance: "Choose the two facts that describe selling tickets, not spending money.",
        noIdeaGuidance: "Ask: What do we multiply to find money from ticket sales?",
        hint: "Revenue = number sold × price each."
      }),
      coreStep({
        id: "find-ticket-revenue",
        coachMessage: "What revenue comes from selling 120 tickets at $6 each?",
        responseType: "numeric",
        answerLabel: "Ticket revenue in dollars",
        correctAnswer: "720",
        nextStep: "find-total-cost",
        explanation: "120 × $6 = $720.",
        incorrectGuidance: "Break 120 into 12 tens: 12 × 6 = 72, then add the zero.",
        noIdeaGuidance: "Find 100 × 6 and 20 × 6, then combine them.",
        hint: "600 + 120 = ?"
      }),
      coreStep({
        id: "find-total-cost",
        coachMessage: "What is the total cost of $420 for stage and sound plus $300 for games and supplies?",
        responseType: "numeric",
        answerLabel: "Total cost in dollars",
        correctAnswer: "720",
        nextStep: "check-budget",
        explanation: "$420 + $300 = $720 in total planned costs.",
        incorrectGuidance: "Add the two expense amounts in the table.",
        noIdeaGuidance: "Add the hundreds first: 400 + 300, then add 20.",
        hint: "420 + 300 = ?"
      }),
      coreStep({
        id: "check-budget",
        coachMessage: "Does the ticket plan cover the festival costs?",
        responseType: "multiple-choice",
        options: [
          { id: "covers", label: "Yes, it covers the costs", description: "$720 revenue equals $720 cost" },
          { id: "short", label: "No, it is short", description: "The cost is larger than the revenue" }
        ],
        correctAnswer: "covers",
        nextStep: "recommend-plan",
        explanation: "The expected revenue and the planned costs are both $720, so the plan breaks even.",
        incorrectGuidance: "Compare the two totals you calculated. Are they equal, or is one larger?",
        noIdeaGuidance: "Write the two totals side by side: $720 and $720.",
        hint: "Equal totals mean the costs are covered."
      }),
      coreStep({
        id: "recommend-plan",
        coachMessage: "Which recommendation best matches the budget evidence?",
        responseType: "recommendation",
        options: [
          { id: "use-plan", label: "Use the ticket plan and watch spending", description: "It breaks even, with no extra cushion" },
          { id: "add-expense", label: "Add another $200 expense", description: "Would cost more than ticket revenue" }
        ],
        correctAnswer: "use-plan",
        nextStep: null,
        explanation: "The plan covers its listed costs but has no extra money, so the team should avoid adding spending.",
        incorrectGuidance: "Choose the option that does not make costs exceed the $720 revenue.",
        noIdeaGuidance: "Would an extra expense fit if the budget already uses all $720?",
        hint: "A break-even budget has no money left over."
      })
    ]
  },
  {
    id: "middle-weather-plan",
    gradeLevel: "middle",
    title: "Field-day forecast",
    description: "Use weather probabilities to choose the better day for an outdoor field day.",
    character: { name: "Omar", role: "PE class representative", visual: "☁" },
    mathConcepts: ["Probability", "Percentages", "Data interpretation", "Decision making"],
    estimatedSteps: 5,
    initialStepId: "find-saturday-dry-chance",
    openingMessage: "PE class can hold field day on Saturday or Sunday. We cannot know the weather for sure, but we can make the better choice from the forecast.",
    conclusion: "Sunday has the stronger weather outlook because its 80% dry chance is higher than Saturday’s 40%.",
    completionSummary: {
      decision: "Schedule field day for Sunday and keep the indoor backup ready.",
      whyItWorked: "Sunday has an 80% chance of dry weather, 40 percentage points higher than Saturday.",
      mathUsed: "Complementary probability and percentage comparison.",
      realWorld: "Forecasts support planning even though they cannot guarantee an outcome.",
      lesson: "Choose the option with stronger evidence while preparing for uncertainty."
    },
    evidence: {
      title: "Weekend forecast",
      description: "The gym is available as an indoor backup on either day.",
      columns: ["Day", "Chance of rain", "Backup"],
      rows: [["Saturday", "60%", "Gym available"], ["Sunday", "20%", "Gym available"]]
    },
    steps: [
      coreStep({
        id: "find-saturday-dry-chance",
        coachMessage: "Saturday has a 60% chance of rain. What is the chance that it stays dry?",
        responseType: "numeric",
        answerLabel: "Dry chance as a percentage",
        correctAnswer: "40",
        nextStep: "find-sunday-dry-chance",
        explanation: "A dry chance is the rest of 100%, so 100% − 60% = 40%.",
        incorrectGuidance: "Rain and no rain together make 100%.",
        noIdeaGuidance: "Start at 60 and count up to 100.",
        hint: "100 − 60 = ?"
      }),
      coreStep({
        id: "find-sunday-dry-chance",
        coachMessage: "Sunday has a 20% chance of rain. What is the chance that it stays dry?",
        responseType: "numeric",
        answerLabel: "Dry chance as a percentage",
        correctAnswer: "80",
        nextStep: "choose-useful-forecast",
        explanation: "100% − 20% = 80% dry weather.",
        incorrectGuidance: "Use the same whole of 100% and subtract Sunday’s rain chance.",
        noIdeaGuidance: "If only 20 out of 100 chances are rainy, how many are dry?",
        hint: "100 − 20 = ?"
      }),
      coreStep({
        id: "choose-useful-forecast",
        coachMessage: "Which pieces of evidence matter most when choosing the outdoor field-day date?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "saturday-rain", label: "Saturday: 60% chance of rain", description: "Forecast evidence" },
          { id: "sunday-rain", label: "Sunday: 20% chance of rain", description: "Forecast evidence" },
          { id: "gym", label: "Gym available", description: "Useful backup, but not a date comparison" }
        ],
        correctAnswer: ["saturday-rain", "sunday-rain"],
        nextStep: "compare-dry-chances",
        explanation: "The two rain forecasts let us compare the likelihood of dry weather for each day.",
        incorrectGuidance: "Choose the two rows that directly compare Saturday and Sunday weather.",
        noIdeaGuidance: "Which information has one percentage for each day?",
        hint: "Use the two weather percentages."
      }),
      coreStep({
        id: "compare-dry-chances",
        coachMessage: "How many percentage points higher is Sunday’s 80% dry chance than Saturday’s 40% dry chance?",
        responseType: "numeric",
        answerLabel: "Percentage points",
        correctAnswer: "40",
        nextStep: "recommend-day",
        explanation: "80% − 40% = 40 percentage points.",
        incorrectGuidance: "Subtract the two dry chances, not the two rain chances.",
        noIdeaGuidance: "Count up from 40 to 80.",
        hint: "80 − 40 = ?"
      }),
      coreStep({
        id: "recommend-day",
        coachMessage: "Which field-day plan uses the forecast most wisely?",
        responseType: "recommendation",
        options: [
          { id: "sunday-backup", label: "Choose Sunday and keep the gym as backup", description: "Higher dry chance with a backup" },
          { id: "saturday-no-backup", label: "Choose Saturday and skip the backup", description: "Lower dry chance and less preparation" }
        ],
        correctAnswer: "sunday-backup",
        nextStep: null,
        explanation: "Sunday has the better dry-weather probability, while the gym still protects the plan if weather changes.",
        incorrectGuidance: "Choose the day with the larger dry chance and keep the available backup.",
        noIdeaGuidance: "Which day has 80% dry weather instead of 40%?",
        hint: "Higher probability plus a backup is the safer plan."
      })
    ]
  },
  {
    id: "middle-food-truck-pricing",
    gradeLevel: "middle",
    title: "Food truck lunch price",
    description: "Help a student food truck set a price that covers costs and earns a reasonable profit.",
    character: { name: "Mina", role: "Entrepreneurship club lead", visual: "▣" },
    mathConcepts: ["Unit rates", "Decimals", "Profit", "Multiplication"],
    estimatedSteps: 5,
    initialStepId: "find-cost-per-meal",
    openingMessage: "Entrepreneurship club is selling veggie wraps at the school fair. We need a price that covers the cost of each wrap and helps the club fund its next project.",
    conclusion: "Pricing each wrap at $3 earns $1.50 per wrap and $60 if all 40 wraps are sold.",
    completionSummary: {
      decision: "Keep the $3 wrap price for the 40-wrap fair plan.",
      whyItWorked: "Each $1.50 profit adds to $60 across 40 wraps.",
      mathUsed: "Adding costs, subtracting for profit, and multiplying a unit rate.",
      realWorld: "Small businesses must price each item above its cost to earn a profit.",
      lesson: "Find profit per item first, then multiply by the number sold."
    },
    evidence: {
      title: "Veggie-wrap plan",
      description: "The club expects to sell 40 wraps at the fair.",
      columns: ["Information", "Amount"],
      rows: [["Ingredients per wrap", "$1.20"], ["Packaging per wrap", "$0.30"], ["Planned price per wrap", "$3.00"], ["Expected wraps sold", "40"]]
    },
    steps: [
      coreStep({
        id: "find-cost-per-meal",
        coachMessage: "What does one wrap cost to make after adding $1.20 for ingredients and $0.30 for packaging?",
        responseType: "numeric",
        answerLabel: "Cost per wrap in dollars",
        correctAnswer: "1.5",
        nextStep: "find-profit-per-meal",
        explanation: "$1.20 + $0.30 = $1.50 to make each wrap.",
        incorrectGuidance: "Add the two costs that happen for every single wrap.",
        noIdeaGuidance: "Thirty cents is 0.30. Add 1.20 and 0.30.",
        hint: "1.20 + 0.30 = 1.50."
      }),
      coreStep({
        id: "find-profit-per-meal",
        coachMessage: "If one wrap sells for $3.00 and costs $1.50 to make, what is the profit on one wrap?",
        responseType: "numeric",
        answerLabel: "Profit per wrap in dollars",
        correctAnswer: "1.5",
        nextStep: "choose-profit-facts",
        explanation: "$3.00 − $1.50 = $1.50 profit per wrap.",
        incorrectGuidance: "Profit is the selling price minus the cost to make the item.",
        noIdeaGuidance: "Start at $1.50 and count up to $3.00.",
        hint: "3.00 − 1.50 = ?"
      }),
      coreStep({
        id: "choose-profit-facts",
        coachMessage: "Which two facts are needed to find the club’s total profit at the fair?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "profit-unit", label: "$1.50 profit per wrap", description: "Money earned for each wrap" },
          { id: "sold", label: "40 expected wraps sold", description: "How many times the profit repeats" },
          { id: "ingredients", label: "$1.20 ingredients per wrap", description: "Already used to find cost" }
        ],
        correctAnswer: ["profit-unit", "sold"],
        nextStep: "find-total-profit",
        explanation: "Total profit uses the profit on one wrap and the number of wraps sold.",
        incorrectGuidance: "Choose one money amount earned per wrap and one count of wraps.",
        noIdeaGuidance: "Think: What repeats, and how many times does it repeat?",
        hint: "Profit per wrap × wraps sold."
      }),
      coreStep({
        id: "find-total-profit",
        coachMessage: "What total profit does the club earn if it sells 40 wraps at $1.50 profit each?",
        responseType: "numeric",
        answerLabel: "Total profit in dollars",
        correctAnswer: "60",
        nextStep: "recommend-price",
        explanation: "40 × $1.50 = $60.",
        incorrectGuidance: "Find 4 × 1.50 first, then use the zero in 40.",
        noIdeaGuidance: "Four wraps earn $6. Multiply that group by 10.",
        hint: "4 × 1.5 = 6, so 40 × 1.5 = 60."
      }),
      coreStep({
        id: "recommend-price",
        coachMessage: "Which pricing recommendation fits the evidence?",
        responseType: "recommendation",
        options: [
          { id: "keep-three", label: "Keep the $3.00 price", description: "Covers cost and earns $1.50 per wrap" },
          { id: "price-one", label: "Lower the price to $1.00", description: "Would not cover the $1.50 cost" }
        ],
        correctAnswer: "keep-three",
        nextStep: null,
        explanation: "The $3 price covers the $1.50 cost and leaves $1.50 profit for each wrap.",
        incorrectGuidance: "Choose the price that is greater than the cost to make one wrap.",
        noIdeaGuidance: "Would a $1 wrap cover a $1.50 cost?",
        hint: "A price must be above cost to make profit."
      })
    ]
  }
];
