function coreStep(step) {
  return {
    core: true,
    incorrectStep: step.id,
    unsureStep: step.id,
    progressiveHints: [step.hint],
    strongHint: step.strongHint ?? step.hint,
    ...step
  };
}

export const highSimulationStories = [
  {
    id: "high-laptop-comparison",
    gradeLevel: "high",
    title: "Laptop for the media team",
    description: "Compare purchase options by looking at total cost, not just the sticker price.",
    character: { name: "Riley", role: "Media-team lead", visual: "▰" },
    mathConcepts: ["Total cost", "Percentages", "Recommendations"],
    estimatedSteps: 5,
    initialStepId: "discounted-price",
    openingMessage: "Our media team needs a laptop. One option looks cheaper at first, but I want to compare what we will actually pay.",
    conclusion: "The better recommendation came from comparing total costs under the same conditions.",
    completionSummary: {
      decision: "Choose Laptop B at $790.",
      whyItWorked: "Laptop A costs $810 after its discount, so Laptop B is $20 less.",
      mathUsed: "Percentage discounts and price comparison.",
      realWorld: "A discount is useful only after comparing the final prices.",
      lesson: "Use final costs, not sticker prices, in a purchase decision."
    },
    evidence: {
      title: "Laptop options",
      description: "Option A has a discount; both options meet the team’s needs.",
      columns: ["Option", "Details"],
      rows: [["A", "$900 with 10% discount"], ["B", "$790, no discount"]]
    },
    steps: [
      {
        id: "discounted-price",
        core: true,
        incorrectStep: "discounted-price",
        unsureStep: "discounted-price",
        progressiveHints: ["Find 10% of $900, then subtract it."],
        strongHint: "Ten percent of 900 is 90, so subtract 90 from 900.",
        coachMessage: "What is the discounted price of Laptop A before tax?",
        responseType: "numeric",
        answerLabel: "Discounted price in dollars",
        correctAnswer: "810",
        nextStep: "recommend-laptop",
        explanation: "Ten percent of $900 is $90. Subtracting gives $900 − $90 = $810.",
        incorrectGuidance: "Find 10% of 900 first, then subtract that discount from 900.",
        noIdeaGuidance: "Ten percent is one tenth. What is one tenth of 900?",
        hint: "900 × 0.10 = 90."
      },
      {
        id: "recommend-laptop",
        core: true,
        incorrectStep: "recommend-laptop",
        unsureStep: "recommend-laptop",
        progressiveHints: ["Compare $810 and $790."],
        strongHint: "$790 is the smaller final price.",
        coachMessage: "Which option should Riley recommend if price is the only difference?",
        responseType: "recommendation",
        options: [
          { id: "option-a", label: "Laptop A", description: "Discounted price: $810" },
          { id: "option-b", label: "Laptop B", description: "Price: $790" }
        ],
        correctAnswer: "option-b",
        nextStep: "find-price-difference",
        explanation: "Laptop B costs $790, which is $20 less than Laptop A’s discounted $810 price.",
        incorrectGuidance: "Compare the final prices after the discount, not the original sticker prices.",
        noIdeaGuidance: "Place $810 and $790 on a number line. Which amount is smaller?",
        hint: "$790 is less than $810."
      },
      coreStep({
        id: "find-price-difference",
        coachMessage: "What is the price difference between Laptop A at $810 and Laptop B at $790?",
        responseType: "numeric",
        answerLabel: "Difference in dollars",
        correctAnswer: "20",
        nextStep: "select-final-price-evidence",
        explanation: "$810 − $790 = $20.",
        incorrectGuidance: "Subtract the smaller final price from the larger final price.",
        noIdeaGuidance: "Count up from 790 to 810 by tens.",
        hint: "810 − 790 = ?"
      }),
      coreStep({
        id: "select-final-price-evidence",
        coachMessage: "Which two pieces of evidence should Riley use to compare the final purchase prices?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "a-final", label: "Laptop A after its 10% discount: $810", description: "Final price for A" },
          { id: "b-final", label: "Laptop B price: $790", description: "Final price for B" },
          { id: "a-sticker", label: "Laptop A sticker price: $900", description: "Price before the discount" }
        ],
        correctAnswer: ["a-final", "b-final"],
        nextStep: "explain-laptop-choice",
        explanation: "The final price for each option gives the fair comparison.",
        incorrectGuidance: "Choose the price after the discount for A and the listed price for B.",
        noIdeaGuidance: "Ask: What would the team actually pay for each laptop?",
        hint: "Use $810 and $790, not $900."
      }),
      coreStep({
        id: "explain-laptop-choice",
        coachMessage: "Write a short reason why Laptop B is the better choice when price is the only difference.",
        responseType: "written",
        answerLabel: "Your comparison reason",
        acceptedPhrases: ["20 less", "$20 less", "790 is less", "lower final price", "cheaper"],
        correctAnswer: "20 less",
        nextStep: null,
        explanation: "Laptop B is $20 less once the discount on Laptop A is included.",
        incorrectGuidance: "Mention one final price and the $20 difference.",
        noIdeaGuidance: "Try: Laptop B costs less because...",
        hint: "Use $790, $810, or $20 in your sentence."
      })
    ]
  },
  {
    id: "high-savings-decision",
    gradeLevel: "high",
    title: "Savings goal choice",
    description: "Evaluate a simple savings option using interest and a clear financial goal.",
    character: { name: "Jordan", role: "Student event planner", visual: "◇" },
    mathConcepts: ["Simple interest", "Financial decisions", "Evidence"],
    estimatedSteps: 5,
    initialStepId: "interest-earned",
    openingMessage: "Jordan has $500 set aside for an event next year. Let’s see how a simple-interest account changes the plan.",
    conclusion: "Interest is part of the financial decision because it changes the money available at the end.",
    completionSummary: {
      decision: "Use the simple-interest savings account for the one-year goal.",
      whyItWorked: "The $500 stays available and earns $20, reaching $520.",
      mathUsed: "Simple interest: principal × rate × time.",
      realWorld: "Interest can make a savings goal easier to reach without adding new deposits.",
      lesson: "A financial recommendation should include both the money kept and the money earned."
    },
    evidence: {
      title: "Savings account offer",
      description: "The account earns simple interest for one year.",
      columns: ["Starting amount", "Annual rate", "Time"],
      rows: [["$500", "4%", "1 year"]]
    },
    steps: [
      {
        id: "interest-earned",
        core: true,
        incorrectStep: "interest-earned",
        unsureStep: "interest-earned",
        progressiveHints: ["Change 4% to 0.04 and multiply by 500."],
        strongHint: "500 × 0.04 = 20.",
        coachMessage: "How many dollars of simple interest will the account earn in one year?",
        responseType: "numeric",
        answerLabel: "Interest earned in dollars",
        correctAnswer: "20",
        nextStep: "find-ending-balance",
        explanation: "Simple interest is principal × rate × time: 500 × 0.04 × 1 = 20.",
        incorrectGuidance: "Change 4% to 0.04, then multiply by $500 for one year.",
        noIdeaGuidance: "First find 1% of $500. Then use that to find 4%.",
        hint: "500 × 0.04 = ?"
      },
      {
        id: "recommend-savings",
        core: true,
        incorrectStep: "recommend-savings",
        unsureStep: "recommend-savings",
        progressiveHints: ["Choose the option that keeps the $500 and adds interest."],
        strongHint: "The account ends with $520 for the event.",
        coachMessage: "Which recommendation best fits Jordan’s one-year savings goal?",
        responseType: "recommendation",
        options: [
          { id: "save", label: "Use the savings account", description: "It adds $20 while keeping the $500 available next year." },
          { id: "spend", label: "Spend the $500 now", description: "It leaves no money earning interest for next year." }
        ],
        correctAnswer: "save",
        nextStep: "explain-savings-choice",
        explanation: "The savings account keeps the $500 for the goal and adds $20 of interest over the year.",
        incorrectGuidance: "Compare what each choice leaves available for the event next year.",
        noIdeaGuidance: "The event is next year. Which option keeps the savings and adds interest?",
        hint: "Look for the choice that preserves the goal money."
      },
      coreStep({
        id: "find-ending-balance",
        coachMessage: "What will Jordan have after adding the $20 interest to the $500 starting amount?",
        responseType: "numeric",
        answerLabel: "Ending balance in dollars",
        correctAnswer: "520",
        nextStep: "select-interest-facts",
        explanation: "$500 + $20 = $520 after one year.",
        incorrectGuidance: "Add the interest earned to the original amount; do not replace the original amount.",
        noIdeaGuidance: "Start at 500 and add two tens.",
        hint: "500 + 20 = ?"
      }),
      coreStep({
        id: "select-interest-facts",
        coachMessage: "Which three facts are needed for one year of simple-interest calculation?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 3,
        options: [
          { id: "principal", label: "$500 starting amount", description: "Principal" },
          { id: "rate", label: "4% annual rate", description: "Rate" },
          { id: "time", label: "1 year", description: "Time" },
          { id: "event", label: "A future event", description: "Goal context, not calculation data" }
        ],
        correctAnswer: ["principal", "rate", "time"],
        nextStep: "recommend-savings",
        explanation: "Simple interest uses the starting amount, rate, and time.",
        incorrectGuidance: "Choose the three numerical facts in the interest formula, not the reason for saving.",
        noIdeaGuidance: "Think P × R × T: principal, rate, and time.",
        hint: "Select $500, 4%, and 1 year."
      }),
      coreStep({
        id: "explain-savings-choice",
        coachMessage: "Write a short reason why the savings account supports Jordan’s one-year goal.",
        responseType: "written",
        answerLabel: "Your financial reason",
        acceptedPhrases: ["adds 20", "earns 20", "520", "keeps the 500", "interest"],
        correctAnswer: "earns 20",
        nextStep: null,
        explanation: "The account protects the $500 goal money and adds $20 of interest for a $520 balance.",
        incorrectGuidance: "Mention the starting savings, the $20 interest, or the $520 ending balance.",
        noIdeaGuidance: "Try: The account helps because it...",
        hint: "Use interest, $20, or $520."
      })
    ]
  },
  {
    id: "high-concert-break-even",
    gradeLevel: "high",
    title: "Concert ticket target",
    description: "Find the break-even point for a student concert before the committee commits to the event.",
    character: { name: "Nora", role: "Arts committee treasurer", visual: "♫" },
    mathConcepts: ["Linear relationships", "Break-even", "Revenue", "Profit"],
    estimatedSteps: 5,
    initialStepId: "select-break-even-facts",
    openingMessage: "The arts committee wants to host a student concert. We need to know how many tickets cover the fixed costs before we tell everyone the plan is safe.",
    conclusion: "The concert breaks even at 60 tickets and earns a $120 surplus if 75 tickets sell.",
    completionSummary: {
      decision: "Proceed with the concert while aiming for at least 60 ticket sales.",
      whyItWorked: "At $8 per ticket, 60 tickets cover $480; 75 tickets bring in $600.",
      mathUsed: "A break-even equation, multiplication, and subtraction.",
      realWorld: "Event teams use a break-even target to decide whether a plan is financially realistic.",
      lesson: "Revenue must first cover fixed costs before it becomes profit."
    },
    evidence: {
      title: "Concert budget",
      description: "Venue, equipment, and licenses are fixed costs even if fewer tickets sell.",
      columns: ["Information", "Amount"],
      rows: [["Fixed concert cost", "$480"], ["Ticket price", "$8"], ["Expected ticket sales", "75"], ["Venue capacity", "100"]]
    },
    steps: [
      coreStep({
        id: "select-break-even-facts",
        coachMessage: "Which two facts are needed to find the number of tickets that break even?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "fixed-cost", label: "$480 fixed concert cost", description: "Amount to cover" },
          { id: "ticket-price", label: "$8 ticket price", description: "Revenue per ticket" },
          { id: "expected-sales", label: "75 expected ticket sales", description: "Used later to estimate profit" },
          { id: "capacity", label: "100-seat capacity", description: "A limit, not the break-even equation" }
        ],
        correctAnswer: ["fixed-cost", "ticket-price"],
        nextStep: "find-break-even",
        explanation: "Break-even uses the cost to cover and the money earned from each ticket.",
        incorrectGuidance: "Choose the total expense and the amount each sale adds toward that expense.",
        noIdeaGuidance: "Ask: What must we pay, and how much does one ticket bring in?",
        hint: "Tickets needed = fixed cost ÷ ticket price."
      }),
      coreStep({
        id: "find-break-even",
        coachMessage: "How many $8 tickets must sell to cover the $480 fixed cost?",
        responseType: "numeric",
        answerLabel: "Tickets to break even",
        correctAnswer: "60",
        nextStep: "find-expected-revenue",
        explanation: "$480 ÷ $8 = 60 tickets.",
        incorrectGuidance: "Divide the total cost by the amount earned for one ticket.",
        noIdeaGuidance: "How many groups of 8 are in 480? Try 48 ÷ 8 first, then use the zero.",
        hint: "480 ÷ 8 = ?"
      }),
      coreStep({
        id: "find-expected-revenue",
        coachMessage: "What revenue comes from selling the expected 75 tickets at $8 each?",
        responseType: "numeric",
        answerLabel: "Expected revenue in dollars",
        correctAnswer: "600",
        nextStep: "find-surplus",
        explanation: "75 × $8 = $600 in ticket revenue.",
        incorrectGuidance: "Multiply the number of expected sales by the price for each ticket.",
        noIdeaGuidance: "Find 75 × 4, then double it for 75 × 8.",
        hint: "75 × 8 = 600."
      }),
      coreStep({
        id: "find-surplus",
        coachMessage: "If revenue is $600 and the fixed cost is $480, what surplus remains?",
        responseType: "numeric",
        answerLabel: "Surplus in dollars",
        correctAnswer: "120",
        nextStep: "recommend-concert",
        explanation: "$600 − $480 = $120 left after costs are covered.",
        incorrectGuidance: "Subtract the amount spent from the money earned.",
        noIdeaGuidance: "Count up from 480 to 600 in tens.",
        hint: "600 − 480 = ?"
      }),
      coreStep({
        id: "recommend-concert",
        coachMessage: "Which recommendation fits the concert evidence?",
        responseType: "recommendation",
        options: [
          { id: "proceed-target", label: "Proceed and set 60 tickets as the minimum target", description: "Expected sales are 75, above break-even" },
          { id: "cancel-short", label: "Cancel because 75 tickets cannot cover costs", description: "Ignores the $600 expected revenue" }
        ],
        correctAnswer: "proceed-target",
        nextStep: null,
        explanation: "The expected 75 sales are 15 above break-even and create a $120 surplus.",
        incorrectGuidance: "Compare expected sales, 75, with the 60 tickets needed to cover costs.",
        noIdeaGuidance: "Is 75 larger or smaller than 60?",
        hint: "Expected sales are above the break-even target."
      })
    ]
  },
  {
    id: "high-water-use-trend",
    gradeLevel: "high",
    title: "School water-use trend",
    description: "Interpret yearly water-use data and evaluate whether a conservation target is realistic.",
    character: { name: "Dr. Park", role: "Environmental science adviser", visual: "⌁" },
    mathConcepts: ["Rates of change", "Trends", "Linear prediction", "Data interpretation"],
    estimatedSteps: 5,
    initialStepId: "select-trend-facts",
    openingMessage: "Our school’s water team wants to set a 2026 conservation target. Let’s use the recent trend carefully instead of guessing.",
    conclusion: "Water use fell by 60 kiloliters in one year; continuing that rate predicts 460 kiloliters in 2026, below the 480 target.",
    completionSummary: {
      decision: "Keep the 480-kiloliter 2026 target and continue the current conservation plan.",
      whyItWorked: "A repeated 60-kiloliter yearly decrease predicts 460 kiloliters, 20 below the target.",
      mathUsed: "Subtraction, rate of change, and linear extrapolation.",
      realWorld: "Trend estimates help organizations set measurable sustainability goals.",
      lesson: "A prediction should state the rate it assumes and compare it with the target."
    },
    evidence: {
      title: "Annual water use",
      description: "The team measures total school water use in kiloliters each calendar year.",
      columns: ["Year", "Water use"],
      rows: [["2024", "580 kL"], ["2025", "520 kL"], ["2026 target", "480 kL"]]
    },
    steps: [
      coreStep({
        id: "select-trend-facts",
        coachMessage: "Which two measurements show the one-year water-use trend?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "use-2024", label: "2024: 580 kL", description: "Earlier measurement" },
          { id: "use-2025", label: "2025: 520 kL", description: "Later measurement" },
          { id: "target-2026", label: "2026 target: 480 kL", description: "Goal, not past trend data" }
        ],
        correctAnswer: ["use-2024", "use-2025"],
        nextStep: "find-one-year-change",
        explanation: "The 2024 and 2025 measurements show what actually changed over one year.",
        incorrectGuidance: "Choose the two completed years, not the future target.",
        noIdeaGuidance: "A trend comes from comparing past measurements at two different times.",
        hint: "Use 580 kL and 520 kL."
      }),
      coreStep({
        id: "find-one-year-change",
        coachMessage: "By how many kiloliters did school water use decrease from 580 kL to 520 kL?",
        responseType: "numeric",
        answerLabel: "Decrease in kiloliters",
        correctAnswer: "60",
        nextStep: "state-rate-of-change",
        explanation: "580 − 520 = 60, so use decreased by 60 kL.",
        incorrectGuidance: "Subtract the later, smaller use from the earlier use.",
        noIdeaGuidance: "Count up from 520 to 580.",
        hint: "580 − 520 = ?"
      }),
      coreStep({
        id: "state-rate-of-change",
        coachMessage: "What is the yearly rate of change if water use went down 60 kL in one year? Use a negative number for a decrease.",
        responseType: "numeric",
        answerLabel: "Kiloliters per year",
        correctAnswer: "-60",
        nextStep: "predict-2026-use",
        explanation: "The rate is −60 kL per year because the amount is decreasing.",
        incorrectGuidance: "A decrease is represented by a negative rate of change.",
        noIdeaGuidance: "The amount went down, so place a minus sign before 60.",
        hint: "Decrease of 60 = −60 per year."
      }),
      coreStep({
        id: "predict-2026-use",
        coachMessage: "If water use decreases by another 60 kL, what is the predicted 2026 water use?",
        responseType: "numeric",
        answerLabel: "Predicted water use in kiloliters",
        correctAnswer: "460",
        nextStep: "recommend-target",
        explanation: "520 − 60 = 460 kL.",
        incorrectGuidance: "Start with the most recent 520 kL measurement and subtract the yearly decrease.",
        noIdeaGuidance: "Move 60 lower from 520: 520 − 60.",
        hint: "520 − 60 = ?"
      }),
      coreStep({
        id: "recommend-target",
        coachMessage: "Which conclusion best fits the trend and the 480-kL target?",
        responseType: "recommendation",
        options: [
          { id: "keep-target", label: "Keep the target and continue conserving", description: "The 460-kL prediction is below 480 kL" },
          { id: "raise-target", label: "Raise the target because 480 kL is impossible", description: "The prediction is actually lower than 480 kL" }
        ],
        correctAnswer: "keep-target",
        nextStep: null,
        explanation: "If the trend continues, 460 kL is 20 kL below the 480-kL target.",
        incorrectGuidance: "Compare the predicted 460 kL with the target of 480 kL. Lower water use is better here.",
        noIdeaGuidance: "Which is smaller: 460 or 480?",
        hint: "460 is 20 below 480."
      })
    ]
  },
  {
    id: "high-data-plan-comparison",
    gradeLevel: "high",
    title: "Data plan for the media club",
    description: "Compare a limited data plan with an unlimited option using expected monthly use.",
    character: { name: "Sofia", role: "Media club producer", visual: "⌁" },
    mathConcepts: ["Functions", "Unit rates", "Cost comparison", "Optimization"],
    estimatedSteps: 5,
    initialStepId: "find-extra-data",
    openingMessage: "Media club posts videos from events, so its data use can be high. Let’s compare the two plans using the club’s expected 7 GB month.",
    conclusion: "At 7 GB, the limited plan costs $44, so the $40 unlimited plan is the better value by $4.",
    completionSummary: {
      decision: "Choose the $40 unlimited plan for the media club.",
      whyItWorked: "Expected use creates 4 GB of overage, making the limited plan cost $44.",
      mathUsed: "A base fee plus a per-unit rate, then cost comparison.",
      realWorld: "Variable-cost plans can become more expensive as use rises.",
      lesson: "Compare a plan’s total cost at the expected level of use."
    },
    evidence: {
      title: "Monthly data-plan offers",
      description: "The club expects to use about 7 GB during a typical event month.",
      columns: ["Plan detail", "Amount"],
      rows: [["Stream Lite base fee", "$24"], ["Data included with Stream Lite", "3 GB"], ["Stream Lite overage", "$5 per GB"], ["Unlimited plan", "$40"], ["Expected club use", "7 GB"]]
    },
    steps: [
      coreStep({
        id: "find-extra-data",
        coachMessage: "The Lite plan includes 3 GB and the club expects 7 GB. How many GB are over the included amount?",
        responseType: "numeric",
        answerLabel: "Extra GB",
        correctAnswer: "4",
        nextStep: "find-lite-total",
        explanation: "7 GB − 3 GB = 4 GB of overage.",
        incorrectGuidance: "Subtract the data included from the expected data use.",
        noIdeaGuidance: "Count from 3 GB up to 7 GB.",
        hint: "7 − 3 = ?"
      }),
      coreStep({
        id: "find-lite-total",
        coachMessage: "The 4 extra GB cost $5 each. What is the full Lite-plan cost after adding the $24 base fee?",
        responseType: "numeric",
        answerLabel: "Lite-plan total in dollars",
        correctAnswer: "44",
        nextStep: "find-price-difference",
        explanation: "4 × $5 = $20 in overage, and $24 + $20 = $44.",
        incorrectGuidance: "Find the overage cost first, then add it to the base fee.",
        noIdeaGuidance: "Four groups of $5 make $20. Add that to $24.",
        hint: "24 + (4 × 5) = ?"
      }),
      coreStep({
        id: "find-price-difference",
        coachMessage: "How many dollars more is the $44 Lite total than the $40 unlimited plan?",
        responseType: "numeric",
        answerLabel: "Difference in dollars",
        correctAnswer: "4",
        nextStep: "select-plan-facts",
        explanation: "$44 − $40 = $4.",
        incorrectGuidance: "Subtract the unlimited price from the Lite total at 7 GB.",
        noIdeaGuidance: "Count up from 40 to 44.",
        hint: "44 − 40 = ?"
      }),
      coreStep({
        id: "select-plan-facts",
        coachMessage: "Which four details are needed to calculate the Lite plan’s cost at 7 GB?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 4,
        options: [
          { id: "base", label: "$24 base fee", description: "Starting cost" },
          { id: "included", label: "3 GB included", description: "Free allowance" },
          { id: "overage", label: "$5 per extra GB", description: "Variable cost" },
          { id: "unlimited", label: "$40 unlimited plan", description: "Used after calculating Lite" },
          { id: "use", label: "7 GB expected use", description: "Usage input" }
        ],
        correctAnswer: ["base", "included", "overage", "use"],
        nextStep: "recommend-data-plan",
        explanation: "The Lite formula starts with its base fee, included data, and per-GB overage rate; expected use supplies the input value.",
        incorrectGuidance: "Choose the details that define the Lite plan itself, not the other plan’s price.",
        noIdeaGuidance: "Look for the fixed fee, the included amount, and the cost after that amount.",
        hint: "Base fee, included GB, and overage rate."
      }),
      coreStep({
        id: "recommend-data-plan",
        coachMessage: "Which plan should the club choose for an expected 7-GB month?",
        responseType: "recommendation",
        options: [
          { id: "unlimited", label: "Unlimited plan", description: "$40 at 7 GB" },
          { id: "lite", label: "Stream Lite", description: "$44 at 7 GB" }
        ],
        correctAnswer: "unlimited",
        nextStep: null,
        explanation: "At expected use, the unlimited plan is $4 less than the Lite plan.",
        incorrectGuidance: "Use the total Lite price at 7 GB, not only its $24 starting fee.",
        noIdeaGuidance: "Compare the two complete totals: $40 and $44.",
        hint: "The smaller total is $40."
      })
    ]
  }
];
