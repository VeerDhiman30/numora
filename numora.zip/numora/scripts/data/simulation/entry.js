function coreStep(step) {
  return {
    core: true,
    incorrectStep: step.id,
    unsureStep: step.id,
    progressiveHints: [step.hint],
    strongHint: step.strongHint ?? step.hint,
    ...step
  };
}

export const entrySimulationStories = [
  {
    id: "entry-snack-budget",
    gradeLevel: "entry",
    title: "Class snack cart",
    description: "Help Ms. Rivera choose snacks, cups, and a plan that fit a class budget.",
    character: { name: "Ms. Rivera", role: "Classroom teacher", visual: "◒" },
    mathConcepts: ["Addition", "Subtraction", "Money", "Budgeting"],
    estimatedSteps: 5,
    initialStepId: "choose-snacks",
    openingMessage: "I have $12 for a class snack cart. Let’s choose treats, check the total, and make sure we still have what the class needs.",
    conclusion: "We chose snacks, checked their total, and used the money left to make a complete plan for the class.",
    completionSummary: {
      decision: "Buy apple slices, cheese cubes, and cups.",
      whyItWorked: "The snack choice cost $8, leaving $4; that was enough for $2 cups.",
      mathUsed: "Addition and subtraction with money.",
      realWorld: "Checking a budget before buying helps a class avoid running out of money.",
      lesson: "Add costs first, then subtract from the budget."
    },
    evidence: {
      title: "Snack-cart prices",
      description: "Each snack pack serves the whole class.",
      columns: ["Item", "Price"],
      rows: [["Apple slices", "$3"], ["Crackers", "$4"], ["Cheese cubes", "$5"], ["Cups", "$2"]]
    },
    steps: [
      coreStep({
        id: "choose-snacks",
        coachMessage: "Which two snack packs cost exactly $8 together?",
        responseType: "recommendation",
        options: [
          { id: "apple-crackers", label: "Apple slices and crackers", description: "$3 + $4" },
          { id: "apple-cheese", label: "Apple slices and cheese cubes", description: "$3 + $5" },
          { id: "crackers-cheese", label: "Crackers and cheese cubes", description: "$4 + $5" }
        ],
        correctAnswer: "apple-cheese",
        nextStep: "find-snack-total",
        explanation: "Apple slices and cheese cubes cost $3 + $5 = $8.",
        incorrectGuidance: "Add the two prices shown in your choice. Which pair makes 8 dollars?",
        noIdeaGuidance: "Start with apple slices at $3. What price would make 8 when added to 3?",
        hint: "Try 3 + 5."
      }),
      coreStep({
        id: "find-snack-total",
        coachMessage: "What is the total cost of the apple slices and cheese cubes?",
        responseType: "numeric",
        answerLabel: "Snack total in dollars",
        correctAnswer: "8",
        nextStep: "money-left",
        explanation: "The snack total is $3 + $5 = $8.",
        incorrectGuidance: "Use the two prices for the snacks we chose: $3 and $5.",
        noIdeaGuidance: "Count on from 3: four, five, six, seven, eight.",
        hint: "3 + 5 = ?"
      }),
      coreStep({
        id: "money-left",
        coachMessage: "After spending $8 from the $12 budget, how many dollars are left?",
        responseType: "numeric",
        answerLabel: "Dollars left",
        correctAnswer: "4",
        nextStep: "add-cups",
        explanation: "$12 − $8 = $4, so four dollars remain.",
        incorrectGuidance: "Start with the full $12 budget and take away the $8 snack total.",
        noIdeaGuidance: "Count up from 8 to 12. How many numbers do you count?",
        hint: "12 − 8 = ?"
      }),
      coreStep({
        id: "add-cups",
        coachMessage: "Cups cost $2. Which choice still fits after buying the $8 snacks?",
        responseType: "multiple-choice",
        options: [
          { id: "buy-cups", label: "Buy the cups", description: "$8 + $2 = $10, which is within $12." },
          { id: "skip-cups", label: "Skip the cups", description: "There is not enough money left." }
        ],
        correctAnswer: "buy-cups",
        nextStep: "explain-budget",
        explanation: "The snacks and cups cost $10 altogether, so the plan stays within the $12 budget.",
        incorrectGuidance: "Compare the $2 cup price with the $4 that is still left.",
        noIdeaGuidance: "You have $4 left. Is 2 more or less than 4?",
        hint: "8 + 2 is less than 12."
      }),
      coreStep({
        id: "explain-budget",
        coachMessage: "Write a short reason why this snack-cart plan works for the class budget.",
        responseType: "written",
        answerLabel: "Your budget reason",
        acceptedPhrases: ["within the budget", "under the budget", "costs 10", "10 dollars", "money left"],
        correctAnswer: "within the budget",
        nextStep: null,
        explanation: "A strong budget reason names the total and shows that it is no more than the money available.",
        incorrectGuidance: "Mention that the snacks and cups cost $10 and the budget is $12.",
        noIdeaGuidance: "Start your sentence with: The plan works because...",
        hint: "Use the words budget, $10, or money left."
      })
    ]
  },
  {
    id: "entry-recipe-double",
    gradeLevel: "entry",
    title: "Smoothie for the team",
    description: "Adjust a smoothie recipe so it makes enough for twice as many students.",
    character: { name: "Kai", role: "Kitchen helper", visual: "◈" },
    mathConcepts: ["Multiplication", "Fractions", "Measurement", "Scaling"],
    estimatedSteps: 5,
    initialStepId: "find-scale-factor",
    openingMessage: "Our smoothie recipe serves 2 students, but four students are waiting. We need to double the recipe without changing its balance.",
    conclusion: "Doubling each ingredient made enough smoothie while keeping the recipe in the same balance.",
    completionSummary: {
      decision: "Double every ingredient in the two-student recipe.",
      whyItWorked: "Four students is twice as many as two students.",
      mathUsed: "Multiplication and fraction measurement.",
      realWorld: "Cooks scale recipes so everyone gets the same balanced serving.",
      lesson: "When servings double, each ingredient must double too."
    },
    evidence: {
      title: "Recipe for 2 students",
      description: "Double each amount to serve 4 students.",
      columns: ["Ingredient", "Amount"],
      rows: [["Yogurt", "1 cup"], ["Berries", "3/4 cup"], ["Ice", "2 scoops"]]
    },
    steps: [
      coreStep({
        id: "find-scale-factor",
        coachMessage: "The recipe serves 2 students and we need 4 servings. By what number should we multiply each ingredient?",
        responseType: "numeric",
        answerLabel: "Multiplier",
        correctAnswer: "2",
        nextStep: "double-ice",
        explanation: "Four is two groups of two, so every amount is multiplied by 2.",
        incorrectGuidance: "Compare the new number of servings, 4, with the old number, 2.",
        noIdeaGuidance: "How many groups of 2 are in 4?",
        hint: "4 ÷ 2 = ?"
      }),
      coreStep({
        id: "double-ice",
        coachMessage: "How many scoops of ice are needed for 4 students?",
        responseType: "numeric",
        answerLabel: "Scoops of ice",
        correctAnswer: "4",
        nextStep: "double-yogurt",
        explanation: "Two scoops doubled is 2 × 2 = 4 scoops.",
        incorrectGuidance: "Make two groups of the original 2 scoops.",
        noIdeaGuidance: "Add 2 scoops and 2 more scoops.",
        hint: "2 + 2 = ?"
      }),
      coreStep({
        id: "double-yogurt",
        coachMessage: "The original recipe has 1 cup of yogurt. How many cups are needed after doubling?",
        responseType: "numeric",
        answerLabel: "Cups of yogurt",
        correctAnswer: "2",
        nextStep: "double-berries",
        explanation: "One cup doubled is 2 cups.",
        incorrectGuidance: "The ingredient amount should use the same multiplier as the servings.",
        noIdeaGuidance: "Think of two 1-cup measures placed together.",
        hint: "1 × 2 = ?"
      }),
      coreStep({
        id: "double-berries",
        coachMessage: "Which amount is double 3/4 cup of berries?",
        responseType: "multiple-choice",
        options: [
          { id: "three-fourths", label: "3/4 cup", description: "The original amount" },
          { id: "one-and-half", label: "1 1/2 cups", description: "Two groups of 3/4 cup" },
          { id: "two-cups", label: "2 cups", description: "More than double" }
        ],
        correctAnswer: "one-and-half",
        nextStep: "explain-scaling",
        explanation: "Two groups of 3/4 cup make 6/4 cups, which is 1 1/2 cups.",
        incorrectGuidance: "Imagine two equal 3/4-cup portions. Together they make more than 1 cup but less than 2 cups.",
        noIdeaGuidance: "Draw two boxes split into fourths and shade three fourths in each.",
        hint: "3/4 + 3/4 = 6/4."
      }),
      coreStep({
        id: "explain-scaling",
        coachMessage: "In a short sentence, explain what we should do to every ingredient when the number of servings doubles.",
        responseType: "written",
        answerLabel: "Your explanation",
        acceptedPhrases: ["double every ingredient", "multiply every ingredient by 2", "multiply each ingredient by 2", "double each ingredient"],
        correctAnswer: "double every ingredient",
        nextStep: null,
        explanation: "Doubling every ingredient keeps the recipe balanced while making enough for everyone.",
        incorrectGuidance: "Think about what happens to all the amounts, not only the ice.",
        noIdeaGuidance: "Use this sentence frame: We should ___ every ingredient.",
        hint: "Use the word double."
      })
    ]
  },
  {
    id: "entry-allowance-goal",
    gradeLevel: "entry",
    title: "Save for the art set",
    description: "Help Priya make a weekly allowance plan for a new art set.",
    character: { name: "Priya", role: "Young artist", visual: "✦" },
    mathConcepts: ["Money", "Subtraction", "Multiplication", "Planning"],
    estimatedSteps: 5,
    initialStepId: "find-amount-needed",
    openingMessage: "I already saved some of my allowance for an art set. Can you help me see how many more weeks I need before I can buy it?",
    conclusion: "Priya can reach her goal by saving three more weekly allowances instead of spending the money early.",
    completionSummary: {
      decision: "Save $8 for three more weeks.",
      whyItWorked: "Priya needs $24 more, and 3 weeks of $8 makes $24.",
      mathUsed: "Subtraction and multiplication with money.",
      realWorld: "A savings plan turns a large purchase into smaller, manageable steps.",
      lesson: "Find what is missing, then divide or count equal weekly savings."
    },
    evidence: {
      title: "Priya’s savings plan",
      description: "Priya saves her full weekly allowance for this goal.",
      columns: ["Information", "Amount"],
      rows: [["Art set price", "$36"], ["Saved so far", "$12"], ["Weekly allowance", "$8"]]
    },
    steps: [
      coreStep({
        id: "find-amount-needed",
        coachMessage: "The art set costs $36 and Priya has saved $12. How many more dollars does she need?",
        responseType: "numeric",
        answerLabel: "Dollars still needed",
        correctAnswer: "24",
        nextStep: "choose-useful-evidence",
        explanation: "$36 − $12 = $24, so Priya still needs $24.",
        incorrectGuidance: "Subtract the amount already saved from the full art-set price.",
        noIdeaGuidance: "Count up from 12 to 36 in tens and ones.",
        hint: "36 − 12 = ?"
      }),
      coreStep({
        id: "choose-useful-evidence",
        coachMessage: "Which number tells us how much Priya can add to her savings each week?",
        responseType: "evidence-selection",
        selectionMode: "single",
        requiredSelections: 1,
        options: [
          { id: "art-price", label: "The $36 art-set price", description: "The total goal" },
          { id: "saved-so-far", label: "The $12 saved so far", description: "Money already collected" },
          { id: "weekly-allowance", label: "The $8 weekly allowance", description: "Money added each week" }
        ],
        correctAnswer: "weekly-allowance",
        nextStep: "count-weeks",
        explanation: "The $8 weekly allowance is the amount Priya can add each week.",
        incorrectGuidance: "Look for the number that repeats every week, not the goal or the amount already saved.",
        noIdeaGuidance: "The question asks about each week. Which row says weekly?",
        hint: "Find the row with the word weekly."
      }),
      coreStep({
        id: "count-weeks",
        coachMessage: "Priya needs $24 more and saves $8 each week. How many weeks will that take?",
        responseType: "numeric",
        answerLabel: "Weeks",
        correctAnswer: "3",
        nextStep: "check-three-weeks",
        explanation: "Three groups of $8 make $24: 8 + 8 + 8 = 24.",
        incorrectGuidance: "Count equal groups of 8 until you reach 24.",
        noIdeaGuidance: "Try: week 1 = $8, week 2 = $16, week 3 = ?",
        hint: "24 ÷ 8 = ?"
      }),
      coreStep({
        id: "check-three-weeks",
        coachMessage: "Which equation checks that three weeks of allowance will fill the $24 gap?",
        responseType: "multiple-choice",
        options: [
          { id: "eight-times-three", label: "$8 × 3 = $24", description: "Three equal weekly savings" },
          { id: "twelve-times-three", label: "$12 × 3 = $36", description: "Uses the saved amount instead" },
          { id: "twentyfour-plus-eight", label: "$24 + $8 = $32", description: "Only one week" }
        ],
        correctAnswer: "eight-times-three",
        nextStep: "recommend-plan",
        explanation: "$8 saved each week for 3 weeks makes the $24 Priya still needs.",
        incorrectGuidance: "Use the weekly allowance, $8, and the number of weeks, 3.",
        noIdeaGuidance: "The same $8 is added once each week. How can we write three $8s?",
        hint: "8 + 8 + 8 is the same as 8 × 3."
      }),
      coreStep({
        id: "recommend-plan",
        coachMessage: "Which plan should Priya choose if she wants the art set in three weeks?",
        responseType: "recommendation",
        options: [
          { id: "save-three-weeks", label: "Save the $8 allowance for three weeks", description: "Adds the needed $24" },
          { id: "spend-now", label: "Spend this week’s $8 now", description: "Makes the goal take longer" }
        ],
        correctAnswer: "save-three-weeks",
        nextStep: null,
        explanation: "Saving each $8 allowance for three weeks gives Priya the $24 needed to reach $36.",
        incorrectGuidance: "Choose the plan that keeps adding $8 toward the art-set goal.",
        noIdeaGuidance: "Which choice helps the savings grow every week?",
        hint: "The goal needs all three weekly allowances."
      })
    ]
  },
  {
    id: "entry-field-trip-time",
    gradeLevel: "entry",
    title: "Museum morning",
    description: "Help Mr. Chen plan when the class should leave for a museum field trip.",
    character: { name: "Mr. Chen", role: "Field-trip teacher", visual: "⌚" },
    mathConcepts: ["Time", "Elapsed time", "Planning", "Addition"],
    estimatedSteps: 5,
    initialStepId: "read-checkin-time",
    openingMessage: "Our class needs to arrive calmly for the museum check-in. Let’s use the schedule to plan a smart departure time.",
    conclusion: "Leaving at 8:40 gives the class the 15 walking minutes needed to arrive right at check-in.",
    completionSummary: {
      decision: "Leave school at 8:40 a.m.",
      whyItWorked: "The 15-minute walk ends at the 8:55 check-in time.",
      mathUsed: "Reading a schedule and finding elapsed time.",
      realWorld: "Trip plans work better when travel time is counted before the event begins.",
      lesson: "Work backward from an arrival time to choose a departure time."
    },
    evidence: {
      title: "Museum morning schedule",
      description: "The class walks together from school to the museum.",
      columns: ["Part of the morning", "Time"],
      rows: [["Museum check-in", "8:55 a.m."], ["Museum tour begins", "9:10 a.m."], ["Walk from school", "15 minutes"]]
    },
    steps: [
      coreStep({
        id: "read-checkin-time",
        coachMessage: "What time does the schedule say the class should check in at the museum?",
        responseType: "multiple-choice",
        options: [
          { id: "840", label: "8:40 a.m.", description: "A possible leaving time" },
          { id: "855", label: "8:55 a.m.", description: "Museum check-in" },
          { id: "910", label: "9:10 a.m.", description: "Tour begins" }
        ],
        correctAnswer: "855",
        nextStep: "choose-travel-fact",
        explanation: "The schedule lists museum check-in at 8:55 a.m.",
        incorrectGuidance: "Read the row labeled Museum check-in, not the tour row.",
        noIdeaGuidance: "Look at the first row in the schedule table.",
        hint: "Check-in happens before the tour begins."
      }),
      coreStep({
        id: "choose-travel-fact",
        coachMessage: "Which piece of evidence tells us how long the class needs to get from school to the museum?",
        responseType: "evidence-selection",
        selectionMode: "single",
        requiredSelections: 1,
        options: [
          { id: "checkin", label: "Museum check-in: 8:55 a.m.", description: "When to arrive" },
          { id: "tour", label: "Museum tour: 9:10 a.m.", description: "When the tour begins" },
          { id: "walk", label: "Walk from school: 15 minutes", description: "How long travel takes" }
        ],
        correctAnswer: "walk",
        nextStep: "find-leave-time",
        explanation: "The 15-minute walking time tells us how long the trip from school takes.",
        incorrectGuidance: "The question asks how long, so choose the row written in minutes.",
        noIdeaGuidance: "Look for a number followed by the word minutes.",
        hint: "Travel time is measured in minutes."
      }),
      coreStep({
        id: "find-leave-time",
        coachMessage: "The class needs 15 minutes to walk and must check in at 8:55. When should it leave school?",
        responseType: "recommendation",
        options: [
          { id: "825", label: "8:25 a.m.", description: "Arrives too early" },
          { id: "840", label: "8:40 a.m.", description: "Arrives at 8:55" },
          { id: "855", label: "8:55 a.m.", description: "Arrives after check-in" }
        ],
        correctAnswer: "840",
        nextStep: "check-elapsed-time",
        explanation: "Starting at 8:40 and walking 15 minutes reaches 8:55.",
        incorrectGuidance: "Work backward 15 minutes from 8:55.",
        noIdeaGuidance: "Count back: 8:55, 8:50, 8:45, 8:40.",
        hint: "55 minutes minus 15 minutes is 40 minutes."
      }),
      coreStep({
        id: "check-elapsed-time",
        coachMessage: "How many minutes are there from the 8:55 check-in until the 9:10 tour begins?",
        responseType: "numeric",
        answerLabel: "Minutes",
        correctAnswer: "15",
        nextStep: "explain-timing",
        explanation: "From 8:55 to 9:10 is 15 minutes.",
        incorrectGuidance: "Count forward from 8:55 to 9:00, then to 9:10.",
        noIdeaGuidance: "There are 5 minutes to 9:00 and 10 more to 9:10.",
        hint: "5 + 10 = ?"
      }),
      coreStep({
        id: "explain-timing",
        coachMessage: "Write a short reason why leaving at 8:40 is a good plan.",
        responseType: "written",
        answerLabel: "Your timing reason",
        acceptedPhrases: ["15 minute walk", "arrive at 8:55", "check in on time", "gets there at 8:55"],
        correctAnswer: "arrive at 8:55",
        nextStep: null,
        explanation: "The reason connects the 15-minute walk to arriving at the 8:55 check-in time.",
        incorrectGuidance: "Mention the leave time, the 15-minute walk, or the 8:55 check-in.",
        noIdeaGuidance: "Try: Leaving at 8:40 works because...",
        hint: "Use 15 minutes and 8:55 in your sentence."
      })
    ]
  },
  {
    id: "entry-garden-plan",
    gradeLevel: "entry",
    title: "Garden bed helpers",
    description: "Plan seed packets for a rectangular school garden bed.",
    character: { name: "Sam", role: "Garden club helper", visual: "✿" },
    mathConcepts: ["Area", "Perimeter", "Multiplication", "Measurement"],
    estimatedSteps: 5,
    initialStepId: "choose-area-facts",
    openingMessage: "Garden club is planting a rectangular bed. We need to know its area for seeds and its perimeter for a small border.",
    conclusion: "The garden needs four seed packets for its 12 square meters, and its border is 14 meters around.",
    completionSummary: {
      decision: "Bring four seed packets and enough border material for 14 meters.",
      whyItWorked: "The bed is 12 square meters, and each packet covers 3 square meters.",
      mathUsed: "Area, division, and perimeter.",
      realWorld: "Gardeners measure space before buying supplies.",
      lesson: "Area covers the inside; perimeter goes around the outside."
    },
    evidence: {
      title: "Garden-bed measurements",
      description: "The bed is a rectangle. One seed packet covers 3 square meters.",
      columns: ["Measurement", "Amount"],
      rows: [["Length", "4 meters"], ["Width", "3 meters"], ["Seed-packet coverage", "3 square meters"]]
    },
    steps: [
      coreStep({
        id: "choose-area-facts",
        coachMessage: "Which two measurements do we need to find the area inside the rectangular garden bed?",
        responseType: "evidence-selection",
        selectionMode: "multiple",
        requiredSelections: 2,
        options: [
          { id: "length", label: "Length: 4 meters", description: "One side measurement" },
          { id: "width", label: "Width: 3 meters", description: "The other side measurement" },
          { id: "coverage", label: "Seed-packet coverage: 3 square meters", description: "Used after finding area" }
        ],
        correctAnswer: ["length", "width"],
        nextStep: "find-area",
        explanation: "Area of a rectangle uses its length and width.",
        incorrectGuidance: "Look for the two measurements that describe the sides of the rectangle.",
        noIdeaGuidance: "Area is the space inside. Which rows tell how long and how wide the bed is?",
        hint: "Choose length and width."
      }),
      coreStep({
        id: "find-area",
        coachMessage: "What is the area of a garden bed that is 4 meters long and 3 meters wide?",
        responseType: "numeric",
        answerLabel: "Square meters",
        correctAnswer: "12",
        nextStep: "find-packets",
        explanation: "Area = length × width = 4 × 3 = 12 square meters.",
        incorrectGuidance: "Multiply the length by the width to count the square meters inside.",
        noIdeaGuidance: "Picture 3 rows of 4 squares. Count all the squares.",
        hint: "4 × 3 = ?"
      }),
      coreStep({
        id: "find-packets",
        coachMessage: "Each seed packet covers 3 square meters. How many packets cover 12 square meters?",
        responseType: "numeric",
        answerLabel: "Seed packets",
        correctAnswer: "4",
        nextStep: "find-perimeter",
        explanation: "Twelve divided into groups of 3 makes 4 packets.",
        incorrectGuidance: "Ask how many groups of 3 fit in 12.",
        noIdeaGuidance: "Count by 3s: 3, 6, 9, 12. How many groups did you count?",
        hint: "12 ÷ 3 = ?"
      }),
      coreStep({
        id: "find-perimeter",
        coachMessage: "What is the perimeter around the outside of a 4-meter-by-3-meter rectangle?",
        responseType: "numeric",
        answerLabel: "Meters around the bed",
        correctAnswer: "14",
        nextStep: "recommend-supplies",
        explanation: "Add all four sides: 4 + 3 + 4 + 3 = 14 meters.",
        incorrectGuidance: "Perimeter goes around every side, not only across the inside.",
        noIdeaGuidance: "A rectangle has two 4-meter sides and two 3-meter sides.",
        hint: "4 + 3 + 4 + 3 = ?"
      }),
      coreStep({
        id: "recommend-supplies",
        coachMessage: "Which supply plan matches the measurements we found?",
        responseType: "recommendation",
        options: [
          { id: "four-packets-border14", label: "4 seed packets and 14 meters of border", description: "Matches the area and perimeter" },
          { id: "three-packets-border12", label: "3 seed packets and 12 meters of border", description: "Does not cover the whole bed" }
        ],
        correctAnswer: "four-packets-border14",
        nextStep: null,
        explanation: "Four packets cover 12 square meters, and 14 meters goes all the way around the rectangle.",
        incorrectGuidance: "Match the packet count to the area and the border length to the perimeter.",
        noIdeaGuidance: "Look back at your two answers: 4 packets and 14 meters.",
        hint: "Choose the plan with both 4 and 14."
      })
    ]
  }
];
