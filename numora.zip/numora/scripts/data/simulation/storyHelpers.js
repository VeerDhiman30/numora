function createSupportBranch(story, step) {
  const branchId = `${story.id}-evidence-support`;
  const gradeLanguage = story.gradeLevel === "entry"
    ? "Let’s slow down and use one number from the evidence at a time."
    : story.gradeLevel === "middle"
      ? "Let’s pause and identify which evidence and relationship should guide the decision."
      : "Let’s pause and identify the evidence and mathematical relationship that should drive the comparison.";

  return {
    id: branchId,
    core: false,
    coachMessage: gradeLanguage,
    responseType: "multiple-choice",
    options: [
      {
        id: "use-evidence",
        label: "Look back at the evidence first",
        description: "Use the numbers or facts in the story before deciding."
      },
      {
        id: "guess-first",
        label: "Make a quick guess",
        description: "Choose without checking the evidence."
      }
    ],
    correctAnswer: "use-evidence",
    nextStep: step.id,
    incorrectStep: branchId,
    unsureStep: branchId,
    explanation: "Good choice. Return to the question and use the evidence to work through it.",
    incorrectGuidance: "The evidence gives you a stronger starting point than a guess.",
    noIdeaGuidance: "Choose the option that starts by looking at the story evidence.",
    hint: "The table or facts in the story are there to help you decide.",
    progressiveHints: [
      "Find the numbers or facts that match the question.",
      "Use those facts before choosing an operation or recommendation.",
      "Return to the question and explain your choice with the evidence."
    ],
    strongHint: "Start with the evidence, then use it to answer the original question."
  };
}

/**
 * Adds one optional remediation branch to each story without changing its five
 * core narrative steps. A student who is unsure or incorrect gets a short
 * evidence-first checkpoint before returning to the original question.
 */
export function withGuidedSupportBranch(story) {
  const firstCoreStep = story.steps.find((step) => step.core !== false);
  if (!firstCoreStep) {
    return story;
  }

  const branchId = `${story.id}-evidence-support`;
  if (story.steps.some((step) => step.id === branchId)) {
    return story;
  }

  const supportBranch = createSupportBranch(story, firstCoreStep);
  return {
    ...story,
    steps: story.steps.flatMap((step) => (
      step.id === firstCoreStep.id
        ? [{ ...step, incorrectStep: branchId, unsureStep: branchId }, supportBranch]
        : [step]
    ))
  };
}
