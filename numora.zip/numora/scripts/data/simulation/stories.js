import { entrySimulationStories } from "./entry.js";
import { middleSimulationStories } from "./middle.js";
import { highSimulationStories } from "./high.js";
import { withGuidedSupportBranch } from "./storyHelpers.js";

export const simulationGradeLevels = [
  { id: "entry", title: "Entry Level", description: "Grades 3–5" },
  { id: "middle", title: "Middle School", description: "Grades 6–8" },
  { id: "high", title: "High School", description: "Grades 9–12" }
];

export const simulationStories = [
  ...entrySimulationStories,
  ...middleSimulationStories,
  ...highSimulationStories
].map(withGuidedSupportBranch);

export function getSimulationStories(gradeLevel) {
  return simulationStories.filter((story) => story.gradeLevel === gradeLevel);
}

export function getSimulationStory(storyId) {
  return simulationStories.find((story) => story.id === storyId) ?? null;
}
