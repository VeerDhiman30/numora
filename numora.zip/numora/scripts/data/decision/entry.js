import { choice, confidence, createQuestion, evidence } from "./questionHelpers.js";

const q = createQuestion;
const c = choice;
const e = evidence;

export const entryDecisionQuestions = [
  q({
    id: "entry-sports-relay", gradeLevel: "entry", module: "sports", title: "Relay runner choice",
    scenario: "Two runners each practiced the same two-lap relay.", question: "Who should run if the team wants the faster time?", contextualBadge: "Compare times",
    evidence: [e.table("Practice times", ["Runner", "Two-lap time"], [["Lena", "80 seconds"], ["Omar", "76 seconds"]]), e.fact("Same distance", "2 laps", "Both runners traveled the same distance.")],
    options: [c("lena", "Choose Lena", "Her time is 80 seconds."), c("omar", "Choose Omar", "His time is 76 seconds.")], correctOption: "omar",
    explanation: "For the same distance, the smaller time is faster. Omar’s 76 seconds is 4 seconds less than Lena’s 80 seconds.", incorrectGuidance: "The runners traveled the same distance. Which number of seconds is smaller?", mathConcepts: ["Subtraction", "Comparison"], hint: "Subtract 76 from 80 to find the difference."
  }),
  q({
    id: "entry-sports-average", gradeLevel: "entry", module: "sports", title: "Target score practice",
    scenario: "Nia is checking whether she averaged 8 points in three basketball drills.", question: "Did Nia meet the 8-point average goal?", contextualBadge: "Find a simple average",
    evidence: [e.table("Drill scores", ["Drill 1", "Drill 2", "Drill 3"], [["6", "8", "10"]]), e.fact("Goal", "8 points", "The target is an average of 8 points.")],
    options: [c("yes", "Yes, she met the goal", "Her three scores average 8."), c("no", "No, she missed the goal", "One score was below 8.")], correctOption: "yes",
    explanation: "6 + 8 + 10 = 24. Dividing 24 by 3 drills gives an average of 8, so Nia met the goal.", incorrectGuidance: "Do not use only one score. Add all three scores, then divide by 3.", mathConcepts: ["Addition", "Division", "Average"], hint: "Add the three scores before dividing by 3."
  }),
  q({
    id: "entry-sports-raffle", gradeLevel: "entry", module: "sports", title: "Team-color raffle",
    scenario: "The coach will draw one ball to choose a team color for warmups.", question: "Which bag gives Maya the better chance of drawing blue?", contextualBadge: "Compare chances",
    evidence: [e.table("Ball bags", ["Bag", "Blue balls", "Other balls"], [["A", "3", "1"], ["B", "2", "2"]]), e.fact("One draw", "1 ball", "Maya gets one ball from the bag she chooses.")],
    options: [c("a", "Choose Bag A", "It has 3 blue balls out of 4."), c("b", "Choose Bag B", "It has 2 blue balls out of 4."), c("same", "Choose either bag", "The bags have the same chance.")], correctOption: "a",
    explanation: "Bag A has 3 blue balls out of 4. Bag B has only 2 blue balls out of 4, so Bag A gives the better chance.", incorrectGuidance: "Both bags have 4 balls. Compare how many of those 4 are blue.", mathConcepts: ["Fractions", "Probability"], hint: "Count blue balls and total balls in each bag.", confidenceData: confidence("Blue-ball chance", "More blue balls out of the same total means a better chance.", [{ label: "Bag A", value: 75 }, { label: "Bag B", value: 50 }])
  }),
  q({
    id: "entry-weather-rain-kit", gradeLevel: "entry", module: "weather", title: "Outdoor science fair",
    scenario: "Your class will display projects outside for 45 minutes after lunch.", question: "Should the class bring the lightweight rain cover?", contextualBadge: "Plan for uncertainty",
    evidence: [e.percentage("Rain chance", "30%", "The afternoon forecast shows a 30% chance of rain."), e.fact("Rain cover", "Fits one tote", "It is easy to carry and free to bring."), e.statistic("Past rainy fairs", "3 of 10", "Rain interrupted three similar fairs.")],
    options: [c("bring", "Bring the rain cover", "Be ready in case the forecast happens."), c("leave", "Leave the rain cover", "Plan only for sunny weather.")], correctOption: "bring",
    explanation: "Bringing the cover is a low-effort way to prepare for a real chance of rain. A 30% chance is not certain, but it is enough to plan for.", incorrectGuidance: "Compare the chance of rain with how easy the cover is to bring. Which choice reduces risk?", mathConcepts: ["Probability", "Risk"], hint: "Compare the rain chance with the effort of one tote.", confidenceData: confidence("Chance comparison", "A 30% rain chance means about 3 out of 10 similar afternoons could have rain.", [{ label: "Rain", value: 30 }, { label: "No rain", value: 70 }])
  }),
  q({
    id: "entry-weather-bike", gradeLevel: "entry", module: "weather", title: "Bike ride timing",
    scenario: "Sam can ride to the park in the morning or after lunch.", question: "Which time is safer if Sam wants to avoid rain?", contextualBadge: "Use a forecast",
    evidence: [e.table("Rain forecast", ["Time", "Chance of rain"], [["Morning", "10%"], ["After lunch", "60%"]]), e.fact("Ride length", "35 minutes", "The ride is the same length at either time.")],
    options: [c("morning", "Ride in the morning", "The rain chance is 10%."), c("afternoon", "Ride after lunch", "The rain chance is 60%.")], correctOption: "morning",
    explanation: "A 10% chance is much lower than a 60% chance, so morning is the safer time for a dry ride.", incorrectGuidance: "The ride is the same length at both times. Compare only the two rain chances.", mathConcepts: ["Percentages", "Comparison"], hint: "Choose the smaller rain percentage.", confidenceData: confidence("Rain risk", "The morning forecast has far less rain risk.", [{ label: "Morning", value: 10 }, { label: "After lunch", value: 60 }])
  }),
  q({
    id: "entry-weather-water", gradeLevel: "entry", module: "weather", title: "Field-day water",
    scenario: "The class needs water jugs for 24 students on a warm field day.", question: "Which water plan gives every student one cup?", contextualBadge: "Multiply to compare",
    evidence: [e.table("Water plans", ["Plan", "Jugs", "Cups per jug"], [["A", "3", "6"], ["B", "4", "6"]]), e.fact("Students", "24", "Each student needs one cup.")],
    options: [c("a", "Choose Plan A", "3 jugs of 6 cups."), c("b", "Choose Plan B", "4 jugs of 6 cups.")], correctOption: "b",
    explanation: "Plan A has 3 × 6 = 18 cups, which is not enough. Plan B has 4 × 6 = 24 cups, exactly one cup for each student.", incorrectGuidance: "Multiply jugs by cups in each jug, then compare the total with 24 students.", mathConcepts: ["Multiplication", "Measurement"], hint: "Find the total cups in each plan."
  }),
  q({
    id: "entry-business-snack-pack", gradeLevel: "entry", module: "business", title: "Club snack table",
    scenario: "The art club needs 3 granola bars for its helpers.", question: "Which way should the club buy the 3 bars?", contextualBadge: "Compare total cost",
    evidence: [e.table("Store choices", ["Choice", "What you get", "Cost"], [["Bundle", "3 bars", "$6.00"], ["Single bars", "1 bar each", "$2.50 each"]]), e.fact("Bars needed", "3", "The club needs exactly three bars.")],
    options: [c("bundle", "Buy one 3-bar bundle", "Get all 3 bars for $6.00."), c("singles", "Buy 3 single bars", "Pay $2.50 for each bar.")], correctOption: "bundle",
    explanation: "One bundle costs $6.00. Three single bars cost $7.50 because 3 × $2.50 = $7.50. The bundle saves $1.50.", incorrectGuidance: "Find the total for three single bars before comparing it with the bundle price.", mathConcepts: ["Cost Comparison", "Multiplication"], hint: "Multiply the single-bar price by the number of bars.", confidenceData: confidence("Total cost", "Three single bars cost $7.50, which is $1.50 more than the bundle.", [{ label: "Bundle", value: 80, display: "$6.00" }, { label: "3 single bars", value: 100, display: "$7.50" }])
  }),
  q({
    id: "entry-business-pencil", gradeLevel: "entry", module: "business", title: "Book-fair pencils",
    scenario: "The library needs 4 pencils as prizes for a reading game.", question: "Which purchase costs less for exactly 4 pencils?", contextualBadge: "Compare money",
    evidence: [e.table("Pencil prices", ["Choice", "Amount", "Cost"], [["Pencil pack", "4 pencils", "$4.80"], ["Single pencil", "1 pencil", "$1.40 each"]])],
    options: [c("pack", "Buy the 4-pencil pack", "It costs $4.80."), c("single", "Buy 4 single pencils", "They cost $1.40 each.")], correctOption: "pack",
    explanation: "Four single pencils cost 4 × $1.40 = $5.60. The $4.80 pack costs $0.80 less.", incorrectGuidance: "Calculate the cost of four single pencils before deciding.", mathConcepts: ["Multiplication", "Money", "Subtraction"], hint: "Multiply $1.40 by 4."
  }),
  q({
    id: "entry-business-lemonade", gradeLevel: "entry", module: "business", title: "Lemonade stand cups",
    scenario: "A stand sold 18 cups on Friday and 25 cups on Saturday.", question: "Which number should the club use when planning for its busier day?", contextualBadge: "Read the data",
    evidence: [e.table("Cups sold", ["Day", "Cups"], [["Friday", "18"], ["Saturday", "25"]]), e.fact("Goal", "Plan for one busy day", "The club wants enough cups for the larger daily total.")],
    options: [c("18", "Plan for 18 cups", "Use Friday’s total."), c("25", "Plan for 25 cups", "Use Saturday’s total."), c("43", "Plan for 43 cups", "Add both days together.")], correctOption: "25",
    explanation: "Saturday was the busier day because 25 is greater than 18. Planning for 25 cups matches the goal of covering one busy day.", incorrectGuidance: "The question asks about one busier day, not both days together. Find the larger daily total.", mathConcepts: ["Data Interpretation", "Comparison"], hint: "Look for the larger number of cups sold."
  }),
  q({
    id: "entry-technology-battery", gradeLevel: "entry", module: "technology", title: "Tablet battery choice",
    scenario: "A museum trip lasts 7 hours and a tablet cannot be charged during the trip.", question: "Which tablet has enough battery for the trip?", contextualBadge: "Match a need",
    evidence: [e.table("Battery life", ["Tablet", "Battery life"], [["A", "8 hours"], ["B", "6 hours"]]), e.fact("Trip", "7 hours", "The tablet must last at least 7 hours.")],
    options: [c("a", "Choose Tablet A", "It lasts 8 hours."), c("b", "Choose Tablet B", "It lasts 6 hours.")], correctOption: "a",
    explanation: "Tablet A lasts 8 hours, which is at least 7 hours. Tablet B would run out after 6 hours.", incorrectGuidance: "Compare each battery time to the 7-hour trip length.", mathConcepts: ["Measurement", "Comparison"], hint: "The battery must be at least as large as 7 hours."
  }),
  q({
    id: "entry-technology-storage", gradeLevel: "entry", module: "technology", title: "Photo-card space",
    scenario: "A camera uses 1 GB for every 10 class photos. The class wants room for 120 photos.", question: "Which memory card has enough space?", contextualBadge: "Use division",
    evidence: [e.table("Memory cards", ["Card", "Space"], [["A", "8 GB"], ["B", "16 GB"]]), e.fact("Photo use", "10 photos per GB", "120 photos need 12 GB of space.")],
    options: [c("a", "Choose Card A", "It has 8 GB."), c("b", "Choose Card B", "It has 16 GB.")], correctOption: "b",
    explanation: "120 photos ÷ 10 photos per GB = 12 GB needed. Card B has 16 GB, while Card A has only 8 GB.", incorrectGuidance: "First find how many GB 120 photos use, then compare that need with each card.", mathConcepts: ["Division", "Measurement"], hint: "Share 120 photos into groups of 10."
  }),
  q({
    id: "entry-technology-headphones", gradeLevel: "entry", module: "technology", title: "Headphone power",
    scenario: "A class uses headphones for 3 hours each day of a five-day project.", question: "Which pair can last through the project without charging?", contextualBadge: "Multiply the days",
    evidence: [e.table("Headphone batteries", ["Pair", "Battery life"], [["A", "12 hours"], ["B", "15 hours"]]), e.fact("Project use", "3 hours × 5 days", "The project needs 15 listening hours.")],
    options: [c("a", "Choose Pair A", "It lasts 12 hours."), c("b", "Choose Pair B", "It lasts 15 hours.")], correctOption: "b",
    explanation: "3 hours for 5 days is 15 hours. Pair B lasts 15 hours, while Pair A is 3 hours short.", incorrectGuidance: "Find the total project hours before comparing the battery lives.", mathConcepts: ["Multiplication", "Measurement"], hint: "Multiply 3 hours by 5 days."
  }),
  q({
    id: "entry-investment-savings-jars", gradeLevel: "entry", module: "investment", title: "Savings-jar plan",
    scenario: "Kai is choosing a way to save for a game.", question: "Which plan has more money after the listed weeks?", contextualBadge: "Multiply savings",
    evidence: [e.table("Saving plans", ["Plan", "Weekly saving", "Weeks"], [["A", "$5", "8"], ["B", "$4", "10"]])],
    options: [c("a", "Choose Plan A", "Save $5 for 8 weeks."), c("b", "Choose Plan B", "Save $4 for 10 weeks."), c("same", "They are the same", "Both plans reach the same amount.")], correctOption: "same",
    explanation: "Plan A saves 8 × $5 = $40. Plan B saves 10 × $4 = $40, so the two plans are equal.", incorrectGuidance: "Multiply the weekly amount by the number of weeks for both plans.", mathConcepts: ["Multiplication", "Money", "Comparison"], hint: "Find each plan’s total savings."
  }),
  q({
    id: "entry-investment-bonus", gradeLevel: "entry", module: "investment", title: "Bank bonus choice",
    scenario: "Two kids each save $20 for one month. One account gives a 5% bonus and the other gives a 2% bonus.", question: "Which account gives the larger bonus?", contextualBadge: "Compare percentages",
    evidence: [e.comparison("Monthly bonus rates", [{ label: "Account A", value: "5%" }, { label: "Account B", value: "2%" }]), e.fact("Same savings", "$20", "Both accounts start with the same amount.")],
    options: [c("a", "Choose Account A", "It gives a 5% bonus."), c("b", "Choose Account B", "It gives a 2% bonus.")], correctOption: "a",
    explanation: "Because both accounts start with $20, the larger percentage gives the larger bonus. 5% is greater than 2%.", incorrectGuidance: "The starting amounts match, so compare the two percentage rates directly.", mathConcepts: ["Percentages", "Comparison"], hint: "Which percentage is larger?", confidenceData: confidence("Bonus-rate comparison", "The same amount grows more with the larger rate.", [{ label: "Account A", value: 5 }, { label: "Account B", value: 2 }])
  }),
  q({
    id: "entry-investment-garden", gradeLevel: "entry", module: "investment", title: "Garden-fund start",
    scenario: "Two garden teams are saving for seeds over four months.", question: "Which team will have more money after four months?", contextualBadge: "Add repeated savings",
    evidence: [e.table("Garden funds", ["Team", "Starts with", "Adds each month"], [["A", "$30", "$5"], ["B", "$35", "$3"]]), e.fact("Time", "4 months", "Each team adds money for four months.")],
    options: [c("a", "Choose Team A", "It starts with $30 and adds $5 each month."), c("b", "Choose Team B", "It starts with $35 and adds $3 each month.")], correctOption: "a",
    explanation: "Team A has $30 + (4 × $5) = $50. Team B has $35 + (4 × $3) = $47, so Team A has more.", incorrectGuidance: "Include both the starting money and the money added each month.", mathConcepts: ["Multiplication", "Addition", "Money"], hint: "Multiply each monthly amount by 4, then add the starting amount."
  })
];
