import { entryDecisionQuestions } from "./entry.js";
import { middleDecisionQuestions } from "./middle.js";
import { highDecisionQuestions } from "./high.js";

export const decisionModules = [
  { id: "sports", title: "Sports", description: "Use scores, averages, probability, performance, and strategy.", glyph: "↗" },
  { id: "weather", title: "Weather", description: "Use temperature, percentages, forecasts, and risk.", glyph: "☁" },
  { id: "business", title: "Business", description: "Use pricing, costs, revenue, discounts, and comparisons.", glyph: "¤" },
  { id: "technology", title: "Technology", description: "Use storage, speed, battery, usage, and product comparisons.", glyph: "⌁" },
  { id: "investment", title: "Investment", description: "Use simple return, growth, percentages, and risk.", glyph: "◒" }
];

export const gradeLevels = [
  { id: "entry", title: "Entry Level", description: "Grades 3–5" },
  { id: "middle", title: "Middle School", description: "Grades 6–8" },
  { id: "high", title: "High School", description: "Grades 9–12" }
];

export const decisionSessionLength = 10;
export const decisionContentVersions = Object.freeze({ entry: 1, middle: 1, high: 2 });
export const decisionQuestions = [...entryDecisionQuestions, ...middleDecisionQuestions, ...highDecisionQuestions];

export function getQuestionsForDecisionLab(gradeLevel, module) {
  return decisionQuestions.filter((item) => item.gradeLevel === gradeLevel && item.module === module);
}

export function getAvailableModules(gradeLevel) {
  return new Set(decisionQuestions.filter((item) => item.gradeLevel === gradeLevel).map((item) => item.module));
}
