export const evidence = {
  fact: (label, value, description) => ({ type: "fact", label, value, description }),
  statistic: (label, value, description) => ({ type: "statistic", label, value, description }),
  percentage: (label, value, description) => ({ type: "percentage", label, value, description }),
  price: (label, value, description) => ({ type: "price", label, value, description }),
  table: (title, columns, rows) => ({ type: "table", title, columns, rows }),
  comparison: (label, items) => ({ type: "comparison", label, items })
};

export function confidence(title, prompt, bars) {
  return { title, prompt, bars };
}

export function choice(id, label, description) {
  return { id, label, description };
}

export function createQuestion(details) {
  return details;
}
