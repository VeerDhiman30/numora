import { choice, confidence, createQuestion, evidence } from "./questionHelpers.js";

const q = createQuestion;
const c = choice;
const e = evidence;

export const middleDecisionQuestions = [
  q({
    id: "middle-sports-pass-plan", gradeLevel: "middle", module: "sports", title: "Final-minute soccer plan",
    scenario: "Your team has one last attack and wants the player most likely to complete a pass into the box.", question: "Which player’s recent passing data supports the better choice?", contextualBadge: "Use a rate, not only a total",
    evidence: [e.table("Recent passing practice", ["Player", "Completed", "Attempts"], [["Maya", "18", "24"], ["Jordan", "14", "16"]]), e.comparison("Completion rates", [{ label: "Maya", value: "75%" }, { label: "Jordan", value: "87.5%" }])],
    options: [c("maya", "Choose Maya", "Maya completed more passes in total."), c("jordan", "Choose Jordan", "Jordan completed a larger share of attempts.")], correctOption: "jordan",
    explanation: "Jordan completed 14 ÷ 16 = 87.5% of passes. Maya completed 18 ÷ 24 = 75%. For one pass now, the higher completion rate is stronger evidence.", incorrectGuidance: "The players had different numbers of attempts. Compare completed passes as a fraction of attempts.", mathConcepts: ["Percentage", "Ratio", "Data Interpretation"], hint: "Divide each player’s completed passes by attempts.", confidenceData: confidence("Pass completion rate", "The longer bar shows the larger completed share of attempts.", [{ label: "Maya", value: 75 }, { label: "Jordan", value: 87.5 }])
  }),
  q({
    id: "middle-sports-swim", gradeLevel: "middle", module: "sports", title: "Swim-turn practice",
    scenario: "Two swimmers are practicing turns. The coach wants the swimmer with the more reliable turn rate.", question: "Which swimmer has the stronger turn success rate?", contextualBadge: "Compare ratios",
    evidence: [e.table("Successful turns", ["Swimmer", "Successful", "Attempts"], [["Ari", "18", "24"], ["Bea", "16", "20"]])],
    options: [c("ari", "Choose Ari", "Ari made 18 successful turns."), c("bea", "Choose Bea", "Bea made 16 successful turns.")], correctOption: "bea",
    explanation: "Ari’s rate is 18 ÷ 24 = 75%. Bea’s rate is 16 ÷ 20 = 80%, so Bea is more reliable despite fewer total successes.", incorrectGuidance: "Total successes do not tell the whole story. Divide successes by attempts for both swimmers.", mathConcepts: ["Ratios", "Percentages"], hint: "Turn each success fraction into a percentage."
  }),
  q({
    id: "middle-sports-batting", gradeLevel: "middle", module: "sports", title: "Batting-order choice",
    scenario: "A baseball coach wants the player with the better recent hit rate.", question: "Who should bat earlier based on the hit data?", contextualBadge: "Find the better percentage",
    evidence: [e.table("Recent hits", ["Player", "Hits", "At-bats"], [["Drew", "9", "30"], ["Emi", "7", "20"]])],
    options: [c("drew", "Choose Drew", "Drew has 9 hits."), c("emi", "Choose Emi", "Emi has 7 hits."), c("either", "Choose either player", "Their rates match.")], correctOption: "emi",
    explanation: "Drew hit 9 ÷ 30 = 30%. Emi hit 7 ÷ 20 = 35%, so Emi has the stronger recent hit rate.", incorrectGuidance: "Compare hits per at-bat, not just the number of hits.", mathConcepts: ["Percentages", "Unit Rates"], hint: "Divide hits by at-bats for each player."
  }),
  q({
    id: "middle-sports-route", gradeLevel: "middle", module: "sports", title: "Cycling-route pace",
    scenario: "A cycling team is choosing a route for a 45-minute practice block.", question: "Which route fits inside the practice time?", contextualBadge: "Use distance and rate",
    evidence: [e.table("Route plans", ["Route", "Distance", "Pace"], [["A", "18 km", "24 km/h"], ["B", "20 km", "24 km/h"]]), e.fact("Practice block", "45 minutes", "45 minutes is 0.75 of an hour.")],
    options: [c("a", "Choose Route A", "18 km at 24 km/h."), c("b", "Choose Route B", "20 km at 24 km/h.")], correctOption: "a",
    explanation: "Route A takes 18 ÷ 24 = 0.75 hour, or 45 minutes. Route B takes about 50 minutes, so Route A fits.", incorrectGuidance: "At the same pace, divide each distance by 24 km/h to find travel time.", mathConcepts: ["Rates", "Time"], hint: "Use time = distance ÷ rate."
  }),
  q({
    id: "middle-weather-picnic", gradeLevel: "middle", module: "weather", title: "Picnic backup",
    scenario: "The class picnic has a 70% chance of rain. A covered pavilion costs $12, while spoiled food would cost about $65.", question: "Which choice is better supported by the evidence?", contextualBadge: "Compare risk and cost",
    evidence: [e.percentage("Rain chance", "70%", "Rain is more likely than not."), e.price("Pavilion", "$12", "The reservation protects the food."), e.price("Possible food loss", "$65", "This is the cost if rain spoils the food.")],
    options: [c("reserve", "Reserve the pavilion", "Pay $12 to reduce a larger rain risk."), c("skip", "Skip the pavilion", "Avoid the $12 cost.")], correctOption: "reserve",
    explanation: "A 70% rain chance is high, and $12 is much smaller than a possible $65 food loss. Reserving the pavilion is better supported.", incorrectGuidance: "Consider both the high rain probability and the difference between $12 and $65.", mathConcepts: ["Probability", "Risk", "Cost Comparison"], hint: "Which cost is smaller: protection now or possible loss later?", confidenceData: confidence("Rain-risk comparison", "Rain is the more likely forecast outcome.", [{ label: "Rain", value: 70 }, { label: "No rain", value: 30 }])
  }),
  q({
    id: "middle-weather-heat", gradeLevel: "middle", module: "weather", title: "Trail cleanup timing",
    scenario: "A club can do a trail cleanup at 9 a.m. or 2 p.m. The group wants the lower heat index.", question: "Which time should the group choose?", contextualBadge: "Compare conditions",
    evidence: [e.table("Forecast", ["Time", "Heat index", "Rain chance"], [["9 a.m.", "82°F", "10%"], ["2 p.m.", "96°F", "10%"]]), e.fact("Same task", "2 hours", "The cleanup takes the same time at either start.")],
    options: [c("morning", "Choose 9 a.m.", "The heat index is 82°F."), c("afternoon", "Choose 2 p.m.", "The heat index is 96°F.")], correctOption: "morning",
    explanation: "The rain chances are equal, so heat index decides the choice. 82°F is 14°F lower than 96°F, making 9 a.m. safer.", incorrectGuidance: "The rain chance does not separate these choices. Compare the heat-index values.", mathConcepts: ["Subtraction", "Data Interpretation"], hint: "Find which time has the smaller heat index."
  }),
  q({
    id: "middle-weather-watering", gradeLevel: "middle", module: "weather", title: "Garden watering plan",
    scenario: "A school garden needs 1 inch of water this week. The forecast predicts 0.4 inch of rain.", question: "How much water should the team add if the forecast arrives?", contextualBadge: "Find the difference",
    evidence: [e.fact("Garden need", "1.0 inch", "The plants need about one inch this week."), e.statistic("Forecast rain", "0.4 inch", "This amount is expected from rain.")],
    options: [c("06", "Add 0.6 inch", "Make up the remaining water."), c("10", "Add 1.0 inch", "Add the full weekly need."), c("14", "Add 1.4 inches", "Add rain and the need together.")], correctOption: "06",
    explanation: "The garden needs 1.0 inch total. If 0.4 inch comes from rain, 1.0 − 0.4 = 0.6 inch remains to add.", incorrectGuidance: "Rain already supplies part of the one-inch need. Subtract it instead of adding it again.", mathConcepts: ["Decimals", "Subtraction", "Measurement"], hint: "Subtract forecast rain from the total need."
  }),
  q({
    id: "middle-weather-snow", gradeLevel: "middle", module: "weather", title: "Bus-route snow",
    scenario: "Buses can run only if expected snow stays below 10 cm. Snow is forecast at 3 cm per hour for four hours.", question: "What should the school do about the bus route?", contextualBadge: "Multiply a rate",
    evidence: [e.statistic("Snow rate", "3 cm per hour", "Snow is expected at a steady rate."), e.fact("Storm duration", "4 hours", "The forecast covers four hours."), e.fact("Bus limit", "Below 10 cm", "The route is not safe at 10 cm or more.")],
    options: [c("run", "Run the usual route", "Expect less than 10 cm."), c("delay", "Delay the route", "Expected snow reaches the limit.")], correctOption: "delay",
    explanation: "3 cm per hour for 4 hours is 12 cm. That is above the 10 cm limit, so delaying is better supported.", incorrectGuidance: "Multiply the hourly snow rate by the number of hours before comparing it to the limit.", mathConcepts: ["Multiplication", "Rates", "Safety"], hint: "Calculate 3 × 4 first."
  }),
  q({
    id: "middle-business-shirts", gradeLevel: "middle", module: "business", title: "Team-shirt order",
    scenario: "The drama club needs 40 shirts for volunteers.", question: "Which supplier has the lower total price?", contextualBadge: "Use a discount",
    evidence: [e.table("Supplier prices", ["Supplier", "Base price", "Discount"], [["A", "$9.00 per shirt", "None"], ["B", "$10.00 per shirt", "10% off"]])],
    options: [c("a", "Choose Supplier A", "40 shirts at $9 each."), c("b", "Choose Supplier B", "40 shirts at 10% off $10."), c("same", "Choose either supplier", "Their totals match.")], correctOption: "same",
    explanation: "Supplier A costs 40 × $9 = $360. Supplier B’s discounted price is $9 per shirt, also $360, so neither is lower.", incorrectGuidance: "A 10% discount on $10 makes $9. Calculate both totals before deciding.", mathConcepts: ["Percentages", "Multiplication", "Cost Comparison"], hint: "Find Supplier B’s price after the discount first."
  }),
  q({
    id: "middle-business-streaming", gradeLevel: "middle", module: "business", title: "Club video subscription",
    scenario: "The media club will use a video service for a full year.", question: "Which plan costs less for 12 months?", contextualBadge: "Compare annual cost",
    evidence: [e.table("Subscription plans", ["Plan", "Price"], [["Monthly", "$15 per month"], ["Annual", "$120 per year"]])],
    options: [c("monthly", "Choose the monthly plan", "Pay $15 each month."), c("annual", "Choose the annual plan", "Pay $120 once.")], correctOption: "annual",
    explanation: "Twelve monthly payments cost 12 × $15 = $180. The annual plan is $120, so it saves $60.", incorrectGuidance: "The club needs a full year, so multiply the monthly price by 12 before comparing.", mathConcepts: ["Multiplication", "Money", "Cost Comparison"], hint: "Calculate 12 × $15."
  }),
  q({
    id: "middle-business-smoothie", gradeLevel: "middle", module: "business", title: "Smoothie stand ingredients",
    scenario: "A smoothie stand wants the lower ingredient cost per smoothie.", question: "Which ingredient box is the better value?", contextualBadge: "Find a unit rate",
    evidence: [e.table("Ingredient boxes", ["Box", "Cost", "Smoothies made"], [["A", "$18", "12"], ["B", "$14", "8"]])],
    options: [c("a", "Choose Box A", "It costs $18 for 12 smoothies."), c("b", "Choose Box B", "It costs $14 for 8 smoothies.")], correctOption: "a",
    explanation: "Box A costs $18 ÷ 12 = $1.50 per smoothie. Box B costs $14 ÷ 8 = $1.75 per smoothie, so Box A is the better value.", incorrectGuidance: "Total cost alone is not enough because the boxes make different numbers of smoothies. Divide cost by smoothies.", mathConcepts: ["Unit Rates", "Division", "Cost Comparison"], hint: "Find the cost for one smoothie from each box."
  }),
  q({
    id: "middle-business-ticket", gradeLevel: "middle", module: "business", title: "Museum-ticket checkout",
    scenario: "A club needs 5 museum tickets. Buying online adds one $4 order fee; buying at the door has no fee.", question: "Which choice costs less if each ticket is $8 either way?", contextualBadge: "Notice fixed fees",
    evidence: [e.price("Ticket price", "$8", "Each ticket costs $8 in both places."), e.price("Online order fee", "$4", "The fee is added once online."), e.fact("Tickets needed", "5", "The club needs five tickets.")],
    options: [c("door", "Buy at the door", "Pay only for the 5 tickets."), c("online", "Buy online", "Pay for tickets plus the fee.")], correctOption: "door",
    explanation: "Both choices include 5 × $8 = $40 for tickets. Online adds $4, so buying at the door costs less at $40.", incorrectGuidance: "The ticket prices match. Look for the extra cost in only one option.", mathConcepts: ["Multiplication", "Fixed Cost", "Comparison"], hint: "Start with the ticket total, then add any fee."
  }),
  q({
    id: "middle-technology-storage-plan", gradeLevel: "middle", module: "technology", title: "Media club storage plan",
    scenario: "The media club needs at least 20 GB of shared storage for edited videos this month.", question: "Which plan gives enough storage for the lower cost per GB?", contextualBadge: "Compare unit price",
    evidence: [e.table("Monthly storage plans", ["Plan", "Storage", "Monthly cost"], [["A", "10 GB", "$12"], ["B", "25 GB", "$18"]]), e.fact("Club need", "At least 20 GB", "A plan under 20 GB will not fit all files.")],
    options: [c("a", "Choose Plan A", "It has the lower monthly price."), c("b", "Choose Plan B", "It meets the need and costs less per GB.")], correctOption: "b",
    explanation: "Plan A does not meet the 20 GB requirement. Plan B does, and $18 ÷ 25 GB is $0.72 per GB, less than Plan A’s $1.20.", incorrectGuidance: "First check which plan holds at least 20 GB. Then compare monthly cost for one GB.", mathConcepts: ["Unit Rate", "Cost Comparison"], hint: "Divide each price by gigabytes after checking the need.", confidenceData: confidence("Storage value", "Plan B has 25 GB, so it clears the 20 GB requirement.", [{ label: "Plan A", value: 40, display: "10 GB" }, { label: "Plan B", value: 100, display: "25 GB" }])
  }),
  q({
    id: "middle-technology-printing", gradeLevel: "middle", module: "technology", title: "Printing-plan choice",
    scenario: "The yearbook club expects to print 180 pages this month.", question: "Which plan covers enough pages for the lower cost?", contextualBadge: "Match usage",
    evidence: [e.table("Printing plans", ["Plan", "Pages included", "Cost"], [["A", "100", "$8"], ["B", "250", "$16"]]), e.fact("Expected use", "180 pages", "The club needs at least 180 pages.")],
    options: [c("a", "Choose Plan A", "It costs only $8."), c("b", "Choose Plan B", "It covers all 180 pages.")], correctOption: "b",
    explanation: "Plan A includes only 100 pages, which is 80 pages short. Plan B includes 250 pages and meets the need.", incorrectGuidance: "The lowest listed price is not useful if the plan cannot cover expected pages.", mathConcepts: ["Subtraction", "Comparison", "Planning"], hint: "Compare each included-page total with 180."
  }),
  q({
    id: "middle-technology-download", gradeLevel: "middle", module: "technology", title: "Video-download speed",
    scenario: "A 600 MB video must download before a 25-second break ends.", question: "Which connection can finish in time?", contextualBadge: "Use a rate",
    evidence: [e.table("Download speeds", ["Connection", "Speed"], [["A", "20 MB per second"], ["B", "30 MB per second"]]), e.fact("Video size", "600 MB", "The video must download in 25 seconds or less.")],
    options: [c("a", "Choose Connection A", "It downloads 20 MB each second."), c("b", "Choose Connection B", "It downloads 30 MB each second.")], correctOption: "b",
    explanation: "Connection A takes 600 ÷ 20 = 30 seconds. Connection B takes 600 ÷ 30 = 20 seconds, so only B finishes in time.", incorrectGuidance: "Divide file size by each speed to find download time.", mathConcepts: ["Rates", "Division", "Time"], hint: "Use time = file size ÷ speed."
  }),
  q({
    id: "middle-technology-battery", gradeLevel: "middle", module: "technology", title: "Power-bank purchase",
    scenario: "A field-recording kit needs at least 5,000 mAh of battery capacity.", question: "Which power bank is the defensible choice?", contextualBadge: "Meet the requirement",
    evidence: [e.table("Power banks", ["Bank", "Capacity", "Price"], [["A", "4,800 mAh", "$30"], ["B", "6,000 mAh", "$42"]]), e.fact("Minimum need", "5,000 mAh", "The kit cannot use a bank below this capacity.")],
    options: [c("a", "Choose Bank A", "It costs less."), c("b", "Choose Bank B", "It reaches the needed capacity.")], correctOption: "b",
    explanation: "Bank A is 200 mAh below the 5,000 mAh requirement. Bank B has 6,000 mAh, so it is the only option that meets the need.", incorrectGuidance: "Price matters only after an option clears the minimum capacity requirement.", mathConcepts: ["Subtraction", "Measurement", "Constraints"], hint: "Check the capacity requirement before comparing prices."
  }),
  q({
    id: "middle-investment-growth", gradeLevel: "middle", module: "investment", title: "Club-fund growth",
    scenario: "The science club is comparing two one-year savings offers.", question: "Which offer gives the larger one-year gain?", contextualBadge: "Calculate a percentage",
    evidence: [e.table("Savings offers", ["Offer", "Starting amount", "Rate"], [["A", "$200", "3%"], ["B", "$250", "2.5%"]])],
    options: [c("a", "Choose Offer A", "3% of $200."), c("b", "Choose Offer B", "2.5% of $250.")], correctOption: "b",
    explanation: "Offer A gains 3% of $200 = $6. Offer B gains 2.5% of $250 = $6.25, so Offer B gains $0.25 more.", incorrectGuidance: "A larger percentage does not always mean a larger gain when starting amounts differ. Calculate both dollar gains.", mathConcepts: ["Percentages", "Money", "Comparison"], hint: "Multiply each starting amount by its rate as a decimal."
  }),
  q({
    id: "middle-investment-event", gradeLevel: "middle", module: "investment", title: "Event-insurance decision",
    scenario: "A club can pay $15 to protect a $100 prize from a 20% chance of damage.", question: "Which choice has the better expected-value support?", contextualBadge: "Compare expected costs",
    evidence: [e.percentage("Damage chance", "20%", "There is a 1 in 5 chance of damage."), e.price("Possible loss", "$100", "The prize must be replaced if damaged."), e.price("Protection cost", "$15", "The fee is paid for certain.")],
    options: [c("protect", "Pay for protection", "The expected loss is larger than $15."), c("skip", "Skip protection", "Avoid the certain $15 fee.")], correctOption: "protect",
    explanation: "The expected damage cost is 20% of $100, or $20. Since $20 is greater than the $15 protection fee, protection has the better expected-value support.", incorrectGuidance: "Compare the fee with probability × possible loss, not only with the full $100 loss.", mathConcepts: ["Probability", "Expected Value", "Money"], hint: "Find 20% of $100 before comparing costs.", confidenceData: confidence("Damage probability", "A 20% chance of a $100 loss has an expected value of $20.", [{ label: "Expected loss", value: 100, display: "$20" }, { label: "Protection fee", value: 75, display: "$15" }])
  }),
  q({
    id: "middle-investment-saving", gradeLevel: "middle", module: "investment", title: "Two-part savings offer",
    scenario: "A club has $50 to place in one account for a year.", question: "Which offer gives more money after one year?", contextualBadge: "Add a bonus",
    evidence: [e.table("Account offers", ["Account", "Rate", "Extra bonus"], [["A", "4%", "None"], ["B", "3%", "$1 bonus"]])],
    options: [c("a", "Choose Account A", "4% of $50."), c("b", "Choose Account B", "3% of $50 plus $1.")], correctOption: "b",
    explanation: "Account A gains $2 from 4% of $50. Account B gains $1.50 plus $1, for $2.50. Account B ends higher.", incorrectGuidance: "Do not ignore Account B’s extra $1. Add it after calculating the percentage gain.", mathConcepts: ["Percentages", "Addition", "Money"], hint: "Calculate each percentage of $50, then include any fixed bonus."
  }),
  q({
    id: "middle-investment-saving-plan", gradeLevel: "middle", module: "investment", title: "Monthly equipment fund",
    scenario: "Two clubs are saving for equipment over six months.", question: "Which plan reaches the larger balance after six months?", contextualBadge: "Use an expression",
    evidence: [e.table("Saving plans", ["Plan", "Starting money", "Added monthly"], [["A", "$80", "$25"], ["B", "$100", "$20"]])],
    options: [c("a", "Choose Plan A", "Start at $80 and add $25 each month."), c("b", "Choose Plan B", "Start at $100 and add $20 each month.")], correctOption: "a",
    explanation: "Plan A is $80 + 6($25) = $230. Plan B is $100 + 6($20) = $220, so Plan A is larger.", incorrectGuidance: "Include the starting amount and six monthly additions in both calculations.", mathConcepts: ["Expressions", "Multiplication", "Addition"], hint: "Write start + 6 × monthly amount for each plan."
  })
];
