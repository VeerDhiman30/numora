import { choice, createQuestion, evidence } from "./questionHelpers.js";

const q = createQuestion;
const c = choice;
const e = evidence;

// Fictional decision models with explicit objectives. Derived answers belong
// in feedback, not in the evidence or in a ready-made comparison of totals.
export const highDecisionQuestions = [
  q({
    id: "high-sports-shot", gradeLevel: "high", module: "sports", title: "One possession to win",
    scenario: "Your basketball team is two points behind with time for exactly one shot. A made two-pointer forces overtime; a made three-pointer wins immediately.",
    question: "Which shot maximizes the probability of eventually winning, and by how many percentage points?",
    contextualBadge: "Conditional probability · choose the right objective",
    assumptions: ["A missed shot loses the game. Ignore fouls, rebounds, and any further possessions.", "If the game reaches overtime, the team has a 55% chance of winning."],
    evidence: [e.table("Final-shot estimates", ["Shot", "Chance of making it", "Result if made"], [["Two-pointer", "60%", "Overtime"], ["Three-pointer", "36%", "Immediate win"]])],
    options: [c("two-rate", "Two-pointer · 24 percentage points better", ""), c("three", "Three-pointer · 3 percentage points better", ""), c("two-points", "Two-pointer · 0.12 more expected points", ""), c("equal", "Either shot · equal winning chances", "")], correctOption: "three",
    explanation: "The three-pointer has the better chance of winning, even though the two-pointer has the higher expected point total.",
    solutionSteps: ["A two-pointer must succeed AND be followed by an overtime win: 0.60 × 0.55 = 0.33, or 33%.", "A made three-pointer wins directly, so its winning probability is 36%.", "36% − 33% = 3 percentage points. The goal is winning probability, not expected points."],
    incorrectGuidance: "A made two-pointer is not yet a win. Include the chance of winning overtime and use the stated objective.", mathConcepts: ["Conditional Probability", "Expected Value", "Percentage Points"], hint: "For the two-point strategy, follow both stages of the path to a win."
  }),
  q({
    id: "high-sports-serving", gradeLevel: "high", module: "sports", title: "Aces are only part of the story",
    scenario: "A volleyball coach must choose one serving strategy for 20 service points. An ace wins the point, a fault loses it, and any other serve starts a rally.",
    question: "Which strategy produces more expected points won out of 20, and by how many?",
    contextualBadge: "Three outcomes · weighted probability",
    assumptions: ["Use the trial frequencies as probabilities for the next 20 serves.", "The rally win rate applies only to serves that are neither aces nor faults."],
    evidence: [e.table("Results from 40 trial serves each", ["Strategy", "Aces", "Faults", "Win rate in other rallies"], [["Inez", "10", "4", "50%"], ["Rae", "8", "2", "60%"]])],
    options: [c("inez-aces", "Inez · 1 more expected point", ""), c("rae-no-faults", "Rae · 1 more expected point", ""), c("rae", "Rae · 1.5 more expected points", ""), c("equal", "Either · 12 expected points each", "")], correctOption: "rae",
    explanation: "Rae's stronger rally results outweigh Inez's higher ace rate.",
    solutionSteps: ["Inez has 40 − 10 − 4 = 26 ordinary rallies. Expected wins per 40 serves: 10 + 0.50(26) = 23.", "Rae has 40 − 8 − 2 = 30 ordinary rallies. Expected wins per 40 serves: 8 + 0.60(30) = 26.", "Scale to 20 serves: Inez 11.5, Rae 13. Rae's advantage is 1.5 expected points; expected values need not be whole numbers."],
    incorrectGuidance: "Not every non-fault serve wins. Separate aces, faults, and rallies before calculating the overall win rate.", mathConcepts: ["Expected Value", "Conditional Rates", "Weighted Probability"], hint: "Subtract aces and faults from 40, then apply the rally win rate only to the remaining serves."
  }),
  q({
    id: "high-sports-training", gradeLevel: "high", module: "sports", title: "Training gains after missed sessions",
    scenario: "A sprinter has 20 scheduled training sessions before a meet. Two plans offer different gains per attended session, but their expected absence rates differ.",
    question: "Which plan gives the larger expected reduction in sprint time over all 20 sessions, and what is its advantage?",
    contextualBadge: "Complementary probability · expected improvement",
    assumptions: ["A missed session produces no improvement.", "For this model, gains add at a constant rate with no fatigue or diminishing returns."],
    evidence: [e.table("Training estimates", ["Plan", "Reduction per attended session", "Chance of missing a session"], [["A", "0.08 seconds", "20%"], ["B", "0.07 seconds", "5%"]])],
    options: [c("a-all", "Plan A · 0.20 seconds better", ""), c("b", "Plan B · 0.05 seconds better", ""), c("a-missed", "Plan A · 0.25 seconds better", ""), c("equal", "Either plan · equal improvement", "")], correctOption: "b",
    explanation: "Accounting for expected attendance makes Plan B slightly better, rather than leaving 'best balance' to opinion.",
    solutionSteps: ["Expected attended sessions: A = 20(1 − 0.20) = 16; B = 20(1 − 0.05) = 19.", "Expected time reductions: A = 16(0.08) = 1.28 seconds; B = 19(0.07) = 1.33 seconds.", "Plan B improves the time by an additional 1.33 − 1.28 = 0.05 seconds."],
    incorrectGuidance: "Use attendance probabilities, not absence probabilities, and compare the resulting total gains.", mathConcepts: ["Expected Value", "Complementary Probability", "Rates"], hint: "First work out how many of the 20 sessions the athlete is expected to attend."
  }),
  q({
    id: "high-sports-tournament", gradeLevel: "high", module: "sports", title: "Arrive before the tournament cutoff",
    scenario: "The team must arrive within 90 minutes. Its travel rule requires at least a 90% chance of arriving on time, and the budget is $30 per person.",
    question: "Work out each route's on-time probability. Which is the cheapest route that satisfies both rules?",
    contextualBadge: "Probability threshold · cost constraint",
    assumptions: ["For each route, either the listed delay happens once or there is no delay; there are no other delays.", "Arriving in exactly 90 minutes counts as on time."],
    evidence: [e.table("Route quotes", ["Route", "Base time", "Possible extra delay", "Cost/person"], [["Express", "85 min", "20 min with 5% chance", "$28"], ["Transfer", "70 min", "25 min with 20% chance", "$20"], ["Shuttle", "80 min", "10 min with 8% chance", "$26"]])],
    options: [c("express", "Take the Express", ""), c("transfer", "Take the Transfer", ""), c("none", "Reject all three routes", ""), c("shuttle", "Take the Shuttle", "")], correctOption: "shuttle",
    explanation: "A delay does not necessarily mean a late arrival. The shuttle meets the cutoff even in its delayed case.",
    solutionSteps: ["Express takes 85 or 105 minutes, so its on-time probability is 95%.", "Transfer takes 70 or 95 minutes, so its on-time probability is only 80%; exclude it.", "Shuttle takes 80 or 90 minutes, so it is on time in both outcomes. Both remaining fares fit $30, and $26 is cheaper than $28."],
    incorrectGuidance: "Calculate each route's actual delayed arrival time before treating a delay as a late arrival.", mathConcepts: ["Probability", "Inequalities", "Constrained Decisions"], hint: "For each route, add the possible delay to its base time and compare both outcomes with 90 minutes."
  }),
  q({
    id: "high-weather-event-backup", gradeLevel: "high", module: "weather", title: "A backup room with two fees",
    scenario: "A school concert faces a 45% chance of a storm. Organizers want to minimize the expected additional cost caused by their weather plan.",
    question: "Should they reserve the backup room, and how much lower is that plan's expected cost?",
    contextualBadge: "Fixed cost + conditional costs",
    assumptions: ["Without a reservation, a storm causes a $600 loss; no storm causes no additional cost.", "The reservation fee is always paid. Activation and the remaining loss occur only if there is a storm. Ignore costs common to both plans."],
    evidence: [e.table("Backup-room terms", ["Charge", "Amount", "When it applies"], [["Reservation", "$80", "Always"], ["Activation", "$120", "Storm only"], ["Remaining storm loss", "$60", "Storm only, even with the room"]])],
    options: [c("reserve", "Reserve · expected saving $109", ""), c("ignore-activation", "Reserve · expected saving $190", ""), c("always-activate", "Reserve · expected saving $43", ""), c("skip", "Skip · expected saving $80", "")], correctOption: "reserve",
    explanation: "The backup is worthwhile under the stated expected-cost objective, after including both types of fee and the remaining risk.",
    solutionSteps: ["Without the room: 0.45($600) + 0.55($0) = $270 expected loss.", "With the room: $80 + 0.45($120 + $60) = $161 expected cost.", "Expected saving: $270 − $161 = $109. The $120 activation fee must not be charged in the no-storm case."],
    incorrectGuidance: "Distinguish costs paid for certain from costs paid only if the storm happens.", mathConcepts: ["Expected Cost", "Conditional Probability", "Fixed and Variable Costs"], hint: "Start with the reservation fee, then add the probability-weighted storm-only costs."
  }),
  q({
    id: "high-weather-insurance", gradeLevel: "high", module: "weather", title: "Tents reduce losses, not all risk",
    scenario: "A school festival can rent tents for $180. The tents reduce weather damage by 80%, but do not prevent all damage.",
    question: "Which plan minimizes expected total cost, including the rental, and what is that expected cost?",
    contextualBadge: "Three weather outcomes · residual risk",
    assumptions: ["The weather outcomes are mutually exclusive and cover every possibility.", "With tents, 20% of each listed damage amount remains. The rental is paid in every weather outcome."],
    evidence: [e.table("Forecast and damage without tents", ["Weather", "Probability", "Damage"], [["Dry", "50%", "$0"], ["Light rain", "30%", "$200"], ["Heavy rain", "20%", "$1,000"]])],
    options: [c("skip", "Skip tents · $260 expected cost", ""), c("full-protection", "Rent tents · $180 expected cost", ""), c("rent", "Rent tents · $232 expected cost", ""), c("reduction-as-cost", "Skip tents · $208 expected cost", "")], correctOption: "rent",
    explanation: "Renting saves $28 in expected cost, even though some damage remains.",
    solutionSteps: ["Without tents: 0.50($0) + 0.30($200) + 0.20($1,000) = $260.", "Tents leave 20% of that expected damage: 0.20($260) = $52.", "Add the certain rental: $180 + $52 = $232, which is $28 below $260."],
    incorrectGuidance: "An 80% reduction leaves 20% of the damage. Include all forecast outcomes and the rental fee.", mathConcepts: ["Expected Value", "Percentage Reduction", "Risk"], hint: "Find expected damage without tents first. Then calculate the part still left after protection."
  }),
  q({
    id: "high-weather-route", gradeLevel: "high", module: "weather", title: "The same average, different arrival risk",
    scenario: "A student leaves at 8:00 a.m. for an 8:45 exam. The student requires at least a 90% chance of arriving by 8:45, then prefers the lowest expected travel time among qualifying routes.",
    question: "Which route should the student take, and what is its expected travel time?",
    contextualBadge: "Expected time versus deadline probability",
    assumptions: ["There is a 60% chance of dry weather and a 40% chance of rain for the whole journey.", "The table gives the full journey time in each outcome. Arrival at 8:45 is allowed."],
    evidence: [e.table("Journey times", ["Route", "Dry weather", "Rain"], [["A", "25 min", "55 min"], ["B", "35 min", "40 min"]])],
    options: [c("a", "Route A · 37 minutes expected", ""), c("b", "Route B · 37 minutes expected", ""), c("either", "Either · 37 minutes expected", ""), c("a-dry", "Route A · 25 minutes expected", "")], correctOption: "b",
    explanation: "Equal expected travel times do not mean equal reliability. Only Route B meets the student's arrival rule.",
    solutionSteps: ["Route A: 0.60(25) + 0.40(55) = 37 minutes. Its rainy journey takes more than 45 minutes, so it is on time only 60% of the time.", "Route B: 0.60(35) + 0.40(40) = 37 minutes. Both journeys fit the 45-minute limit.", "Route B's 100% on-time probability meets 90%; Route A's 60% does not."],
    incorrectGuidance: "Check the deadline probability separately from average travel time.", mathConcepts: ["Expected Value", "Probability", "Constraints"], hint: "Calculate both weighted averages, then identify which weather outcomes would make each route late."
  }),
  q({
    id: "high-weather-heating", gradeLevel: "high", module: "weather", title: "Heating across a changing forecast",
    scenario: "A greenhouse needs an indoor temperature of 20°C for five nights. Two heating schedules use a daily base amount plus extra energy for each degree below 20°C outside.",
    question: "Which schedule uses less energy over the five nights, including startup, and by how much?",
    contextualBadge: "Build a linear model · sum changing conditions",
    assumptions: ["Use each nightly outdoor temperature to find that night's temperature gap.", "Schedule B's 6 kWh startup is used once, not every night. Schedule A has no startup use."],
    evidence: [e.table("Nightly outdoor temperature", ["Night 1", "Night 2", "Night 3", "Night 4", "Night 5"], [["16°C", "12°C", "8°C", "4°C", "10°C"]]), e.table("Schedule energy model", ["Schedule", "Base per night", "Extra per degree of gap", "One-time startup"], [["A", "5 kWh", "0.80 kWh", "0 kWh"], ["B", "8 kWh", "0.45 kWh", "6 kWh"]])],
    options: [c("b-no-start", "Schedule B · 2.5 kWh less", ""), c("b-one-base", "Schedule B · 8.5 kWh less", ""), c("a", "Schedule A · 3.5 kWh less", ""), c("a-daily-start", "Schedule A · 27.5 kWh less", "")], correctOption: "a",
    explanation: "B has a lower variable rate, but its higher base use and one-time startup outweigh that advantage over this five-night period.",
    solutionSteps: ["Temperature gaps: 4, 8, 12, 16, and 10 degrees; their sum is 50.", "A uses 5(5) + 0.80(50) = 65 kWh.", "B uses 5(8) + 0.45(50) + 6 = 68.5 kWh. A saves 3.5 kWh."],
    incorrectGuidance: "Count five base charges, all five temperature gaps, and exactly one startup charge.", mathConcepts: ["Linear Models", "Summation", "Fixed and Variable Costs"], hint: "Add the five temperature gaps first. Apply each per-degree rate to that total."
  }),
  q({
    id: "high-business-catering", gradeLevel: "high", module: "business", title: "A bulk discount changes the break-even point",
    scenario: "A club needs catering for 85 guests. Supplier B discounts its food charge by 10% when there are at least 80 guests, but never discounts its fixed fee.",
    question: "Which supplier is cheaper for 85 guests, and what is the first whole-number guest count above 80 at which A becomes strictly cheaper than B?",
    contextualBadge: "Piecewise pricing · strict break-even inequality",
    assumptions: ["Apply B's discount only to the per-guest food subtotal.", "There are no taxes or other fees. B keeps the same bulk discount for every guest count of 80 or more."],
    evidence: [e.table("Catering quotes", ["Supplier", "Fixed fee", "Food per guest"], [["A", "$180", "$12"], ["B", "$60", "$14 before discount"]])],
    options: [c("ignore-discount", "A · $1,200 now · 81 guests", ""), c("discount-all", "B · $1,125 now · 211 guests", ""), c("equal-boundary", "B · $1,131 now · 200 guests", ""), c("b", "B · $1,131 now · 201 guests", "")], correctOption: "b",
    explanation: "B wins at 85 guests, but A's lower per-guest rate eventually overtakes B's lower fixed fee.",
    solutionSteps: ["At 85 guests, A = 180 + 12(85) = $1,200; B = 60 + 0.90(14)(85) = $1,131.", "In the bulk-discount range, A < B means 180 + 12n < 60 + 12.6n.", "120 < 0.6n, so n > 200. At 200 the bills tie; the first whole-number count making A cheaper is 201."],
    incorrectGuidance: "Keep B's fixed fee outside the discount, and distinguish an equal bill from a strictly cheaper bill.", mathConcepts: ["Piecewise Models", "Discounts", "Linear Inequalities"], hint: "Write a cost expression for each supplier in the 80-or-more range before comparing them."
  }),
  q({
    id: "high-business-ad", gradeLevel: "high", module: "business", title: "Clicks, purchases, and returns",
    scenario: "A school enterprise can buy one advertising campaign. Each purchase that is kept contributes $18 after product costs, before advertising costs. Returned purchases contribute $0.",
    question: "Which campaign has the larger expected net profit after returns and advertising, and by how much?",
    contextualBadge: "Conversion funnel · net profit",
    assumptions: ["The purchase rate is the fraction of clicks that become purchases.", "The return rate applies only to purchases. Ignore any further costs or repeat purchases."],
    evidence: [e.table("Campaign forecasts", ["Campaign", "Clicks", "Purchase rate", "Return rate", "Ad cost"], [["A", "500", "8%", "10%", "$400"], ["B", "400", "10%", "5%", "$450"]])],
    options: [c("a", "Campaign A · $14 more", ""), c("no-returns", "Campaign A · $50 more", ""), c("b-customers", "Campaign B · $36 more", ""), c("return-only", "Campaign A · $36 more", "")], correctOption: "a",
    explanation: "B keeps more purchases, but A's $50 lower advertising bill more than compensates for its two fewer kept purchases.",
    solutionSteps: ["A: 500(0.08) = 40 purchases; 40(0.90) = 36 kept purchases. Net profit = 36($18) − $400 = $248.", "B: 400(0.10) = 40 purchases; 40(0.95) = 38 kept purchases. Net profit = 38($18) − $450 = $234.", "A's advantage is $248 − $234 = $14."],
    incorrectGuidance: "Follow all stages: clicks → purchases → kept purchases → contribution minus ad cost.", mathConcepts: ["Conditional Rates", "Expected Profit", "Multistep Percentages"], hint: "Multiply by one minus the return rate after calculating expected purchases."
  }),
  q({
    id: "high-business-printer", gradeLevel: "high", module: "business", title: "Printing with different pricing bands",
    scenario: "The yearbook team will print 1,800 pages this month. The two plans charge for different bands of page usage.",
    question: "Which plan has the lower total bill for 1,800 pages, and how much does it save?",
    contextualBadge: "Piecewise costs · included allowances",
    assumptions: ["A's lower rate applies only to pages after the first 1,000, not to all pages.", "B includes its first 500 pages in the fee. All quoted prices are final."],
    evidence: [e.table("Monthly printer quotes", ["Plan", "Monthly fee", "Page charges"], [["A", "$40", "$0.05 each for first 1,000; $0.03 each after"], ["B", "$70", "First 500 included; $0.02 each after"]])],
    options: [c("a-all-low", "Plan A · saves $2", ""), c("b", "Plan B · saves $18", ""), c("b-no-allowance", "Plan B · saves $8", ""), c("b-all-high", "Plan B · saves $34", "")], correctOption: "b",
    explanation: "Separate included pages and pricing bands before calculating each total.",
    solutionSteps: ["A: $40 + 1,000($0.05) + 800($0.03) = $114.", "B charges for 1,800 − 500 = 1,300 pages: $70 + 1,300($0.02) = $96.", "Plan B saves $114 − $96 = $18."],
    incorrectGuidance: "Do not apply one rate to every page. Identify how many pages belong in each band.", mathConcepts: ["Piecewise Functions", "Unit Rates", "Cost Comparison"], hint: "Split A's pages at 1,000 and subtract B's 500-page allowance before multiplying."
  }),
  q({
    id: "high-business-pricing", gradeLevel: "high", module: "business", title: "Price for profit, not just ticket sales",
    scenario: "A club is choosing among four ticket prices for a fundraiser. Demand falls as price rises, and the venue can hold at most 120 people.",
    question: "Calculate predicted profit at each offered price. Which price gives the most profit after fixed and per-attendee costs?",
    contextualBadge: "Demand model · capacity · profit",
    assumptions: ["At price p dollars, predicted demand is 180 − 6(p − 10) tickets.", "Tickets sold equal the smaller of predicted demand and 120. Each attendee costs $4 to serve, plus a fixed $300 event cost."],
    evidence: [e.table("Prices under consideration", ["Choice A", "Choice B", "Choice C", "Choice D"], [["$18", "$20", "$22", "$24"]])],
    options: [c("18", "Charge $18 per ticket", ""), c("20", "Charge $20 per ticket", ""), c("22", "Charge $22 per ticket", ""), c("24", "Charge $24 per ticket", "")], correctOption: "22",
    explanation: "The $22 price gives the largest modeled profit, even though it does not fill the venue.",
    solutionSteps: ["Demand at $18, $20, $22, and $24 is 132, 120, 108, and 96. Capacity reduces the first result to 120 tickets sold.", "For each price, profit = (p − 4) × tickets sold − 300.", "Profits are $1,380, $1,620, $1,644, and $1,620. The $22 price wins among the four offered prices."],
    incorrectGuidance: "The objective is profit, not attendance or gross revenue. Account for both types of cost and the seat limit.", mathConcepts: ["Linear Demand", "Quadratic Profit", "Constraints"], hint: "First calculate tickets sold at each price. Then use the profit per attendee, not the full ticket price."
  }),
  q({
    id: "high-technology-server", gradeLevel: "high", module: "technology", title: "Hosting cost under a downtime limit",
    scenario: "A student app can tolerate at most 3.6 hours of downtime in a 30-day month. The team wants the cheapest qualifying plan over its first 12 months.",
    question: "Calculate each plan's monthly downtime and first-year cost. Which is the cheapest plan that meets the downtime limit?",
    contextualBadge: "Convert availability · compare whole-year cost",
    assumptions: ["Use 30 × 24 = 720 hours per month when converting uptime to downtime.", "Treat the quoted uptime as the model for comparison. Pay each setup fee once and all 12 monthly fees."],
    evidence: [e.table("Hosting quotes", ["Plan", "Uptime", "Monthly fee", "Setup fee"], [["A", "99.4%", "$32", "$0"], ["B", "99.6%", "$46", "$120"], ["C", "99.7%", "$52", "$0"], ["D", "99.9%", "$56", "$40"]])],
    options: [c("a", "Choose Plan A", ""), c("b", "Choose Plan B", ""), c("d", "Choose Plan D", ""), c("c", "Choose Plan C", "")], correctOption: "c",
    explanation: "Plan C costs less over the full year than B, even though B advertises a lower monthly fee.",
    solutionSteps: ["Downtime = 720 × (1 − uptime as a decimal): A 4.32 h, B 2.88 h, C 2.16 h, D 0.72 h. Exclude A because 4.32 > 3.6.", "First-year totals: B = 12($46) + $120 = $672; C = 12($52) = $624; D = 12($56) + $40 = $712.", "C is the least expensive qualifying plan and stays under the downtime limit."],
    incorrectGuidance: "Convert the small downtime percentage to hours, then include the one-time setup fees in the annual totals.", mathConcepts: ["Complementary Percentages", "Unit Conversion", "Constraints"], hint: "A plan with 99.7% uptime has 0.3% downtime, not 99.7% downtime."
  }),
  q({
    id: "high-technology-battery", gradeLevel: "high", module: "technology", title: "Enough battery after losses and reserve",
    scenario: "A field sensor runs at 9 W for 6 hours and at 1 W for the other 18 hours. Its battery must weigh no more than 1.1 kg.",
    question: "Calculate the sensor's energy need and each battery's usable energy. Which is the cheapest battery that lasts the full day while preserving the reserve?",
    contextualBadge: "Energy budget · successive percentages",
    assumptions: ["Only 80% of rated battery energy reaches the sensor because of conversion losses.", "Keep at least 20% of that delivered energy unused as a reserve. Energy in Wh equals power in W × time in hours."],
    evidence: [e.table("Battery choices", ["Battery", "Rated energy", "Mass", "Price"], [["A", "110 Wh", "0.8 kg", "$72"], ["B", "120 Wh", "1.0 kg", "$78"], ["C", "140 Wh", "1.2 kg", "$70"], ["D", "150 Wh", "1.1 kg", "$90"]])],
    options: [c("a", "Choose Battery A", ""), c("b", "Choose Battery B", ""), c("c", "Choose Battery C", ""), c("d", "Choose Battery D", "")], correctOption: "b",
    explanation: "B is the cheapest valid option. Two separate 20% reductions must be applied successively, not added together.",
    solutionSteps: ["The sensor needs 9(6) + 1(18) = 72 Wh.", "Usable energy after conversion and reserve is rated energy × 0.80 × 0.80 = 0.64 × rated energy.", "A supplies only 70.4 Wh and fails. C is too heavy. B supplies 76.8 Wh and costs less than D, so choose B."],
    incorrectGuidance: "Check power × hours, both percentage factors, and mass before choosing by price.", mathConcepts: ["Energy and Rates", "Successive Percentages", "Constrained Optimization"], hint: "The reserve is a percentage of delivered energy, so apply it after the conversion loss."
  }),
  q({
    id: "high-technology-internet", gradeLevel: "high", module: "technology", title: "Finish the upload before the broadcast",
    scenario: "A school studio must upload a 30 GB video in at most 12 minutes. It wants the lowest first-year cost among plans that can meet this deadline.",
    question: "Calculate upload time using each plan's sustained speed, then compare annual costs. Which plan should the studio choose?",
    contextualBadge: "Units · effective speed · annual cost",
    assumptions: ["For this model, 1 GB = 1,000 MB and 1 byte = 8 bits. Mbps means megabits per second.", "Sustained upload speed is 70% of advertised speed. Ignore other delays; pay setup once and 12 monthly fees. Round time only at the end."],
    evidence: [e.table("Upload-plan quotes", ["Plan", "Advertised upload", "Monthly fee", "Setup fee"], [["A", "400 Mbps", "$45", "$0"], ["B", "500 Mbps", "$62", "$120"], ["C", "600 Mbps", "$68", "$0"], ["D", "1,000 Mbps", "$80", "$0"]])],
    options: [c("a", "Choose Plan A", ""), c("b", "Choose Plan B", ""), c("c", "Choose Plan C", ""), c("d", "Choose Plan D", "")], correctOption: "c",
    explanation: "C beats B on full-year cost once B's setup fee is included, and both satisfy the upload deadline.",
    solutionSteps: ["The file contains 30 × 1,000 × 8 = 240,000 megabits. Effective speeds are 280, 350, 420, and 700 Mbps.", "Time in minutes = 240,000 ÷ effective speed ÷ 60: about 14.29, 11.43, 9.52, and 5.71. A misses the 12-minute deadline.", "Qualifying first-year costs are B $864, C $816, D $960. C is cheapest."],
    incorrectGuidance: "Do not confuse bytes with bits or advertised with sustained speed. The cost comparison covers a year, not one month.", mathConcepts: ["Unit Conversion", "Rates", "Multistep Constraints"], hint: "Put file size and connection speed into matching units before dividing."
  }),
  q({
    id: "high-technology-cloud", gradeLevel: "high", module: "technology", title: "Storage growth with a capacity reserve",
    scenario: "A design team already stores 640 GB. At the end of each of the next six months it creates 60 GB, then immediately deletes 10% of that month's new files.",
    question: "Which plan has the lowest six-month subscription cost while keeping at least 20% of its total capacity unused throughout the period?",
    contextualBadge: "Retention rate · growth · capacity inequality",
    assumptions: ["The original 640 GB is never deleted. Evaluate storage after each monthly deletion; no temporary upload space is needed.", "Use 1 TB = 1,000 GB. Keep the same plan for all six months, with no other fees."],
    evidence: [e.table("Storage subscriptions", ["Plan", "Total capacity", "Monthly cost"], [["A", "1 TB", "$19"], ["B", "1.2 TB", "$22"], ["C", "1.5 TB", "$25"], ["D", "2 TB", "$31"]])],
    options: [c("a", "Choose Plan A", ""), c("b", "Choose Plan B", ""), c("d", "Choose Plan D", ""), c("c", "Choose Plan C", "")], correctOption: "c",
    explanation: "Plan B misses the reserve requirement by just 4 GB of usable capacity. Plan C is the smallest qualifying subscription.",
    solutionSteps: ["Each month retains 60(0.90) = 54 GB. Maximum stored data after six months: 640 + 6(54) = 964 GB.", "A 20% unused reserve means stored data must be no more than 80% of total capacity: capacity ≥ 964 ÷ 0.80 = 1,205 GB.", "B allows only 0.80(1,200) = 960 GB of stored data. C qualifies at 1,500 GB and costs 6($25) = $150, less than D."],
    incorrectGuidance: "The reserve is 20% of the plan's total capacity, not 20% of the files. Divide by 0.80 rather than multiplying by 1.20.", mathConcepts: ["Linear Growth", "Percentages", "Inequalities"], hint: "First find the maximum stored data. Then write stored data ≤ 0.80 × plan capacity."
  }),
  q({
    id: "high-investment-club-fund", gradeLevel: "high", module: "investment", title: "The highest rate is not always the best offer",
    scenario: "In this fictional savings exercise, a robotics club places $2,000 in one account for exactly 18 months. It wants the largest ending balance after fees and bonuses.",
    question: "Calculate interest, fees, and bonuses over the full 18 months. Which offer leaves the club with the most money?",
    contextualBadge: "Fractional years · fees · net return",
    assumptions: ["All rates are annual simple interest on the original $2,000. Use 18 months = 1.5 years.", "Deduct fees and add bonuses at withdrawal, so they do not change the interest calculation. Ignore taxes; all offers have the same access and safety in this exercise."],
    evidence: [e.table("Fictional savings offers", ["Offer", "Annual interest", "Fee or bonus"], [["A", "4%", "No fee or bonus"], ["B", "5%", "$36 fee per year, prorated for 18 months"], ["C", "3.5%", "$30 bonus at month 18"], ["D", "4.5%", "$15 one-time fee"]])],
    options: [c("a", "Choose Offer A", ""), c("b", "Choose Offer B", ""), c("c", "Choose Offer C", ""), c("d", "Choose Offer D", "")], correctOption: "c",
    explanation: "C's bonus makes its ending balance highest, despite its lower advertised interest rate.",
    solutionSteps: ["A: $2,000 + $2,000(0.04)(1.5) = $2,120.", "B: $2,000 + $2,000(0.05)(1.5) − $36(1.5) = $2,096.", "C: $2,000 + $2,000(0.035)(1.5) + $30 = $2,135. D: $2,000 + $2,000(0.045)(1.5) − $15 = $2,120."],
    incorrectGuidance: "Compare ending balances over the same 18 months, not annual rates alone. Prorate B's annual fee too.", mathConcepts: ["Simple Interest", "Rates and Time", "Net Return"], hint: "Use principal × annual rate × 1.5, then include each offer's fee or bonus."
  }),
  q({
    id: "high-investment-compound", gradeLevel: "high", module: "investment", title: "A close two-year savings comparison",
    scenario: "In a fictional savings model, a club invests $1,200 for two full years. Some offers compound, while others pay simple interest on the original deposit.",
    question: "Calculate the ending balances, including each fee or bonus. Which offer ends highest? Round only the final balances to the nearest cent.",
    contextualBadge: "Compound growth versus simple interest",
    assumptions: ["Add bonuses and deduct fees only at the end of year two. Do not round intermediate calculations.", "There are no extra deposits, withdrawals, taxes, or differences in risk or access in this model."],
    evidence: [e.table("Fictional account offers", ["Offer", "Annual rate", "Interest rule", "End adjustment"], [["A", "5%", "Compound yearly", "None"], ["B", "5.2%", "Simple", "$6 fee"], ["C", "4.5%", "Compound yearly", "$12 bonus"], ["D", "4.8%", "Simple", "$6 bonus"]])],
    options: [c("a", "Choose Offer A", ""), c("b", "Choose Offer B", ""), c("c", "Choose Offer C", ""), c("d", "Choose Offer D", "")], correctOption: "a",
    explanation: "A wins by only $0.57 over C. Both the growth rule and final adjustment matter.",
    solutionSteps: ["A = 1,200(1.05)² = $1,323.00. B = 1,200(1 + 2 × 0.052) − 6 = $1,318.80.", "C = 1,200(1.045)² + 12 = $1,322.43. D = 1,200(1 + 2 × 0.048) + 6 = $1,321.20.", "Compare the complete balances: A is largest, exceeding C by $0.57."],
    incorrectGuidance: "A higher annual rate does not automatically win when growth rules and fees differ.", mathConcepts: ["Compound Growth", "Simple Interest", "Rounding"], hint: "Compound accounts multiply by (1 + rate) twice; simple-interest accounts calculate both years on the original principal."
  }),
  q({
    id: "high-investment-portfolio", gradeLevel: "high", module: "investment", title: "Weighted returns after management fees",
    scenario: "In a fictional one-year model, a club compares portfolios for $2,000. The exercise treats their risk and access as equivalent and asks only for expected net gain.",
    question: "Which portfolio has the larger expected gain after fees, and what is its dollar advantage?",
    contextualBadge: "Weighted average · fee-adjusted return",
    assumptions: ["Rates are modeled expectations, not guaranteed returns.", "The fee is a percentage of the initial $2,000, charged once at year-end. Ignore taxes and other costs."],
    evidence: [e.table("Portfolio models", ["Portfolio", "Allocation and expected annual rates", "Annual fee"], [["A", "60% in X at 8%; 40% in Y at 2%", "1.0% of initial amount"], ["B", "100% in Z at 5%", "0.2% of initial amount"]])],
    options: [c("a-gross", "Portfolio A · $12 advantage", ""), c("b", "Portfolio B · $4 advantage", ""), c("b-no-fee", "Portfolio B · $8 advantage", ""), c("a-unweighted", "Portfolio A · $84 advantage", "")], correctOption: "b",
    explanation: "A has the higher gross expected return, but B has the higher expected return after fees.",
    solutionSteps: ["A's weighted gross rate is 0.60(8%) + 0.40(2%) = 5.6%. Its gross gain is $112, less a $20 fee, leaving $92.", "B's gross gain is $2,000(0.05) = $100. Its fee is $2,000(0.002) = $4, leaving $96.", "B's expected advantage is $96 − $92 = $4."],
    incorrectGuidance: "Weight A's returns by the allocation, then subtract each portfolio's own fee before comparing.", mathConcepts: ["Weighted Average", "Expected Return", "Percentage Fees"], hint: "Calculate the weighted gross gain first; subtract the dollar fee as a separate step."
  }),
  q({
    id: "high-investment-equipment", gradeLevel: "high", module: "investment", title: "Buy or lease when resale matters",
    scenario: "A club can buy equipment or lease it monthly. Buying also requires monthly maintenance, but the equipment can be resold when the project ends.",
    question: "What is the first whole month at which buying is strictly cheaper, and how much does buying save for a 20-month project?",
    contextualBadge: "Net ownership cost · break-even inequality",
    assumptions: ["Compare total net costs after selling the equipment at the end of the project.", "Assume the resale quote stays $240 over the comparison period. Charge maintenance or rent for every month used; ignore interest and taxes."],
    evidence: [e.table("Equipment terms", ["Option", "Upfront cost", "Monthly cost", "Money received at end"], [["Buy", "$840", "$12 maintenance", "$240 resale"], ["Lease", "$60 setup", "$42 rent", "$0"]])],
    options: [c("tie", "Month 18 · saves $60 at month 20", ""), c("no-resale", "Month 27 · buying costs $180 more at month 20", ""), c("buy", "Month 19 · saves $60 at month 20", ""), c("no-maintenance", "Month 13 · saves $300 at month 20", "")], correctOption: "buy",
    explanation: "The two options tie at month 18. Buying first becomes cheaper at month 19, and its advantage grows by $30 per additional month.",
    solutionSteps: ["Buy cost after m months = 840 + 12m − 240 = 600 + 12m. Lease cost = 60 + 42m.", "Buying is strictly cheaper when 600 + 12m < 60 + 42m: 540 < 30m, so m > 18. The first whole month is 19.", "At 20 months, buy = $840 and lease = $900, so buying saves $60."],
    incorrectGuidance: "Subtract resale from ownership cost, include maintenance, and distinguish a tie from a strict saving.", mathConcepts: ["Linear Models", "Break-even", "Inequalities"], hint: "Write the two net-cost expressions in m before solving for when one is smaller."
  })
];
