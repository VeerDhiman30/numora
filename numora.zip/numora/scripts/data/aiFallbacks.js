const genericCoachFallbacks = [
  "Let’s break the problem into a smaller step.",
  "Which piece of information seems most useful here?",
  "Try comparing the two quantities first.",
  "What operation connects these values?"
];

function hashText(text) {
  return [...String(text)].reduce((total, character) => (
    (total * 31 + character.charCodeAt(0)) >>> 0
  ), 0);
}

export function getLocalCoachFallback(message = "") {
  return genericCoachFallbacks[hashText(message) % genericCoachFallbacks.length];
}

export { genericCoachFallbacks };
