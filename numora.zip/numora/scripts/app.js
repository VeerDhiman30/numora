import { createHeader } from "./components/header.js";
import { createAuthenticationView } from "./components/auth/authViews.js";
import { createAiConnectionTestView } from "./components/development/aiTestView.js";
import { createHomeView } from "./components/home/home.js";
import { createDecisionLabView } from "./labs/decision/decisionLab.js";
import { createQuantLabView } from "./labs/quant/quantLab.js";
import { createSimulationLabView } from "./labs/simulation/simulationLab.js";
import { createArcadeView } from "./arcade/arcadeLab.js";
import { createDashboardView } from "./components/dashboard/dashboardView.js";
import { createLeaderboardView } from "./components/leaderboard/leaderboardView.js";
import { initializeRewardNotifications } from "./components/rewardNotifications.js";
import { startEconomySynchronization } from "./services/economyService.js";
import { getCurrentRoute, navigateToRoute } from "./components/navigation.js";
import { initializeAuthentication, signOut } from "./services/authService.js";
import {
  consumePostAuthRoute,
  getAppState,
  setPostAuthRoute,
  subscribeToAppState
} from "./services/appState.js";

const requiredElements = ["app", "app-header", "app-main", "app-footer"];
const protectedRoutes = new Set(["#/dashboard", "#/leaderboard", "#/decision", "#/quant", "#/simulation", "#/arcade"]);
const authenticationRoutes = new Set([
  "#/signin",
  "#/signup",
  "#/forgot-password",
  "#/reset-password",
  "#/check-email"
]);

const views = {
  "/": {
    eyebrow: "Project foundation",
    title: "Numora",
    description: "A thoughtful mathematics learning space is taking shape."
  }
};

const placeholderNavigation = [
  { label: "Decision Lab", route: "#/decision" },
  { label: "Quant Lab", route: "#/quant" },
  { label: "Simulation Lab", route: "#/simulation" },
  { label: "Arcade", route: "#/arcade" },
  { label: "Dashboard", route: "#/dashboard" },
  { label: "Leaderboard", route: "#/leaderboard" }
];

function getApplicationElements() {
  return requiredElements.reduce((elements, id) => {
    const element = document.getElementById(id);

    if (!element) {
      throw new Error(`Numora could not initialize: #${id} is missing.`);
    }

    elements[id] = element;
    return elements;
  }, {});
}

function createSessionCheckingView() {
  const section = document.createElement("section");
  const content = document.createElement("div");
  const heading = document.createElement("h1");
  const description = document.createElement("p");

  section.className = "placeholder-view section";
  section.setAttribute("aria-live", "polite");
  content.className = "page-container placeholder-view__checking stack stack--tight";
  heading.textContent = "Restoring your session…";
  description.className = "placeholder-view__copy";
  description.textContent = "We’re checking whether you’re already signed in.";
  content.append(heading, description);
  section.append(content);
  return section;
}

function redirectToSignIn() {
  const url = new URL(window.location.href);
  url.searchParams.delete("auth");
  url.hash = "#/signin";
  window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
  return "#/signin";
}

function createPlaceholderView(view, route) {
  const section = document.createElement("section");
  section.className = "placeholder-view section";
  section.setAttribute("aria-live", "polite");
  section.innerHTML = `
    <div class="page-container placeholder-view__content">
      <header class="placeholder-view__header">
        <p class="placeholder-view__eyebrow">${view.eyebrow}</p>
        <h1>${view.title}</h1>
        <p class="placeholder-view__copy">${view.description}</p>
      </header>
      <aside class="placeholder-view__selectors" aria-label="Explore Numora">
        <section class="placeholder-view__selector card">
          <div>
            <p class="placeholder-view__eyebrow">Explore Numora</p>
            <h2>Choose an experience</h2>
          </div>
          <nav class="placeholder-view__links" aria-label="Learning experiences">
            ${placeholderNavigation.map((item) => `
              <a href="${item.route}" data-route-link data-route="${item.route}" ${item.route === route ? "aria-current=\"page\"" : ""}>${item.label}</a>
            `).join("")}
          </nav>
        </section>
      </aside>
      <section class="placeholder-view__workspace card" aria-labelledby="${route.replace(/[^a-z]/g, "") || "not-found"}-workspace-title">
        <p class="placeholder-view__eyebrow">Coming next</p>
        <h2 id="${route.replace(/[^a-z]/g, "") || "not-found"}-workspace-title">This space is being prepared.</h2>
        <p>${view.description}</p>
        <a class="button button--primary" href="#/decision" data-route-link data-route="#/decision">Try Decision Lab</a>
      </section>
    </div>
  `;
  return section;
}

function renderView(mainElement, route, callbacks) {
  mainElement.firstElementChild?.destroy?.();
  if (authenticationRoutes.has(route)) {
    mainElement.replaceChildren(createAuthenticationView(route, callbacks));
    document.title = route === "#/signup" ? "Create Account · Numora" : "Sign In · Numora";
    return;
  }

  if (route === "/") {
    mainElement.replaceChildren(createHomeView());
    document.title = "Numora";
    return;
  }

  if (route === "#/decision") {
    mainElement.replaceChildren(createDecisionLabView());
    document.title = "Decision Lab · Numora";
    return;
  }

  if (route === "#/quant") {
    mainElement.replaceChildren(createQuantLabView());
    document.title = "Quant Lab · Numora";
    return;
  }

  if (route === "#/simulation") {
    mainElement.replaceChildren(createSimulationLabView());
    document.title = "Simulation Lab · Numora";
    return;
  }

  if (route === "#/arcade") {
    mainElement.replaceChildren(createArcadeView());
    document.title = "Arcade · Numora";
    return;
  }

  if (route === "#/dashboard") {
    mainElement.replaceChildren(createDashboardView());
    document.title = "Dashboard · Numora";
    return;
  }

  if (route === "#/ai-test") {
    mainElement.replaceChildren(createAiConnectionTestView());
    document.title = "Gemini Connection Test · Numora";
    return;
  }

  if (route === "#/leaderboard") {
    mainElement.replaceChildren(createLeaderboardView());
    document.title = "Weekly Leaderboard · Numora";
    return;
  }

  const view = views[route] ?? {
    eyebrow: "Not Found",
    title: "That page is not here",
    description: "Choose a destination from the navigation to continue."
  };
  mainElement.replaceChildren(createPlaceholderView(view, route));
  document.title = view.title === "Numora" ? "Numora" : `${view.title} · Numora`;
}

function initializeApplication() {
  initializeRewardNotifications();
  startEconomySynchronization();
  const elements = getApplicationElements();
  let header;
  let lastRenderedRoute = null;
  let lastRenderedAccessState = null;

  const getAccessState = (state) => [
    state.authStatus,
    state.user?.id ?? "anonymous",
    state.user?.gradeLevel ?? ""
  ].join(":");

  const createOrRefreshHeader = (currentRoute) => {
    header?.destroy();
    header = createHeader(elements["app-header"], {
      currentRoute,
      onRouteChange: updateApplication,
      onSignOut: async () => {
        await signOut();
        navigateToRoute("/", updateApplication);
      }
    });
  };

  const updateApplication = ({ force = false } = {}) => {
    let route = getCurrentRoute();
    const state = getAppState();
    const accessState = getAccessState(state);

    if (protectedRoutes.has(route) && state.authStatus === "checking") {
      if (state.user && route === lastRenderedRoute) {
        header?.update(route);
        return;
      }

      if (force || route !== lastRenderedRoute || accessState !== lastRenderedAccessState) {
        elements["app-main"].firstElementChild?.destroy?.();
        elements["app-main"].replaceChildren(createSessionCheckingView());
        document.title = route === "#/decision"
          ? "Decision Lab · Numora"
          : route === "#/quant"
            ? "Quant Lab · Numora"
          : route === "#/simulation"
            ? "Simulation Lab · Numora"
            : route === "#/arcade"
              ? "Arcade · Numora"
            : route === "#/leaderboard"
              ? "Weekly Leaderboard · Numora"
            : "Dashboard · Numora";
        lastRenderedRoute = route;
        lastRenderedAccessState = accessState;
      }
      header?.update(route);
      return;
    }

    if (protectedRoutes.has(route) && state.authStatus !== "authenticated") {
      setPostAuthRoute(route);
      route = redirectToSignIn();
    }

    if (force || route !== lastRenderedRoute || accessState !== lastRenderedAccessState) {
      renderView(elements["app-main"], route, {
        onNavigate: (nextRoute) => navigateToRoute(nextRoute, updateApplication),
        onAuthenticated: () => navigateToRoute(consumePostAuthRoute() ?? "/", updateApplication)
      });
      lastRenderedRoute = route;
      lastRenderedAccessState = accessState;
    }
    header?.update(route);
  };

  elements["app-main"].addEventListener("click", (event) => {
    if (!(event.target instanceof Element)) {
      return;
    }

    const routeLink = event.target.closest("[data-route-link]");
    if (routeLink) {
      event.preventDefault();
      navigateToRoute(routeLink.dataset.route, updateApplication);
    }
  });

  subscribeToAppState(() => {
    createOrRefreshHeader(getCurrentRoute());
    updateApplication();
  });

  createOrRefreshHeader(getCurrentRoute());
  updateApplication({ force: true });
  window.addEventListener("hashchange", updateApplication);
  window.addEventListener("popstate", updateApplication);
  void initializeAuthentication({
    onPasswordRecovery: updateApplication
  });
  console.info("Numora initialized successfully.");
}

initializeApplication();
