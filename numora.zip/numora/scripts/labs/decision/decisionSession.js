import { displayReward } from "../../services/rewardDisplay.js";
const storagePrefix = "numora:decision-session:v1";
const sessionVersion = 1;

export const decisionRewardValues = Object.freeze({
  get correctXp() { return displayReward("decision_correct").xp; },
  get hintCoinCost() { return Math.abs(displayReward("decision_hint").coins); }
});

const eventSuffixes = Object.freeze({
  correct: "correct",
  incorrect: "incorrect",
  hint: "hint"
});

function getSessionStorage() {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
}

function getStorageKey(userId) {
  return `${storagePrefix}:${userId}`;
}

function isSafeKeySegment(value) {
  return /^[a-z0-9][a-z0-9-]{1,120}$/.test(value ?? "");
}

export function createDecisionActivityId() {
  const randomId = globalThis.crypto?.randomUUID?.().replaceAll("-", "")
    ?? `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 14)}`;

  return `s${randomId.toLowerCase()}`;
}

export function createDecisionEventKey({ activityId, questionId, outcome }) {
  const suffix = eventSuffixes[outcome];

  if (!isSafeKeySegment(activityId) || !isSafeKeySegment(questionId) || !suffix) {
    throw new Error("Decision activity details are invalid.");
  }

  return `decision:${activityId}:${questionId}:${suffix}`;
}

export function loadDecisionLabSession(userId) {
  if (!userId) {
    return null;
  }

  try {
    const storedSession = getSessionStorage()?.getItem(getStorageKey(userId));
    if (!storedSession) {
      return null;
    }

    const parsedSession = JSON.parse(storedSession);
    return parsedSession?.version === sessionVersion ? parsedSession : null;
  } catch {
    return null;
  }
}

export function saveDecisionLabSession(userId, session) {
  if (!userId) {
    return;
  }

  const sessionStorage = getSessionStorage();
  if (!sessionStorage) {
    return;
  }

  const persistedSession = {
    version: sessionVersion,
    activityId: session.activityId,
    gradeLevel: session.gradeLevel,
    contentVersion: session.contentVersion,
    module: session.module,
    queue: session.queue,
    position: session.position,
    questionId: session.questionId,
    selectedOption: session.selectedOption,
    isChecked: session.isChecked,
    hintVisible: session.hintVisible,
    sessionComplete: session.sessionComplete,
    checkedPositions: session.checkedPositions,
    completedAnswerKeys: session.completedAnswerKeys,
    purchasedHintKeys: session.purchasedHintKeys,
    summary: session.summary
  };

  try {
    sessionStorage.setItem(getStorageKey(userId), JSON.stringify(persistedSession));
  } catch {
    // The lab remains usable when browser storage is unavailable.
  }
}
