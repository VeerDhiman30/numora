import { decisionModules, gradeLevels, getAvailableModules } from "../../data/decision/questions.js";
import { decisionRewardValues } from "./decisionSession.js";

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

function renderEvidence(evidence, advanced = false) {
  return evidence.map((item) => {
    if (item.type === "table") {
      const wide = advanced && item.columns.length >= 4;
      const headings = item.columns.map((column) => `<th scope="col">${escapeHtml(column)}</th>`).join("");
      const rows = item.rows.map((row) => (
        `<tr>${row.map((cell) => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`
      )).join("");
      return `
        <article class="decision-evidence-card decision-evidence-card--table">
          <h3>${escapeHtml(item.title)}</h3>
          ${wide ? '<p class="decision-table-scroll-hint">Swipe or scroll to see all columns.</p>' : ""}
          <div class="decision-table-wrap${wide ? ' decision-table-wrap--wide' : ''}" ${wide ? `style="--table-columns:${item.columns.length}" tabindex="0" role="region" aria-label="${escapeHtml(item.title)} — scrollable data table"` : ""}>
            <table>
              <thead><tr>${headings}</tr></thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
        </article>
      `;
    }

    if (item.type === "comparison") {
      return `
        <article class="decision-evidence-card decision-evidence-card--comparison">
          <p class="decision-evidence-card__label">${escapeHtml(item.label)}</p>
          <div class="decision-evidence-comparison">
            ${item.items.map((entry) => `<span><strong>${escapeHtml(entry.value)}</strong>${escapeHtml(entry.label)}</span>`).join("")}
          </div>
        </article>
      `;
    }

    return `
      <article class="decision-evidence-card decision-evidence-card--${escapeHtml(item.type)}">
        <p class="decision-evidence-card__label">${escapeHtml(item.label)}</p>
        <strong>${escapeHtml(item.value)}</strong>
        <p>${escapeHtml(item.description)}</p>
      </article>
    `;
  }).join("");
}

function renderConfidenceData(confidenceData) {
  if (!confidenceData) {
    return "";
  }

  return `
    <aside class="decision-confidence" aria-label="${escapeHtml(confidenceData.title)}">
      <div>
        <p class="decision-confidence__eyebrow">${escapeHtml(confidenceData.title)}</p>
        <p>${escapeHtml(confidenceData.prompt)}</p>
      </div>
      <div class="decision-confidence__bars" aria-hidden="true">
        ${confidenceData.bars.map((bar) => `
          <div class="decision-confidence__bar-row">
            <span>${escapeHtml(bar.label)}</span>
            <div><span style="width: ${Math.max(0, Math.min(Number(bar.value) || 0, 100))}%"></span></div>
            <strong>${escapeHtml(bar.display ?? `${bar.value}%`)}</strong>
          </div>
        `).join("")}
      </div>
    </aside>
  `;
}

function renderFeedback(question, session) {
  if (!session.isChecked) {
    return `<div class="decision-feedback" aria-live="polite" aria-atomic="true"></div>`;
  }

  const isCorrect = session.selectedOption === question.correctOption;
  const heading = isCorrect ? "Evidence supports your decision." : "A stronger decision is available.";
  const guidance = isCorrect
    ? "You selected the choice most supported by the evidence."
    : question.incorrectGuidance;

  return `
    <section class="decision-feedback decision-feedback--${isCorrect ? "correct" : "review"}" aria-live="polite" aria-atomic="true" tabindex="-1" data-decision-feedback>
      <p class="decision-feedback__status">${isCorrect ? "✓ Decision checked: supported by the evidence." : "↗ Decision checked: review the evidence again."}</p>
      <h2>${escapeHtml(heading)}</h2>
      <p>${escapeHtml(guidance)}</p>
      <div class="decision-feedback__explanation">
        <strong>Why this works</strong>
        <p>${escapeHtml(question.explanation)}</p>
        ${question.solutionSteps?.length ? `<ol class="decision-solution-steps">${question.solutionSteps.map(step => `<li>${escapeHtml(step)}</li>`).join("")}</ol>` : ""}
      </div>
      <div class="decision-concepts" aria-label="Math concepts used">
        ${question.mathConcepts.map((concept) => `<span class="badge">${escapeHtml(concept)}</span>`).join("")}
      </div>
    </section>
  `;
}

function renderHint(question, session) {
  const hintAction = session.hintVisible
    ? "Hide hint"
    : session.isUnlockingHint
      ? "Unlocking hint…"
      : session.purchasedHintKeys.some((key) => key.endsWith(`:${question.id}:hint`))
        ? "Show hint"
        : `Unlock hint · −${decisionRewardValues.hintCoinCost} coins`;

  return `
    <div class="decision-hint-wrap">
      <button class="button button--ghost decision-hint-toggle" type="button" data-decision-hint aria-expanded="${session.hintVisible}" ${session.isUnlockingHint ? "disabled aria-busy=\"true\"" : ""}>
        ${hintAction}
      </button>
      ${session.hintVisible ? `<aside class="decision-hint" aria-live="polite"><strong>Hint</strong><p>${escapeHtml(question.hint)}</p></aside>` : ""}
    </div>
  `;
}

function renderRewardFeedback(session) {
  if (!session.rewardFeedback) {
    return `<div class="decision-reward-feedback" aria-live="polite" aria-atomic="true"></div>`;
  }

  return `
    <div class="decision-reward-feedback decision-reward-feedback--${escapeHtml(session.rewardFeedback.tone)}" aria-live="polite" aria-atomic="true" role="status">
      ${escapeHtml(session.rewardFeedback.message)}
    </div>
  `;
}

function renderSessionSummary(session, question) {
  const summary = session.summary;
  const accuracy = summary.decisionsCompleted
    ? Math.round((summary.correctDecisions / summary.decisionsCompleted) * 100)
    : 0;
  const topics = summary.topics.length ? summary.topics : [question.module];

  return `
    <section class="decision-session-summary card" tabindex="-1" data-decision-summary aria-labelledby="decision-session-summary-title">
      <p class="decision-section-heading__eyebrow">Session complete</p>
      <h2 id="decision-session-summary-title">Evidence practice, wrapped up.</h2>
      <p>Nice work turning numbers into thoughtful choices. Your permanent XP and progress are saved to your Numora account.</p>
      <dl class="decision-session-summary__stats">
        <div><dt>Decisions completed</dt><dd>${summary.decisionsCompleted}</dd></div>
        <div><dt>Correct decisions</dt><dd>${summary.correctDecisions}</dd></div>
        <div><dt>Accuracy</dt><dd>${accuracy}%</dd></div>
        <div><dt>XP earned</dt><dd>+${summary.xpEarned}</dd></div>
      </dl>
      <p class="decision-session-summary__topics"><strong>Topics practiced</strong>${topics.map((topic) => `<span class="badge">${escapeHtml(topic)}</span>`).join("")}</p>
      <div class="decision-actions decision-session-summary__actions">
        <button class="button button--primary" type="button" data-decision-practice-again>Practice Again</button>
        <button class="button button--secondary" type="button" data-decision-choose-module>Choose Another Module</button>
        <button class="button button--ghost" type="button" data-decision-back-home>Back to Home</button>
      </div>
    </section>
  `;
}

function renderGradeSelector(session) {
  return `
    <section class="decision-selector" aria-labelledby="decision-grade-title">
      <div class="decision-selector__heading">
        <p class="decision-selector__eyebrow">Learning level</p>
        <h2 id="decision-grade-title">Choose a lens</h2>
      </div>
      <div class="decision-grade-list" role="group" aria-label="Decision Lab grade level">
        ${gradeLevels.map((grade) => `
          <button class="decision-grade-button${session.gradeLevel === grade.id ? " is-selected" : ""}" type="button" data-decision-grade="${grade.id}" aria-pressed="${session.gradeLevel === grade.id}">
            <span>${escapeHtml(grade.title)}</span>
            <small>${escapeHtml(grade.description)}</small>
          </button>
        `).join("")}
      </div>
    </section>
  `;
}

function renderModuleSelector(session) {
  const availableModules = getAvailableModules(session.gradeLevel);

  return `
    <section class="decision-selector" aria-labelledby="decision-module-title">
      <div class="decision-selector__heading">
        <p class="decision-selector__eyebrow">Decision setting</p>
        <h2 id="decision-module-title">Choose a module</h2>
      </div>
      <div class="decision-module-list" role="group" aria-label="Decision Lab module">
        ${decisionModules.map((module) => {
          const isAvailable = availableModules.has(module.id);
          const isSelected = session.module === module.id;
          return `
            <button class="decision-module-button${isSelected ? " is-selected" : ""}" type="button" data-decision-module="${module.id}" aria-pressed="${isSelected}" ${isAvailable ? "" : "disabled aria-disabled=\"true\""}>
              <span class="decision-module-button__glyph" aria-hidden="true">${escapeHtml(module.glyph)}</span>
              <span>
                <strong>${escapeHtml(module.title)}</strong>
                <small>${isAvailable ? escapeHtml(module.description) : "Starter decision coming soon"}</small>
              </span>
            </button>
          `;
        }).join("")}
      </div>
    </section>
  `;
}

export function renderDecisionLab(root, session, {
  question,
  questionIndex,
  questionCount,
  onGradeChange,
  onModuleChange,
  onChoiceChange,
  onHintToggle,
  onCheckDecision,
  onNextDecision,
  onPracticeAgain,
  onChooseAnotherModule,
  onBackHome
}) {
  const selectedChoice = question.options.find((option) => option.id === session.selectedOption);
  const selectedDescription = selectedChoice ? `${selectedChoice.label} selected.` : "No decision selected yet.";
  const module = decisionModules.find((item) => item.id === question.module);
  const nextLabel = questionIndex === questionCount - 1 && session.isChecked
      ? "Finish session"
      : "Next Decision";
  const workspace = session.sessionComplete
    ? renderSessionSummary(session, question)
    : `
      <div class="decision-lab__read-column">
        <section class="decision-scenario card" aria-labelledby="decision-scenario-title">
          <div class="decision-scenario__meta">
            <span class="badge decision-scenario__module">${escapeHtml(module.title)}</span>
            <span>${escapeHtml(question.contextualBadge)}</span>
          </div>
          <h2 id="decision-scenario-title">${escapeHtml(question.title)}</h2>
          <p class="decision-scenario__story">${escapeHtml(question.scenario)}</p>
          ${question.assumptions?.length ? `<div class="decision-assumptions"><h3>Rules for this decision</h3><ul>${question.assumptions.map(rule => `<li>${escapeHtml(rule)}</li>`).join("")}</ul></div><p class="decision-task-label">Your task</p>` : ""}
          <p class="decision-scenario__question">${escapeHtml(question.question)}</p>
        </section>

        <section class="decision-evidence" aria-labelledby="decision-evidence-title">
          <div class="decision-section-heading">
            <p class="decision-section-heading__eyebrow">Inspect the evidence</p>
            <h2 id="decision-evidence-title">What do the numbers show?</h2>
          </div>
          <div class="decision-evidence-grid">
            ${renderEvidence(question.evidence, question.gradeLevel === "high")}
          </div>
        </section>

        ${renderConfidenceData(question.confidenceData)}
      </div>

      <aside class="decision-lab__decision-column" aria-labelledby="decision-choice-title">
        <section class="decision-choices card">
          <div class="decision-section-heading">
            <p class="decision-section-heading__eyebrow">Make your call</p>
            <h2 id="decision-choice-title">Which decision best uses the evidence?</h2>
          </div>
          <form data-decision-form aria-busy="${session.isSavingDecision}">
            <fieldset ${session.isChecked || session.isSavingDecision ? "disabled" : ""}>
              <legend class="sr-only">Decision choices</legend>
              <div class="decision-choice-list">
                ${question.options.map((option) => {
                  const isSelected = session.selectedOption === option.id;
                  const isCorrectOption = session.isChecked && option.id === question.correctOption;
                  const isIncorrectSelected = session.isChecked && isSelected && option.id !== question.correctOption;
                  const status = isCorrectOption
                    ? "Best-supported choice"
                    : isIncorrectSelected
                      ? "Your choice"
                      : isSelected
                        ? "Selected"
                        : "";
                  return `
                    <label class="decision-choice${isSelected ? " is-selected" : ""}${isCorrectOption ? " is-correct" : ""}${isIncorrectSelected ? " is-incorrect" : ""}">
                      <input type="radio" name="decision-choice" value="${escapeHtml(option.id)}" ${isSelected ? "checked" : ""}>
                      <span class="decision-choice__marker" aria-hidden="true"></span>
                      <span class="decision-choice__copy"><strong>${escapeHtml(option.label)}</strong>${option.description ? `<small>${escapeHtml(option.description)}</small>` : ""}</span>
                      <span class="decision-choice__status">${status}</span>
                    </label>
                  `;
                }).join("")}
              </div>
            </fieldset>
            <p class="decision-choice__selection" aria-live="polite">${escapeHtml(selectedDescription)}</p>
            ${renderHint(question, session)}
            ${renderRewardFeedback(session)}
            <div class="decision-actions">
              <button class="button button--primary" type="submit" ${session.selectedOption && !session.isChecked && !session.isSavingDecision ? "" : "disabled"}>
                ${session.isSavingDecision ? "Saving decision…" : "Check Decision"}
              </button>
              <button class="button button--secondary" type="button" data-next-decision ${session.isChecked ? "" : "disabled"}>${nextLabel}</button>
            </div>
          </form>
        </section>
        ${renderFeedback(question, session)}
      </aside>
    `;

  root.innerHTML = `
    <div class="page-container decision-lab__container">
      <header class="decision-lab__header">
        <div>
          <p class="decision-lab__eyebrow">Think with evidence</p>
          <h1>Decision Lab</h1>
          <p>Use mathematics, context, and evidence to choose the next move—not just the fastest answer.</p>
        </div>
        <div class="decision-progress" aria-label="Session progress">
          <span>Decision ${questionIndex + 1} of ${questionCount}</span>
          <div class="decision-progress__track" role="progressbar" aria-valuemin="1" aria-valuemax="${questionCount}" aria-valuenow="${questionIndex + 1}" aria-valuetext="Decision ${questionIndex + 1} of ${questionCount}">
            <span style="width: ${((questionIndex + 1) / questionCount) * 100}%"></span>
          </div>
          ${session.sessionComplete ? "<p class=\"decision-progress__complete\">Session complete — begin a new set when you’re ready.</p>" : ""}
        </div>
      </header>

      <aside class="decision-lab__selectors" aria-label="Decision Lab settings">
        ${renderGradeSelector(session)}
        ${renderModuleSelector(session)}
      </aside>

      <div class="decision-lab__workspace">
        ${workspace}
      </div>
    </div>
  `;

  root.querySelectorAll("[data-decision-grade]").forEach((button) => {
    button.addEventListener("click", () => onGradeChange(button.dataset.decisionGrade));
  });
  root.querySelectorAll("[data-decision-module]").forEach((button) => {
    button.addEventListener("click", () => onModuleChange(button.dataset.decisionModule));
  });
  root.querySelectorAll("input[name=decision-choice]").forEach((input) => {
    input.addEventListener("change", () => onChoiceChange(input.value));
  });
  root.querySelector("[data-decision-hint]")?.addEventListener("click", onHintToggle);
  root.querySelector("[data-decision-form]")?.addEventListener("submit", (event) => {
    event.preventDefault();
    onCheckDecision();
  });
  root.querySelector("[data-next-decision]")?.addEventListener("click", onNextDecision);
  root.querySelector("[data-decision-practice-again]")?.addEventListener("click", onPracticeAgain);
  root.querySelector("[data-decision-choose-module]")?.addEventListener("click", onChooseAnotherModule);
  root.querySelector("[data-decision-back-home]")?.addEventListener("click", onBackHome);

  if (session.sessionComplete) {
    root.querySelector("[data-decision-summary]")?.focus();
  } else if (session.isChecked) {
    root.querySelector("[data-decision-feedback]")?.focus();
  }
}
