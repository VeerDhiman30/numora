import {
  decisionSessionLength,
  decisionContentVersions,
  getAvailableModules,
  getQuestionsForDecisionLab,
  gradeLevels
} from "../../data/decision/questions.js";
import { getAppState } from "../../services/appState.js";
import { recordActivity } from "../../services/rewardService.js";
import { renderDecisionLab } from "./decisionRenderer.js";
import {
  createDecisionActivityId,
  createDecisionEventKey,
  decisionRewardValues,
  loadDecisionLabSession,
  saveDecisionLabSession
} from "./decisionSession.js";

function isSupportedGrade(gradeLevel) {
  return gradeLevels.some((grade) => grade.id === gradeLevel);
}

function getFirstAvailableModule(gradeLevel) {
  return [...getAvailableModules(gradeLevel)][0] ?? null;
}

function shuffleQuestionIds(questions, previousId) {
  const ids = questions.map((item) => item.id);

  for (let index = ids.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [ids[index], ids[swapIndex]] = [ids[swapIndex], ids[index]];
  }

  if (ids.length > 1 && ids[0] === previousId) {
    [ids[0], ids[1]] = [ids[1], ids[0]];
  }

  return ids;
}

function createSessionQueue(questions, previousId = null) {
  if (!questions.length) {
    return [];
  }

  const queue = [];
  let lastId = previousId;

  while (queue.length < decisionSessionLength) {
    const round = shuffleQuestionIds(questions, lastId);
    const remaining = decisionSessionLength - queue.length;
    const nextIds = round.slice(0, remaining);
    queue.push(...nextIds);
    lastId = queue.at(-1) ?? lastId;
  }

  return queue;
}

function createEmptySummary() {
  return {
    decisionsCompleted: 0,
    correctDecisions: 0,
    xpEarned: 0,
    topics: []
  };
}

function isValidSummary(summary) {
  return Number.isInteger(summary?.decisionsCompleted)
    && summary.decisionsCompleted >= 0
    && Number.isInteger(summary?.correctDecisions)
    && summary.correctDecisions >= 0
    && Number.isInteger(summary?.xpEarned)
    && summary.xpEarned >= 0
    && Array.isArray(summary?.topics)
    && summary.topics.every((topic) => typeof topic === "string");
}

function getPersistedSession(userId) {
  const storedSession = loadDecisionLabSession(userId);

  if (!storedSession
    || !isSupportedGrade(storedSession.gradeLevel)
    || (storedSession.contentVersion ?? 1) !== decisionContentVersions[storedSession.gradeLevel]
    || typeof storedSession.module !== "string"
    || typeof storedSession.activityId !== "string"
    || !Array.isArray(storedSession.queue)
    || !Number.isInteger(storedSession.position)
    || !isValidSummary(storedSession.summary)) {
    return null;
  }

  const questions = getQuestionsForDecisionLab(storedSession.gradeLevel, storedSession.module);
  const validQuestionIds = new Set(questions.map((question) => question.id));
  const hasValidQueue = storedSession.queue.length === decisionSessionLength
    && storedSession.queue.every((questionId) => validQuestionIds.has(questionId));
  const hasValidPosition = storedSession.position >= 0 && storedSession.position < storedSession.queue.length;

  if (!hasValidQueue || !hasValidPosition || storedSession.questionId !== storedSession.queue[storedSession.position]) {
    return null;
  }

  return {
    ...storedSession,
    selectedOption: typeof storedSession.selectedOption === "string" ? storedSession.selectedOption : null,
    isChecked: Boolean(storedSession.isChecked),
    hintVisible: Boolean(storedSession.hintVisible),
    sessionComplete: Boolean(storedSession.sessionComplete),
    checkedPositions: Array.isArray(storedSession.checkedPositions)
      ? storedSession.checkedPositions.filter((position) => Number.isInteger(position) && position >= 0 && position < decisionSessionLength)
      : [],
    completedAnswerKeys: Array.isArray(storedSession.completedAnswerKeys) ? storedSession.completedAnswerKeys : [],
    purchasedHintKeys: Array.isArray(storedSession.purchasedHintKeys) ? storedSession.purchasedHintKeys : [],
    summary: {
      ...storedSession.summary,
      topics: [...new Set(storedSession.summary.topics)]
    },
    isSavingDecision: false,
    isUnlockingHint: false,
    rewardFeedback: null
  };
}

export function createDecisionLabView() {
  const appState = getAppState();
  const userId = appState.user?.id;
  const profileGrade = appState.user?.gradeLevel;
  const gradeLevel = isSupportedGrade(profileGrade) ? profileGrade : "middle";
  const root = document.createElement("section");
  const session = getPersistedSession(userId) ?? {
    activityId: createDecisionActivityId(),
    gradeLevel,
    contentVersion: decisionContentVersions[gradeLevel],
    module: getFirstAvailableModule(gradeLevel),
    queue: [],
    position: 0,
    questionId: null,
    selectedOption: null,
    isChecked: false,
    hintVisible: false,
    sessionComplete: false,
    isSavingDecision: false,
    isUnlockingHint: false,
    checkedPositions: [],
    completedAnswerKeys: [],
    purchasedHintKeys: [],
    rewardFeedback: null,
    summary: createEmptySummary()
  };

  function resetAnswerState() {
    session.selectedOption = null;
    session.isChecked = false;
    session.hintVisible = false;
    session.isSavingDecision = false;
    session.isUnlockingHint = false;
    session.rewardFeedback = null;
  }

  function saveSession() {
    saveDecisionLabSession(userId, session);
  }

  function resetSession(module, previousQuestionId = null) {
    const questions = getQuestionsForDecisionLab(session.gradeLevel, module);
    session.activityId = createDecisionActivityId();
    session.module = module;
    session.contentVersion = decisionContentVersions[session.gradeLevel];
    session.queue = createSessionQueue(questions, previousQuestionId);
    session.position = 0;
    session.questionId = session.queue[0] ?? null;
    session.sessionComplete = false;
    session.checkedPositions = [];
    session.completedAnswerKeys = [];
    session.purchasedHintKeys = [];
    session.summary = createEmptySummary();
    resetAnswerState();
    saveSession();
  }

  function getCurrentQuestion() {
    return getQuestionsForDecisionLab(session.gradeLevel, session.module)
      .find((item) => item.id === session.questionId) ?? null;
  }

  function render() {
    const question = getCurrentQuestion();

    if (!question) {
      root.innerHTML = "<div class=\"page-container\"><p>Decision Lab is preparing a question set.</p></div>";
      return;
    }

    renderDecisionLab(root, session, {
      question,
      questionIndex: session.position,
      questionCount: decisionSessionLength,
      onGradeChange: (nextGrade) => {
        if (!isSupportedGrade(nextGrade) || nextGrade === session.gradeLevel) {
          return;
        }

        session.gradeLevel = nextGrade;
        resetSession(getFirstAvailableModule(nextGrade), question.id);
        render();
      },
      onModuleChange: (nextModule) => {
        if (!getAvailableModules(session.gradeLevel).has(nextModule) || nextModule === session.module) {
          return;
        }

        resetSession(nextModule, question.id);
        render();
      },
      onChoiceChange: (choiceId) => {
        if (session.isChecked || !question.options.some((option) => option.id === choiceId)) {
          return;
        }

        session.selectedOption = choiceId;
        session.rewardFeedback = null;
        saveSession();
        render();
      },
      onHintToggle: async () => {
        if (session.isUnlockingHint) {
          return;
        }

        const hintKey = createDecisionEventKey({
          activityId: session.activityId,
          questionId: question.id,
          outcome: "hint"
        });

        if (session.hintVisible) {
          session.hintVisible = false;
          saveSession();
          render();
          return;
        }

        if (session.purchasedHintKeys.includes(hintKey)) {
          session.hintVisible = true;
          session.rewardFeedback = { tone: "hint", message: "Hint unlocked · already purchased" };
          saveSession();
          render();
          return;
        }

        const coins = getAppState().coins;
        if (Number.isInteger(coins) && coins < decisionRewardValues.hintCoinCost) {
          session.rewardFeedback = {
            tone: "error",
            message: `You need ${decisionRewardValues.hintCoinCost} coins to use this hint.`
          };
          render();
          return;
        }

        if (typeof window !== "undefined" && !window.confirm(`Use ${decisionRewardValues.hintCoinCost} coins to unlock this hint?`)) {
          return;
        }

        session.isUnlockingHint = true;
        session.rewardFeedback = null;
        render();

        try {
          const result = await recordActivity({
            eventKey: hintKey,
            module: "decision",
            topic: question.module,
            activityType: "hint",
            metadata: {
              activity_id: session.activityId,
              question_id: question.id,
              grade_level: session.gradeLevel
            }
          });

          if (!session.purchasedHintKeys.includes(hintKey)) {
            session.purchasedHintKeys.push(hintKey);
          }
          session.hintVisible = true;
          session.rewardFeedback = {
            tone: "hint",
            message: result.eventRecorded ? `Hint unlocked · −${decisionRewardValues.hintCoinCost} coins` : "Hint unlocked · already purchased"
          };
        } catch (error) {
          session.rewardFeedback = { tone: "error", message: error.message };
        } finally {
          session.isUnlockingHint = false;
          saveSession();
          render();
        }
      },
      onCheckDecision: async () => {
        if (!session.selectedOption || session.isChecked || session.isSavingDecision) {
          return;
        }

        const isCorrect = session.selectedOption === question.correctOption;
        const outcome = isCorrect ? "correct" : "incorrect";
        const answerKey = createDecisionEventKey({
          activityId: session.activityId,
          questionId: question.id,
          outcome
        });

        session.isSavingDecision = true;
        session.rewardFeedback = null;
        render();

        try {
          const result = await recordActivity({
            eventKey: answerKey,
            module: "decision",
            topic: question.module,
            activityType: isCorrect ? "correct_answer" : "incorrect_answer",
            metadata: {
              activity_id: session.activityId,
              question_id: question.id,
              grade_level: session.gradeLevel,
              selected_option: session.selectedOption
            }
          });

          if (!session.checkedPositions.includes(session.position)) {
            session.checkedPositions.push(session.position);
            session.summary.decisionsCompleted += 1;
            if (isCorrect) {
              session.summary.correctDecisions += 1;
            }
            if (!session.summary.topics.includes(question.module)) {
              session.summary.topics.push(question.module);
            }
          }

          if (!session.completedAnswerKeys.includes(answerKey)) {
            session.completedAnswerKeys.push(answerKey);
            if (isCorrect) {
              session.summary.xpEarned += decisionRewardValues.correctXp;
            }
          }

          session.isChecked = true;
          session.rewardFeedback = isCorrect
            ? {
              tone: "reward",
              message: result.eventRecorded
                ? `Correct! +${decisionRewardValues.correctXp} XP`
                : `Correct! +${decisionRewardValues.correctXp} XP already saved`
            }
            : { tone: "neutral", message: "Decision saved. Use the explanation to strengthen your next call." };
        } catch (error) {
          session.rewardFeedback = { tone: "error", message: error.message };
        } finally {
          session.isSavingDecision = false;
          saveSession();
          render();
        }
      },
      onNextDecision: () => {
        if (session.sessionComplete) {
          resetSession(session.module, question.id);
          render();
          return;
        }
        if (!session.isChecked) {
          return;
        }

        if (session.position === decisionSessionLength - 1) {
          session.sessionComplete = true;
          saveSession();
          render();
          return;
        }

        session.position += 1;
        session.questionId = session.queue[session.position];
        resetAnswerState();
        saveSession();
        render();
      },
      onPracticeAgain: () => {
        resetSession(session.module, question.id);
        render();
      },
      onChooseAnotherModule: () => {
        root.querySelector("[data-decision-module]")?.focus();
      },
      onBackHome: () => {
        window.location.hash = "";
      }
    });
  }

  root.className = "decision-lab section";
  root.dataset.labSession = "active";
  if (!session.queue.length) {
    resetSession(session.module);
  } else {
    saveSession();
  }
  render();
  return root;
}
