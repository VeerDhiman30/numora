function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

function getItemsById(items = []) {
  return new Map(items.map((item) => [item.id, item]));
}

function renderResetControl() {
  return `<button class="button button--ghost quant-interactive__reset" type="button" data-quant-interactive-reset>Reset activity</button>`;
}

function renderDragDrop(question, session) {
  const response = session.response ?? { selectedItem: null, placements: {} };
  const itemsById = getItemsById(question.items);
  const placedItemIds = new Set(Object.values(response.placements ?? {}));
  const sourceItems = (question.items ?? []).filter((item) => !placedItemIds.has(item.id));

  return `
    <section class="quant-interactive quant-drag-drop" data-quant-drag-drop data-selected-item="${escapeHtml(response.selectedItem ?? "")}" aria-label="Drag and drop activity">
      <p class="quant-interactive__guide">Select an item, then select its destination. You can also drag an item to a destination.</p>
      <div class="quant-drag-drop__sources" aria-label="Items to place">
        ${sourceItems.map((item) => `
          <button class="quant-interactive-item${response.selectedItem === item.id ? " is-selected" : ""}" type="button" draggable="true" data-quant-drag-item="${escapeHtml(item.id)}" aria-pressed="${response.selectedItem === item.id}">${escapeHtml(item.label)}</button>
        `).join("") || "<p class=\"quant-interactive__empty\">Every item has been placed. Select a placed item to move it.</p>"}
      </div>
      <div class="quant-drag-drop__targets" aria-label="Destinations">
        ${(question.targets ?? []).map((target) => {
          const placedItemId = response.placements?.[target.id];
          const placedItem = itemsById.get(placedItemId);
          const isCorrect = placedItemId === question.correctPlacements?.[target.id];
          const expectedItem = itemsById.get(question.correctPlacements?.[target.id]);
          const review = session.isChecked
            ? `<span class="quant-interactive__review">${isCorrect ? "Correct placement" : `Correct item: ${escapeHtml(expectedItem?.label ?? "")}`}</span>`
            : "";
          return `
            <div class="quant-drop-zone${placedItem ? " is-filled" : ""}${session.isChecked ? (isCorrect ? " is-correct" : " is-incorrect") : ""}" data-quant-drop-zone="${escapeHtml(target.id)}">
              <button class="quant-drop-zone__target" type="button" data-quant-drop-target="${escapeHtml(target.id)}" aria-label="Place selected item in ${escapeHtml(target.label)}">
                <span>${escapeHtml(target.label)}</span>
                <small>${placedItem ? "Select the placed item to move it." : "Select this destination to place your item."}</small>
              </button>
              ${placedItem ? `<button class="quant-interactive-item quant-interactive-item--placed" type="button" draggable="true" data-quant-drag-item="${escapeHtml(placedItem.id)}" aria-label="Move ${escapeHtml(placedItem.label)} from ${escapeHtml(target.label)}">${escapeHtml(placedItem.label)}</button>` : ""}
              ${review}
            </div>
          `;
        }).join("")}
      </div>
      ${renderResetControl()}
    </section>
  `;
}

function renderArrangeOrder(question, session) {
  const response = session.response ?? { order: [], hasInteracted: false };
  const itemsById = getItemsById(question.items);
  const correctOrder = question.correctOrder ?? [];

  return `
    <section class="quant-interactive quant-arrange-order" aria-label="Arrange items in order">
      <p class="quant-interactive__guide">Use the Move up and Move down buttons, or drag an item to a new position.</p>
      <ol class="quant-arrange-list">
        ${(response.order ?? []).map((itemId, index) => {
          const item = itemsById.get(itemId);
          const isCorrect = correctOrder[index] === itemId;
          const review = session.isChecked
            ? `<span class="quant-interactive__review">${isCorrect ? "Correct position" : `Should be position ${correctOrder.indexOf(itemId) + 1}`}</span>`
            : "";
          return `
            <li class="quant-arrange-item${session.isChecked ? (isCorrect ? " is-correct" : " is-incorrect") : ""}" draggable="true" data-quant-arrange-item="${escapeHtml(itemId)}">
              <span class="quant-arrange-item__number" aria-hidden="true">${index + 1}</span>
              <span class="quant-arrange-item__label">${escapeHtml(item?.label ?? "")}${review}</span>
              <span class="quant-arrange-item__controls">
                <button class="quant-icon-button" type="button" data-quant-arrange-move="up" data-quant-arrange-item-id="${escapeHtml(itemId)}" ${index === 0 ? "disabled" : ""} aria-label="Move ${escapeHtml(item?.label ?? "item")} up">↑</button>
                <button class="quant-icon-button" type="button" data-quant-arrange-move="down" data-quant-arrange-item-id="${escapeHtml(itemId)}" ${index === response.order.length - 1 ? "disabled" : ""} aria-label="Move ${escapeHtml(item?.label ?? "item")} down">↓</button>
              </span>
            </li>
          `;
        }).join("")}
      </ol>
      ${renderResetControl()}
    </section>
  `;
}

function renderMatching(question, session) {
  const response = session.response ?? { selectedLeft: null, pairs: {} };
  const leftById = getItemsById(question.leftItems);
  const rightById = getItemsById(question.rightItems);
  const pairedRightIds = new Set(Object.values(response.pairs ?? {}));

  return `
    <section class="quant-interactive quant-matching" data-quant-matching data-selected-left="${escapeHtml(response.selectedLeft ?? "")}" aria-label="Matching activity">
      <p class="quant-interactive__guide">Select an item on the left, then select its match on the right. Use Remove pairing to change a match.</p>
      <div class="quant-matching__columns">
        <div class="quant-matching__column" aria-label="Items to match">
          <p>Left side</p>
          ${(question.leftItems ?? []).map((item) => {
            const pairedRight = rightById.get(response.pairs?.[item.id]);
            const isCorrect = response.pairs?.[item.id] === question.matches?.[item.id];
            const review = session.isChecked && pairedRight
              ? `<span class="quant-interactive__review">${isCorrect ? "Correct pairing" : `Should match ${escapeHtml(rightById.get(question.matches?.[item.id])?.label ?? "")}`}</span>`
              : "";
            return `
              <button class="quant-match-card${response.selectedLeft === item.id ? " is-selected" : ""}${pairedRight ? " is-paired" : ""}${session.isChecked && pairedRight ? (isCorrect ? " is-correct" : " is-incorrect") : ""}" type="button" data-quant-match-left="${escapeHtml(item.id)}" aria-pressed="${response.selectedLeft === item.id}">
                <span>${escapeHtml(item.label)}</span>${pairedRight ? `<small>Matched with ${escapeHtml(pairedRight.label)}</small>` : ""}${review}
              </button>
            `;
          }).join("")}
        </div>
        <div class="quant-matching__column" aria-label="Possible matches">
          <p>Right side</p>
          ${(question.rightItems ?? []).map((item) => `
            <button class="quant-match-card${pairedRightIds.has(item.id) ? " is-paired" : ""}" type="button" data-quant-match-right="${escapeHtml(item.id)}" aria-label="Match selected left item with ${escapeHtml(item.label)}">${escapeHtml(item.label)}</button>
          `).join("")}
        </div>
      </div>
      <div class="quant-match-pairs" aria-live="polite">
        <p>Completed pairings</p>
        <ul>
          ${Object.entries(response.pairs ?? {}).map(([leftId, rightId]) => `
            <li><span>${escapeHtml(leftById.get(leftId)?.label ?? "")} ↔ ${escapeHtml(rightById.get(rightId)?.label ?? "")}</span><button type="button" data-quant-match-remove="${escapeHtml(leftId)}" aria-label="Remove pairing ${escapeHtml(leftById.get(leftId)?.label ?? "")} and ${escapeHtml(rightById.get(rightId)?.label ?? "")}">Remove pairing</button></li>
          `).join("") || "<li>No pairings yet.</li>"}
        </ul>
      </div>
      ${renderResetControl()}
    </section>
  `;
}

function renderCategorize(question, session) {
  const response = session.response ?? { selectedItem: null, placements: {} };
  const itemsById = getItemsById(question.items);
  const placedItemIds = new Set(Object.values(response.placements ?? {}).flat());
  const sourceItems = (question.items ?? []).filter((item) => !placedItemIds.has(item.id));

  return `
    <section class="quant-interactive quant-categorize" data-quant-categorize data-selected-item="${escapeHtml(response.selectedItem ?? "")}" aria-label="Categorize values activity">
      <p class="quant-interactive__guide">Select a value, then select its category. You can also drag a value to a category.</p>
      <div class="quant-categorize__sources" aria-label="Values to categorize">
        ${sourceItems.map((item) => `
          <button class="quant-interactive-item${response.selectedItem === item.id ? " is-selected" : ""}" type="button" draggable="true" data-quant-categorize-item="${escapeHtml(item.id)}" aria-pressed="${response.selectedItem === item.id}">${escapeHtml(item.label)}</button>
        `).join("") || "<p class=\"quant-interactive__empty\">Every value has been categorized. Select a placed value to move it.</p>"}
      </div>
      <div class="quant-categorize__categories" aria-label="Categories">
        ${(question.categories ?? []).map((category) => {
          const categoryItems = (response.placements?.[category.id] ?? []).map((itemId) => itemsById.get(itemId)).filter(Boolean);
          return `
            <div class="quant-category" data-quant-category-zone="${escapeHtml(category.id)}">
              <button class="quant-category__target" type="button" data-quant-category-target="${escapeHtml(category.id)}" aria-label="Place selected value in ${escapeHtml(category.label)}">${escapeHtml(category.label)}</button>
              <div class="quant-category__items">
                ${categoryItems.map((item) => {
                  const isCorrect = question.correctCategories?.[item.id] === category.id;
                  const review = session.isChecked
                    ? `<span class="quant-interactive__review">${isCorrect ? "Correct category" : `Correct category: ${escapeHtml((question.categories ?? []).find((itemCategory) => itemCategory.id === question.correctCategories?.[item.id])?.label ?? "")}`}</span>`
                    : "";
                  return `<button class="quant-interactive-item quant-interactive-item--placed${session.isChecked ? (isCorrect ? " is-correct" : " is-incorrect") : ""}" type="button" draggable="true" data-quant-categorize-item="${escapeHtml(item.id)}" aria-label="Move ${escapeHtml(item.label)} from ${escapeHtml(category.label)}">${escapeHtml(item.label)}${review}</button>`;
                }).join("")}
              </div>
            </div>
          `;
        }).join("")}
      </div>
      ${renderResetControl()}
    </section>
  `;
}

function renderFractionVisual(visual) {
  return `
    <svg class="quant-visual__svg" viewBox="0 0 300 170" role="img" aria-label="A fraction with ${escapeHtml(visual.numerator)} above the bar and ${escapeHtml(visual.denominator)} below it">
      <rect x="48" y="22" width="204" height="126" rx="18" fill="none" stroke="currentColor" opacity=".35" />
      <text x="150" y="76" text-anchor="middle" font-size="46" font-weight="700">${escapeHtml(visual.numerator)}</text>
      <line x1="94" y1="92" x2="206" y2="92" stroke="currentColor" stroke-width="4" stroke-linecap="round" />
      <text x="150" y="135" text-anchor="middle" font-size="46" font-weight="700">${escapeHtml(visual.denominator)}</text>
    </svg>
  `;
}

function renderCoordinateVisual(visual) {
  const points = visual.points ?? [];
  const pointMarkup = points.map((point) => {
    const cx = 130 + Number(point.x) * 20;
    const cy = 105 - Number(point.y) * 20;
    return `<g><circle cx="${cx}" cy="${cy}" r="6" fill="currentColor" /><text x="${cx + 10}" y="${cy - 8}" font-size="14" font-weight="700">${escapeHtml(point.id)}</text></g>`;
  }).join("");
  return `
    <svg class="quant-visual__svg" viewBox="0 0 260 210" role="img" aria-label="Coordinate plane with labeled points">
      <g stroke="currentColor" opacity=".18">${[-4, -2, 2, 4].map((value) => `<line x1="${130 + value * 20}" y1="25" x2="${130 + value * 20}" y2="185" /><line x1="50" y1="${105 - value * 20}" x2="210" y2="${105 - value * 20}" />`).join("")}</g>
      <g stroke="currentColor" stroke-width="2"><line x1="45" y1="105" x2="215" y2="105" /><line x1="130" y1="190" x2="130" y2="20" /></g>
      <text x="215" y="98" font-size="13">x</text><text x="137" y="30" font-size="13">y</text>
      ${pointMarkup}
    </svg>
  `;
}

function renderFunctionVisual(visual) {
  return `
    <svg class="quant-visual__svg" viewBox="0 0 280 205" role="img" aria-label="Graph of ${escapeHtml(visual.equation ?? "a linear function")}">
      <g stroke="currentColor" opacity=".18">${[45, 85, 125, 165, 205, 245].map((value) => `<line x1="${value}" y1="20" x2="${value}" y2="180" /><line x1="35" y1="${value - 25}" x2="255" y2="${value - 25}" />`).join("")}</g>
      <g stroke="currentColor" stroke-width="2"><line x1="30" y1="100" x2="260" y2="100" /><line x1="145" y1="185" x2="145" y2="15" /></g>
      <line x1="115" y1="180" x2="195" y2="20" stroke="#e56d59" stroke-width="4" stroke-linecap="round" />
      <circle cx="145" cy="120" r="6" fill="#deb052" /><text x="154" y="133" font-size="13">intercept</text>
      <text x="178" y="48" font-size="13">rise 2</text><text x="250" y="94" font-size="13">x</text><text x="152" y="25" font-size="13">y</text>
      <text x="42" y="30" font-size="13" font-weight="700">${escapeHtml(visual.equation ?? "")}</text>
    </svg>
  `;
}

const visualRenderers = {
  fraction: renderFractionVisual,
  "coordinate-plane": renderCoordinateVisual,
  "function-line": renderFunctionVisual
};

function renderVisualLabel(question, session) {
  const response = session.response ?? { selectedLabel: null, assignments: {} };
  const labelsById = getItemsById(question.labels);
  const visualMarkup = visualRenderers[question.visual?.type]?.(question.visual ?? {})
    ?? "<p class=\"quant-interactive__empty\">This visual is preparing.</p>";

  return `
    <section class="quant-interactive quant-visual-label" data-quant-visual-builder data-selected-label="${escapeHtml(response.selectedLabel ?? "")}" aria-label="Visual labeling activity">
      <p class="quant-interactive__guide">Select a label, then select the part of the visual it describes. Select an assigned target to move its label.</p>
      <div class="quant-visual">${visualMarkup}</div>
      <div class="quant-visual-label__workspace">
        <div class="quant-visual-label__labels" aria-label="Labels to assign">
          <p>Labels</p>
          ${(question.labels ?? []).map((label) => {
            const isAssigned = Object.values(response.assignments ?? {}).includes(label.id);
            return `<button class="quant-interactive-item${response.selectedLabel === label.id ? " is-selected" : ""}${isAssigned ? " is-placed" : ""}" type="button" data-quant-visual-label="${escapeHtml(label.id)}" aria-pressed="${response.selectedLabel === label.id}">${escapeHtml(label.label)}${isAssigned ? " <small>Assigned</small>" : ""}</button>`;
          }).join("")}
        </div>
        <div class="quant-visual-label__targets" aria-label="Visual targets">
          <p>Parts of the visual</p>
          ${(question.targets ?? []).map((target) => {
            const assignedLabelId = response.assignments?.[target.id];
            const assignedLabel = labelsById.get(assignedLabelId);
            const isCorrect = assignedLabelId === question.correctAssignments?.[target.id];
            const review = session.isChecked
              ? `<span class="quant-interactive__review">${isCorrect ? "Correct label" : `Correct label: ${escapeHtml(labelsById.get(question.correctAssignments?.[target.id])?.label ?? "")}`}</span>`
              : "";
            return `
              <button class="quant-visual-target${assignedLabel ? " is-filled" : ""}${session.isChecked ? (isCorrect ? " is-correct" : " is-incorrect") : ""}" type="button" data-quant-visual-target="${escapeHtml(target.id)}" data-quant-visual-assigned="${escapeHtml(assignedLabelId ?? "")}" aria-label="${escapeHtml(target.label)}${assignedLabel ? `, assigned ${escapeHtml(assignedLabel.label)}` : ", no label assigned"}">
                <span>${escapeHtml(target.label)}</span><strong>${escapeHtml(assignedLabel?.label ?? "Choose a label")}</strong>${review}
              </button>
            `;
          }).join("")}
        </div>
      </div>
      ${renderResetControl()}
    </section>
  `;
}

const interactiveRenderers = {
  "drag-drop": renderDragDrop,
  "arrange-order": renderArrangeOrder,
  matching: renderMatching,
  categorize: renderCategorize,
  "visual-label": renderVisualLabel
};

export function renderInteractiveQuestion(question, session) {
  return interactiveRenderers[question.type]?.(question, session) ?? "";
}

export function bindInteractiveEvents(root, onInteractiveAction) {
  root.querySelectorAll("[data-quant-interactive-reset]").forEach((button) => {
    button.addEventListener("click", () => onInteractiveAction({ type: "reset" }));
  });

  root.querySelectorAll("[data-quant-drag-item]").forEach((item) => {
    item.addEventListener("click", () => onInteractiveAction({ type: "select", itemId: item.dataset.quantDragItem }));
    item.addEventListener("dragstart", (event) => {
      event.dataTransfer?.setData("text/plain", item.dataset.quantDragItem);
      event.dataTransfer.effectAllowed = "move";
    });
  });
  root.querySelectorAll("[data-quant-drop-zone]").forEach((zone) => {
    zone.addEventListener("dragover", (event) => event.preventDefault());
    zone.addEventListener("drop", (event) => {
      event.preventDefault();
      onInteractiveAction({ type: "place", itemId: event.dataTransfer?.getData("text/plain"), targetId: zone.dataset.quantDropZone });
    });
  });
  root.querySelectorAll("[data-quant-drop-target]").forEach((target) => {
    target.addEventListener("click", () => onInteractiveAction({ type: "place", targetId: target.dataset.quantDropTarget }));
  });

  root.querySelectorAll("[data-quant-arrange-move]").forEach((button) => {
    button.addEventListener("click", () => onInteractiveAction({
      type: "move",
      itemId: button.dataset.quantArrangeItemId,
      direction: button.dataset.quantArrangeMove === "up" ? -1 : 1
    }));
  });
  root.querySelectorAll("[data-quant-arrange-item]").forEach((item) => {
    item.addEventListener("dragstart", (event) => {
      event.dataTransfer?.setData("text/plain", item.dataset.quantArrangeItem);
      event.dataTransfer.effectAllowed = "move";
    });
    item.addEventListener("dragover", (event) => event.preventDefault());
    item.addEventListener("drop", (event) => {
      event.preventDefault();
      onInteractiveAction({ type: "move-to", itemId: event.dataTransfer?.getData("text/plain"), targetId: item.dataset.quantArrangeItem });
    });
  });

  root.querySelectorAll("[data-quant-match-left]").forEach((item) => {
    item.addEventListener("click", () => onInteractiveAction({ type: "select-left", leftId: item.dataset.quantMatchLeft }));
  });
  root.querySelectorAll("[data-quant-match-right]").forEach((item) => {
    item.addEventListener("click", () => onInteractiveAction({ type: "match", rightId: item.dataset.quantMatchRight }));
  });
  root.querySelectorAll("[data-quant-match-remove]").forEach((button) => {
    button.addEventListener("click", () => onInteractiveAction({ type: "remove-pair", leftId: button.dataset.quantMatchRemove }));
  });

  root.querySelectorAll("[data-quant-categorize-item]").forEach((item) => {
    item.addEventListener("click", () => onInteractiveAction({ type: "select", itemId: item.dataset.quantCategorizeItem }));
    item.addEventListener("dragstart", (event) => {
      event.dataTransfer?.setData("text/plain", item.dataset.quantCategorizeItem);
      event.dataTransfer.effectAllowed = "move";
    });
  });
  root.querySelectorAll("[data-quant-category-zone]").forEach((zone) => {
    zone.addEventListener("dragover", (event) => event.preventDefault());
    zone.addEventListener("drop", (event) => {
      event.preventDefault();
      onInteractiveAction({ type: "place", itemId: event.dataTransfer?.getData("text/plain"), categoryId: zone.dataset.quantCategoryZone });
    });
  });
  root.querySelectorAll("[data-quant-category-target]").forEach((target) => {
    target.addEventListener("click", () => onInteractiveAction({ type: "place", categoryId: target.dataset.quantCategoryTarget }));
  });

  root.querySelectorAll("[data-quant-visual-label]").forEach((label) => {
    label.addEventListener("click", () => onInteractiveAction({ type: "select-label", labelId: label.dataset.quantVisualLabel }));
  });
  root.querySelectorAll("[data-quant-visual-target]").forEach((target) => {
    target.addEventListener("click", () => {
      const selectedLabel = target.closest("[data-quant-visual-builder]")?.dataset.selectedLabel;
      onInteractiveAction(selectedLabel
        ? { type: "assign", targetId: target.dataset.quantVisualTarget }
        : { type: "select-assigned", targetId: target.dataset.quantVisualTarget });
    });
  });
}
