function toText(value) {
  return String(value ?? "").trim();
}

export function normalizeText(value) {
  return toText(value).toLocaleLowerCase().replace(/\s+/g, " ");
}

export function parseNumericAnswer(value, { percentage = false } = {}) {
  const cleaned = toText(value).replaceAll(",", "").replaceAll("$", "");
  if (!cleaned) {
    return null;
  }

  const hasPercentSymbol = cleaned.endsWith("%");
  const numberText = hasPercentSymbol ? cleaned.slice(0, -1).trim() : cleaned;
  if (!numberText || !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(numberText)) {
    return null;
  }

  if (hasPercentSymbol && !percentage) {
    return null;
  }

  const parsed = Number(numberText);
  return Number.isFinite(parsed) ? parsed : null;
}

function greatestCommonDivisor(first, second) {
  let a = Math.abs(first);
  let b = Math.abs(second);

  while (b) {
    [a, b] = [b, a % b];
  }

  return a || 1;
}

export function parseFraction(value) {
  const match = toText(value).match(/^([+-]?\d+)\s*\/\s*([+-]?\d+)$/);
  if (!match) {
    return null;
  }

  let numerator = Number(match[1]);
  let denominator = Number(match[2]);
  if (!Number.isSafeInteger(numerator) || !Number.isSafeInteger(denominator) || denominator === 0) {
    return null;
  }

  if (denominator < 0) {
    numerator *= -1;
    denominator *= -1;
  }

  const divisor = greatestCommonDivisor(numerator, denominator);
  return {
    numerator: numerator / divisor,
    denominator: denominator / divisor,
    isSimplified: divisor === 1
  };
}

export function compareNumericAnswer(response, answer, { percentage = false, tolerance } = {}) {
  const submittedValue = parseNumericAnswer(response, { percentage });
  const expectedValue = parseNumericAnswer(answer, { percentage });
  if (submittedValue === null || expectedValue === null) {
    return false;
  }

  return Number.isFinite(tolerance)
    ? Math.abs(submittedValue - expectedValue) <= tolerance
    : submittedValue === expectedValue;
}

export function compareFractionAnswer(response, answer, { requireSimplified = false } = {}) {
  const submittedValue = parseFraction(response);
  const expectedValue = parseFraction(answer);
  if (!submittedValue || !expectedValue || (requireSimplified && !submittedValue.isSimplified)) {
    return false;
  }

  return submittedValue.numerator === expectedValue.numerator
    && submittedValue.denominator === expectedValue.denominator;
}

export function compareMultipleSelection(response, correctOptions) {
  const submitted = new Set(Array.isArray(response) ? response : []);
  const correct = new Set(correctOptions ?? []);
  return submitted.size === correct.size && [...submitted].every((option) => correct.has(option));
}

export function normalizeExpression(value) {
  const expression = Array.isArray(value)
    ? value.join("")
    : toText(value);
  const normalized = expression
    .replaceAll("×", "*")
    .replaceAll("÷", "/")
    .replaceAll("−", "-")
    .replace(/\s+/g, "");

  if (!normalized || !/^[\dA-Za-z+*/().-]+$/.test(normalized)) {
    return null;
  }

  const commutativeMatch = normalized.match(/^([\dA-Za-z.]+)([+*])([\dA-Za-z.]+)$/);
  if (commutativeMatch) {
    const [, left, operator, right] = commutativeMatch;
    return [left, right].sort().join(operator);
  }

  return normalized;
}

function getAnswerOptions(question) {
  return [question.answer, ...(question.acceptedAnswers ?? [])];
}

function isTextCorrect(question, response) {
  const submittedValue = normalizeText(response);
  return getAnswerOptions(question).some((answer) => normalizeText(answer) === submittedValue);
}

function isSingleAnswerCorrect(question, response) {
  if (question.answerFormat === "numeric") {
    return getAnswerOptions(question).some((answer) => compareNumericAnswer(response, answer, question));
  }

  if (question.answerFormat === "fraction") {
    return getAnswerOptions(question).some((answer) => compareFractionAnswer(response, answer, question));
  }

  return isTextCorrect(question, response);
}

function validateSingleAnswer(question, response, label = "answer") {
  if (!toText(response)) {
    return `Enter ${label} before checking.`;
  }

  if (question.answerFormat === "numeric" && parseNumericAnswer(response, question) === null) {
    return `Enter a valid number for ${label} before checking.`;
  }

  if (question.answerFormat === "fraction" && !parseFraction(response)) {
    return `Enter a valid fraction for ${label}. The denominator cannot be zero.`;
  }

  return null;
}

function getBlankQuestion(blank) {
  return {
    answer: blank.answer,
    acceptedAnswers: blank.acceptedAnswers,
    answerFormat: blank.answerFormat ?? "numeric",
    percentage: blank.percentage,
    tolerance: blank.tolerance,
    requireSimplified: blank.requireSimplified
  };
}

function getExpressionTokens(question, response) {
  const pieceIds = Array.isArray(response?.pieces) ? response.pieces : [];
  const piecesById = new Map((question.pieces ?? []).map((piece) => [piece.id, piece.token ?? piece.label]));
  return pieceIds.map((pieceId) => piecesById.get(pieceId)).filter(Boolean);
}

function clonePlacements(placements = {}) {
  return Object.fromEntries(Object.entries(placements).map(([key, value]) => [
    key,
    Array.isArray(value) ? [...value] : value
  ]));
}

function removePlacedItem(placements, itemId) {
  Object.entries(placements).forEach(([targetId, placedItem]) => {
    if (placedItem === itemId) {
      delete placements[targetId];
    }
  });
}

function removeCategorizedItem(placements, itemId) {
  Object.entries(placements).forEach(([categoryId, itemIds]) => {
    placements[categoryId] = (itemIds ?? []).filter((placedItemId) => placedItemId !== itemId);
  });
}

function areMappingsEqual(responseMapping, correctMapping) {
  const entries = Object.entries(correctMapping ?? {});
  return Object.keys(responseMapping ?? {}).length === entries.length
    && entries.every(([key, value]) => responseMapping?.[key] === value);
}

function getInteractiveItemIds(question) {
  return (question.items ?? []).map((item) => item.id);
}

function getInitialArrangeOrder(question) {
  return [...(question.initialOrder ?? getInteractiveItemIds(question))];
}

function getInitialInteractiveResponse(question) {
  const initialResponses = {
    "drag-drop": () => ({ selectedItem: null, placements: {} }),
    "arrange-order": () => ({ order: getInitialArrangeOrder(question), hasInteracted: false }),
    matching: () => ({ selectedLeft: null, pairs: {} }),
    categorize: () => ({
      selectedItem: null,
      placements: Object.fromEntries((question.categories ?? []).map((category) => [category.id, []]))
    }),
    "visual-label": () => ({ selectedLabel: null, assignments: {} })
  };

  return initialResponses[question.type]?.() ?? null;
}

export function getInitialResponse(question) {
  if (question?.type === "multiple-select") {
    return [];
  }

  if (question?.type === "complete-equation") {
    return Object.fromEntries((question.blanks ?? []).map((blank) => [blank.id, ""]));
  }

  if (question?.type === "build-expression") {
    return { pieces: [] };
  }

  const interactiveResponse = getInitialInteractiveResponse(question);
  if (interactiveResponse) {
    return interactiveResponse;
  }

  return "";
}

export function hasResponse(question, response) {
  if (question?.type === "multiple-select") {
    return Array.isArray(response) && response.length > 0;
  }

  if (question?.type === "complete-equation") {
    return (question.blanks ?? []).every((blank) => toText(response?.[blank.id]));
  }

  if (question?.type === "build-expression") {
    return Array.isArray(response?.pieces) && response.pieces.length > 0;
  }

  if (question?.type === "drag-drop") {
    const placedItemIds = Object.values(response?.placements ?? {});
    const itemIds = getInteractiveItemIds(question);
    return (question.targets ?? []).every((target) => response?.placements?.[target.id])
      && placedItemIds.length === itemIds.length
      && new Set(placedItemIds).size === itemIds.length
      && itemIds.every((itemId) => placedItemIds.includes(itemId));
  }

  if (question?.type === "arrange-order") {
    const itemIds = getInteractiveItemIds(question);
    const order = response?.order ?? [];
    return response?.hasInteracted
      && order.length === itemIds.length
      && new Set(order).size === itemIds.length
      && itemIds.every((itemId) => order.includes(itemId));
  }

  if (question?.type === "matching") {
    const leftIds = (question.leftItems ?? []).map((item) => item.id);
    const pairedRightIds = Object.values(response?.pairs ?? {});
    return leftIds.every((leftId) => response?.pairs?.[leftId])
      && new Set(pairedRightIds).size === leftIds.length;
  }

  if (question?.type === "categorize") {
    const placedItemIds = Object.values(response?.placements ?? {}).flat();
    const itemIds = getInteractiveItemIds(question);
    return placedItemIds.length === itemIds.length
      && new Set(placedItemIds).size === itemIds.length
      && itemIds.every((itemId) => placedItemIds.includes(itemId));
  }

  if (question?.type === "visual-label") {
    return (question.targets ?? []).every((target) => response?.assignments?.[target.id]);
  }

  return toText(response).length > 0;
}

const validators = {
  "multiple-select": (question, response) => (
    hasResponse(question, response) ? null : "Select at least one answer before checking."
  ),
  "complete-equation": (question, response) => {
    for (const blank of question.blanks ?? []) {
      const label = blank.label ?? "this blank";
      const validation = validateSingleAnswer(getBlankQuestion(blank), response?.[blank.id], label);
      if (validation) {
        return validation;
      }
    }
    return null;
  },
  "build-expression": (question, response) => {
    if (!hasResponse(question, response)) {
      return "Add tiles to build an expression before checking.";
    }

    return normalizeExpression(getExpressionTokens(question, response))
      ? null
      : "Build a valid expression from the available tiles.";
  },
  "drag-drop": (question, response) => (
    hasResponse(question, response) ? null : "Place every item in a destination before checking."
  ),
  "arrange-order": (question, response) => (
    hasResponse(question, response) ? null : "Move an item to confirm the order before checking."
  ),
  matching: (question, response) => (
    hasResponse(question, response) ? null : "Match every item before checking."
  ),
  categorize: (question, response) => (
    hasResponse(question, response) ? null : "Place every item in a category before checking."
  ),
  "visual-label": (question, response) => (
    hasResponse(question, response) ? null : "Assign a label to every target before checking."
  )
};

const correctnessChecks = {
  "multiple-select": (question, response) => compareMultipleSelection(response, question.correctOptions),
  "complete-equation": (question, response) => (question.blanks ?? []).every((blank) => (
    isSingleAnswerCorrect(getBlankQuestion(blank), response?.[blank.id])
  )),
  "build-expression": (question, response) => {
    const submittedValue = normalizeExpression(getExpressionTokens(question, response));
    const acceptedExpressions = question.acceptedExpressions ?? getAnswerOptions(question);
    return submittedValue !== null && acceptedExpressions.some((expression) => (
      normalizeExpression(expression) === submittedValue
    ));
  },
  "drag-drop": (question, response) => areMappingsEqual(response?.placements, question.correctPlacements),
  "arrange-order": (question, response) => (
    (question.correctOrder ?? []).every((itemId, index) => response?.order?.[index] === itemId)
  ),
  matching: (question, response) => areMappingsEqual(response?.pairs, question.matches),
  categorize: (question, response) => {
    const categorizedItems = Object.entries(response?.placements ?? {})
      .flatMap(([categoryId, itemIds]) => (itemIds ?? []).map((itemId) => [itemId, categoryId]));
    return areMappingsEqual(Object.fromEntries(categorizedItems), question.correctCategories);
  },
  "visual-label": (question, response) => areMappingsEqual(response?.assignments, question.correctAssignments)
};

function applyDragDropAction(question, response, action) {
  const placements = clonePlacements(response?.placements);
  const itemId = action.itemId ?? response?.selectedItem;

  if (action.type === "select" && action.itemId) {
    removePlacedItem(placements, action.itemId);
    return { selectedItem: action.itemId, placements };
  }

  if (action.type === "place" && itemId && (question.targets ?? []).some((target) => target.id === action.targetId)) {
    removePlacedItem(placements, itemId);
    delete placements[action.targetId];
    placements[action.targetId] = itemId;
    return { selectedItem: null, placements };
  }

  return { selectedItem: response?.selectedItem ?? null, placements };
}

function applyArrangeAction(question, response, action) {
  const order = [...(response?.order ?? getInitialArrangeOrder(question))];
  const itemIndex = order.indexOf(action.itemId);
  if (itemIndex < 0) {
    return { order, hasInteracted: response?.hasInteracted ?? false };
  }

  if (action.type === "move") {
    const nextIndex = itemIndex + Number(action.direction);
    if (nextIndex >= 0 && nextIndex < order.length) {
      [order[itemIndex], order[nextIndex]] = [order[nextIndex], order[itemIndex]];
    }
  }

  if (action.type === "move-to" && action.targetId && action.targetId !== action.itemId) {
    order.splice(itemIndex, 1);
    const targetIndex = order.indexOf(action.targetId);
    order.splice(targetIndex < 0 ? order.length : targetIndex, 0, action.itemId);
  }

  return { order, hasInteracted: action.type === "move" || action.type === "move-to" || response?.hasInteracted };
}

function applyMatchingAction(question, response, action) {
  const pairs = { ...(response?.pairs ?? {}) };
  if (action.type === "select-left" && action.leftId) {
    if (pairs[action.leftId]) {
      delete pairs[action.leftId];
    }
    return { selectedLeft: action.leftId, pairs };
  }

  if (action.type === "match" && response?.selectedLeft && action.rightId) {
    Object.entries(pairs).forEach(([leftId, rightId]) => {
      if (rightId === action.rightId) {
        delete pairs[leftId];
      }
    });
    pairs[response.selectedLeft] = action.rightId;
    return { selectedLeft: null, pairs };
  }

  if (action.type === "remove-pair" && action.leftId) {
    delete pairs[action.leftId];
  }

  return { selectedLeft: response?.selectedLeft ?? null, pairs };
}

function applyCategorizeAction(question, response, action) {
  const placements = clonePlacements(response?.placements);
  const itemId = action.itemId ?? response?.selectedItem;

  if (action.type === "select" && action.itemId) {
    removeCategorizedItem(placements, action.itemId);
    return { selectedItem: action.itemId, placements };
  }

  if (action.type === "place" && itemId && (question.categories ?? []).some((category) => category.id === action.categoryId)) {
    removeCategorizedItem(placements, itemId);
    placements[action.categoryId] = [...(placements[action.categoryId] ?? []), itemId];
    return { selectedItem: null, placements };
  }

  return { selectedItem: response?.selectedItem ?? null, placements };
}

function applyVisualLabelAction(question, response, action) {
  const assignments = { ...(response?.assignments ?? {}) };
  if (action.type === "select-label" && action.labelId) {
    Object.entries(assignments).forEach(([targetId, assignedLabelId]) => {
      if (assignedLabelId === action.labelId) {
        delete assignments[targetId];
      }
    });
    return { selectedLabel: action.labelId, assignments };
  }

  if (action.type === "select-assigned" && action.targetId && assignments[action.targetId]) {
    const selectedLabel = assignments[action.targetId];
    delete assignments[action.targetId];
    return { selectedLabel, assignments };
  }

  if (action.type === "assign" && response?.selectedLabel && action.targetId) {
    Object.entries(assignments).forEach(([targetId, assignedLabelId]) => {
      if (assignedLabelId === response.selectedLabel) {
        delete assignments[targetId];
      }
    });
    assignments[action.targetId] = response.selectedLabel;
    return { selectedLabel: null, assignments };
  }

  return { selectedLabel: response?.selectedLabel ?? null, assignments };
}

const interactionActionHandlers = {
  "drag-drop": applyDragDropAction,
  "arrange-order": applyArrangeAction,
  matching: applyMatchingAction,
  categorize: applyCategorizeAction,
  "visual-label": applyVisualLabelAction
};

export function applyInteractiveAction(question, response, action) {
  if (action.type === "reset") {
    return getInitialInteractiveResponse(question);
  }

  return interactionActionHandlers[question.type]?.(question, response, action) ?? response;
}

export function validateResponse(question, response) {
  return validators[question.type]?.(question, response)
    ?? validateSingleAnswer(question, response);
}

export function isCorrectResponse(question, response) {
  return correctnessChecks[question.type]?.(question, response)
    ?? isSingleAnswerCorrect(question, response);
}

export function getQuestionTypeLabel(type) {
  const labels = {
    "written-answer": "Written answer",
    "fill-in-the-blank": "Fill in the blank",
    "true-false": "True or false",
    "single-choice": "Single choice",
    "multiple-select": "Select all that apply",
    "complete-equation": "Complete an equation",
    "build-expression": "Build an expression",
    "drag-drop": "Drag and drop",
    "arrange-order": "Arrange in order",
    matching: "Connect matching items",
    categorize: "Categorize values",
    "visual-label": "Visual labeling"
  };

  return labels[type] ?? "Practice question";
}
