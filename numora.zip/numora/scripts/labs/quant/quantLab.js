import {
  getQuantQuestions,
  getQuantTopic,
  getQuantTopics,
  getAvailableQuantTopicIds,
  quantGradeLevels,
  quantSessionLength
} from "../../data/quant/questions.js";
import { getAppState } from "../../services/appState.js";
import { recordActivity } from "../../services/rewardService.js";
import {
  applyInteractiveAction,
  getInitialResponse,
  isCorrectResponse,
  validateResponse
} from "./questionEngine.js";
import { renderQuantLab } from "./questionRenderers.js";
import {
  createQuantEventKey,
  loadQuantLabSession,
  quantRewardValues,
  saveQuantLabSession
} from "./quantSession.js";
import { createQuantQuestionQueue } from "./questionQueue.js";

export { createQuantQuestionQueue } from "./questionQueue.js";

function isSupportedGrade(gradeLevel) {
  return quantGradeLevels.some((grade) => grade.id === gradeLevel);
}

function createEmptySummary() {
  return { completed: 0, correct: 0, xpEarned: 0, hintsUsed: 0, topics: [] };
}

function isValidSummary(summary) {
  return Number.isInteger(summary?.completed)
    && summary.completed >= 0
    && Number.isInteger(summary?.correct)
    && summary.correct >= 0
    && Number.isInteger(summary?.xpEarned)
    && summary.xpEarned >= 0
    && Number.isInteger(summary?.hintsUsed)
    && summary.hintsUsed >= 0
    && Array.isArray(summary?.topics)
    && summary.topics.every((topic) => typeof topic === "string");
}

function getPersistedSession(userId) {
  const storedSession = loadQuantLabSession(userId);
  if (!storedSession
    || !isSupportedGrade(storedSession.gradeLevel)
    || typeof storedSession.topic !== "string"
    || !getQuantTopic(storedSession.gradeLevel, storedSession.topic)
    || !Array.isArray(storedSession.queue)
    || !Number.isInteger(storedSession.position)
    || !isValidSummary(storedSession.summary)) {
    return null;
  }

  const questions = getQuantQuestions(storedSession.gradeLevel, storedSession.topic);
  const validQuestionIds = new Set(questions.map((question) => question.id));
  const hasValidQueue = storedSession.queue.length === quantSessionLength
    && storedSession.queue.every((questionId) => validQuestionIds.has(questionId));
  const hasValidPosition = storedSession.position >= 0 && storedSession.position < storedSession.queue.length;
  if (!hasValidQueue || !hasValidPosition || storedSession.questionId !== storedSession.queue[storedSession.position]) {
    return null;
  }

  return {
    ...storedSession,
    response: storedSession.response ?? getInitialResponse(questions.find((question) => question.id === storedSession.questionId)),
    isChecked: Boolean(storedSession.isChecked),
    isCorrect: Boolean(storedSession.isCorrect),
    hintVisible: Boolean(storedSession.hintVisible),
    sessionComplete: Boolean(storedSession.sessionComplete),
    checkedPositions: Array.isArray(storedSession.checkedPositions)
      ? storedSession.checkedPositions.filter((position) => Number.isInteger(position) && position >= 0 && position < quantSessionLength)
      : [],
    completedAnswerKeys: Array.isArray(storedSession.completedAnswerKeys) ? storedSession.completedAnswerKeys : [],
    purchasedHintKeys: Array.isArray(storedSession.purchasedHintKeys) ? storedSession.purchasedHintKeys : [],
    summary: { ...storedSession.summary, topics: [...new Set(storedSession.summary.topics)] },
    isSavingAnswer: false,
    isUnlockingHint: false,
    rewardFeedback: null
  };
}

export function createQuantLabView() {
  const appState = getAppState();
  const userId = appState.user?.id;
  const profileGrade = appState.user?.gradeLevel;
  const gradeLevel = isSupportedGrade(profileGrade) ? profileGrade : "middle";
  const root = document.createElement("section");
  const session = getPersistedSession(userId) ?? {
    gradeLevel,
    topic: "mix",
    queue: [],
    position: 0,
    questionId: null,
    response: null,
    isChecked: false,
    isCorrect: false,
    hintVisible: false,
    validationMessage: null,
    sessionComplete: false,
    isSavingAnswer: false,
    isUnlockingHint: false,
    checkedPositions: [],
    completedAnswerKeys: [],
    purchasedHintKeys: [],
    rewardFeedback: null,
    summary: createEmptySummary()
  };

  function getCurrentQuestion() {
    return getQuantQuestions(session.gradeLevel, session.topic)
      .find((question) => question.id === session.questionId) ?? null;
  }

  function saveSession() {
    saveQuantLabSession(userId, session);
  }

  function resetAnswerState(question = getCurrentQuestion()) {
    session.response = getInitialResponse(question);
    session.isChecked = false;
    session.isCorrect = false;
    session.hintVisible = false;
    session.validationMessage = null;
    session.isSavingAnswer = false;
    session.isUnlockingHint = false;
    session.rewardFeedback = null;
  }

  function startSession(topic = session.topic, previousQuestionId = null) {
    const questions = getQuantQuestions(session.gradeLevel, topic);
    session.topic = topic;
    session.queue = createQuantQuestionQueue(questions, topic, quantSessionLength);
    if (previousQuestionId && session.queue.length > 1 && session.queue[0] === previousQuestionId) {
      [session.queue[0], session.queue[1]] = [session.queue[1], session.queue[0]];
    }
    session.position = 0;
    session.questionId = session.queue[0] ?? null;
    session.sessionComplete = false;
    session.checkedPositions = [];
    session.completedAnswerKeys = [];
    session.purchasedHintKeys = [];
    session.summary = createEmptySummary();
    resetAnswerState();
    saveSession();
  }

  function render() {
    const question = getCurrentQuestion();
    if (!question) {
      root.innerHTML = "<div class=\"page-container\"><p>Quant Lab is preparing a question set.</p></div>";
      return;
    }

    renderQuantLab(root, session, {
      question,
      questionIndex: session.position,
      questionCount: quantSessionLength,
      gradeLevels: quantGradeLevels,
      topics: getQuantTopics(session.gradeLevel),
      availableTopicIds: getAvailableQuantTopicIds(session.gradeLevel),
      currentTopic: getQuantTopic(session.gradeLevel, question.topic),
      onGradeChange: (nextGrade) => {
        if (!isSupportedGrade(nextGrade) || nextGrade === session.gradeLevel) {
          return;
        }
        session.gradeLevel = nextGrade;
        startSession("mix", question.id);
        render();
      },
      onTopicChange: (nextTopic) => {
        if (!getQuantTopic(session.gradeLevel, nextTopic)
          || !getQuantQuestions(session.gradeLevel, nextTopic).length
          || nextTopic === session.topic) {
          return;
        }
        startSession(nextTopic, question.id);
        render();
      },
      onResponseChange: (response, { render: shouldRender }) => {
        if (session.isChecked || session.isSavingAnswer) {
          return;
        }
        session.response = response;
        session.validationMessage = null;
        session.rewardFeedback = null;
        saveSession();
        if (shouldRender) {
          render();
        }
      },
      onExpressionAction: (action, pieceId) => {
        if (session.isChecked || session.isSavingAnswer || question.type !== "build-expression") {
          return;
        }

        const currentPieces = Array.isArray(session.response?.pieces) ? session.response.pieces : [];
        let nextPieces = currentPieces;
        if (action === "add" && (question.pieces ?? []).some((piece) => piece.id === pieceId)) {
          nextPieces = [...currentPieces, pieceId];
        } else if (action === "remove") {
          nextPieces = currentPieces.slice(0, -1);
        } else if (action === "clear") {
          nextPieces = [];
        }

        session.response = { pieces: nextPieces };
        session.validationMessage = null;
        saveSession();
        render();
      },
      onInteractiveAction: (action) => {
        if (session.isChecked || session.isSavingAnswer) {
          return;
        }
        session.response = applyInteractiveAction(question, session.response, action);
        session.validationMessage = null;
        saveSession();
        render();
      },
      onHintToggle: async () => {
        if (session.isUnlockingHint) {
          return;
        }

        const hintKey = createQuantEventKey({ questionId: question.id, outcome: "hint" });
        if (session.hintVisible) {
          session.hintVisible = false;
          saveSession();
          render();
          return;
        }

        if (session.purchasedHintKeys.includes(hintKey)) {
          session.hintVisible = true;
          session.rewardFeedback = { tone: "hint", message: "Hint unlocked · no additional coins used" };
          saveSession();
          render();
          return;
        }

        const coins = getAppState().coins;
        if (Number.isInteger(coins) && coins < quantRewardValues.hintCoinCost) {
          session.rewardFeedback = { tone: "error", message: `You need ${quantRewardValues.hintCoinCost} coins to use this hint.` };
          render();
          return;
        }

        if (!window.confirm(`Use ${quantRewardValues.hintCoinCost} coins to unlock this hint?`)) return;
        session.isUnlockingHint = true;
        session.rewardFeedback = null;
        render();
        try {
          const result = await recordActivity({
            eventKey: hintKey,
            module: "quant",
            topic: question.topic,
            activityType: "hint",
            metadata: { question_id: question.id, grade_level: session.gradeLevel, question_type: question.type }
          });

          if (!session.purchasedHintKeys.includes(hintKey)) {
            session.purchasedHintKeys.push(hintKey);
          }
          if (result.eventRecorded) {
            session.summary.hintsUsed += 1;
          }
          session.hintVisible = true;
          session.rewardFeedback = {
            tone: "hint",
            message: result.eventRecorded ? `Hint unlocked · −${quantRewardValues.hintCoinCost} coins` : "Hint unlocked · already purchased"
          };
        } catch (error) {
          session.rewardFeedback = {
            tone: "error",
            message: /enough coins/i.test(error.message ?? "") ? `You need ${quantRewardValues.hintCoinCost} coins to use this hint.` : error.message
          };
        } finally {
          session.isUnlockingHint = false;
          saveSession();
          render();
        }
      },
      onCheckAnswer: async () => {
        if (session.isChecked || session.isSavingAnswer) {
          return;
        }
        const validationMessage = validateResponse(question, session.response);
        if (validationMessage) {
          session.validationMessage = validationMessage;
          render();
          return;
        }

        const isCorrect = isCorrectResponse(question, session.response);
        const outcome = isCorrect ? "correct" : "incorrect";
        const answerKey = createQuantEventKey({ questionId: question.id, outcome });
        session.isSavingAnswer = true;
        session.rewardFeedback = null;
        render();

        try {
          const result = await recordActivity({
            eventKey: answerKey,
            module: "quant",
            topic: question.topic,
            activityType: isCorrect ? "correct_answer" : "incorrect_answer",
            metadata: {
              question_id: question.id,
              grade_level: session.gradeLevel,
              question_type: question.type
            }
          });

          if (!session.checkedPositions.includes(session.position)) {
            session.checkedPositions.push(session.position);
            session.summary.completed += 1;
            if (isCorrect) {
              session.summary.correct += 1;
            }
            if (!session.summary.topics.includes(question.topic)) {
              session.summary.topics.push(question.topic);
            }
          }
          if (!session.completedAnswerKeys.includes(answerKey)) {
            session.completedAnswerKeys.push(answerKey);
            if (isCorrect && result.eventRecorded) {
              session.summary.xpEarned += quantRewardValues.correctXp;
            }
          }

          session.isChecked = true;
          session.isCorrect = isCorrect;
          session.rewardFeedback = isCorrect
            ? {
              tone: "reward",
              message: result.eventRecorded ? `Correct! +${quantRewardValues.correctXp} XP` : "Correct! XP was already awarded for this question."
            }
            : { tone: "neutral", message: "No XP this time. Use the explanation, then continue." };
        } catch (error) {
          session.rewardFeedback = { tone: "error", message: error.message };
        } finally {
          session.isSavingAnswer = false;
          saveSession();
          render();
        }
      },
      onNextQuestion: () => {
        if (!session.isChecked) {
          return;
        }
        if (session.position === quantSessionLength - 1) {
          session.sessionComplete = true;
          saveSession();
          render();
          return;
        }
        session.position += 1;
        session.questionId = session.queue[session.position];
        resetAnswerState();
        saveSession();
        render();
      },
      onPracticeAgain: () => {
        startSession(session.topic, question.id);
        render();
      },
      onChooseTopic: () => {
        root.querySelector("[data-quant-topic]")?.focus();
      },
      onTryMix: () => {
        startSession("mix", question.id);
        render();
      },
      onBackHome: () => {
        window.location.hash = "";
      }
    });
  }

  root.className = "quant-lab section";
  root.dataset.labSession = "active";
  if (!session.queue.length) {
    startSession();
  } else {
    saveSession();
  }
  render();
  return root;
}
