function shuffle(items) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
  }
  return copy;
}

export function createQuantQuestionQueue(questions, topic, sessionLength) {
  if (!questions.length || !Number.isInteger(sessionLength) || sessionLength < 1) {
    return [];
  }

  const queue = [];
  let previousQuestion = null;
  const topicCounts = new Map();
  const distinctTopicCount = new Set(questions.map((question) => question.topic)).size;
  const topicLimit = topic === "mix"
    ? Math.ceil(sessionLength / Math.min(distinctTopicCount, sessionLength))
    : Infinity;

  while (queue.length < sessionLength) {
    const withoutImmediateRepeat = questions.filter((question) => question.id !== previousQuestion?.id);
    const candidates = withoutImmediateRepeat.length ? withoutImmediateRepeat : questions;
    const belowTopicLimit = topic === "mix"
      ? candidates.filter((question) => (topicCounts.get(question.topic) ?? 0) < topicLimit)
      : candidates;
    const balancedCandidates = belowTopicLimit.length ? belowTopicLimit : candidates;
    const variedTopicAndType = topic === "mix"
      ? balancedCandidates.filter((question) => question.topic !== previousQuestion?.topic && question.type !== previousQuestion?.type)
      : [];
    const variedTopic = topic === "mix"
      ? balancedCandidates.filter((question) => question.topic !== previousQuestion?.topic)
      : [];
    const variedType = topic === "mix"
      ? balancedCandidates.filter((question) => question.type !== previousQuestion?.type)
      : [];
    const nextQuestion = shuffle(
      variedTopicAndType.length
        ? variedTopicAndType
        : variedTopic.length
          ? variedTopic
          : variedType.length
            ? variedType
            : balancedCandidates
    )[0];

    queue.push(nextQuestion.id);
    topicCounts.set(nextQuestion.topic, (topicCounts.get(nextQuestion.topic) ?? 0) + 1);
    previousQuestion = nextQuestion;
  }

  return queue;
}
