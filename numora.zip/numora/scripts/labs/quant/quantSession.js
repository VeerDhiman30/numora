import { displayReward } from "../../services/rewardDisplay.js";
const storagePrefix = "numora:quant-session:v1";
const sessionVersion = 1;

export const quantRewardValues = Object.freeze({
  get correctXp() { return displayReward("quant_correct").xp; },
  get hintCoinCost() { return Math.abs(displayReward("quant_hint").coins); }
});

const eventSuffixes = Object.freeze({
  correct: "correct",
  incorrect: "incorrect",
  hint: "hint"
});

function getSessionStorage() {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
}

function getStorageKey(userId) {
  return `${storagePrefix}:${userId}`;
}

function isSafeQuestionId(questionId) {
  return /^[a-z0-9][a-z0-9-]{1,120}$/.test(questionId ?? "");
}

export function createQuantEventKey({ questionId, outcome }) {
  const suffix = eventSuffixes[outcome];
  if (!isSafeQuestionId(questionId) || !suffix) {
    throw new Error("Quant activity details are invalid.");
  }

  return `quant:${questionId}:${suffix}`;
}

export function loadQuantLabSession(userId) {
  if (!userId) {
    return null;
  }

  try {
    const storedSession = getSessionStorage()?.getItem(getStorageKey(userId));
    if (!storedSession) {
      return null;
    }

    const session = JSON.parse(storedSession);
    return session?.version === sessionVersion ? session : null;
  } catch {
    return null;
  }
}

export function saveQuantLabSession(userId, session) {
  if (!userId) {
    return;
  }

  const storage = getSessionStorage();
  if (!storage) {
    return;
  }

  const persistedSession = {
    version: sessionVersion,
    gradeLevel: session.gradeLevel,
    topic: session.topic,
    queue: session.queue,
    position: session.position,
    questionId: session.questionId,
    response: session.response,
    isChecked: session.isChecked,
    isCorrect: session.isCorrect,
    hintVisible: session.hintVisible,
    sessionComplete: session.sessionComplete,
    checkedPositions: session.checkedPositions,
    completedAnswerKeys: session.completedAnswerKeys,
    purchasedHintKeys: session.purchasedHintKeys,
    summary: session.summary
  };

  try {
    storage.setItem(getStorageKey(userId), JSON.stringify(persistedSession));
  } catch {
    // The lab remains usable when session storage is unavailable.
  }
}
