import { getQuestionTypeLabel, hasResponse } from "./questionEngine.js";
import { quantRewardValues } from "./quantSession.js";
import { bindInteractiveEvents, renderInteractiveQuestion } from "./interactiveRenderers.js";

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

function renderTextInput(question, response, { blank = false } = {}) {
  const inputMode = question.data?.inputMode ?? "text";
  const label = question.data?.answerLabel ?? "Your answer";
  const field = `
    <label class="quant-answer-field">
      <span>${escapeHtml(label)}</span>
      <input data-quant-text-answer type="text" inputmode="${escapeHtml(inputMode)}" autocomplete="off" value="${escapeHtml(response)}" aria-describedby="quant-answer-help">
    </label>
  `;

  if (!blank) {
    return field;
  }

  return `
    <div class="quant-equation" aria-label="${escapeHtml(label)}">
      <span>${escapeHtml(question.data?.before ?? "")}</span>
      ${field}
      <span>${escapeHtml(question.data?.after ?? "")}</span>
    </div>
  `;
}

function renderChoiceList(question, response, options) {
  return `
    <fieldset class="quant-choice-group">
      <legend class="sr-only">${escapeHtml(question.instruction)}</legend>
      <div class="quant-choice-list">
        ${options.map((option) => `
          <label class="quant-choice${response === option.id ? " is-selected" : ""}">
            <input type="radio" name="quant-answer" value="${escapeHtml(option.id)}" ${response === option.id ? "checked" : ""}>
            <span class="quant-choice__marker" aria-hidden="true"></span>
            <span>${escapeHtml(option.label)}</span>
          </label>
        `).join("")}
      </div>
    </fieldset>
  `;
}

function renderMultipleSelect(question, session) {
  const selectedOptions = new Set(Array.isArray(session.response) ? session.response : []);
  const correctOptions = new Set(question.correctOptions ?? []);

  return `
    <fieldset class="quant-choice-group">
      <legend>${escapeHtml(question.instruction)}</legend>
      <div class="quant-choice-list">
        ${(question.options ?? []).map((option) => {
          const isSelected = selectedOptions.has(option.id);
          const isCorrect = correctOptions.has(option.id);
          const reviewClass = session.isChecked
            ? (isCorrect ? " is-correct" : isSelected ? " is-incorrect" : "")
            : "";
          const reviewText = session.isChecked
            ? `<span class="quant-choice__review">${isCorrect ? "Correct option" : isSelected ? "Not a correct option" : ""}</span>`
            : "";

          return `
            <label class="quant-choice quant-choice--multiple${isSelected ? " is-selected" : ""}${reviewClass}">
              <input data-quant-multiple type="checkbox" value="${escapeHtml(option.id)}" ${isSelected ? "checked" : ""}>
              <span class="quant-choice__marker" aria-hidden="true"></span>
              <span>${escapeHtml(option.label)}${reviewText}</span>
            </label>
          `;
        }).join("")}
      </div>
    </fieldset>
  `;
}

function renderEquationCompletion(question, session) {
  const blanksById = new Map((question.blanks ?? []).map((blank) => [blank.id, blank]));
  const segments = question.segments ?? [];

  return `
    <div class="quant-equation quant-equation--completion" aria-label="${escapeHtml(question.instruction)}">
      ${segments.map((segment) => {
        if (typeof segment === "string") {
          return `<span class="quant-equation__text">${escapeHtml(segment)}</span>`;
        }

        const blank = blanksById.get(segment.blank);
        if (!blank) {
          return "";
        }

        const label = blank.label ?? "Missing value";
        const inputMode = blank.inputMode ?? (blank.answerFormat === "numeric" ? "decimal" : "text");
        return `
          <label class="quant-equation__blank">
            <span class="sr-only">${escapeHtml(label)}</span>
            <input data-quant-equation-blank="${escapeHtml(blank.id)}" type="text" inputmode="${escapeHtml(inputMode)}" autocomplete="off" value="${escapeHtml(session.response?.[blank.id] ?? "")}" aria-label="${escapeHtml(label)}" aria-describedby="quant-answer-help">
          </label>
        `;
      }).join("")}
    </div>
  `;
}

function renderExpressionBuilder(question, session) {
  const selectedIds = Array.isArray(session.response?.pieces) ? session.response.pieces : [];
  const piecesById = new Map((question.pieces ?? []).map((piece) => [piece.id, piece]));
  const expression = selectedIds.map((pieceId) => piecesById.get(pieceId)?.label).filter(Boolean).join(" ");

  return `
    <section class="quant-expression-builder" aria-label="Expression builder">
      <p class="quant-expression-builder__label">Your expression</p>
      <output class="quant-expression-builder__output" data-quant-expression-output aria-live="polite" aria-atomic="true">${expression ? escapeHtml(expression) : "Choose tiles to build an expression."}</output>
      <div class="quant-expression-builder__controls" aria-label="Edit expression">
        <button class="button button--secondary" type="button" data-quant-expression-action="remove" ${selectedIds.length ? "" : "disabled"}>Remove last</button>
        <button class="button button--ghost" type="button" data-quant-expression-action="clear" ${selectedIds.length ? "" : "disabled"}>Clear</button>
      </div>
      <p class="quant-expression-builder__label">Available tiles</p>
      <div class="quant-expression-builder__tiles" aria-label="Available expression tiles">
        ${(question.pieces ?? []).map((piece) => `
          <button class="quant-expression-tile" type="button" data-quant-expression-piece="${escapeHtml(piece.id)}" aria-label="Add ${escapeHtml(piece.label)} to expression">${escapeHtml(piece.label)}</button>
        `).join("")}
      </div>
    </section>
  `;
}

const interactionRenderers = {
  "written-answer": (question, session) => renderTextInput(question, session.response),
  "fill-in-the-blank": (question, session) => renderTextInput(question, session.response, { blank: true }),
  "true-false": (question, session) => renderChoiceList(question, session.response, [
    { id: "true", label: "True" },
    { id: "false", label: "False" }
  ]),
  "single-choice": (question, session) => renderChoiceList(question, session.response, question.options ?? []),
  "multiple-select": renderMultipleSelect,
  "complete-equation": renderEquationCompletion,
  "build-expression": renderExpressionBuilder,
  "drag-drop": renderInteractiveQuestion,
  "arrange-order": renderInteractiveQuestion,
  matching: renderInteractiveQuestion,
  categorize: renderInteractiveQuestion,
  "visual-label": renderInteractiveQuestion
};

export function renderQuestionInteraction(question, session) {
  return interactionRenderers[question.type]?.(question, session)
    ?? "<p class=\"quant-unsupported\">This question type is coming soon.</p>";
}

function renderFeedback(question, session) {
  if (!session.isChecked) {
    return "<div class=\"quant-feedback\" aria-live=\"polite\" aria-atomic=\"true\"></div>";
  }

  const heading = session.isCorrect ? "Correct — your reasoning is on track." : "Review the method, then carry it forward.";
  const status = session.isCorrect ? "✓ Answer checked: correct." : "↗ Answer checked: not quite yet.";

  return `
    <section class="quant-feedback quant-feedback--${session.isCorrect ? "correct" : "review"}" data-quant-feedback tabindex="-1" aria-live="polite" aria-atomic="true">
      <p class="quant-feedback__status">${status}</p>
      <h2>${escapeHtml(heading)}</h2>
      <p>${escapeHtml(question.explanation)}</p>
    </section>
  `;
}

function renderRewardFeedback(session) {
  if (!session.rewardFeedback) {
    return "";
  }

  return `<p class="quant-reward-feedback quant-reward-feedback--${escapeHtml(session.rewardFeedback.tone)}" aria-live="polite">${escapeHtml(session.rewardFeedback.message)}</p>`;
}

function renderSummary(session, topics) {
  const accuracy = session.summary.completed
    ? Math.round((session.summary.correct / session.summary.completed) * 100)
    : 0;
  const topicTitles = session.summary.topics
    .map((topicId) => topics.find((topic) => topic.id === topicId)?.title ?? topicId)
    .join(", ");

  return `
    <section class="quant-session-summary card" data-quant-summary tabindex="-1" aria-labelledby="quant-summary-title">
      <p class="quant-eyebrow">Session complete</p>
      <h2 id="quant-summary-title">Your practice is complete.</h2>
      <p>You worked through ten questions. Use the next session to keep building fluency.</p>
      <dl class="quant-session-summary__stats">
        <div><dt>Questions completed</dt><dd>${session.summary.completed}</dd></div>
        <div><dt>Correct answers</dt><dd>${session.summary.correct}</dd></div>
        <div><dt>Accuracy</dt><dd>${accuracy}%</dd></div>
        <div><dt>XP earned</dt><dd>+${session.summary.xpEarned}</dd></div>
        <div><dt>Hints used</dt><dd>${session.summary.hintsUsed}</dd></div>
      </dl>
      <p class="quant-session-summary__topics"><strong>Topics practiced:</strong> ${escapeHtml(topicTitles || "No completed topics yet")}</p>
      <div class="quant-actions quant-session-summary__actions">
        <button class="button button--primary" type="button" data-quant-practice-again>Practice Again</button>
        <button class="button button--secondary" type="button" data-quant-choose-topic>Choose Another Topic</button>
        <button class="button button--secondary" type="button" data-quant-try-mix>Try Mix</button>
        <button class="button button--ghost" type="button" data-quant-back-home>Back to Home</button>
      </div>
    </section>
  `;
}

export function renderQuantLab(root, session, {
  question,
  questionIndex,
  questionCount,
  gradeLevels,
  topics,
  availableTopicIds,
  currentTopic,
  onGradeChange,
  onTopicChange,
  onResponseChange,
  onExpressionAction,
  onInteractiveAction,
  onHintToggle,
  onCheckAnswer,
  onNextQuestion,
  onPracticeAgain,
  onChooseTopic,
  onTryMix,
  onBackHome
}) {
  const questionWorkspace = session.sessionComplete
    ? renderSummary(session, topics)
    : `
      <section class="quant-question card" aria-labelledby="quant-question-title">
        <div class="quant-question__meta">
          <span class="badge quant-question__topic">${escapeHtml(currentTopic?.title ?? question.topic)}</span>
          <span>${escapeHtml(getQuestionTypeLabel(question.type))}</span>
        </div>
        <p class="quant-question__instruction">${escapeHtml(question.instruction)}</p>
        <h2 id="quant-question-title">${escapeHtml(question.prompt)}</h2>
        <form data-quant-form novalidate>
          <fieldset ${session.isChecked ? "disabled" : ""}>
            <legend class="sr-only">Answer area</legend>
            <div class="quant-answer-area">
              ${renderQuestionInteraction(question, session)}
            </div>
          </fieldset>
          <p id="quant-answer-help" class="quant-answer-message" aria-live="polite">${escapeHtml(session.validationMessage ?? "")}</p>
          ${renderRewardFeedback(session)}
          <div class="quant-hint-wrap">
            <button class="button button--ghost" type="button" data-quant-hint aria-expanded="${session.hintVisible}" ${session.isUnlockingHint ? "disabled" : ""}>${session.hintVisible ? "Hide hint" : session.isUnlockingHint ? "Unlocking hint…" : session.purchasedHintKeys?.includes(`quant:${question.id}:hint`) ? "Show hint" : `Unlock hint · ${quantRewardValues.hintCoinCost} coins`}</button>
            ${session.hintVisible ? `<aside class="quant-hint" aria-live="polite"><strong>Hint</strong><p>${escapeHtml(question.hint)}</p></aside>` : ""}
          </div>
          <div class="quant-actions">
            <button class="button button--primary" type="submit" data-quant-check ${hasResponse(question, session.response) && !session.isChecked && !session.isSavingAnswer ? "" : "disabled"}>${session.isSavingAnswer ? "Checking…" : "Check Answer"}</button>
            <button class="button button--secondary" type="button" data-quant-next ${session.isChecked ? "" : "hidden"}>${questionIndex === questionCount - 1 ? "Finish Session" : "Next Question"}</button>
          </div>
        </form>
      </section>
      ${renderFeedback(question, session)}
    `;

  root.innerHTML = `
    <div class="page-container quant-lab__container">
      <header class="quant-lab__header">
        <div>
          <p class="quant-eyebrow">Practice with purpose</p>
          <h1>Quant Lab</h1>
          <p>Build mathematical fluency one clear, well-supported step at a time.</p>
        </div>
        <div class="quant-progress" aria-label="Session progress">
          <span>Question ${questionIndex + 1} of ${questionCount}</span>
          <div class="quant-progress__track" role="progressbar" aria-valuemin="1" aria-valuemax="${questionCount}" aria-valuenow="${questionIndex + 1}" aria-valuetext="Question ${questionIndex + 1} of ${questionCount}">
            <span style="width: ${((questionIndex + 1) / questionCount) * 100}%"></span>
          </div>
        </div>
      </header>

      <section class="quant-selectors card" aria-label="Quant Lab settings">
        <div class="quant-selector">
          <p class="quant-selector__label">Learning level</p>
          <div class="quant-grade-list" role="group" aria-label="Quant Lab grade level">
            ${gradeLevels.map((grade) => `
              <button class="quant-grade-button${session.gradeLevel === grade.id ? " is-selected" : ""}" type="button" data-quant-grade="${grade.id}" aria-pressed="${session.gradeLevel === grade.id}">
                <span>${escapeHtml(grade.title)}</span><small>${escapeHtml(grade.description)}</small>
              </button>
            `).join("")}
          </div>
        </div>
        <div class="quant-selector">
          <p class="quant-selector__label">Practice topic</p>
          <div class="quant-topic-list" role="group" aria-label="Quant Lab topic">
            ${topics.map((topic) => {
              const isAvailable = topic.id === "mix" || availableTopicIds.has(topic.id);
              return `
              <button class="quant-topic-button${session.topic === topic.id ? " is-selected" : ""}" type="button" data-quant-topic="${topic.id}" aria-pressed="${session.topic === topic.id}" ${isAvailable ? "" : "disabled aria-disabled=\"true\" title=\"Starter questions for this topic are coming soon\""}>
                ${escapeHtml(topic.title)}
              </button>
            `;
            }).join("")}
          </div>
        </div>
      </section>

      <div class="quant-lab__workspace">
        ${questionWorkspace}
      </div>
    </div>
  `;

  root.querySelectorAll("[data-quant-grade]").forEach((button) => {
    button.addEventListener("click", () => onGradeChange(button.dataset.quantGrade));
  });
  root.querySelectorAll("[data-quant-topic]").forEach((button) => {
    button.addEventListener("click", () => onTopicChange(button.dataset.quantTopic));
  });
  root.querySelectorAll("[data-quant-text-answer]").forEach((input) => {
    input.addEventListener("input", (event) => {
      onResponseChange(event.target.value, { render: false });
      const checkButton = root.querySelector("[data-quant-check]");
      if (checkButton) {
        checkButton.disabled = !hasResponse(question, event.target.value);
      }
    });
  });
  root.querySelectorAll("[data-quant-equation-blank]").forEach((input) => {
    input.addEventListener("input", (event) => {
      const nextResponse = { ...session.response, [input.dataset.quantEquationBlank]: event.target.value };
      onResponseChange(nextResponse, { render: false });
      const checkButton = root.querySelector("[data-quant-check]");
      if (checkButton) {
        checkButton.disabled = !hasResponse(question, nextResponse);
      }
    });
  });
  root.querySelectorAll("input[name=quant-answer]").forEach((input) => {
    input.addEventListener("change", () => onResponseChange(input.value, { render: true }));
  });
  root.querySelectorAll("[data-quant-multiple]").forEach((input) => {
    input.addEventListener("change", () => {
      const selections = [...root.querySelectorAll("[data-quant-multiple]:checked")].map((item) => item.value);
      onResponseChange(selections, { render: true });
    });
  });
  root.querySelectorAll("[data-quant-expression-piece]").forEach((button) => {
    button.addEventListener("click", () => onExpressionAction("add", button.dataset.quantExpressionPiece));
  });
  root.querySelectorAll("[data-quant-expression-action]").forEach((button) => {
    button.addEventListener("click", () => onExpressionAction(button.dataset.quantExpressionAction));
  });
  bindInteractiveEvents(root, onInteractiveAction);
  root.querySelector("[data-quant-hint]")?.addEventListener("click", onHintToggle);
  root.querySelector("[data-quant-form]")?.addEventListener("submit", (event) => {
    event.preventDefault();
    onCheckAnswer();
  });
  root.querySelector("[data-quant-next]")?.addEventListener("click", onNextQuestion);
  root.querySelector("[data-quant-practice-again]")?.addEventListener("click", onPracticeAgain);
  root.querySelector("[data-quant-choose-topic]")?.addEventListener("click", onChooseTopic);
  root.querySelector("[data-quant-try-mix]")?.addEventListener("click", onTryMix);
  root.querySelector("[data-quant-back-home]")?.addEventListener("click", onBackHome);

  if (session.sessionComplete) {
    root.querySelector("[data-quant-summary]")?.focus();
  } else if (session.isChecked) {
    root.querySelector("[data-quant-feedback]")?.focus();
  }
}
