function normalizeResponse(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9.%]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getStepMap(story) {
  return new Map(story.steps.map((step) => [step.id, step]));
}

function getCoreSteps(story) {
  return story.steps.filter((step) => step.core !== false);
}

function getInitialStep(story) {
  return getStepMap(story).get(story.initialStepId) ?? story.steps[0] ?? null;
}

function getStepId(story, state) {
  if (typeof state?.currentStepId === "string") {
    return state.currentStepId;
  }

  return story.steps[state?.stepIndex ?? 0]?.id ?? getInitialStep(story)?.id ?? null;
}

function getOptionLabel(step, value) {
  return step.options?.find((option) => option.id === value)?.label ?? String(value ?? "");
}

function normalizeSelection(value) {
  return Array.isArray(value) ? [...new Set(value.map(String))] : value ? [String(value)] : [];
}

function selectionsMatch(response, answer) {
  const normalizedResponse = normalizeSelection(response).sort();
  const normalizedAnswer = normalizeSelection(answer).sort();

  return normalizedResponse.length === normalizedAnswer.length
    && normalizedResponse.every((value, index) => value === normalizedAnswer[index]);
}

export function evaluateStoryResponse(step, response, { writtenIsCorrect = null } = {}) {
  if (!step) {
    return false;
  }

  if (step.responseType === "numeric") {
    const text = String(response).replace(/[$,\s]/g, "");
    if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) return false;
    const entered = Number(text);
    const expected = Number.parseFloat(step.correctAnswer);
    return Number.isFinite(entered) && Number.isFinite(expected) && Math.abs(entered - expected) < 0.001;
  }

  if (step.responseType === "written") {
    if (typeof writtenIsCorrect === "boolean") {
      return writtenIsCorrect;
    }

    const normalized = normalizeResponse(response);
    return Boolean(normalized) && step.acceptedPhrases?.some((phrase) => (
      normalized.includes(normalizeResponse(phrase))
    ));
  }

  if (step.responseType === "evidence-selection") {
    return selectionsMatch(response, step.correctAnswer);
  }

  return response === step.correctAnswer;
}

function createCoachMessage(story, content, id) {
  return {
    id,
    role: "coach",
    speaker: story.character.name,
    content
  };
}

function createStudentMessage(story, step, response, attempt) {
  const content = step.responseType === "evidence-selection"
    ? normalizeSelection(response).map((value) => getOptionLabel(step, value)).join("; ")
    : ["multiple-choice", "recommendation", "single-choice"].includes(step.responseType)
      ? getOptionLabel(step, response)
      : String(response ?? "").trim();

  return {
    id: `${story.id}:${step.id}:student:${attempt}`,
    role: "student",
    content
  };
}

function getGuidanceMessage(step, { noIdea, guidanceLevel }) {
  const progressiveHints = Array.isArray(step.progressiveHints) ? step.progressiveHints : [];
  const level = Math.max(1, Math.min(Number(guidanceLevel) || 1, 3));

  if (level >= 3) {
    return step.strongHint
      ?? progressiveHints.at(-1)
      ?? (noIdea ? step.noIdeaGuidance : step.incorrectGuidance)
      ?? step.hint;
  }

  if (level >= 2) {
    return progressiveHints[Math.min(level - 1, progressiveHints.length - 1)]
      ?? step.hint
      ?? (noIdea ? step.noIdeaGuidance : step.incorrectGuidance);
  }

  return noIdea ? step.noIdeaGuidance : step.incorrectGuidance;
}

function getNextStep(story, step) {
  const stepMap = getStepMap(story);
  if (Object.hasOwn(step, "nextStep")) {
    return step.nextStep && stepMap.has(step.nextStep) ? stepMap.get(step.nextStep) : null;
  }

  const position = story.steps.findIndex((candidate) => candidate.id === step.id);
  return story.steps[position + 1] ?? null;
}

function getBranchStep(story, step, { noIdea }) {
  const stepMap = getStepMap(story);
  const targetId = noIdea ? step.unsureStep : step.incorrectStep;
  return targetId && stepMap.get(targetId) ? stepMap.get(targetId) : null;
}

function getCompletedStepIds(story, state) {
  const validStepIds = new Set(getCoreSteps(story).map((step) => step.id));
  return [...new Set((state.completedStepIds ?? []).filter((stepId) => validStepIds.has(stepId)))];
}

function completionMessage(story) {
  if (typeof story.conclusion === "string" && story.conclusion.trim()) {
    return story.conclusion;
  }

  return story.completionSummary?.lesson ?? "You used evidence and mathematical reasoning to guide a real choice.";
}

export function createStoryState(story) {
  const firstStep = getInitialStep(story);
  if (!firstStep) {
    throw new Error("Simulation story must include at least one step.");
  }

  return {
    storyId: story.id,
    currentStepId: firstStep.id,
    stepIndex: 0,
    response: "",
    attempts: 0,
    guidedAttempts: 0,
    noIdeaCount: 0,
    guidanceLevel: 0,
    completedStepIds: [],
    isThinking: false,
    isCompleting: false,
    isComplete: false,
    rewardPending: false,
    persistenceNotice: null,
    messages: [
      { id: `${story.id}:start`, role: "system", content: `Story started · ${story.title}` },
      createCoachMessage(story, story.openingMessage, `${story.id}:opening`),
      createCoachMessage(story, firstStep.coachMessage, `${story.id}:${firstStep.id}:question`)
    ]
  };
}

export function getCurrentStoryStep(story, state) {
  return getStepMap(story).get(getStepId(story, state)) ?? null;
}

export function getStoryProgress(story, state) {
  const total = getCoreSteps(story).length;
  const completed = state?.isComplete ? total : getCompletedStepIds(story, state).length;

  return {
    total,
    completed,
    current: state?.isComplete ? total : Math.min(completed + 1, total),
    percentage: total ? Math.round((completed / total) * 100) : 0
  };
}

export function hasStoryProgress(state) {
  return Boolean(state && (state.completedStepIds?.length || state.messages?.some((message) => message.role === "student")));
}

export function shouldUseAdaptiveCoach(plan) {
  return Boolean(plan && (plan.noIdea || plan.step.responseType === "written" || !plan.localIsCorrect));
}

export function beginStoryResponse(story, state, { response, noIdea = false }) {
  const step = getCurrentStoryStep(story, state);
  if (!step || state.isComplete || state.isThinking || state.isCompleting) {
    return null;
  }

  const normalizedResponse = step.responseType === "evidence-selection"
    ? normalizeSelection(response)
    : String(response ?? "").trim();
  if (!noIdea && (!normalizedResponse || (Array.isArray(normalizedResponse) && !normalizedResponse.length))) {
    return null;
  }

  const localIsCorrect = !noIdea && evaluateStoryResponse(step, normalizedResponse);
  const attempt = state.attempts + 1;
  const nextState = {
    ...state,
    response: step.responseType === "evidence-selection" ? [] : "",
    isThinking: true,
    coachingNotice: null,
    pendingResponse: {
      stepId: step.id,
      response: normalizedResponse,
      noIdea,
      localIsCorrect,
      attempt
    },
    messages: [
      ...state.messages,
      createStudentMessage(story, step, noIdea ? "I have no idea yet." : normalizedResponse, attempt)
    ]
  };

  return { state: nextState, step, noIdea, response: normalizedResponse, localIsCorrect };
}

export function finalizeStoryResponse(story, state, plan, { coachMessage = null, writtenIsCorrect = null } = {}) {
  const pending = state.pendingResponse;
  const step = getCurrentStoryStep(story, state);
  if (!pending || !step || pending.stepId !== plan?.step?.id || state.isComplete) {
    return state;
  }

  const isCorrect = !pending.noIdea && evaluateStoryResponse(step, pending.response, {
    writtenIsCorrect: step.responseType === "written"
      ? Boolean(pending.localIsCorrect || writtenIsCorrect)
      : null
  });
  const baseState = {
    ...state,
    attempts: pending.attempt,
    response: step.responseType === "evidence-selection" ? [] : "",
    isThinking: false,
    pendingResponse: null
  };

  if (!isCorrect) {
    const guidanceLevel = Math.min((state.guidanceLevel ?? 0) + 1, 3);
    const branchStep = getBranchStep(story, step, { noIdea: pending.noIdea });
    const guidance = coachMessage?.trim() || getGuidanceMessage(step, {
      noIdea: pending.noIdea,
      guidanceLevel
    }) || step.hint || "Let’s look at one piece of the evidence together.";
    const messages = [
      ...baseState.messages,
      createCoachMessage(story, guidance, `${story.id}:${step.id}:guide:${pending.attempt}`)
    ];

    if (branchStep && branchStep.id !== step.id) {
      messages.push(createCoachMessage(story, branchStep.coachMessage, `${story.id}:${branchStep.id}:question`));
    }

    return {
      ...baseState,
      currentStepId: branchStep?.id ?? step.id,
      stepIndex: Math.max(0, story.steps.findIndex((candidate) => candidate.id === (branchStep?.id ?? step.id))),
      guidanceLevel,
      guidedAttempts: (state.guidedAttempts ?? 0) + 1,
      noIdeaCount: (state.noIdeaCount ?? 0) + (pending.noIdea ? 1 : 0),
      messages
    };
  }

  const completedStepIds = getCompletedStepIds(story, state);
  if (step.core !== false && !completedStepIds.includes(step.id)) {
    completedStepIds.push(step.id);
  }

  const nextStep = getNextStep(story, step);
  const messages = [
    ...baseState.messages,
    createCoachMessage(story, coachMessage?.trim() || step.explanation, `${story.id}:${step.id}:explanation`)
  ];

  if (nextStep) {
    messages.push(createCoachMessage(story, nextStep.coachMessage, `${story.id}:${nextStep.id}:question`));
    return {
      ...baseState,
      currentStepId: nextStep.id,
      stepIndex: Math.max(0, story.steps.findIndex((candidate) => candidate.id === nextStep.id)),
      completedStepIds,
      guidanceLevel: 0,
      messages
    };
  }

  messages.push(
    createCoachMessage(story, completionMessage(story), `${story.id}:conclusion`),
    { id: `${story.id}:complete`, role: "system", content: "Story complete" }
  );

  return {
    ...baseState,
    currentStepId: null,
    stepIndex: story.steps.length,
    completedStepIds,
    guidanceLevel: 0,
    isComplete: true,
    messages
  };
}

export function submitStoryResponse(story, state, input, options = {}) {
  const plan = beginStoryResponse(story, state, input);
  return plan ? finalizeStoryResponse(story, plan.state, plan, options) : state;
}

// Preserve evidence of the student's core responses when trimming a long chat.
// A plain last-12 slice can discard a response in favor of extra coach messages,
// causing the database's completion guard to reject an honestly finished story.
export function compactResponseHistory(messages, requiredResponses) {
  const history = messages.filter(message => ["coach", "student"].includes(message.role)
    && typeof message.content === "string");
  const students = history.map((message, index) => message.role === "student" ? index : -1).filter(index => index >= 0);
  const reserved = new Set(students.slice(-Math.max(1, Math.min(12, requiredResponses))));
  for (let index = history.length - 1; index >= 0 && reserved.size < 12; index--) reserved.add(index);
  return [...reserved].sort((a, b) => a - b).map(index => ({
    role: history[index].role, content: history[index].content.slice(0, 700)
  }));
}

export function restoreStoryState(story, storedState = {}) {
  const initialState = createStoryState(story);
  const storedStepIndex = Number.isInteger(storedState.stepIndex) ? storedState.stepIndex : -1;
  const currentStep = getStepMap(story).get(storedState.currentStepId)
    ?? story.steps[storedStepIndex]
    ?? null;
  const isComplete = Boolean(storedState.isComplete);
  const messages = Array.isArray(storedState.messages)
    ? storedState.messages
      .filter((message) => ["coach", "student", "system"].includes(message?.role) && typeof message.content === "string")
      .slice(-24)
      .map((message, index) => ({
        id: typeof message.id === "string" ? message.id : `${story.id}:restored:${index}`,
        role: message.role,
        ...(message.role === "coach" ? { speaker: story.character.name } : {}),
        content: message.content.slice(0, 700)
      }))
    : initialState.messages;
  const persistenceNotice = typeof storedState.persistenceNotice === "string"
    ? storedState.persistenceNotice.slice(0, 260)
    : null;
  const rewardFeedback = storedState.rewardFeedback && typeof storedState.rewardFeedback === "object"
    ? {
        ...(storedState.rewardFeedback.eventRecorded === true ? { eventRecorded: true } : {}),
        ...(typeof storedState.rewardFeedback.message === "string"
          ? { message: storedState.rewardFeedback.message.slice(0, 260) }
          : {})
      }
    : null;

  return {
    ...initialState,
    currentStepId: isComplete ? null : currentStep?.id ?? initialState.currentStepId,
    stepIndex: isComplete ? story.steps.length : Math.max(0, story.steps.findIndex((step) => step.id === currentStep?.id)),
    response: "",
    attempts: Math.min(Math.max(Number(storedState.attempts) || 0, 0), 100),
    guidedAttempts: Math.min(Math.max(Number(storedState.guidedAttempts) || 0, 0), 100),
    noIdeaCount: Math.min(Math.max(Number(storedState.noIdeaCount) || 0, 0), 100),
    guidanceLevel: Math.min(Math.max(Number(storedState.guidanceLevel) || 0, 0), 3),
    completedStepIds: getCompletedStepIds(story, storedState),
    isComplete,
    rewardPending: isComplete && Boolean(storedState.rewardPending),
    ...(persistenceNotice ? { persistenceNotice } : {}),
    ...(rewardFeedback ? { rewardFeedback } : {}),
    messages: messages.length ? messages : initialState.messages
  };
}
