import { getSimulationStories, getSimulationStory, simulationGradeLevels } from "../../data/simulation/stories.js";
import { sendSimulationResponse } from "../../services/aiService.js";
import { getAppState } from "../../services/appState.js";
import { recordActivity } from "../../services/rewardService.js";
import { displayReward } from "../../services/rewardDisplay.js";
import {
  getSimulationProgress,
  saveSimulationProgress,
  SimulationProgressAuthenticationError
} from "../../services/simulationProgressService.js";
import { renderSimulationLab } from "./conversationRenderer.js";
import {
  beginStoryResponse,
  compactResponseHistory,
  createStoryState,
  finalizeStoryResponse,
  getStoryProgress,
  hasStoryProgress,
  restoreStoryState,
  shouldUseAdaptiveCoach
} from "./storyEngine.js";
import { loadSimulationLabSession, saveSimulationLabSession } from "./simulationSession.js";

function isSupportedGrade(gradeLevel) {
  return simulationGradeLevels.some((grade) => grade.id === gradeLevel);
}

function isValidStoredStory(story, state) {
  return state?.storyId === story.id
    && Array.isArray(state.messages)
    && typeof state.isComplete === "boolean";
}

function getStoredSession(userId, fallbackGrade) {
  const stored = loadSimulationLabSession(userId);
  if (!stored || !isSupportedGrade(stored.gradeLevel)) {
    return { gradeLevel: fallbackGrade, storyId: null, storyState: null, isReplay: false };
  }

  const story = getSimulationStory(stored.storyId);
  if (!story || story.gradeLevel !== stored.gradeLevel || !isValidStoredStory(story, stored.storyState)) {
    return { gradeLevel: stored.gradeLevel, storyId: null, storyState: null, isReplay: false };
  }

  return {
    gradeLevel: stored.gradeLevel,
    storyId: story.id,
    storyState: restoreStoryState(story, stored.storyState),
    isReplay: Boolean(stored.isReplay)
  };
}

function createProgressMap(records) {
  return new Map(records.map((record) => [record.storyId, record]));
}

function getCoreSteps(story) {
  return story.steps.filter((step) => step.core !== false);
}

function createStateFromProgress(story, progress) {
  const coreSteps = getCoreSteps(story);
  const completedCount = progress.status === "completed"
    ? coreSteps.length
    : Math.min(Math.max(progress.currentStep, 0), coreSteps.length);
  const activeStep = coreSteps[completedCount] ?? null;

  return restoreStoryState(story, {
    storyId: story.id,
    currentStepId: activeStep?.id ?? null,
    stepIndex: activeStep ? story.steps.findIndex((step) => step.id === activeStep.id) : story.steps.length,
    completedStepIds: coreSteps.slice(0, completedCount).map((step) => step.id),
    attempts: progress.attempts,
    guidedAttempts: progress.helpUses,
    noIdeaCount: progress.helpUses,
    guidanceLevel: progress.guidanceLevel,
    messages: progress.responseHistory,
    isComplete: progress.status === "completed"
  });
}

function createProgressPayload(story, state) {
  const progress = getStoryProgress(story, state);
  return {
    storyId: story.id,
    gradeLevel: story.gradeLevel,
    // Persist the number of completed core decisions rather than a raw array
    // index. Support branches are optional, so their position must not make a
    // student look farther through the story than they really are.
    currentStep: Math.min(Math.max(progress.completed, 0), 100),
    attempts: Math.min(Math.max(state.attempts ?? 0, 0), 1000),
    helpUses: Math.min(Math.max((state.guidedAttempts ?? 0) + (state.noIdeaCount ?? 0), 0), 1000),
    guidanceLevel: Math.min(Math.max(state.guidanceLevel ?? 0, 0), 3),
    responseHistory: compactResponseHistory(state.messages, getCoreSteps(story).length)
  };
}

function createConversationHistory(messages) {
  return messages
    .filter((message) => ["coach", "student"].includes(message.role) && typeof message.content === "string")
    .slice(-6)
    .map((message) => ({ role: message.role, content: message.content.slice(0, 600) }));
}

function toAiResponseText(response) {
  return Array.isArray(response) ? response.join(", ") : String(response ?? "");
}

export function createSimulationLabView() {
  const appState = getAppState();
  const userId = appState.user?.id;
  const fallbackGrade = isSupportedGrade(appState.user?.gradeLevel) ? appState.user.gradeLevel : "middle";
  const session = {
    ...getStoredSession(userId, fallbackGrade),
    progressByStory: new Map(),
    isProgressLoaded: false,
    hasUserInteracted: false
  };
  const root = document.createElement("section");
  root.className = "simulation-lab section";
  let saveQueue = Promise.resolve(null);
  let pendingTurnId = 0;

  function currentStory() {
    return session.storyId ? getSimulationStory(session.storyId) : null;
  }

  function saveLocalSession() {
    saveSimulationLabSession(userId, session);
  }

  function discardCurrentStory() {
    session.storyId = null;
    session.storyState = null;
    session.isReplay = false;
  }

  function queueProgressSave(story = currentStory(), state = session.storyState) {
    if (!story || !state || session.isReplay) {
      return Promise.resolve(null);
    }

    const payload = createProgressPayload(story, state);
    const saveTask = saveQueue
      .catch(() => null)
      .then(async () => {
        const progress = await saveSimulationProgress(payload);
        session.progressByStory.set(progress.storyId, progress);
        if (session.storyId === story.id && session.storyState?.persistenceNotice) {
          session.storyState.persistenceNotice = null;
          saveLocalSession();
        }
        return progress;
      });
    saveQueue = saveTask.catch(() => null);
    return saveTask;
  }

  function saveProgressInBackground(story = currentStory(), state = session.storyState) {
    void queueProgressSave(story, state).catch((error) => {
      if (session.storyId !== story?.id || !session.storyState) {
        return;
      }

      session.storyState.persistenceNotice = error instanceof SimulationProgressAuthenticationError
        ? "Your sign-in expired. Sign in again to keep saving this story."
        : "Your work is safely kept on this device and will be saved when you are back online.";
      saveLocalSession();
      render();
    });
  }

  function render({ focusLatest = false } = {}) {
    const story = currentStory();
    renderSimulationLab(root, session, {
      stories: getSimulationStories(session.gradeLevel),
      story,
      progressByStory: session.progressByStory,
      onGradeChange: (nextGrade) => {
        if (!isSupportedGrade(nextGrade) || nextGrade === session.gradeLevel) {
          return;
        }

        if (session.storyState && hasStoryProgress(session.storyState)
          && !session.storyState.isComplete
          && !window.confirm("Changing levels will leave this story ready to continue later. Continue?")) {
          return;
        }

        session.hasUserInteracted = true;
        session.gradeLevel = nextGrade;
        discardCurrentStory();
        saveLocalSession();
        render();
      },
      onStartStory: (storyId) => {
        const nextStory = getSimulationStory(storyId);
        if (!nextStory || nextStory.gradeLevel !== session.gradeLevel) {
          return;
        }

        session.hasUserInteracted = true;
        const knownProgress = session.progressByStory.get(nextStory.id);
        session.storyId = nextStory.id;
        session.isReplay = knownProgress?.status === "completed";
        session.storyState = knownProgress?.status === "in_progress"
          ? createStateFromProgress(nextStory, knownProgress)
          : createStoryState(nextStory);
        saveLocalSession();
        saveProgressInBackground();
        render({ focusLatest: true });
      },
      onResponseChange: (response, shouldRender) => {
        if (!session.storyState || session.storyState.isThinking || session.storyState.isCompleting) {
          return;
        }

        session.storyState.response = response;
        saveLocalSession();
        if (shouldRender) {
          render();
        }
      },
      onSubmitResponse: () => {
        void handleStudentResponse({ response: session.storyState?.response });
      },
      onNoIdea: () => {
        void handleStudentResponse({ noIdea: true });
      },
      onRetryCompletion: () => {
        const activeStory = currentStory();
        if (activeStory) {
          void completeStory(activeStory);
        }
      },
      onRestart: () => {
        const activeStory = currentStory();
        if (!activeStory || !session.storyState || session.storyState.isThinking || session.storyState.isCompleting) {
          return;
        }

        if (hasStoryProgress(session.storyState)
          && !window.confirm("Restart this story and clear your current responses?")) {
          return;
        }

        session.hasUserInteracted = true;
        session.isReplay = session.progressByStory.get(activeStory.id)?.status === "completed";
        session.storyState = createStoryState(activeStory);
        saveLocalSession();
        saveProgressInBackground();
        render({ focusLatest: true });
      },
      onBack: () => {
        if (session.storyState && hasStoryProgress(session.storyState)
          && !session.storyState.isComplete
          && !window.confirm("Return to story selection? Your in-progress story will be ready to continue later.")) {
          return;
        }

        session.hasUserInteracted = true;
        discardCurrentStory();
        saveLocalSession();
        render();
      },
      onBackHome: () => {
        window.location.hash = "#/";
      }
    });

    if (focusLatest) {
      requestAnimationFrame(() => {
        root.querySelector("[data-simulation-latest-coach], [data-simulation-complete]")?.focus();
      });
    }
  }

  async function completeStory(story) {
    if (!session.storyState?.isComplete || session.storyState.isCompleting) {
      return;
    }

    session.storyState.isCompleting = true;
    session.storyState.rewardPending = true;
    session.storyState.rewardFeedback = { message: "Saving your completed story…" };
    saveLocalSession();
    render();

    try {
      await queueProgressSave(story, session.storyState);
      const reward = await recordActivity({
        eventKey: `simulation:${story.id}:completed`,
        module: "simulation",
        topic: story.id,
        activityType: "story_completed",
        metadata: {
          story_id: story.id,
          grade_level: story.gradeLevel,
          math_concepts: story.mathConcepts.slice(0, 8),
          guided_attempts: session.storyState.guidedAttempts ?? 0,
          support_requests: session.storyState.noIdeaCount ?? 0
        }
      });
      session.progressByStory.set(story.id, {
        ...(session.progressByStory.get(story.id) ?? {}),
        storyId: story.id,
        gradeLevel: story.gradeLevel,
        status: "completed"
      });
      session.storyState.rewardFeedback = reward.eventRecorded
        ? { eventRecorded: true }
        : { message: `This story has already awarded its ${displayReward("simulation_complete").xp} XP.` };
      session.storyState.rewardPending = false;
    } catch (error) {
      session.storyState.rewardFeedback = {
        message: error instanceof SimulationProgressAuthenticationError
          ? "Your sign-in expired. Sign in again to save this completed story and its XP."
          : "Your story is complete. We will retry saving its XP when Numora reconnects."
      };
      session.storyState.rewardPending = true;
    } finally {
      session.storyState.isCompleting = false;
      saveLocalSession();
      render({ focusLatest: true });
    }
  }

  async function handleStudentResponse(input) {
    const story = currentStory();
    if (!story || !session.storyState) {
      return;
    }

    const plan = beginStoryResponse(story, session.storyState, input);
    if (!plan) {
      return;
    }

    session.hasUserInteracted = true;
    const turnId = ++pendingTurnId;
    session.storyState = plan.state;
    saveLocalSession();
    saveProgressInBackground(story, session.storyState);
    render();

    let adaptiveResult = null;
    if (shouldUseAdaptiveCoach(plan)) {
      adaptiveResult = await sendSimulationResponse({
        storyId: story.id,
        gradeLevel: story.gradeLevel,
        currentStep: plan.step.id,
        studentResponse: plan.noIdea ? "I have no idea yet." : toAiResponseText(plan.response),
        interaction: plan.noIdea ? "no_idea" : "answer",
        guidanceLevel: Math.min((session.storyState.guidanceLevel ?? 0) + 1, 3),
        conversationHistory: createConversationHistory(session.storyState.messages)
      });
    }

    if (turnId !== pendingTurnId || !session.storyState?.pendingResponse) {
      return;
    }

    let coachMessage = null;
    let writtenIsCorrect = null;
    if (adaptiveResult?.success) {
      const aiSaysCorrect = adaptiveResult.status === "correct";
      if (plan.noIdea || plan.step.responseType === "written") {
        writtenIsCorrect = plan.step.responseType === "written" ? aiSaysCorrect : null;
        if (plan.noIdea || plan.localIsCorrect === aiSaysCorrect) {
          coachMessage = adaptiveResult.coachMessage;
        }
      } else if (plan.localIsCorrect === aiSaysCorrect) {
        coachMessage = adaptiveResult.coachMessage;
      }
    } else if (adaptiveResult?.reason === "authentication") {
      session.storyState.coachingNotice = "Your response is kept on this device. Sign in again to keep saving your story.";
    } else if (adaptiveResult?.scriptedFallback) {
      session.storyState.coachingNotice = "Your coach is using the guided story path for now.";
    }

    session.storyState = finalizeStoryResponse(story, session.storyState, plan, {
      coachMessage,
      writtenIsCorrect
    });
    saveLocalSession();
    saveProgressInBackground(story, session.storyState);

    if (session.storyState.isComplete) {
      await completeStory(story);
      return;
    }

    render({ focusLatest: true });
  }

  async function hydrateProgress() {
    let completionToRetry = null;
    try {
      const records = await getSimulationProgress();
      if (session.hasUserInteracted) {
        return;
      }

      session.progressByStory = createProgressMap(records);
      const localStory = currentStory();
      const matchingRemote = localStory ? session.progressByStory.get(localStory.id) : null;

      if (!localStory) {
        const resumable = records.find((record) => record.status === "in_progress" && getSimulationStory(record.storyId));
        if (resumable) {
          const story = getSimulationStory(resumable.storyId);
          session.gradeLevel = story.gradeLevel;
          session.storyId = story.id;
          session.storyState = createStateFromProgress(story, resumable);
          session.isReplay = false;
          saveLocalSession();
        }
      } else if (matchingRemote?.status === "completed") {
        if (session.storyState?.isComplete) {
          session.storyState.rewardPending = false;
          session.storyState.rewardFeedback ??= {
            message: "This story has already awarded its 10 XP."
          };
          saveLocalSession();
        }
      } else if (session.storyState?.isComplete && !session.isReplay) {
        // Preserve a locally completed story until its final save and reward
        // have succeeded. Replacing it with an older in-progress row here
        // would make a retry impossible after an offline moment.
        session.storyState.rewardPending = true;
        completionToRetry = localStory;
        saveLocalSession();
      } else if (matchingRemote?.status === "in_progress") {
        session.storyState = createStateFromProgress(localStory, matchingRemote);
        session.isReplay = false;
        saveLocalSession();
      }
    } catch (error) {
      if (session.storyState?.isComplete && !session.isReplay) {
        session.storyState.rewardPending = true;
        session.storyState.rewardFeedback = {
          message: error instanceof SimulationProgressAuthenticationError
            ? "Your sign-in expired. Sign in again to save this completed story and its XP."
            : "Your completed story is kept on this device. Try saving it again when you are online."
        };
        saveLocalSession();
      }
      // Local session state remains available when private progress cannot be loaded.
    } finally {
      session.isProgressLoaded = true;
      render();
      if (completionToRetry) {
        void completeStory(completionToRetry);
      }
    }
  }

  render();
  void hydrateProgress();
  return root;
}
