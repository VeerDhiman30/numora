import { simulationGradeLevels } from "../../data/simulation/stories.js";
import { displayReward } from "../../services/rewardDisplay.js";
import { getStoryProgress } from "./storyEngine.js";

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

function renderProgress(story, state) {
  if (!state) {
    return "";
  }

  const progress = getStoryProgress(story, state);
  const label = state.isComplete
    ? `${progress.total} of ${progress.total} steps complete`
    : `Step ${progress.current} of ${progress.total}`;

  return `
    <div class="simulation-progress" aria-label="Story progress: ${escapeHtml(label)}">
      <span>${escapeHtml(label)}</span>
      <div class="simulation-progress__track" aria-hidden="true"><span style="width: ${progress.percentage}%"></span></div>
    </div>
  `;
}

function renderGradeSelector(session) {
  return `
    <section class="simulation-selector" aria-labelledby="simulation-grade-title">
      <p class="simulation-selector__eyebrow">Learning level</p>
      <h2 id="simulation-grade-title">Choose a lens</h2>
      <div class="simulation-grade-list" role="group" aria-label="Simulation Lab grade level">
        ${simulationGradeLevels.map((grade) => `
          <button class="simulation-grade-button${session.gradeLevel === grade.id ? " is-selected" : ""}" type="button" data-simulation-grade="${grade.id}" aria-pressed="${session.gradeLevel === grade.id}">
            <span>${escapeHtml(grade.title)}</span>
            <small>${escapeHtml(grade.description)}</small>
          </button>
        `).join("")}
      </div>
    </section>
  `;
}

function storyStatusText(status) {
  if (status?.status === "completed") {
    return `<span class="simulation-story-card__status simulation-story-card__status--completed">✓ Completed</span>`;
  }

  if (status?.status === "in_progress") {
    return `<span class="simulation-story-card__status simulation-story-card__status--progress">In progress</span>`;
  }

  return `<span class="simulation-story-card__status">Not started</span>`;
}

function renderStoryCards(stories, progressByStory) {
  return `
    <section class="simulation-story-selection" aria-labelledby="simulation-stories-title">
      <header class="simulation-section-heading">
        <p>Choose a scenario</p>
        <h2 id="simulation-stories-title">Where would you like to use math?</h2>
        <span>Follow a coach through a real decision, one thoughtful step at a time.</span>
      </header>
      <div class="simulation-story-grid">
        ${stories.map((story) => {
          const status = progressByStory?.get(story.id);
          const action = status?.status === "in_progress"
            ? "Continue story"
            : status?.status === "completed"
              ? "Replay story"
              : "Start story";
          return `
            <article class="simulation-story-card card">
              <span class="simulation-story-card__visual" aria-hidden="true">${escapeHtml(story.character.visual)}</span>
              <p class="simulation-story-card__character">With ${escapeHtml(story.character.name)}</p>
              <h3>${escapeHtml(story.title)}</h3>
              <p>${escapeHtml(story.description)}</p>
              <div class="simulation-concepts" aria-label="Math concepts">
                ${story.mathConcepts.map((concept) => `<span class="badge">${escapeHtml(concept)}</span>`).join("")}
              </div>
              <div class="simulation-story-card__footer">
                <span>${story.steps.filter((step) => step.core !== false).length} steps</span>
                ${storyStatusText(status)}
                <button class="button button--primary" type="button" data-simulation-start="${story.id}">${action}</button>
              </div>
            </article>
          `;
        }).join("")}
      </div>
    </section>
  `;
}

function renderTableEvidence(evidence) {
  const headings = evidence.columns.map((heading) => `<th scope="col">${escapeHtml(heading)}</th>`).join("");
  const rows = evidence.rows.map((row) => `<tr>${row.map((cell) => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`).join("");

  return `
    <article class="simulation-evidence__item">
      <h3>${escapeHtml(evidence.title)}</h3>
      ${evidence.description ? `<p>${escapeHtml(evidence.description)}</p>` : ""}
      <div class="simulation-table-wrap">
        <table>
          <thead><tr>${headings}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </article>
  `;
}

function renderFactEvidence(evidence) {
  const items = evidence.items ?? evidence.rows ?? [];
  return `
    <article class="simulation-evidence__item">
      <h3>${escapeHtml(evidence.title)}</h3>
      ${evidence.description ? `<p>${escapeHtml(evidence.description)}</p>` : ""}
      <dl class="simulation-evidence__facts">
        ${items.map((item) => `<div><dt>${escapeHtml(item.label ?? item[0])}</dt><dd>${escapeHtml(item.value ?? item[1])}</dd></div>`).join("")}
      </dl>
    </article>
  `;
}

function renderEvidence(story) {
  const evidenceItems = Array.isArray(story.evidence) ? story.evidence : [story.evidence].filter(Boolean);
  const content = evidenceItems.map((evidence) => (
    evidence.columns && evidence.rows ? renderTableEvidence(evidence) : renderFactEvidence(evidence)
  )).join("");

  return `
    <aside class="simulation-evidence card" aria-labelledby="simulation-evidence-title">
      <p class="simulation-evidence__eyebrow">Story evidence</p>
      <h2 id="simulation-evidence-title">Use what you know</h2>
      <div class="simulation-evidence__list">${content}</div>
    </aside>
  `;
}

function renderMessages(state) {
  const messages = state.messages.map((message, index) => {
    const label = message.role === "coach" ? message.speaker : message.role === "student" ? "You" : "Story update";
    const latestCoach = message.role === "coach" && index === state.messages.length - 1 && !state.isThinking;
    return `
      <article class="simulation-message simulation-message--${message.role}" ${latestCoach ? "tabindex=\"-1\" data-simulation-latest-coach" : ""}>
        <p class="simulation-message__speaker">${escapeHtml(label)}</p>
        <p>${escapeHtml(message.content)}</p>
      </article>
    `;
  }).join("");

  const thinking = state.isThinking
    ? `<div class="simulation-thinking" role="status" aria-live="polite"><span aria-hidden="true"></span>${escapeHtml(state.thinkingLabel ?? "Coach is considering your reasoning…")}</div>`
    : "";
  return `${messages}${thinking}`;
}

function renderCompletionSummary(story, state) {
  const summary = story.completionSummary ?? {};
  const reward = state.rewardFeedback?.eventRecorded
    ? `+${displayReward("simulation_complete").xp} XP added to your Numora progress`
    : state.rewardFeedback?.message ?? `+${displayReward("simulation_complete").xp} XP is awarded once when a story is first completed.`;

  return `
    <section class="simulation-response simulation-completion card" aria-labelledby="simulation-complete-title" tabindex="-1" data-simulation-complete>
      <p class="simulation-response__eyebrow">Story complete</p>
      <h2 id="simulation-complete-title">${escapeHtml(summary.title ?? "You followed the evidence to a decision.")}</h2>
      <dl class="simulation-completion__summary">
        <div><dt>What you decided</dt><dd>${escapeHtml(summary.decision ?? story.title)}</dd></div>
        <div><dt>Why it worked</dt><dd>${escapeHtml(summary.whyItWorked ?? story.conclusion)}</dd></div>
        <div><dt>Math you used</dt><dd>${escapeHtml(summary.mathUsed ?? story.mathConcepts.join(", "))}</dd></div>
        <div><dt>In real life</dt><dd>${escapeHtml(summary.realWorld ?? summary.lesson ?? "Using evidence helps people make stronger choices.")}</dd></div>
      </dl>
      <p class="simulation-completion__reward" role="status">${escapeHtml(reward)}</p>
      <dl class="simulation-completion__metrics" aria-label="Story session summary">
        <div><dt>Core steps</dt><dd>${story.steps.filter((step) => step.core !== false).length}</dd></div>
        <div><dt>Guided retries</dt><dd>${state.guidedAttempts ?? 0}</dd></div>
        <div><dt>Support requests</dt><dd>${state.noIdeaCount ?? 0}</dd></div>
      </dl>
      <div class="simulation-response__actions">
        ${state.rewardPending ? `<button class="button button--secondary" type="button" data-simulation-retry ${state.isCompleting ? "disabled" : ""}>Save completion</button>` : ""}
        <button class="button button--primary" type="button" data-simulation-back ${state.isCompleting ? "disabled" : ""}>Try another story</button>
        <button class="button button--secondary" type="button" data-simulation-restart ${state.isCompleting ? "disabled" : ""}>Replay story</button>
        <button class="button button--ghost" type="button" data-simulation-home ${state.isCompleting ? "disabled" : ""}>Back to Home</button>
      </div>
    </section>
  `;
}

function renderChoiceOptions(step, state) {
  const isEvidence = step.responseType === "evidence-selection";
  const selected = isEvidence
    ? new Set(Array.isArray(state.response) ? state.response : [])
    : new Set([state.response]);
  const isMultiple = isEvidence && step.selectionMode === "multiple";
  const controlType = isMultiple ? "checkbox" : "radio";
  const instruction = isEvidence && isMultiple
    ? `Choose ${step.requiredSelections ?? "the"} pieces of evidence.`
    : "Choose one response.";

  return `
    <fieldset class="simulation-response-options" ${state.isThinking || state.isCompleting ? "disabled" : ""}>
      <legend>${escapeHtml(instruction)}</legend>
      ${step.options?.map((option) => `
        <label class="simulation-response-option${selected.has(option.id) ? " is-selected" : ""}">
          <input type="${controlType}" name="simulation-response" value="${escapeHtml(option.id)}" ${selected.has(option.id) ? "checked" : ""}>
          <span><strong>${escapeHtml(option.label)}</strong>${option.description ? `<small>${escapeHtml(option.description)}</small>` : ""}</span>
        </label>
      `).join("") ?? ""}
    </fieldset>
  `;
}

function renderResponseArea(story, step, state) {
  if (state.isComplete) {
    return renderCompletionSummary(story, state);
  }

  const isChoice = ["multiple-choice", "recommendation", "single-choice", "evidence-selection"].includes(step.responseType);
  const inputType = step.responseType === "numeric" ? "number" : "text";
  const responseValue = Array.isArray(state.response) ? "" : state.response;
  const isDisabled = state.isThinking || state.isCompleting;
  const buttonText = state.isThinking ? "Coach is thinking…" : "Share response";

  return `
    <section class="simulation-response card" aria-labelledby="simulation-response-title">
      <p class="simulation-response__eyebrow">Your turn</p>
      <h2 id="simulation-response-title">Make your call</h2>
      <form data-simulation-response-form>
        ${isChoice ? renderChoiceOptions(step, state) : `
          <label class="simulation-response-input" for="simulation-response-input">
            <span>${escapeHtml(step.answerLabel ?? "Your response")}</span>
            <input id="simulation-response-input" name="response" type="${inputType}" ${inputType === "number" ? "inputmode=\"decimal\" step=\"any\"" : ""} value="${escapeHtml(responseValue)}" autocomplete="off" required ${isDisabled ? "disabled" : ""}>
          </label>
        `}
        <div class="simulation-response__actions">
          <button class="button button--primary" type="submit" data-simulation-submit ${(responseValue || (Array.isArray(state.response) && state.response.length)) && !isDisabled ? "" : "disabled"} ${isDisabled ? "aria-busy=\"true\"" : ""}>${buttonText}</button>
          <button class="button button--ghost" type="button" data-simulation-no-idea ${isDisabled ? "disabled" : ""}>I have no idea</button>
        </div>
        ${state.coachingNotice ? `<p class="simulation-response__notice" role="status">${escapeHtml(state.coachingNotice)}</p>` : ""}
        ${state.persistenceNotice ? `<p class="simulation-response__notice" role="status">${escapeHtml(state.persistenceNotice)}</p>` : ""}
        <p class="simulation-response__hint">Hint: ${escapeHtml(step.hint)}</p>
      </form>
    </section>
  `;
}

function renderActiveStory(story, state) {
  const step = state.isComplete ? null : story.steps.find((item) => item.id === state.currentStepId) ?? story.steps[state.stepIndex];
  return `
    <div class="simulation-active-grid">
      <section class="simulation-conversation card" aria-labelledby="simulation-conversation-title">
        <header class="simulation-conversation__header">
          <div>
            <p class="simulation-conversation__eyebrow">${escapeHtml(story.character.role)}</p>
            <h2 id="simulation-conversation-title">${escapeHtml(story.title)}</h2>
          </div>
          <span class="simulation-character-mark" aria-label="Coach: ${escapeHtml(story.character.name)}">${escapeHtml(story.character.visual)}</span>
        </header>
        <div class="simulation-message-list" aria-live="polite" aria-relevant="additions text">
          ${renderMessages(state)}
        </div>
      </section>
      <div class="simulation-active-grid__context">
        ${renderEvidence(story)}
        <aside class="simulation-coach card" aria-label="Your coach">
          <span aria-hidden="true">${escapeHtml(story.character.visual)}</span>
          <div><p>Your coach</p><strong>${escapeHtml(story.character.name)}</strong><small>${escapeHtml(story.character.role)}</small></div>
        </aside>
      </div>
      ${renderResponseArea(story, step, state)}
    </div>
  `;
}

export function renderSimulationLab(root, session, {
  stories,
  story,
  progressByStory,
  onGradeChange,
  onStartStory,
  onResponseChange,
  onSubmitResponse,
  onNoIdea,
  onRetryCompletion,
  onRestart,
  onBack,
  onBackHome
}) {
  const hasStory = Boolean(story && session.storyState);
  root.innerHTML = `
    <div class="page-container simulation-lab__container">
      <header class="simulation-lab__header">
        <div>
          <p class="simulation-eyebrow">Applied reasoning</p>
          <h1>Simulation Lab</h1>
          <p>Use mathematics inside everyday situations with a coach beside you.</p>
        </div>
        ${hasStory ? renderProgress(story, session.storyState) : ""}
      </header>
      <aside class="simulation-lab__selectors card" aria-label="Simulation settings">
        ${renderGradeSelector(session)}
        ${hasStory ? `
          <section class="simulation-story-controls" aria-label="Current story controls">
            <p class="simulation-selector__eyebrow">Current story</p>
            <strong>${escapeHtml(story.title)}</strong>
            <button class="button button--secondary" type="button" data-simulation-restart ${session.storyState.isThinking || session.storyState.isCompleting ? "disabled" : ""}>Restart story</button>
            <button class="button button--ghost" type="button" data-simulation-back ${session.storyState.isThinking || session.storyState.isCompleting ? "disabled" : ""}>Back to stories</button>
          </section>
        ` : ""}
      </aside>
      <main class="simulation-lab__workspace">
        ${hasStory ? renderActiveStory(story, session.storyState) : renderStoryCards(stories, progressByStory)}
      </main>
    </div>
  `;

  root.querySelectorAll("[data-simulation-grade]").forEach((button) => {
    button.addEventListener("click", () => onGradeChange(button.dataset.simulationGrade));
  });
  root.querySelectorAll("[data-simulation-start]").forEach((button) => {
    button.addEventListener("click", () => onStartStory(button.dataset.simulationStart));
  });
  root.querySelectorAll("[data-simulation-restart]").forEach((button) => button.addEventListener("click", onRestart));
  root.querySelectorAll("[data-simulation-back]").forEach((button) => button.addEventListener("click", onBack));
  root.querySelector("[data-simulation-retry]")?.addEventListener("click", onRetryCompletion);
  root.querySelector("[data-simulation-home]")?.addEventListener("click", onBackHome);

  const form = root.querySelector("[data-simulation-response-form]");
  if (form) {
    form.addEventListener("change", (event) => {
      const input = event.target;
      if (!(input instanceof HTMLInputElement) || input.name !== "simulation-response") {
        return;
      }

      const checked = [...form.querySelectorAll("input[name=simulation-response]:checked")].map((control) => control.value);
      onResponseChange(input.type === "checkbox" ? checked : input.value, true);
    });
    form.addEventListener("input", (event) => {
      const input = event.target;
      if (input instanceof HTMLInputElement && input.name === "response") {
        const submitButton = form.querySelector("[data-simulation-submit]");
        if (submitButton instanceof HTMLButtonElement) {
          submitButton.disabled = !input.value.trim();
        }
        onResponseChange(input.value, false);
      }
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      onSubmitResponse();
    });
  }
  root.querySelector("[data-simulation-no-idea]")?.addEventListener("click", onNoIdea);
}
