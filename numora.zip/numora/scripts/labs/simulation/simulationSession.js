const storagePrefix = "numora:simulation-session:v1";
const sessionVersion = 2;

function getSessionStorage() {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
}

function getStorageKey(userId) {
  return `${storagePrefix}:${userId}`;
}

export function loadSimulationLabSession(userId) {
  if (!userId) {
    return null;
  }

  try {
    const value = getSessionStorage()?.getItem(getStorageKey(userId));
    const session = value ? JSON.parse(value) : null;
    return session?.version === 1 || session?.version === sessionVersion ? session : null;
  } catch {
    return null;
  }
}

export function saveSimulationLabSession(userId, session) {
  if (!userId) {
    return;
  }

  try {
    getSessionStorage()?.setItem(getStorageKey(userId), JSON.stringify({
      version: sessionVersion,
      gradeLevel: session.gradeLevel,
      storyId: session.storyId,
      storyState: session.storyState,
      isReplay: Boolean(session.isReplay)
    }));
  } catch {
    // A story can still be completed when browser storage is unavailable.
  }
}
