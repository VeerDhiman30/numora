// A bounded arithmetic parser. Never execute calculator input as JavaScript.
export function evaluateExpression(expression, { mode = "DEG", answer = 0 } = {}) {
  if (!["DEG", "RAD"].includes(mode)) throw new Error("Choose degrees or radians.");
  if (typeof expression !== "string" || expression.length > 256) throw new Error("Keep calculations under 256 characters.");
  if (mode === "RAD" && expression.includes("°")) throw new Error("Switch to degrees to use the ° symbol.");
  const source = expression.toLowerCase().replace(/×/g, "*").replace(/÷/g, "/")
    .replace(/−/g, "-").replace(/π/g, "pi").replace(/√/g, "sqrt").replace(/²/g, "^2").replace(/°/g, "");
  const tokens = [];
  for (let offset = 0; offset < source.length;) {
    const rest = source.slice(offset);
    const match = rest.match(/^\s+|^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|^[a-z]+|^[+\-*/^()%!]/);
    if (!match) throw new Error("Use numbers, calculator functions, and math symbols only.");
    if (match[0].trim()) tokens.push(match[0]);
    offset += match[0].length;
  }
  if (!tokens.length) throw new Error("Enter a calculation first.");
  let position = 0, depth = 0;
  const peek = () => tokens[position];
  const finite = value => {
    if (!Number.isFinite(value)) throw new Error("This calculation has no finite real result.");
    return value;
  };
  const toRadians = value => mode === "DEG" ? value * Math.PI / 180 : value;
  const fromRadians = value => mode === "DEG" ? value * 180 / Math.PI : value;
  function apply(name, value) {
    switch (name) {
      case "sin": return Math.sin(toRadians(value));
      case "cos": return Math.cos(toRadians(value));
      case "tan": {
        const angle = toRadians(value);
        if (Math.abs(Math.cos(angle)) < 1e-12) throw new Error("Tangent is undefined at this angle.");
        return Math.tan(angle);
      }
      case "asin": case "acos":
        if (Math.abs(value) > 1) throw new Error("Inverse sine and cosine need an input from −1 to 1.");
        return fromRadians(name === "asin" ? Math.asin(value) : Math.acos(value));
      case "atan": return fromRadians(Math.atan(value));
      case "sqrt":
        if (value < 0) throw new Error("A real square root needs a nonnegative number.");
        return Math.sqrt(value);
      case "ln": case "log":
        if (value <= 0) throw new Error("Logarithms need a positive number.");
        return name === "ln" ? Math.log(value) : Math.log10(value);
      case "abs": return Math.abs(value);
      default: throw new Error("Unknown function. Use the scientific buttons below.");
    }
  }
  function primary() {
    if (++depth > 64) throw new Error("This calculation is too deeply nested.");
    try {
      const token = tokens[position++];
      if (token === "(") {
        const value = sum();
        if (tokens[position++] !== ")") throw new Error("Check that every opening parenthesis has a closing one.");
        return value;
      }
      if (token && /^(?:\d|\.)/.test(token)) return finite(Number(token));
      if (token === "pi") return Math.PI;
      if (token === "e") return Math.E;
      if (token === "ans") return finite(answer);
      if (token && /^[a-z]+$/.test(token)) {
        if (tokens[position++] !== "(") throw new Error("Put a function's input in parentheses, like sin(30).");
        const value = sum();
        if (tokens[position++] !== ")") throw new Error("Check that every opening parenthesis has a closing one.");
        return finite(apply(token, value));
      }
      throw new Error("Check the numbers and operators in your calculation.");
    } finally { depth--; }
  }
  function postfix() {
    let value = primary();
    while (["%", "!"].includes(peek())) {
      const operator = tokens[position++];
      if (operator === "%") value /= 100;
      else {
        if (!Number.isInteger(value) || value < 0 || value > 170) throw new Error("Factorial needs a whole number from 0 to 170.");
        let product = 1;
        for (let n = 2; n <= value; n++) product *= n;
        value = product;
      }
    }
    return finite(value);
  }
  function power() {
    const value = postfix();
    if (peek() !== "^") return value;
    position++;
    return finite(Math.pow(value, unary()));
  }
  function unary() {
    if (peek() === "+" || peek() === "-") {
      const sign = tokens[position++] === "-" ? -1 : 1;
      return sign * unary();
    }
    return power();
  }
  function product() {
    let value = unary();
    while (position < tokens.length) {
      const operator = peek();
      // Support 2π, 2(3+4), and (2)(3), but not accidental adjacent numbers.
      const implicit = operator === "(" || /^[a-z]+$/.test(operator);
      if (!["*", "/"].includes(operator) && !implicit) break;
      if (!implicit) position++;
      const right = unary();
      if (operator === "/" && right === 0) throw new Error("You cannot divide by zero.");
      value = finite(operator === "/" ? value / right : value * right);
    }
    return value;
  }
  function sum() {
    let value = product();
    while (peek() === "+" || peek() === "-") {
      const operator = tokens[position++];
      const right = product();
      value = finite(operator === "+" ? value + right : value - right);
    }
    return value;
  }
  const result = sum();
  if (position !== tokens.length) throw new Error("Check for an extra parenthesis or a missing operator.");
  return Object.is(result, -0) ? 0 : finite(result);
}

export function formatCalculatorResult(value) {
  return Number(value.toPrecision(12)).toString();
}
