import { BALLOON_POP_MS } from './balloonGame.js';

// Keep burst positions and start times outside the re-rendered board. Saving a
// reward may rebuild the UI, but must not restart or erase the three-second pop.
export function createBalloonEffects(root) {
  let effects = [], sequence = 0;
  const waiters = new Map();
  function update() {
    const now = performance.now();
    effects = effects.filter(effect => now - effect.startedAt < BALLOON_POP_MS);
    const stage = root.querySelector('.arcade-balloons');
    if (!stage) return;
    stage.querySelectorAll('[data-balloon-pop]').forEach(node => {
      if (!effects.some(effect => String(effect.id) === node.dataset.balloonPop)) node.remove();
    });
    for (const effect of effects) {
      if (stage.querySelector(`[data-balloon-pop="${effect.id}"]`)) continue;
      const burst = document.createElement('span');
      burst.className = `balloon-pop-effect balloon-pop-effect--${effect.kind}`;
      burst.dataset.balloonPop = effect.id;
      burst.setAttribute('aria-hidden','true');
      burst.style.left = `${effect.x * 100}%`;
      burst.style.top = `${effect.y * 100}%`;
      burst.style.setProperty('--pop-color',effect.color);
      burst.style.setProperty('--pop-duration',`${BALLOON_POP_MS}ms`);
      burst.style.setProperty('--pop-delay',`${-Math.max(0,now-effect.startedAt)}ms`);
      burst.innerHTML = `<svg viewBox="-70 -70 140 140" aria-hidden="true"><circle class="balloon-pop-ring" r="22"/>${Array.from({length:10},(_,i)=>{
        const angle=i*Math.PI/5;
        return `<path class="balloon-pop-shard" style="--shard-x:${Math.cos(angle)*52}px;--shard-y:${Math.sin(angle)*52+12}px;--shard-rotation:${i*61}deg" d="M-4 -8 L5 -3 L3 8 L-5 3Z"/>`;
      }).join('')}</svg><span class="balloon-pop-word">${effect.kind==='missed'?'Missed':'Pop!'}</span>`;
      stage.append(burst);
    }
  }
  function pop(index, kind='correct') {
    const stage=root.querySelector('.arcade-balloons');
    const button=stage?.querySelector(`[data-balloon-index="${index}"]`);
    if (!stage || !button || button.hidden) return;
    const board=stage.getBoundingClientRect(), bounds=button.getBoundingClientRect();
    effects.push({id:++sequence, startedAt:performance.now(), kind,
      x:(bounds.left+bounds.width/2-board.left)/board.width,
      y:(bounds.top+bounds.height*45/144-board.top)/board.height,
      color:kind==='missed'?'#ff9c86':getComputedStyle(button).getPropertyValue('--balloon-color').trim() || '#a0e0c8'});
    update();
  }
  function finish() {
    const remaining = Math.max(0,...effects.map(effect=>effect.startedAt+BALLOON_POP_MS-performance.now()));
    if (!remaining) return Promise.resolve();
    return new Promise(resolve => {
      const timer=window.setTimeout(()=>{waiters.delete(timer);resolve();},remaining);
      waiters.set(timer,resolve);
    });
  }
  function clear() {
    effects=[];
    root.querySelectorAll('[data-balloon-pop]').forEach(node=>node.remove());
    for(const [timer,resolve] of waiters) {window.clearTimeout(timer);resolve();}
    waiters.clear();
  }
  return {pop, update, finish, clear};
}
