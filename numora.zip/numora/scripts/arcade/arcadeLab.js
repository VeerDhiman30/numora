import { getAppState, subscribeToAppState } from "../services/appState.js";
import { displayReward } from "../services/rewardDisplay.js";
import { arcadeGames, arcadeGrades, arcadeTestGame, advanceGameState, createGameState, evaluateGameAction, getArcadeGame, getGamesForGrade, isCalculatorRound, renderGameBoard } from "./games.js";
import { createScientificCalculator } from "./scientificCalculator.js";
import { BALLOON_FLIGHT_MS, BALLOON_COOLDOWN_MS, balloonRounds, balloonHasLaunched, balloonIsCorrect, balloonProgress, balloonResolved, balloonRoundDone } from "./balloonGame.js";
import { createBalloonEffects } from "./balloonEffects.js";
import { MEMORY_FLIP_LIMIT, resetMemoryBoard, settleMemoryMismatch } from "./memoryGame.js";
import { LINE_GRID, createLineState, linePointFromSvg } from "./lineGame.js";
import { awardArcadeCoin, getArcadeState, loseArcadeLife } from "./arcadeService.js";
import { createArcadeEventKey, createArcadeId, formatCountdown, playArcadeSound } from "./arcadeSession.js";

function formatGrade(gradeLevel) {
  return arcadeGrades.find((grade) => grade.id === gradeLevel)?.label ?? "Middle School";
}

function getProfileGrade() {
  const grade = getAppState().user?.gradeLevel;
  return arcadeGrades.some((item) => item.id === grade) ? grade : "middle";
}

function coinBalance() {
  const coins = getAppState().coins;
  return Number.isInteger(coins) ? coins : "—";
}

function escapeAttribute(value) {
  return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}

function gameCard(game) {
  return `
    <article class="arcade-game-card card">
      <span class="arcade-game-card__icon" aria-hidden="true">${game.icon}</span>
      <div>
        <p class="arcade-game-card__mechanic">${game.mechanic}</p>
        <h3>${game.title}</h3>
        <p>${game.description}</p>
      </div>
      <p class="arcade-game-card__concepts">${game.concepts}</p>
      <button class="button button--primary" type="button" data-arcade-action="choose-game:${game.id}">Play ${game.title}</button>
    </article>
  `;
}

function renderLives(state, { compact = false } = {}) {
  const known = Number.isInteger(state.lives);
  const countdown = state.lives < 8 ? formatCountdown(state.nextRegenerationAt) : null;
  const label = state.loading ? "Lives are loading" : !known ? "Lives unavailable. Please retry." : `${state.lives} of 8 lives remaining`;
  return `
    <div class="arcade-hud__lives${compact ? " arcade-hud__lives--compact" : ""}" aria-live="polite" aria-atomic="true">
      <span class="arcade-hud__icon" aria-hidden="true">♥</span>
      <strong>${state.loading || !known ? "—" : state.lives}/8</strong>
      <span class="sr-only">${label}</span>
      ${countdown ? `<span class="arcade-hud__timer">Next life in ${countdown}</span>` : `<span class="arcade-hud__timer">${!known ? "Checking lives" : "Lives full"}</span>`}
    </div>
  `;
}

function renderHud(state) {
  return `
    <aside class="arcade-hud card" aria-label="Arcade game status">
      ${renderLives(state, { compact: true })}
      <span class="arcade-hud__coins" aria-label="${coinBalance()} coins"><span aria-hidden="true">●</span> ${coinBalance()} coins</span>
      <span class="arcade-hud__score">${state.gameState?.correctActions ?? 0} correct</span>
    </aside>
  `;
}

function renderHome(state) {
  const games = getGamesForGrade(state.gradeLevel);
  return `
    <section class="arcade section">
      <div class="page-container arcade__container">
        <header class="arcade__header">
          <div>
            <p class="arcade__eyebrow">Playful mathematical thinking</p>
            <h1>Arcade</h1>
            <p>Choose a visual math game, protect your lives, and collect coins for each confirmed correct action.</p>
          </div>
          <div class="arcade-home-status card">
            ${renderLives(state)}
            <span class="arcade-hud__coins"><span aria-hidden="true">●</span> ${coinBalance()} coins</span>
          </div>
        </header>

        ${!Number.isInteger(state.lives) && !state.loading ? '<p role="status">We couldn’t load your lives. <button class="button button--secondary" type="button" data-arcade-action="retry-lives">Retry loading lives</button></p>' : ""}

        <section class="arcade-grade-selector card" aria-labelledby="arcade-grade-title">
          <div>
            <p class="arcade__eyebrow">Choose a level</p>
            <h2 id="arcade-grade-title">Play at your pace</h2>
            <p>We started with your saved grade. Switching here only changes this Arcade visit.</p>
          </div>
          <div class="arcade-grade-selector__buttons" role="group" aria-label="Arcade grade level">
            ${arcadeGrades.map((grade) => `<button class="arcade-grade-button${grade.id === state.gradeLevel ? " is-selected" : ""}" type="button" data-arcade-action="grade:${grade.id}" aria-pressed="${grade.id === state.gradeLevel}"><span>${grade.label}</span><small>${grade.detail}</small></button>`).join("")}
          </div>
        </section>

        <section class="arcade-library" aria-labelledby="arcade-library-title">
          <div class="arcade-library__heading"><div><p class="arcade__eyebrow">${formatGrade(state.gradeLevel)}</p><h2 id="arcade-library-title">Choose a game</h2></div><p>${games.length} visual games ready to play.</p></div>
          <div class="arcade-game-grid">${games.map(gameCard).join("")}</div>
        </section>

        <aside class="arcade-rules card" aria-labelledby="arcade-rules-title">
          <h2 id="arcade-rules-title">Arcade rules</h2>
          <ul><li>You have 8 lives. Most games use one for an incorrect submitted action. In Balloon Pop, wrong guesses cause a cooldown; missed matching balloons cost lives. In Memory Match, only an unfinished board after 8 card flips costs one life.</li><li>One life returns every 3 minutes, even while you are away.</li><li>Correct confirmed actions earn ${displayReward("arcade_correct").coins} coin. Arcade does not change academic mastery.</li></ul>
        </aside>

        <details class="arcade-test-game"><summary>Engine test</summary><p>This small largest-number game is only for checking the shared Arcade framework.</p><button class="button button--secondary" type="button" data-arcade-action="choose-game:${arcadeTestGame.id}">Open test game</button></details>
      </div>
    </section>
  `;
}

function renderInstructions(state, game) {
  return `
    <section class="arcade section"><div class="page-container arcade-game-shell">
      <button class="arcade-back" type="button" data-arcade-action="back-home">← Back to Arcade</button>
      <section class="arcade-instructions card">
        <span class="arcade-game-card__icon" aria-hidden="true">${game.icon}</span>
        <p class="arcade__eyebrow">${formatGrade(game.gradeLevel)}</p>
        <h1>${game.title}</h1>
        <p>${game.description}</p>
        <div class="arcade-instructions__details"><span><strong>Math:</strong> ${game.concepts}</span><span><strong>How it works:</strong> ${game.mechanic}</span></div>
        <p class="arcade-instructions__notice">${game.id === "balloon-pop" ? `Pop the 2–3 matching balloons in each round. Each takes ${BALLOON_FLIGHT_MS/1000} seconds to rise from the bottom. A pop has a three-second burst effect. A wrong guess causes a ${BALLOON_COOLDOWN_MS/1000}-second countdown, not life loss. Each matching balloon that reaches the top costs one life.` : game.id === "memory-match" ? "Match all 3 pairs within 8 individual card flips. Each flipped card uses one try—even a correct one. A wrong pair turns back over without costing a life. If the board is unfinished after 8 flips, you lose just one life and get a fresh board with new values and 8 new flips. Each matched pair earns a coin." : game.id === "draw-the-line" ? "Use the equation to calculate two different points. Tap their positions on the coordinate grid or enter their x and y values. A line joins them automatically. You can adjust either point freely before choosing Check line. A correct line earns a coin; checking an incorrect line uses one life." : "Correct confirmed actions earn a coin. Incorrect submitted actions use one life."} You can use the keyboard, touch, or buttons on screen.</p>
        <div class="arcade-board__controls"><button class="button button--secondary" type="button" data-arcade-action="back-home">Choose another game</button><button class="button button--primary" type="button" data-arcade-action="start-game">Start game</button></div>
      </section>
    </div></section>
  `;
}

function renderGame(state, game) {
  const unavailable = !Number.isInteger(state.lives);
  const blocked = unavailable || (!state.loading && state.lives <= 0);
  const feedback = state.feedback ? `<div class="arcade-feedback arcade-feedback--${state.feedback.tone}" role="status">${state.feedback.tone === "incorrect" ? '<span class="arcade-feedback__mark" aria-hidden="true">×</span>' : ""}<span>${state.feedback.message}</span></div>` : "";
  return `
    <section class="arcade section"><div class="page-container arcade-game-shell">
      <div class="arcade-game-shell__top"><button class="arcade-back" type="button" data-arcade-action="back-home">← Back to Arcade</button>${renderHud(state)}</div>
      <section class="arcade-game card${blocked ? " is-paused" : ""}">
        <header class="arcade-game__header"><div><p class="arcade__eyebrow">${game.mechanic} · ${formatGrade(game.gradeLevel)}</p><h1>${game.title}</h1><p>${game.description}</p></div><div class="arcade-game__progress">${state.gameState.correctActions} correct action${state.gameState.correctActions === 1 ? "" : "s"}</div></header>
        ${unavailable ? `<div class="arcade-zero-lives" role="status"><h2>${state.loading ? "Checking your lives…" : "Your lives couldn’t be loaded"}</h2><p>Gameplay will unlock when your saved lives are confirmed.</p>${!state.loading ? '<button class="button button--secondary" type="button" data-arcade-action="retry-lives">Retry loading lives</button>' : ""}</div>` : blocked ? `<div class="arcade-zero-lives" role="alert"><h2>Your lives are regenerating</h2><p>Gameplay will unlock when your next life returns${formatCountdown(state.nextRegenerationAt) ? ` in ${formatCountdown(state.nextRegenerationAt)}` : ""}.</p></div>` : `<div class="arcade-play-area">${renderGameBoard(game, state.gameState)}</div>`}
        ${feedback}
        ${state.pendingReward ? '<button class="button button--primary" type="button" data-arcade-action="retry-reward">Retry saving this action</button>' : ""}
        ${state.pendingBalloonMiss ? '<button class="button button--primary" type="button" data-arcade-action="retry-balloon-miss">Retry saving missed balloon</button>' : ""}
        ${state.pendingMemoryFailure ? '<button class="button button--primary" type="button" data-arcade-action="retry-memory-board">Retry saving this board</button>' : ""}
        <div class="arcade-game__footer"><button class="button button--secondary" type="button" data-arcade-action="restart-game">Restart game</button><button class="button button--secondary" type="button" data-arcade-action="back-home">Exit to Arcade</button></div>
      </section>
      <p class="sr-only" aria-live="polite" data-arcade-live>${escapeAttribute(state.liveMessage)}</p>
    </div></section>
  `;
}

function renderComplete(state, game) {
  return `
    <section class="arcade section"><div class="page-container arcade-game-shell">
      <section class="arcade-complete card" aria-live="polite">
        <span aria-hidden="true">✦</span><p class="arcade__eyebrow">Game complete</p><h1>${game.title} complete!</h1>
        <p>You confirmed ${state.gameState.correctActions} correct action${state.gameState.correctActions === 1 ? "" : "s"} and earned ${state.sessionCoins} coin${state.sessionCoins === 1 ? "" : "s"} this session.</p>
        <div class="arcade-complete__stats"><span>${state.lives}/8 lives remaining</span><span>${coinBalance()} total coins</span></div>
        <div class="arcade-board__controls"><button class="button button--secondary" type="button" data-arcade-action="restart-game">Play again</button><button class="button button--primary" type="button" data-arcade-action="back-home">Choose another game</button></div>
      </section>
    </div></section>
  `;
}

export function createArcadeView() {
  const root = document.createElement("section");
  const balloonEffects = createBalloonEffects(root);
  const ownerId = getAppState().user?.id;
  const storageKey = `numora:arcade-session:v1:${ownerId}`;
  let disposed = false;
  let memoryRevealTimer;
  const calculator = createScientificCalculator({
    returnFocus: () => { if (!disposed) root.querySelector('[data-arcade-action="open-calculator"]')?.focus({ preventScroll: true }); }
  });
  const state = {
    gradeLevel: getProfileGrade(),
    phase: "home",
    selectedGameId: null,
    gameState: null,
    sessionId: null,
    sessionCoins: 0,
    lives: null,
    nextRegenerationAt: null,
    loading: true,
    feedback: null,
    liveMessage: "",
    pendingActions: new Set(),
    intervalId: null,
    draggedPortalValue: null,
    pendingReward: null,
    pendingBalloonMiss: null,
    pendingMemoryFailure: null
  };
  try {
    const saved = JSON.parse(window.sessionStorage.getItem(storageKey) ?? "null");
    if (saved && getArcadeGame(saved.selectedGameId) && saved.sessionId && saved.gameState
      && ["play", "complete"].includes(saved.phase) && Number.isInteger(saved.gameState.correctActions)
      && (saved.selectedGameId !== "balloon-pop" || saved.gameState.balloon?.version === 3)
      && (saved.selectedGameId !== "memory-match" || saved.gameState.memory?.version === 1)) {
      // Keep earned rewards and the current round when replacing an old
      // slope/intercept draft with the two-point plotting interaction.
      if (saved.selectedGameId === "draw-the-line" && saved.gameState.graph?.version !== 2) saved.gameState.graph = createLineState();
      Object.assign(state, { gradeLevel: saved.gradeLevel, selectedGameId: saved.selectedGameId, sessionId: saved.sessionId,
        gameState: saved.gameState, phase: saved.phase, sessionCoins: saved.sessionCoins ?? 0, pendingReward: saved.pendingReward ?? null, pendingBalloonMiss: saved.pendingBalloonMiss ?? null, pendingMemoryFailure: saved.pendingMemoryFailure ?? null });
    }
  } catch { /* The game remains playable without session storage. */ }

  function persistSession() {
    if (disposed || getAppState().user?.id !== ownerId) return;
    try {
      window.sessionStorage.setItem(storageKey, JSON.stringify({ gradeLevel: state.gradeLevel,
        selectedGameId: state.selectedGameId, sessionId: state.sessionId, gameState: state.gameState,
        phase: state.phase, sessionCoins: state.sessionCoins, pendingReward: state.pendingReward, pendingBalloonMiss: state.pendingBalloonMiss, pendingMemoryFailure: state.pendingMemoryFailure }));
    } catch { /* Database event keys still protect retries during this session. */ }
  }

  function activeGame() {
    return getArcadeGame(state.selectedGameId);
  }

  function setFeedback(tone, message) {
    state.feedback = message ? { tone, message } : null;
    state.liveMessage = message ?? "";
  }

  function canEditLine() {
    return state.phase === "play" && state.selectedGameId === "draw-the-line" && state.gameState
      && !state.loading && state.lives > 0 && !state.pendingActions.size && !state.pendingReward;
  }

  function render() {
    if (disposed) return;
    const focusedAction = root.contains(document.activeElement) ? document.activeElement?.dataset?.arcadeAction : null;
    const focusedLineControl = root.contains(document.activeElement) ? document.activeElement?.dataset?.lineFocus : null;
    persistSession();
    const game = activeGame();
    root.className = "arcade-root";
    root.innerHTML = state.phase === "instructions" && game
      ? renderInstructions(state, game)
      : state.phase === "play" && game
        ? renderGame(state, game)
        : state.phase === "complete" && game
          ? renderComplete(state, game)
          : renderHome(state);
    updateBalloonView();
    if (state.selectedGameId === "draw-the-line") {
      const editable = canEditLine();
      root.querySelector("[data-line-grid]")?.setAttribute("aria-disabled", String(!editable));
      if (!editable) root.querySelectorAll(".line-board button, .line-board input").forEach(control => {control.disabled = true;});
      if (focusedLineControl) root.querySelector(`[data-line-focus="${focusedLineControl}"]`)?.focus({preventScroll:true});
    }
    if (focusedAction && ["balloon-pop", "memory-match", "draw-the-line"].includes(state.selectedGameId)) {
      const matching = [...root.querySelectorAll("[data-arcade-action]")].find(button => button.dataset.arcadeAction === focusedAction && !button.hidden && !button.disabled);
      if (state.selectedGameId === "draw-the-line") {
        (matching ?? root.querySelector("[data-line-grid]"))?.focus({preventScroll:true});
        return;
      }
      (matching ?? root.querySelector('[data-arcade-action="balloon-launch"], [data-balloon-index]:not([hidden])'))?.focus({preventScroll:true});
    }
  }

  async function refreshLives({ quiet = false } = {}) {
    try {
      const arcadeState = await getArcadeState();
      const livesChanged = state.lives !== arcadeState.lives;
      state.lives = arcadeState.lives;
      state.nextRegenerationAt = arcadeState.nextRegenerationAt;
      state.loading = false;
      if (livesChanged && !quiet) setFeedback("neutral", `You have ${state.lives} lives ready.`);
    } catch (error) {
      state.loading = false;
      state.lives = null;
      state.nextRegenerationAt = null;
      setFeedback("error", error.message);
    }
    render();
  }

  function startGame() {
    const game = activeGame();
    if (!game) return;
    balloonEffects.clear();
    window.clearTimeout(memoryRevealTimer);
    state.sessionId = createArcadeId();
    state.gameState = createGameState(game.id);
    state.sessionCoins = 0;
    state.pendingReward = null;
    state.pendingBalloonMiss = null;
    state.pendingMemoryFailure = null;
    state.phase = "play";
    setFeedback("neutral", "Choose your first move.");
    render();
  }

  function restartGame() {
    if (!activeGame()) return;
    balloonEffects.clear();
    window.clearTimeout(memoryRevealTimer);
    state.sessionId = createArcadeId();
    state.gameState = createGameState(state.selectedGameId);
    state.sessionCoins = 0;
    state.pendingReward = null;
    state.pendingBalloonMiss = null;
    state.pendingMemoryFailure = null;
    state.phase = "play";
    setFeedback("neutral", "New game ready. Your real lives and coins stay the same.");
    render();
  }

  function updateBalloonView() {
    const stage = root.querySelector(".arcade-balloons"), flight = state.gameState?.balloon;
    if (!stage || !flight) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const cooldown = Math.max(0, Math.ceil((flight.cooldownUntilMs-flight.elapsedMs)/1000));
    stage.classList.toggle("is-cooling-down", flight.running && cooldown > 0);
    const unavailable = state.pendingActions.size || state.pendingReward || state.pendingBalloonMiss || state.lives <= 0;
    stage.querySelectorAll("[data-balloon-index]").forEach(button => {
      const index = Number(button.dataset.balloonIndex);
      button.hidden = !flight.running || !balloonHasLaunched(index,flight.elapsedMs) || balloonResolved(state.gameState,index) || flight.expired.includes(index) || state.pendingBalloonMiss?.index === index;
      const progress = balloonProgress(index,flight.elapsedMs);
      const height = button.offsetHeight || 144;
      // Start with the body at the floor and the string below it. The string
      // emerges naturally as the balloon rises toward the visible cutoff line.
      const belowFloor = height * 51/144;
      const cutoff = stage.querySelector('.balloon-top-line')?.offsetHeight ?? 30;
      const travel = Math.max(0,stage.clientHeight-cutoff-(height-belowFloor));
      button.style.bottom = `-${belowFloor}px`;
      const distance = reduced ? Math.max(0,travel-Math.floor(index/4)*height) : travel*progress;
      button.style.transform = `translate(-50%, -${distance}px)`;
      button.classList.toggle("is-rejected",flight.rejected.includes(index));
      const value = balloonRounds[state.gameState.round].values[index];
      button.setAttribute("aria-label", flight.rejected.includes(index) ? `${value}: wrong balloon, does not fit the rule` : `Pop ${value}`);
      button.setAttribute("aria-disabled",String(Boolean(cooldown || unavailable || flight.rejected.includes(index))));
      button.dataset.seconds = `${Math.max(0,Math.ceil((1-progress)*BALLOON_FLIGHT_MS/1000))}s`;
    });
    const status = root.querySelector("[data-balloon-status]");
    if (status) status.textContent = `${balloonRounds[state.gameState.round].values.filter((_,index)=>balloonIsCorrect(state.gameState,index)&&state.gameState.popped.includes(`${state.gameState.round}-${index}`)).length} popped · ${flight.missed.length} missed`;
    const message = cooldown ? `Cooldown: ${cooldown}s — look for a matching balloon.` : (flight.running && document.hidden ? "Paused while this tab is hidden." : "");
    const notice = root.querySelector("[data-balloon-cooldown]");
    if (notice && notice.textContent !== message) notice.textContent = message;
    const overlay = stage.querySelector("[data-balloon-countdown-overlay]");
    if (overlay) {
      overlay.hidden = !flight.running || cooldown === 0;
      const number = overlay.querySelector("[data-balloon-countdown]");
      if (number.textContent !== String(cooldown)) number.textContent = String(cooldown);
    }
    balloonEffects.update();
  }

  function resumeMemoryBoard() {
    if (disposed || state.phase !== "play" || state.selectedGameId !== "memory-match"
      || state.pendingReward || state.pendingActions.size || state.pendingMemoryFailure) return;
    window.clearTimeout(memoryRevealTimer);
    const board = state.gameState.memory;
    if (board.status === "mismatch") {
      if (!settleMemoryMismatch(state.gameState)) {
        memoryRevealTimer = window.setTimeout(resumeMemoryBoard, Math.max(0, board.revealUntilMs - Date.now()));
        return;
      }
      render();
    }
    if (board.status === "failed") {
      const round = state.gameState.round;
      state.pendingMemoryFailure = {round, eventKey: createArcadeEventKey({gameId: "memory-match",
        sessionId: state.sessionId, roundId: round, actionId: `board-${round}-failed`, type: "incorrect"})};
      void saveMemoryFailure();
    }
  }

  async function saveMemoryFailure() {
    const pending = state.pendingMemoryFailure;
    if (!pending || state.pendingActions.has(pending.eventKey)) return;
    state.pendingActions.add(pending.eventKey);
    setFeedback("neutral", "All 8 flips used. Saving this board before dealing new values…");
    // Keep the same board event across reloads and retries, including a lost
    // response after the database has already deducted the one life.
    render();
    try {
      const result = await loseArcadeLife(pending.eventKey);
      if (disposed || getAppState().user?.id !== ownerId) return;
      state.lives = result.lives;
      state.nextRegenerationAt = result.nextRegenerationAt;
      resetMemoryBoard(state.gameState);
      state.pendingMemoryFailure = null;
      setFeedback("incorrect", `The board wasn't cleared in 8 flips. ${result.lifeLost ? "One life used." : "Board result saved."} New values and 8 new flips are ready.${result.lives === 0 ? " Play resumes when a life returns." : ""}`);
      if (result.lifeLost) playArcadeSound("incorrect", getAppState().soundEnabled);
    } catch {
      if (!disposed) setFeedback("error", "We couldn't save this board yet. Retry to continue; retries won't cost an extra life.");
    } finally {
      state.pendingActions.delete(pending.eventKey);
      render();
    }
  }

  async function saveBalloonMiss() {
    const pending = state.pendingBalloonMiss;
    if (!pending || state.pendingActions.has(pending.eventKey)) return;
    state.pendingActions.add(pending.eventKey);
    persistSession();
    try {
      const result = await loseArcadeLife(pending.eventKey);
      if (disposed || getAppState().user?.id !== ownerId) return;
      const roundEnding = result.lives === 0 || balloonRounds[state.gameState.round].values.every((_,index)=>
        !balloonIsCorrect(state.gameState,index) || index===pending.index || balloonResolved(state.gameState,index));
      if (roundEnding) {
        await balloonEffects.finish();
        if (disposed || getAppState().user?.id !== ownerId) return;
      }
      state.lives = result.lives; state.nextRegenerationAt = result.nextRegenerationAt;
      const flight = state.gameState.balloon;
      if (!flight.missed.includes(pending.index)) flight.missed.push(pending.index);
      if (!flight.expired.includes(pending.index)) flight.expired.push(pending.index);
      state.pendingBalloonMiss = null;
      setFeedback("incorrect", `A matching balloon (${balloonRounds[pending.round].values[pending.index]}) reached the top. ${result.lifeLost ? "One life used." : "The missed balloon is saved."}`);
      if (result.lifeLost) playArcadeSound("incorrect",getAppState().soundEnabled);
      // Once out of lives, do not charge future regenerated lives for this round.
      if (state.lives === 0) balloonRounds[state.gameState.round].values.forEach((_,index)=>{
        if (balloonIsCorrect(state.gameState,index) && !balloonResolved(state.gameState,index)) flight.missed.push(index);
      });
      if (balloonRoundDone(state.gameState)) {
        if (state.gameState.round === balloonRounds.length-1) state.phase = "complete";
        else advanceGameState(activeGame(),state.gameState,{advance:true,complete:false});
      }
    } catch (error) { setFeedback("error", "Balloons are paused. We couldn't save that missed balloon yet. Retry to continue; it won't cost an extra life."); }
    finally { state.pendingActions.delete(pending.eventKey); render(); }
  }

  let balloonFrame, lastBalloonFrame = 0, lastBalloonSave = 0;
  function animateBalloons(now) {
    if (disposed) return;
    const elapsed = lastBalloonFrame ? Math.min(250,now-lastBalloonFrame) : 0;
    lastBalloonFrame = now;
    const flight = state.gameState?.balloon;
    if (state.phase === "play" && state.selectedGameId === "balloon-pop" && flight?.running && !document.hidden
      && state.lives > 0 && !state.pendingActions.size && !state.pendingReward && !state.pendingBalloonMiss) {
      flight.elapsedMs += elapsed;
      const values = balloonRounds[state.gameState.round].values;
      for (let index=0; index<values.length; index++) {
        if (balloonResolved(state.gameState,index) || flight.expired.includes(index) || balloonProgress(index,flight.elapsedMs)<1) continue;
        if (!balloonIsCorrect(state.gameState,index)) { flight.expired.push(index); continue; }
        const actionId = `round-${state.gameState.round}-missed-${index}`;
        const eventKey = createArcadeEventKey({gameId:"balloon-pop",sessionId:state.sessionId,roundId:state.gameState.round,actionId,type:"incorrect"});
        // Position this frame before sampling the burst origin at the top.
        updateBalloonView();
        balloonEffects.pop(index,"missed");
        state.pendingBalloonMiss = {round:state.gameState.round,index,eventKey};
        void saveBalloonMiss(); break;
      }
      updateBalloonView();
      if (now-lastBalloonSave>1000) { persistSession(); lastBalloonSave=now; }
    }
    balloonEffects.update();
    balloonFrame = window.requestAnimationFrame(animateBalloons);
  }

  function startTimer() {
    balloonFrame = window.requestAnimationFrame(animateBalloons);
    state.intervalId = window.setInterval(() => {
      if (!state.nextRegenerationAt || state.lives >= 8) return;
      if (Date.parse(state.nextRegenerationAt) <= Date.now()) {
        void refreshLives({ quiet: true });
      } else if (state.phase === "home" || state.phase === "play") {
        // Updating a clock must not recreate the controls under keyboard focus.
        root.querySelectorAll(".arcade-hud__timer").forEach(timer => {
          timer.textContent = `Next life in ${formatCountdown(state.nextRegenerationAt)}`;
        });
      }
    }, 1000);
  }

  async function applyIncorrect(game, outcome) {
    const actionId = `round-${state.gameState.round}-incorrect-${state.gameState.moves + 1}`;
    const eventKey = createArcadeEventKey({ gameId: game.id, sessionId: state.sessionId, roundId: state.gameState.round, actionId, type: "incorrect" });
    if (state.pendingActions.has(eventKey)) return;
    state.pendingActions.add(eventKey);
    state.gameState.moves += 1;
    playArcadeSound("incorrect", getAppState().soundEnabled);
    setFeedback("incorrect", outcome.message);
    render();

    try {
      const result = await loseArcadeLife(eventKey);
      state.lives = result.lives;
      state.nextRegenerationAt = result.nextRegenerationAt;
      if (result.lifeLost) {
        setFeedback("incorrect", `${outcome.message} One life used.`);
      }
    } catch (error) {
      setFeedback("error", error.message);
    } finally {
      state.pendingActions.delete(eventKey);
      render();
      if (outcome.resetSelection) {
        window.setTimeout(() => {
          if (state.phase === "play" && state.gameState) {
            state.gameState.selected = [];
            render();
          }
        }, 650);
      }
    }
  }

  async function applyCorrect(game, outcome) {
    const actionId = outcome.actionId;
    const eventKey = createArcadeEventKey({ gameId: game.id, sessionId: state.sessionId, roundId: state.gameState.round, actionId, type: "correct" });
    if (state.pendingActions.has(eventKey)) return;
    state.pendingActions.add(eventKey);
    state.pendingReward = outcome;
    setFeedback("neutral", "Saving your coin reward…");
    render();

    try {
      const result = await awardArcadeCoin({ eventKey, gameId: game.id, sessionId: state.sessionId, roundId: state.gameState.round, actionId });
      if (disposed || getAppState().user?.id !== ownerId) return;
      if (game.id === "balloon-pop" && outcome.advance) {
        setFeedback("correct", "Round cleared! Let the last balloons pop…");
        render();
        await balloonEffects.finish();
        if (disposed || getAppState().user?.id !== ownerId) return;
      }
      // A duplicate can be the successful response to an earlier interrupted save.
      state.sessionCoins += displayReward("arcade_correct").coins;
      if (result.eventRecorded) {
        playArcadeSound("correct", getAppState().soundEnabled);
        setFeedback("correct", `${outcome.message} +${displayReward("arcade_correct").coins} coin`);
      } else {
        setFeedback("neutral", outcome.message);
      }
    } catch (error) {
      setFeedback("error", error.message);
      state.pendingActions.delete(eventKey);
      render();
      return;
    }

    state.pendingReward = null;
    state.gameState.correctActions += 1;
    advanceGameState(game, state.gameState, outcome);
    if (outcome.complete) {
      state.phase = "complete";
      playArcadeSound("complete", getAppState().soundEnabled);
    }
    state.pendingActions.delete(eventKey);
    render();
    if (game.id === "memory-match") resumeMemoryBoard();
  }

  async function handleGameAction(action) {
    const game = activeGame();
    if (!game || !state.gameState || !Number.isInteger(state.lives) || state.loading || state.lives <= 0 || state.pendingActions.size || state.pendingReward || state.pendingBalloonMiss || state.pendingMemoryFailure) return;
    const outcome = evaluateGameAction(game, state.gameState, action);
    if (outcome.kind === "none") return;
    if (outcome.kind === "memory-mismatch") {
      playArcadeSound("incorrect", getAppState().soundEnabled);
      setFeedback("incorrect", state.gameState.memory.flips === MEMORY_FLIP_LIMIT ? "Not a match. All 8 flips used. Take a last look at these cards…" : outcome.message);
      render();
      resumeMemoryBoard();
      return;
    }
    if (outcome.kind === "select") {
      if (outcome.feedbackTone === "incorrect") playArcadeSound("incorrect", getAppState().soundEnabled);
      setFeedback(outcome.feedbackTone ?? "neutral", outcome.message ?? "");
      render();
      return;
    }
    if (outcome.kind === "incorrect") {
      await applyIncorrect(game, outcome);
      return;
    }
    if (outcome.kind === "correct") {
      if (game.id === "balloon-pop") balloonEffects.pop(Number(action.slice(8)));
      await applyCorrect(game, outcome);
    }
  }

  root.addEventListener("click", (event) => {
    const grid = event.target instanceof Element ? event.target.closest("[data-line-grid]") : null;
    if (grid) {
      if (!canEditLine()) return;
      const bounds = grid.getBoundingClientRect();
      const point = linePointFromSvg((event.clientX - bounds.left) * LINE_GRID.size / bounds.width,
        (event.clientY - bounds.top) * LINE_GRID.size / bounds.height);
      if (point) void handleGameAction(`line-plot:${point.x}:${point.y}`);
      return;
    }
    const button = event.target instanceof Element ? event.target.closest("[data-arcade-action]") : null;
    if (!button || !(button instanceof HTMLElement)) return;
    const action = button.dataset.arcadeAction;
    if (!action) return;
    if (action === "retry-lives") { void refreshLives(); return; }
    if (state.pendingActions.size) return;
    if (state.pendingMemoryFailure) {
      if (action === "retry-memory-board") void saveMemoryFailure();
      return;
    }
    if (state.pendingBalloonMiss) {
      if (action === "retry-balloon-miss") void saveBalloonMiss();
      return;
    }
    if (state.pendingReward) {
      if (action === "retry-reward") void applyCorrect(activeGame(), state.pendingReward);
      else setFeedback("neutral", "Save the pending reward before starting another action.");
      return;
    }
    // Do not let a restart skip an exhausted board while its last pair is shown.
    if (state.phase === "play" && state.selectedGameId === "memory-match"
      && state.gameState.memory.flips >= MEMORY_FLIP_LIMIT && state.gameState.memory.status !== "complete") return;

    if (action === "open-calculator") {
      if (state.phase === "play" && state.lives > 0 && isCalculatorRound(state.selectedGameId, state.gameState)) {
        calculator.open(root.querySelector(".arcade-board__heading h3")?.textContent ?? "");
      }
    } else if (action.startsWith("grade:")) {
      state.gradeLevel = action.slice("grade:".length);
      setFeedback("neutral", "");
      render();
    } else if (action.startsWith("choose-game:")) {
      state.selectedGameId = action.slice("choose-game:".length);
      state.phase = "instructions";
      setFeedback("neutral", "");
      render();
    } else if (action === "start-game") {
      startGame();
    } else if (action === "restart-game") {
      restartGame();
    } else if (action === "back-home") {
      balloonEffects.clear();
      window.clearTimeout(memoryRevealTimer);
      state.phase = "home";
      state.selectedGameId = null;
      state.gameState = null;
      setFeedback("neutral", "");
      render();
    } else {
      void handleGameAction(action);
    }
  });

  root.addEventListener("keydown", event => {
    if (!(event.target instanceof Element) || !event.target.matches("[data-line-grid]") || !canEditLine()) return;
    const directions = {ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down", Home: "home"};
    if (directions[event.key]) {
      event.preventDefault();
      void handleGameAction(`line-cursor:${directions[event.key]}`);
    } else if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      const {x, y} = state.gameState.graph.cursor;
      void handleGameAction(`line-plot:${x}:${y}`);
    }
  });

  root.addEventListener("input", event => {
    if (!(event.target instanceof HTMLInputElement) || !event.target.matches("[data-line-input]") || !canEditLine()) return;
    const axis = event.target.dataset.lineInput;
    if (axis === "x" || axis === "y") {
      state.gameState.graph.draft[axis] = event.target.value;
      persistSession();
    }
  });

  root.addEventListener("submit", event => {
    if (!(event.target instanceof HTMLFormElement) || !event.target.matches("[data-line-coordinates]")) return;
    event.preventDefault();
    if (!canEditLine() || !event.target.reportValidity()) return;
    const x = event.target.querySelector('[data-line-input="x"]').value;
    const y = event.target.querySelector('[data-line-input="y"]').value;
    void handleGameAction(`line-plot:${x}:${y}`);
  });

  root.addEventListener("dragstart", (event) => {
    const item = event.target instanceof Element ? event.target.closest("[data-arcade-drag-value]") : null;
    if (!item || !(item instanceof HTMLElement)) return;
    state.draggedPortalValue = item.dataset.arcadeDragValue ?? null;
    event.dataTransfer?.setData("text/plain", state.draggedPortalValue ?? "");
  });

  root.addEventListener("dragover", (event) => {
    const portal = event.target instanceof Element ? event.target.closest(".arcade-portal") : null;
    if (portal) event.preventDefault();
  });

  root.addEventListener("drop", (event) => {
    const portal = event.target instanceof Element ? event.target.closest("[data-arcade-action^='portal-target:']") : null;
    if (!portal || !(portal instanceof HTMLElement) || !state.draggedPortalValue) return;
    event.preventDefault();
    state.gameState.portalValue = Number(state.draggedPortalValue);
    state.draggedPortalValue = null;
    void handleGameAction(portal.dataset.arcadeAction);
  });

  render();
  const unsubscribe = subscribeToAppState(() => {
    if (disposed) return;
    root.querySelectorAll(".arcade-hud__coins").forEach((counter) => {
      counter.textContent = `${coinBalance()} coins`;
      counter.setAttribute("aria-label", `${coinBalance()} coins`);
    });
  });
  root.destroy = () => {
    persistSession();
    disposed = true;
    balloonEffects.clear();
    calculator.destroy();
    unsubscribe();
    window.clearInterval(state.intervalId);
    window.cancelAnimationFrame(balloonFrame);
    window.clearTimeout(memoryRevealTimer);
  };
  startTimer();
  void refreshLives({ quiet: true }).then(resumeMemoryBoard);
  return root;
}
