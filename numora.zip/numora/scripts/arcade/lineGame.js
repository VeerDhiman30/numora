export const LINE_GRID = {min: -6, max: 6, size: 440, origin: 220, scale: 30};
export const lineRounds = [
  {slope: 1.5, intercept: -1, equation: "y = (3/2)x − 1"},
  {slope: -1.5, intercept: 4, equation: "y = −(3/2)x + 4"},
  {slope: 2.5, intercept: -3, equation: "y = (5/2)x − 3"}
];

export function createLineState() {
  return {version: 2, points: [null, null], activePoint: 0, cursor: {x: 0, y: 0}, draft: {x: "", y: ""}, lastCheck: null};
}

const validCoordinate = value => Number.isFinite(value) && value >= LINE_GRID.min && value <= LINE_GRID.max;
const validPoint = point => Boolean(point && validCoordinate(point.x) && validCoordinate(point.y));
const samePoint = (a, b) => a && b && a.x === b.x && a.y === b.y;
const position = point => ({x: LINE_GRID.origin + point.x * LINE_GRID.scale, y: LINE_GRID.origin - point.y * LINE_GRID.scale});
const pointName = index => index === 0 ? "A" : "B";
const coordinateText = point => `(${point.x}, ${point.y})`;
const escapeAttribute = value => String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// SVG coordinates use downward-positive y; mathematical coordinates use up.
// Only the plotted grid is clickable, not the labels or surrounding margin.
export function linePointFromSvg(svgX, svgY) {
  if (!Number.isFinite(svgX) || !Number.isFinite(svgY) || svgX < 40 || svgX > 400 || svgY < 40 || svgY > 400) return null;
  return {x: Math.round((svgX - LINE_GRID.origin) / LINE_GRID.scale), y: Math.round((LINE_GRID.origin - svgY) / LINE_GRID.scale)};
}

export function lineMatchesEquation(points, round) {
  if (!round || !Array.isArray(points) || points.length !== 2 || !points.every(validPoint) || samePoint(...points) || points[0].x === points[1].x) return false;
  return points.every(point => Math.abs(point.y - (round.slope * point.x + round.intercept)) < 1e-9);
}

function selectPoint(graph, index) {
  graph.activePoint = index;
  const point = graph.points[index];
  graph.draft = {x: point ? String(point.x) : "", y: point ? String(point.y) : ""};
  if (point) graph.cursor = {...point};
}

export function evaluateLineAction(state, action) {
  const graph = state.graph;
  if (action === "graph-reset") {
    state.graph = createLineState();
    return {kind: "select", message: "Points cleared. Choose two points that satisfy the equation."};
  }
  if (/^line-select:[01]$/.test(action)) {
    selectPoint(graph, Number(action.slice(-1)));
    return {kind: "select", message: `Now placing Point ${pointName(graph.activePoint)}. Tap the grid or enter its coordinates.`};
  }
  if (action.startsWith("line-cursor:")) {
    const direction = action.slice(12), moves = {left: [-1, 0], right: [1, 0], up: [0, 1], down: [0, -1]};
    if (direction === "home") graph.cursor = {x: 0, y: 0};
    else if (moves[direction]) {
      const [dx, dy] = moves[direction];
      graph.cursor = {x: Math.max(-6, Math.min(6, graph.cursor.x + dx)), y: Math.max(-6, Math.min(6, graph.cursor.y + dy))};
    } else return {kind: "none"};
    return {kind: "select", message: `Cursor ${coordinateText(graph.cursor)}. Press Enter to plot Point ${pointName(graph.activePoint)}.`};
  }
  if (action.startsWith("line-plot:")) {
    const parts = action.split(":");
    const point = {x: Number(parts[1]), y: Number(parts[2])};
    if (parts.length !== 3 || !parts[1].trim() || !parts[2].trim() || !validPoint(point)) {
      return {kind: "select", message: "Enter an x and y coordinate from −6 to 6. Decimals are allowed."};
    }
    if (samePoint(point, graph.points[1 - graph.activePoint])) return {kind: "select", message: "Choose a different position for the second point. Two distinct points are needed to draw a line."};
    const placed = graph.activePoint;
    graph.points[placed] = point;
    graph.cursor = {...point};
    graph.lastCheck = null;
    // After the first point, offer the empty slot. Once both exist, keep the
    // selected slot active so adjusting a point is predictable.
    selectPoint(graph, graph.points[1 - placed] ? placed : 1 - placed);
    return {kind: "select", message: `Point ${pointName(placed)} plotted at ${coordinateText(point)}. ${graph.points.every(Boolean) ? "Your line is drawn. Adjust either point or check your line." : `Now plot Point ${pointName(graph.activePoint)}.`}`};
  }
  if (action === "graph-check") {
    if (!graph.points.every(validPoint) || samePoint(...graph.points)) return {kind: "select", message: "Plot two different points before checking your line. No life used."};
    const round = lineRounds[state.round];
    if (!lineMatchesEquation(graph.points, round)) {
      graph.lastCheck = "incorrect";
      return {kind: "incorrect", message: "Not quite. Substitute each point’s x into the equation and check that it gives that point’s y. Adjust your points, then try again."};
    }
    graph.lastCheck = "correct";
    return {kind: "correct", actionId: `round-${state.round}-line`, advance: true,
      complete: state.round === lineRounds.length - 1, message: "Both points satisfy the equation—your line is correct!"};
  }
  return {kind: "none"};
}

export function renderLineBoard(state) {
  const graph = state.graph, round = lineRounds[state.round];
  const marks = Array.from({length: 13}, (_, i) => i - 6).map(value => {
    const x = LINE_GRID.origin + value * LINE_GRID.scale, y = LINE_GRID.origin - value * LINE_GRID.scale;
    return `<path class="line-graph__grid" d="M${x} 40V400M40 ${y}H400"/>${value === 0 ? '<text class="line-graph__tick" x="207" y="239">0</text>' : `<text class="line-graph__tick" x="${x}" y="239" text-anchor="middle">${value}</text><text class="line-graph__tick" x="207" y="${y + 5}" text-anchor="end">${value}</text>`}`;
  }).join("");
  const connection = graph.points.every(validPoint) ? (() => {
    const [a, b] = graph.points.map(position);
    return `<line class="line-graph__connection" data-line-connection x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"/>`;
  })() : "";
  const points = graph.points.map((point, index) => {
    if (!point) return "";
    const p = position(point), labelLeft = point.x >= 5, labelBelow = point.y >= 5;
    return `<g class="line-graph__point line-graph__point--${pointName(index).toLowerCase()}" data-line-point="${index}"><circle cx="${p.x}" cy="${p.y}" r="7"/><text x="${p.x + (labelLeft ? -13 : 13)}" y="${p.y + (labelBelow ? 21 : -12)}" text-anchor="${labelLeft ? "end" : "start"}">${pointName(index)}</text></g>`;
  }).join("");
  const cursor = position(graph.cursor);
  return `<div class="arcade-board__heading"><span>Graph ${state.round + 1} of ${lineRounds.length}</span><h3>Plot two points for ${round.equation}.</h3></div>
    <p class="arcade-board__hint">Work out two different points on the line. Plot them and we’ll connect them automatically.</p>
    <div class="line-board">
      <div class="line-point-picker" role="group" aria-label="Choose which point to plot">${graph.points.map((point,index) => `<button type="button" class="line-point-choice line-point-choice--${pointName(index).toLowerCase()}" data-arcade-action="line-select:${index}" aria-pressed="${graph.activePoint === index}"><span>Point ${pointName(index)}</span><strong>${point ? coordinateText(point) : "Not plotted"}</strong></button>`).join("")}</div>
      <div class="line-graph${graph.lastCheck === "incorrect" ? " line-graph--incorrect" : ""}"><svg data-line-grid data-line-focus="grid" viewBox="0 0 440 440" tabindex="0" role="group" aria-label="Coordinate grid, x and y from minus 6 to 6. Placing Point ${pointName(graph.activePoint)}. Keyboard cursor ${coordinateText(graph.cursor)}." aria-describedby="line-keyboard-help">
        <title>Plot two points on the coordinate grid</title><desc>${graph.points.map((p,i)=>`Point ${pointName(i)} ${p ? coordinateText(p) : "not plotted"}`).join(". ")}. ${connection ? "A line connects the two points." : "No line yet."}</desc>
        <rect class="line-graph__surface" x="40" y="40" width="360" height="360"/>${marks}
        <path class="line-graph__axes" d="M30 220H410M403 215L410 220L403 225M220 410V30M215 37L220 30L225 37"/>
        <text class="line-graph__axis-label" x="416" y="214">x</text><text class="line-graph__axis-label" x="231" y="28">y</text>
        ${connection}${points}<circle class="line-graph__cursor" cx="${cursor.x}" cy="${cursor.y}" r="11"/>
      </svg></div>
      <p class="line-input-help">Tap a grid intersection, or enter exact coordinates below. Choose Point A or B above to move it.</p>
      <form class="line-coordinate-form" data-line-coordinates>
        <fieldset><legend>Place Point ${pointName(graph.activePoint)}</legend><div class="line-coordinate-inputs">
          <label for="line-x">x coordinate<input id="line-x" data-line-input="x" data-line-focus="x" type="number" min="-6" max="6" step="any" required autocomplete="off" value="${escapeAttribute(graph.draft.x)}"></label>
          <label for="line-y">y coordinate<input id="line-y" data-line-input="y" data-line-focus="y" type="number" min="-6" max="6" step="any" required autocomplete="off" value="${escapeAttribute(graph.draft.y)}"></label>
          <button type="submit" class="button button--secondary" data-line-focus="plot">Plot point</button>
        </div></fieldset>
      </form>
      <p id="line-keyboard-help" class="line-input-help">Keyboard: focus the grid, use arrow keys to move, then Enter or Space to plot. Home returns to (0, 0).</p>
      <div class="arcade-board__controls"><button type="button" class="button button--secondary" data-arcade-action="graph-reset">Clear points</button><button type="button" class="button button--primary" data-arcade-action="graph-check" ${graph.points.every(Boolean) ? "" : "disabled"}>Check line</button></div>
    </div>`;
}
