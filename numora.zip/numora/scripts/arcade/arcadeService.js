import { recordActivity } from "../services/rewardService.js";
import { getSupabaseClient } from "../services/supabase.js";

export class ArcadeServiceError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = "ArcadeServiceError";
    this.cause = cause;
  }
}

function mapArcadeState(row) {
  if (!row || !Number.isInteger(row.lives) || row.lives < 0 || row.lives > 8
    || !Number.isFinite(Date.parse(row.updated_at))
    || (row.lives < 8 && !Number.isFinite(Date.parse(row.next_regeneration_at)))) {
    throw new Error("Arcade state is incomplete.");
  }
  return {
    lives: row.lives,
    nextRegenerationAt: row.next_regeneration_at ?? null,
    updatedAt: row.updated_at ?? null
  };
}

export async function getArcadeState() {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("get_my_arcade_state");

    if (error) {
      throw error;
    }

    return mapArcadeState(Array.isArray(data) ? data[0] : data);
  } catch (error) {
    console.error("Numora could not load Arcade lives:", error);
    throw new ArcadeServiceError("We couldn't load your Arcade lives right now. Please try again.", error);
  }
}

export async function loseArcadeLife(eventKey) {
  try {
    const client = await getSupabaseClient();
    const { data, error } = await client.rpc("lose_arcade_life", { p_event_key: eventKey });

    if (error) {
      throw error;
    }

    const row = Array.isArray(data) ? data[0] : data;
    if (typeof row?.life_lost !== "boolean") throw new Error("Arcade action is incomplete.");
    return {
      lifeLost: Boolean(row?.life_lost),
      ...mapArcadeState(row)
    };
  } catch (error) {
    console.error("Numora could not save an Arcade life:", error);
    throw new ArcadeServiceError("Your answer was noted, but we couldn't update your lives. Please try again.", error);
  }
}

export async function awardArcadeCoin({ eventKey, gameId, sessionId, roundId, actionId }) {
  try {
    return await recordActivity({
      eventKey,
      module: "arcade",
      topic: gameId,
      activityType: "arcade_correct",
      metadata: {
        game_id: gameId,
        session_id: sessionId,
        round_id: roundId,
        action_id: actionId
      }
    });
  } catch (error) {
    console.error("Numora could not award an Arcade coin:", error);
    throw new ArcadeServiceError("Nice work — we couldn't save that coin yet. Please try again shortly.", error);
  }
}
