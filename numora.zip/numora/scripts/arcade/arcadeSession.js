export function createArcadeId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID().toLowerCase();
  }

  return `arcade-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function createArcadeEventKey({ gameId, sessionId, roundId, actionId, type }) {
  return `arcade:${gameId}:${sessionId}:${roundId}:${actionId}:${type}`.toLowerCase();
}

export function formatCountdown(nextRegenerationAt) {
  const timestamp = Date.parse(nextRegenerationAt ?? "");
  if (!Number.isFinite(timestamp)) {
    return null;
  }

  const remaining = Math.max(0, Math.ceil((timestamp - Date.now()) / 1000));
  const minutes = Math.floor(remaining / 60).toString().padStart(2, "0");
  const seconds = (remaining % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

export function playArcadeSound(kind, isEnabled) {
  if (!isEnabled || typeof window === "undefined" || !window.AudioContext) {
    return;
  }

  try {
    const context = new window.AudioContext();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const wrong = kind === "incorrect";
    const frequency = {
      correct: 660,
      incorrect: 180,
      coin: 880,
      complete: 740
    }[kind] ?? 440;

    oscillator.frequency.value = frequency;
    oscillator.type = wrong ? "sawtooth" : "sine";
    // A quiet, short descending buzz: ease in and out so it is clear without
    // a sharp click or the volume of a reward chime.
    if (wrong) {
      oscillator.frequency.exponentialRampToValueAtTime(120, context.currentTime + 0.16);
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.linearRampToValueAtTime(0.018, context.currentTime + 0.012);
    } else {
      gain.gain.setValueAtTime(0.035, context.currentTime);
    }
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + (wrong ? 0.17 : 0.11));
    oscillator.connect(gain).connect(context.destination);
    oscillator.start();
    oscillator.stop(context.currentTime + (wrong ? 0.18 : 0.12));
    oscillator.addEventListener("ended", () => context.close().catch(() => {}), { once: true });
  } catch {
    // Sound is decorative. Playback failure must never interrupt a game.
  }
}
