export const BALLOON_FLIGHT_MS = 15000;
export const BALLOON_POP_MS = 3000;
export const BALLOON_WAVE_MS = 5000;
export const BALLOON_COOLDOWN_MS = 4000;
export const balloonRounds = [
  { prompt: "Pop every multiple of 6.", values: [18,25,42,49,54,22,35,17], answers: [18,42,54] },
  { prompt: "Pop values with a digit sum of 9.", values: [36,46,63,52,81,58,74], answers: [36,63,81] },
  { prompt: "Pop answers equivalent to 3 × 18.", values: [45,54,"6 × 9","3 × 16","60 − 8","18 + 18"], answers: [54,"6 × 9"] }
];
export function createBalloonFlight() {
  return { version: 3, elapsedMs: 0, running: false, cooldownUntilMs: 0, missed: [], expired: [], rejected: [] };
}
export function balloonProgress(index, elapsedMs) {
  return Math.max(0, Math.min(1, (elapsedMs - Math.floor(index / 4) * BALLOON_WAVE_MS) / BALLOON_FLIGHT_MS));
}
export function balloonHasLaunched(index, elapsedMs) { return elapsedMs >= Math.floor(index / 4) * BALLOON_WAVE_MS; }
export function balloonIsCorrect(state, index) {
  const round = balloonRounds[state.round];
  return Boolean(round && Number.isInteger(index) && index >= 0 && index < round.values.length && round.answers.includes(round.values[index]));
}
export function balloonResolved(state, index) {
  return state.popped.includes(`${state.round}-${index}`) || state.balloon.missed.includes(index);
}
export function balloonRoundDone(state) {
  return balloonRounds[state.round].values.every((_, index) => !balloonIsCorrect(state,index) || balloonResolved(state,index));
}
export function evaluateBalloonAction(state, action) {
  const flight = state.balloon ??= createBalloonFlight();
  if (action === 'balloon-launch') { flight.running = true; return {kind:'select',message:'Pop the matching balloons before they reach the top.'}; }
  if (!action.startsWith('balloon:') || !flight.running || flight.elapsedMs < flight.cooldownUntilMs) return {kind:'none'};
  const index = Number(action.slice(8)), round = balloonRounds[state.round];
  if (!Number.isInteger(index) || index < 0 || index >= round.values.length || balloonResolved(state,index)
    || flight.rejected.includes(index) || flight.expired.includes(index) || !balloonHasLaunched(index,flight.elapsedMs) || balloonProgress(index,flight.elapsedMs) >= 1) return {kind:'none'};
  if (!balloonIsCorrect(state,index)) {
    flight.rejected.push(index); flight.cooldownUntilMs = flight.elapsedMs + BALLOON_COOLDOWN_MS;
    return {kind:'select',feedbackTone:'incorrect',message:'Wrong balloon—it does not fit the rule. Short cooldown—no life lost. Look for the next matching value.'};
  }
  state.popped.push(`${state.round}-${index}`);
  const done = balloonRoundDone(state);
  return {kind:'correct',actionId:`round-${state.round}-balloon-${index}`,advance:done,
    complete:done && state.round === balloonRounds.length-1,message:done?'Round cleared!':'Matching balloon popped!'};
}

export function renderBalloonBoard(state) {
  const flight = state.balloon ??= createBalloonFlight(), round = balloonRounds[state.round];
  const balloons = round.values.map((value,index) => `<button type="button" class="arcade-balloon" data-arcade-action="balloon:${index}" data-balloon-index="${index}" aria-label="Pop ${value}" style="--balloon-lane:${index%4}" hidden>
    <svg viewBox="0 0 90 144" aria-hidden="true"><path class="balloon-string" d="M45 90 C25 106 65 120 43 143"/><path class="balloon-body" d="M45 3 C18 3 7 22 10 44 C12 62 27 79 45 86 C63 79 78 62 80 44 C83 22 72 3 45 3Z"/><path class="balloon-shine" d="M24 20 Q18 27 20 36"/><path class="balloon-knot" d="M45 84 L38 93 Q45 90 52 93Z"/><text x="45" y="47" text-anchor="middle" class="balloon-value${String(value).length>3?' balloon-value--expression':''}">${value}</text><g class="balloon-wrong-mark"><circle cx="70" cy="15" r="10"/><path d="M66 11L74 19M74 11L66 19"/></g></svg></button>`).join('');
  return `<div class="arcade-board__heading"><span>Round ${state.round+1} of ${balloonRounds.length}</span><h3>${round.prompt}</h3></div>
    <div class="balloon-round-controls"><p>Find <strong>${round.answers.length} matching balloons</strong> among ${round.values.length} choices.</p>${!flight.running?'<button class="button button--primary" type="button" data-arcade-action="balloon-launch">Launch balloons</button>':''}<p data-balloon-status></p><p class="balloon-cooldown" data-balloon-cooldown role="status" aria-live="polite"></p></div>
    <div class="arcade-balloons" aria-label="Rising balloon play area"><div class="balloon-top-line" aria-hidden="true">Pop matching balloons before this line</div>${balloons}${!flight.running?`<p class="balloon-ready">Read the rule, then launch.<br>Each balloon takes ${BALLOON_FLIGHT_MS/1000} seconds to reach the top.</p>`:''}<div class="balloon-cooldown-overlay" data-balloon-countdown-overlay hidden aria-hidden="true"><div class="balloon-cooldown-overlay__badge"><span>✕ Wrong balloon</span><strong data-balloon-countdown></strong><small>Cooldown · get ready!</small></div></div></div>
    <p class="arcade-board__hint">Tap a balloon, or use Tab and Enter. Wrong guesses pause popping for ${BALLOON_COOLDOWN_MS/1000} seconds. Each missed matching balloon costs one life. Other balloons can float away safely.</p>`;
}
