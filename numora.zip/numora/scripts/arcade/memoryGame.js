export const MEMORY_FLIP_LIMIT = 8;
export const MEMORY_REVEAL_MS = 1000;

// Each value has exactly two equivalent representations. A replacement board
// excludes every pair from the previous board, not just its card positions.
const pairs = [
  ["1/4", "0.25"], ["1/2", "0.5"], ["3/4", "0.75"],
  ["1/5", "0.2"], ["2/5", "0.4"], ["3/5", "0.6"], ["4/5", "0.8"],
  ["$1.25", "125¢"], ["$2.50", "250¢"], ["$3.75", "375¢"], ["$4.50", "450¢"],
  ["3 × 8", "24"], ["2 × 18", "36"], ["7 × 6", "42"],
  ["8 × 7", "56"], ["72 ÷ 8", "9"], ["96 ÷ 8", "12"]
];

function shuffle(items, random) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function createMemoryBoard(previousCards = [], random = Math.random) {
  const previous = new Set(previousCards.map(card => card.pairId));
  const available = pairs.map((labels, pairId) => ({labels, pairId})).filter(pair => !previous.has(pair.pairId));
  const cards = shuffle(available, random).slice(0, 3).flatMap(({labels, pairId}) => labels.map(label => ({label, pairId})));
  return {version: 1, cards: shuffle(cards, random), flips: 0, status: "playing", revealUntilMs: 0};
}

export function resetMemoryBoard(state) {
  state.memory = createMemoryBoard(state.memory.cards);
  state.selected = [];
  state.matched = [];
  state.round += 1;
}

export function settleMemoryMismatch(state, now = Date.now()) {
  const board = state.memory;
  if (board.status !== "mismatch" || now < board.revealUntilMs) return false;
  state.selected = [];
  board.revealUntilMs = 0;
  board.status = board.flips >= MEMORY_FLIP_LIMIT ? "failed" : "playing";
  return true;
}

export function evaluateMemoryAction(state, action, now = Date.now()) {
  const board = state.memory;
  if (!/^memory:[0-5]$/.test(action) || board.status !== "playing" || board.flips >= MEMORY_FLIP_LIMIT) return {kind: "none"};
  const index = Number(action.slice(7));
  if (state.selected.includes(index) || state.matched.includes(index)) return {kind: "none"};
  board.flips += 1;
  state.moves += 1;
  state.selected.push(index);
  if (state.selected.length === 1) return {kind: "select", message: "One flip used. Choose another card to find its match."};
  const [first, second] = state.selected;
  if (board.cards[first].pairId !== board.cards[second].pairId) {
    board.status = "mismatch";
    board.revealUntilMs = now + MEMORY_REVEAL_MS;
    return {kind: "memory-mismatch", message: "Not a match. Remember their positions—no life lost for a wrong pair."};
  }
  state.selected = [];
  state.matched.push(first, second);
  const complete = state.matched.length === board.cards.length;
  board.status = complete ? "complete" : board.flips >= MEMORY_FLIP_LIMIT ? "failed" : "playing";
  return {kind: "correct", actionId: `board-${state.round}-pair-${board.cards[first].pairId}`,
    advance: false, complete, message: complete ? "All three pairs found!" : "That pair matches!"};
}

export function renderMemoryBoard(state) {
  const board = state.memory, remaining = MEMORY_FLIP_LIMIT - board.flips;
  const cards = board.cards.map(({label}, index) => {
    const matched = state.matched.includes(index), revealed = matched || state.selected.includes(index);
    const mismatch = board.status === "mismatch" && state.selected.includes(index);
    const unavailable = revealed || board.status !== "playing";
    return `<button type="button" class="arcade-memory-card${revealed ? " is-revealed" : ""}${matched ? " is-matched" : ""}${mismatch ? " is-mismatch" : ""}" data-arcade-action="memory:${index}" aria-disabled="${unavailable}" aria-label="Card ${index + 1}, ${mismatch ? `not a match: ${label}` : matched ? `matched: ${label}` : revealed ? label : "face down"}">${revealed ? label : "?"}${mismatch ? '<span class="memory-wrong-mark" aria-hidden="true">×</span>' : ""}</button>`;
  }).join("");
  return `<div class="arcade-board__heading"><span>Board ${state.round + 1} · Match all 3 pairs</span><h3>Find the equal values in 8 flips.</h3></div>
    <p class="memory-flips${remaining <= 2 ? " memory-flips--low" : ""}" role="status" aria-live="polite"><strong data-memory-flips>${remaining}</strong> ${remaining === 1 ? "flip" : "flips"} left</p>
    <div class="arcade-memory" aria-label="Six-card memory board">${cards}</div>
    <p class="arcade-board__hint">Matched pairs: ${state.matched.length / 2} of 3. Every card flip uses one try.<br>Wrong pairs turn back over. An unfinished board after 8 flips costs one life, then new values appear.</p>`;
}
