import { evaluateExpression, formatCalculatorResult } from "./calculatorMath.js";

// Mounted outside the Arcade render root: life timers must not destroy input,
// close the dialog, or steal focus. The Arcade view owns its cleanup.
export function createScientificCalculator({ returnFocus } = {}) {
  const dialog = document.createElement("dialog");
  dialog.className = "scientific-calculator";
  dialog.setAttribute("aria-labelledby", "calculator-title");
  dialog.setAttribute("aria-describedby", "calculator-help");
  const key = (label, token, description = label) => `<button type="button" data-calc-insert="${token}" aria-label="${description}">${label}</button>`;
  dialog.innerHTML = `
    <header class="scientific-calculator__header"><div><p class="arcade__eyebrow">Trig Target · math tools</p><h2 id="calculator-title">Scientific calculator</h2></div><button type="button" class="scientific-calculator__close" data-calc-close aria-label="Close calculator">✕</button></header>
    <p id="calculator-help" class="sr-only">Work out your setup first, then calculate here. These questions use degrees. Calculating does not submit an answer or use a life.</p>
    <div class="scientific-calculator__modes" role="group" aria-label="Angle mode"><button type="button" data-calc-mode="DEG" aria-pressed="true">DEG · Degrees</button><button type="button" data-calc-mode="RAD" aria-pressed="false">RAD · Radians</button></div>
    <p class="scientific-calculator__mode-note" data-calc-mode-note>Angles and inverse-trig answers are in degrees.</p>
    <label for="calculator-expression">Your calculation</label>
    <input id="calculator-expression" type="text" maxlength="256" spellcheck="false" autocomplete="off" autocapitalize="off" placeholder="e.g. sin(30)" aria-describedby="calculator-syntax" enterkeyhint="done">
    <output class="scientific-calculator__result" for="calculator-expression" role="status" aria-live="polite" aria-atomic="true" data-calc-result>Result appears here</output>
    <div class="scientific-calculator__science" role="group" aria-label="Scientific functions">
      ${key("sin", "sin(", "Sine")}${key("cos", "cos(", "Cosine")}${key("tan", "tan(", "Tangent")}
      ${key("sin⁻¹", "asin(", "Inverse sine")}${key("cos⁻¹", "acos(", "Inverse cosine")}${key("tan⁻¹", "atan(", "Inverse tangent")}
      ${key("√", "sqrt(", "Square root")}${key("x²", "^2", "Square")}${key("xʸ", "^", "Power")}${key("(", "(", "Open parenthesis")}${key(")", ")", "Close parenthesis")}${key("π", "π", "Pi")}
      ${key("log", "log(", "Base ten logarithm")}${key("ln", "ln(", "Natural logarithm")}${key("e", "e", "Euler's number")}${key("|x|", "abs(", "Absolute value")}${key("x!", "!", "Factorial")}${key("Ans", "Ans", "Previous answer")}
    </div>
    <div class="scientific-calculator__keypad" role="group" aria-label="Numbers and operations">
      <button type="button" data-calc-clear aria-label="Clear calculation">AC</button><button type="button" data-calc-delete aria-label="Delete previous character">⌫</button>${key("%", "%", "Percent: divide by 100")}${key("÷", "÷", "Divide")}
      ${key("7", "7")}${key("8", "8")}${key("9", "9")}${key("×", "×", "Multiply")}
      ${key("4", "4")}${key("5", "5")}${key("6", "6")}${key("−", "−", "Subtract")}
      ${key("1", "1")}${key("2", "2")}${key("3", "3")}${key("+", "+", "Add")}
      <button type="button" data-calc-negate aria-label="Change sign">+/−</button>${key("0", "0")}${key(".", ".", "Decimal point")}<button type="button" class="scientific-calculator__equals" data-calc-equals aria-label="Calculate result">=</button>
    </div>
    <details class="scientific-calculator__question"><summary>Question & calculator help</summary><p data-calc-question></p><p id="calculator-syntax" class="scientific-calculator__syntax">Work out your setup first, then type or tap the keys; press Enter to calculate. sin⁻¹ means inverse sine. % divides by 100. Use Ans to reuse the unrounded result. Calculating does not submit an answer or use a life.</p></details>`;
  const input = dialog.querySelector("input");
  const output = dialog.querySelector("[data-calc-result]");
  let mode = "DEG", answer = 0, destroyed = false;
  function show(message, error = false) {
    output.textContent = message;
    output.classList.toggle("is-error", error);
    input.setAttribute("aria-invalid", String(error));
  }
  function edited() { show("Ready to calculate"); }
  function skipClosingParenthesis() {
    const cursor = input.selectionStart;
    if (cursor !== input.selectionEnd || input.value[cursor] !== ")") return false;
    input.focus({ preventScroll: true }); input.setSelectionRange(cursor + 1, cursor + 1);
    return true;
  }
  function replace(text, start = input.selectionStart, end = input.selectionEnd, caret = start + text.length) {
    if (input.value.length - (end - start) + text.length > 256) { show("Keep calculations under 256 characters.", true); return; }
    input.setRangeText(text, start, end, "end");
    input.focus({ preventScroll: true }); input.setSelectionRange(caret, caret); edited();
  }
  function calculate() {
    try {
      answer = evaluateExpression(input.value, { mode, answer });
      show(`= ${formatCalculatorResult(answer)}`);
    } catch (error) { show(error.message, true); }
    const box = output.getBoundingClientRect(), viewport = dialog.getBoundingClientRect();
    if (box.top < viewport.top || box.bottom > viewport.bottom) output.scrollIntoView({ block: "nearest" });
  }
  dialog.addEventListener("input", edited);
  input.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === "=") { event.preventDefault(); event.stopPropagation(); calculate(); }
    if (event.key === ")" && skipClosingParenthesis()) event.preventDefault();
  });
  dialog.addEventListener("keydown", event => {
    if (event.key !== "Tab") return;
    const focusable = [...dialog.querySelectorAll("button:not(:disabled), input:not(:disabled), summary")]
      .filter(item => item.getClientRects().length);
    const first = focusable[0], last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  dialog.addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.hasAttribute("data-calc-close")) { dialog.close(); return; }
    if (button.hasAttribute("data-calc-equals")) { calculate(); return; }
    if (button.dataset.calcMode) {
      mode = button.dataset.calcMode;
      dialog.querySelectorAll("[data-calc-mode]").forEach(item => item.setAttribute("aria-pressed", String(item.dataset.calcMode === mode)));
      dialog.querySelector("[data-calc-mode-note]").textContent = mode === "DEG" ? "Angles and inverse-trig answers are in degrees." : "Radians selected. Switch to DEG for this question's angles.";
      edited(); return;
    }
    if (button.hasAttribute("data-calc-clear")) { replace("", 0, input.value.length, 0); return; }
    if (button.hasAttribute("data-calc-delete")) {
      const start = input.selectionStart, end = input.selectionEnd;
      replace("", start === end ? Math.max(0, start - 1) : start, end, start === end ? Math.max(0, start - 1) : start); return;
    }
    if (button.hasAttribute("data-calc-negate")) { replace(`-(${input.value || "0"})`, 0, input.value.length, input.value.length + 3); return; }
    const token = button.dataset.calcInsert;
    if (token === undefined) return;
    if (token === ")" && skipClosingParenthesis()) return;
    if (token.endsWith("(") && token.length > 1) {
      const selected = input.value.slice(input.selectionStart, input.selectionEnd);
      replace(`${token}${selected})`, input.selectionStart, input.selectionEnd, input.selectionStart + token.length + (selected ? selected.length + 1 : 0));
    } else replace(token);
  });
  dialog.addEventListener("close", () => { if (!destroyed) returnFocus?.(); });
  return {
    open(question) {
      if (destroyed || dialog.open) return;
      dialog.querySelector("[data-calc-question]").textContent = question;
      if (!dialog.isConnected) document.body.append(dialog);
      dialog.showModal();
      // Focus a key instead of opening the phone's keyboard automatically.
      dialog.querySelector("[data-calc-close]").focus({ preventScroll: true });
    },
    destroy() { destroyed = true; if (dialog.open) dialog.close(); dialog.remove(); }
  };
}
