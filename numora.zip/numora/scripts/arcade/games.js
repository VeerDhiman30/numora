import { createBalloonFlight, evaluateBalloonAction, renderBalloonBoard } from "./balloonGame.js";
import { createMemoryBoard, evaluateMemoryAction, renderMemoryBoard } from "./memoryGame.js";
import { createLineState, evaluateLineAction, renderLineBoard } from "./lineGame.js";

export const arcadeGrades = [
  { id: "entry", label: "Entry Level", detail: "Grades 3–5" },
  { id: "middle", label: "Middle School", detail: "Grades 6–8" },
  { id: "high", label: "High School", detail: "Grades 9–12" }
];

export const arcadeGames = [
  { id: "balloon-pop", gradeLevel: "entry", icon: "🎈", title: "Balloon Pop", description: "Pop every answer that fits the math rule.", concepts: "Multiples · operations", mechanic: "Pop" },
  { id: "memory-match", gradeLevel: "entry", icon: "🃏", title: "Memory Match", description: "Reveal equivalent math pairs.", concepts: "Facts · money · fractions", mechanic: "Match" },
  { id: "number-portal", gradeLevel: "entry", icon: "🌀", title: "Number Portal", description: "Send values through the right portal.", concepts: "Comparisons · patterns", mechanic: "Sort" },
  { id: "fruit-fractions", gradeLevel: "entry", icon: "🍊", title: "Fruit Fractions", description: "Build fractions with bright fruit slices.", concepts: "Fractions · equivalence", mechanic: "Build" },
  { id: "draw-the-line", gradeLevel: "middle", icon: "📈", title: "Draw the Line", description: "Plot two points from an equation to draw its line.", concepts: "Coordinates · linear equations", mechanic: "Plot" },
  { id: "algebra-circuit", gradeLevel: "middle", icon: "⚡", title: "Algebra Circuit", description: "Power a path by solving equations.", concepts: "Equations · integers", mechanic: "Circuit" },
  { id: "factor-forest", gradeLevel: "middle", icon: "🌲", title: "Factor Forest", description: "Guide numbers through factor trails.", concepts: "Prime · composite · factors", mechanic: "Explore" },
  { id: "ratio-builder", gradeLevel: "middle", icon: "🧱", title: "Ratio Builder", description: "Construct scenes that keep a target ratio.", concepts: "Ratios · proportions", mechanic: "Construct" },
  { id: "function-shift", gradeLevel: "high", icon: "✦", title: "Function Shift", description: "Transform a function to meet its target graph.", concepts: "Functions · transformations", mechanic: "Transform" },
  { id: "trig-target", gradeLevel: "high", icon: "📐", title: "Trig Target", description: "Use right-triangle reasoning to reach a target.", concepts: "Sine · cosine · tangent", mechanic: "Target" },
  { id: "probability-lab", gradeLevel: "high", icon: "🎯", title: "Probability Lab", description: "Predict, simulate, and compare outcomes.", concepts: "Theoretical probability", mechanic: "Simulate" },
  { id: "optimization-challenge", gradeLevel: "high", icon: "⬚", title: "Optimization Challenge", description: "Experiment under a real constraint.", concepts: "Area · optimization", mechanic: "Optimize" }
];

export const arcadeTestGame = {
  id: "largest-number-test",
  gradeLevel: "test",
  icon: "🧪",
  title: "Largest Number Test",
  description: "A small internal game for checking the Arcade engine.",
  concepts: "Number comparison",
  mechanic: "Test"
};

const fruitRounds = [
  { story: "A fruit salad uses 2/6 mango and 3/6 orange. Select their total.", pieces: 6, target: [0, 1, 2, 3, 4], label: "5/6" },
  { story: "Show an amount equivalent to 2/3 using sixths.", pieces: 6, target: [0, 1, 2, 3], label: "4/6" },
  { story: "Show 7/4: one whole fruit and three extra quarters.", pieces: 8, target: [0, 1, 2, 3, 4, 5, 6], label: "7/4" }
];

const circuitRounds = [
  { equation: "5x − 7 = 3x + 13", answer: "10", options: ["3", "10", "20"] },
  { equation: "3(x − 2) = 2x + 7", answer: "13", options: ["9", "13", "27"] },
  { equation: "x/3 + 5 = 11", answer: "18", options: ["2", "6", "18"] }
];

const forestRounds = [
  { number: 91, answer: "composite", prompt: "Guide 91 to the correct tree. Test factors beyond 2, 3, and 5." },
  { number: 84, answer: "12", prompt: "Choose the greatest common factor of 84 and 60.", choices: ["6", "12", "24"] },
  { number: 18, answer: "72", prompt: "Choose the least common multiple of 18 and 24.", choices: ["48", "72", "96"] }
];

const ratioRounds = [
  { red: 12, blue: 8, prompt: "A garden has 20 plants in a 3 : 2 flowers-to-trees ratio. Build it." },
  { red: 9, blue: 15, prompt: "Use 24 tiles in a 3 : 5 red-to-blue ratio." },
  { red: 14, blue: 6, prompt: "Use 20 blocks in a 7 : 3 red-to-blue scale model." }
];

const functionRounds = [
  { h: 3, k: -2, a: -2, prompt: "Transform y = x² into y = −2(x − 3)² − 2." },
  { h: -2, k: 1, a: 0.5, prompt: "Transform y = x² into y = ½(x + 2)² + 1." },
  { h: 1, k: 3, a: -1, prompt: "Transform y = x² into −(x − 1)² + 3." }
];

const trigRounds = [
  { calculator: true, prompt: "A surveyor stands 48 m from a building. The angle of elevation to its roof is 37°. About how tall is the building? First model the triangle, then use tan(37°) in degree mode.", answer: "36.2 m", options: ["28.9 m", "36.2 m", "60.2 m"] },
  { calculator: false, prompt: "A rescue boat is 10√3 km east and 10 km north of its dock. What is its direction from the dock?", answer: "30° north of east", options: ["30° north of east", "60° north of east", "30° east of north"] },
  { calculator: true, prompt: "From a 250 m cliff, a ranger sees a boat at a 22° angle of depression. About how far is the boat horizontally from the base of the cliff? Draw the triangle first, then use tan(22°) in degree mode.", answer: "618.8 m", options: ["101.0 m", "231.8 m", "618.8 m"] }
];

export function isCalculatorRound(gameId, state) {
  return gameId === "trig-target" && Boolean(state && gameRound(state, trigRounds)?.calculator);
}

const probabilityRounds = [
  { prompt: "A game pays $4 with probability 3/8, $1 with probability 2/8, and $0 otherwise. What is the expected payout?", answer: "$1.75", options: ["$1.25", "$1.75", "$2.50"] },
  { prompt: "A bag has 5 red, 3 blue, and 2 green counters. Two are drawn without replacement. What is P(two blue)?", answer: "1/15", options: ["1/10", "1/15", "3/10"] },
  { prompt: "A spinner has 2 green, 3 purple, and 5 yellow sectors. In 200 spins, which green count is most reasonable?", answer: "about 40", options: ["about 10", "about 40", "about 100"] }
];

const portalRounds = [
  { values: [32, 68, 51, 24, 77], warmLabel: "Greater than 50", coolLabel: "50 or less", rule: "greater" },
  { values: [18, 25, 42, 49, 54], warmLabel: "Multiple of 6", coolLabel: "Not a multiple of 6", rule: "multiple-of-6" },
  { values: [4, 6, 9, 12, 15], warmLabel: "Factor of 36", coolLabel: "Not a factor of 36", rule: "factor-of-36" }
];

const optimizationRounds = [
  { fence: 100, type: "three", target: 25, prompt: "100 m of fencing encloses three sides of a rectangular garden against a wall. Choose the width that maximizes area." },
  { fence: 120, type: "four", target: 30, prompt: "120 m of fencing encloses all four sides of a rectangle. Choose the width that maximizes area." },
  { fence: 80, type: "three", target: 20, prompt: "80 m of fencing encloses three sides of a dog run against a building. Choose the width that maximizes area." }
];

function gameById(gameId) {
  return [...arcadeGames, arcadeTestGame].find((game) => game.id === gameId) ?? null;
}

export function getGamesForGrade(gradeLevel) {
  return arcadeGames.filter((game) => game.gradeLevel === gradeLevel);
}

export function getArcadeGame(gameId) {
  return gameById(gameId);
}

export function createGameState(gameId) {
  return {
    gameId,
    round: 0,
    correctActions: 0,
    moves: 0,
    selected: [],
    matched: [],
    popped: [],
    balloon: createBalloonFlight(),
    memory: gameId === "memory-match" ? createMemoryBoard() : null,
    portalValue: null,
    ratio: { red: 0, blue: 0 },
    graph: createLineState(),
    transform: { h: 0, k: 0, a: 1 },
    optimizationWidth: 5,
    simulation: { trials: 0, hits: 0 }
  };
}

function gameRound(state, rounds) {
  return rounds[Math.min(state.round, rounds.length - 1)];
}

function actionButton(action, label, className = "arcade-action") {
  return `<button class="${className}" type="button" data-arcade-action="${action}">${label}</button>`;
}

function boardHeading(label, prompt) {
  return `<div class="arcade-board__heading"><span>${label}</span><h3>${prompt}</h3></div>`;
}

function renderBalloonPop(state) {
  return renderBalloonBoard(state);
}

function renderMemoryMatch(state) {
  return renderMemoryBoard(state);
}

function renderNumberPortal(state) {
  const round = gameRound(state, portalRounds);
  const valueButtons = round.values.map((value) => `<button class="arcade-number-chip${state.portalValue === value ? " is-selected" : ""}" type="button" draggable="true" data-arcade-drag-value="${value}" data-arcade-action="portal-value:${value}">${value}</button>`).join("");
  return `${boardHeading(`Placement ${state.round + 1} of 3`, "Choose a value, then send it through the correct rule portal.")}<div class="arcade-portal-values">${valueButtons}</div><div class="arcade-portals"><button type="button" class="arcade-portal arcade-portal--warm" data-arcade-action="portal-target:match">${round.warmLabel}</button><button type="button" class="arcade-portal arcade-portal--cool" data-arcade-action="portal-target:not-match">${round.coolLabel}</button></div><p class="arcade-board__hint">Drag a number into a portal, or tap a number then a portal.</p>`;
}

function renderFruitFractions(state) {
  const round = gameRound(state, fruitRounds);
  const pieces = Array.from({ length: round.pieces }, (_, index) => actionButton(
    `fruit:${index}`,
    state.selected.includes(index) ? "✓" : "",
    `arcade-fruit-piece${state.selected.includes(index) ? " is-selected" : ""}`
  )).join("");
  return `${boardHeading(`Round ${state.round + 1} of 3`, round.story)}<div class="arcade-fruit">${pieces}</div><div class="arcade-board__controls">${actionButton("fruit-reset", "Reset selection", "button button--secondary")}${actionButton("fruit-check", `Check ${round.label}`, "button button--primary")}</div>`;
}

function renderDrawTheLine(state) {
  return renderLineBoard(state);
}

function renderAlgebraCircuit(state) {
  const round = gameRound(state, circuitRounds);
  return `${boardHeading(`Node ${state.round + 1} of 3`, `Solve ${round.equation}`)}<div class="arcade-circuit" aria-label="An equation node with three possible circuit paths"><span class="arcade-circuit__node">Start</span><span class="arcade-circuit__wire" aria-hidden="true"></span><span class="arcade-circuit__node arcade-circuit__node--equation">${round.equation}</span><span class="arcade-circuit__wire" aria-hidden="true"></span><div class="arcade-circuit__paths">${round.options.map((option) => actionButton(`circuit:${option}`, `x = ${option}`, "arcade-circuit__path")).join("")}</div></div>`;
}

function renderFactorForest(state) {
  const round = gameRound(state, forestRounds);
  const choices = round.choices ?? ["prime", "composite"];
  return `${boardHeading(`Trail ${state.round + 1} of 3`, round.prompt)}<div class="arcade-forest"><div class="arcade-forest__number">${round.number}</div><div class="arcade-forest__trees">${choices.map((choice, index) => actionButton(`forest:${choice}`, choice === "prime" ? "Prime tree" : choice === "composite" ? "Composite tree" : choice, `arcade-tree arcade-tree--${index ? "composite" : "prime"}`)).join("")}</div></div><p class="arcade-board__hint">Use factor pairs, not just a divisibility test.</p>`;
}

function renderRatioBuilder(state) {
  const round = gameRound(state, ratioRounds);
  const makeBlocks = (count, color) => Array.from({ length: count }, () => `<span class="arcade-ratio-block arcade-ratio-block--${color}" aria-hidden="true"></span>`).join("");
  return `${boardHeading(`Build ${state.round + 1} of 3`, round.prompt)}<div class="arcade-ratio-scene"><div>${makeBlocks(state.ratio.red, "red")}</div><div>${makeBlocks(state.ratio.blue, "blue")}</div></div><div class="arcade-steppers"><div><span>Red pieces: <strong>${state.ratio.red}</strong></span>${actionButton("ratio:red:-1", "−", "arcade-step")}${actionButton("ratio:red:1", "+", "arcade-step")}</div><div><span>Blue pieces: <strong>${state.ratio.blue}</strong></span>${actionButton("ratio:blue:-1", "−", "arcade-step")}${actionButton("ratio:blue:1", "+", "arcade-step")}</div></div><div class="arcade-board__controls">${actionButton("ratio-reset", "Reset", "button button--secondary")}${actionButton("ratio-check", "Submit design", "button button--primary")}</div>`;
}

function renderFunctionShift(state) {
  const round = gameRound(state, functionRounds);
  const { h, k, a } = state.transform;
  const signedShift = h === 0 ? "x" : `x ${h >= 0 ? "−" : "+"} ${Math.abs(h)}`;
  const signedVertical = k === 0 ? "" : ` ${k >= 0 ? "+" : "−"} ${Math.abs(k)}`;
  const equation = `y = ${a}(${signedShift})²${signedVertical}`;
  const targetCurve = 80 - round.k * 10 - round.a * 26;
  const currentCurve = 80 - k * 10 - a * 26;
  return `${boardHeading(`Transform ${state.round + 1} of 3`, round.prompt)}<div class="arcade-graph arcade-function-graph" role="img" aria-label="Current parabola has scale ${a} and vertex ${h}, ${k}."><svg viewBox="0 0 240 160" aria-hidden="true"><path d="M20 80H220M120 12V148" class="arcade-graph__axis"/><path d="M45 20 Q${120 + round.h * 12} ${targetCurve} 195 20" class="arcade-graph__line arcade-graph__line--target"/><path d="M45 20 Q${120 + h * 12} ${currentCurve} 195 20" class="arcade-graph__line"/></svg></div><p class="arcade-equation">${equation}</p><div class="arcade-steppers"><div><span>Horizontal shift: <strong>${h}</strong></span>${actionButton("function-h:-1", "Left", "arcade-step")}${actionButton("function-h:1", "Right", "arcade-step")}</div><div><span>Vertical shift: <strong>${k}</strong></span>${actionButton("function-k:-1", "Down", "arcade-step")}${actionButton("function-k:1", "Up", "arcade-step")}</div><div><span>Vertical scale: <strong>${a}</strong></span>${actionButton("function-a:0.5", "÷ 2", "arcade-step")}${actionButton("function-a:2", "× 2", "arcade-step")}${actionButton("function-a:-1", "Reflect", "arcade-step")}</div></div><div class="arcade-board__controls">${actionButton("function-reset", "Reset", "button button--secondary")}${actionButton("function-check", "Submit transformation", "button button--primary")}</div>`;
}

function renderTrigTarget(state) {
  const round = gameRound(state, trigRounds);
  const tools = round.calculator
    ? `<div class="arcade-calculator-tools"><span class="arcade-calculator-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M8 6h8v4H8zM8 14h2m4 0h2m-8 4h2m4 0h2"/></svg>Calculator question</span><button class="button button--secondary" type="button" data-arcade-action="open-calculator" aria-haspopup="dialog">Open scientific calculator</button></div>`
    : '<p class="arcade-no-calculator">No calculator needed · use an exact trig ratio.</p>';
  return `${boardHeading(`Target ${state.round + 1} of 3`, round.prompt)}${tools}<div class="arcade-triangle"><svg viewBox="0 0 260 160" role="img" aria-label="A right triangle target"><path d="M36 132 L214 132 L214 28 Z"/><path d="M196 132V114H214"/><text x="108" y="151">adjacent</text><text x="220" y="85">opposite</text><text x="112" y="68">hypotenuse</text></svg></div><div class="arcade-option-row">${round.options.map((option) => actionButton(`trig:${option}`, option, "arcade-option")).join("")}</div>`;
}

function renderProbabilityLab(state) {
  const round = gameRound(state, probabilityRounds);
  const simulatedRate = state.simulation.trials ? `${Math.round((state.simulation.hits / state.simulation.trials) * 100)}%` : "—";
  return `${boardHeading(`Experiment ${state.round + 1} of 3`, round.prompt)}<div class="arcade-probability"><div class="arcade-spinner" aria-hidden="true"><span></span></div><div class="arcade-probability__results"><strong>${state.simulation.trials}</strong><span>simulated trials</span><strong>${simulatedRate}</strong><span>highlighted-outcome rate</span></div></div><div class="arcade-board__controls">${actionButton("probability-run", "Run 12 simulations", "button button--secondary")}</div><div class="arcade-option-row">${round.options.map((option) => actionButton(`probability:${option}`, option, "arcade-option")).join("")}</div><p class="arcade-board__hint">The simulation is evidence only. Work out the expected value or theoretical probability before choosing.</p>`;
}

function renderOptimizationChallenge(state) {
  const round = gameRound(state, optimizationRounds);
  const width = state.optimizationWidth;
  const height = round.type === "three" ? round.fence - 2 * width : (round.fence - 2 * width) / 2;
  return `${boardHeading(`Challenge ${state.round + 1} of 3`, round.prompt)}<div class="arcade-optimization"><div class="arcade-optimization__shape" style="--shape-width:${width};--shape-height:${Math.max(5, height / 2)}" aria-label="Rectangle ${width} metres by ${height} metres"></div><div><p>Width: <strong>${width} m</strong> · Other side: <strong>${height} m</strong></p><p>Calculate the area yourself before submitting.</p></div></div><div class="arcade-steppers"><div><span>Adjust width by 1 m</span>${actionButton("optimization:-1", "− 1", "arcade-step")}${actionButton("optimization:1", "+ 1", "arcade-step")}</div></div><div class="arcade-board__controls">${actionButton("optimization-check", "Submit dimensions", "button button--primary")}</div>`;
}

function renderTestGame(state) {
  const values = [[18, 42, 31], [67, 54, 81], [92, 99, 90]][state.round];
  return `${boardHeading(`Engine test ${state.round + 1} of 3`, "Select the largest number.")}<div class="arcade-option-row">${values.map((value) => actionButton(`test:${value}`, value, "arcade-option")).join("")}</div>`;
}

export function renderGameBoard(game, state) {
  const renderers = {
    "balloon-pop": renderBalloonPop,
    "memory-match": renderMemoryMatch,
    "number-portal": renderNumberPortal,
    "fruit-fractions": renderFruitFractions,
    "draw-the-line": renderDrawTheLine,
    "algebra-circuit": renderAlgebraCircuit,
    "factor-forest": renderFactorForest,
    "ratio-builder": renderRatioBuilder,
    "function-shift": renderFunctionShift,
    "trig-target": renderTrigTarget,
    "probability-lab": renderProbabilityLab,
    "optimization-challenge": renderOptimizationChallenge,
    "largest-number-test": renderTestGame
  };
  return renderers[game.id]?.(state) ?? "<p>This game is preparing its first round.</p>";
}

function success(state, { advance = true, finalAt = 3, message = "Correct!" } = {}) {
  return {
    kind: "correct",
    actionId: `round-${state.round}-correct-${state.correctActions + 1}`,
    advance,
    complete: state.correctActions + 1 >= finalAt,
    message
  };
}

function incorrect(message = "Not quite — try the next move with that idea in mind.") {
  return { kind: "incorrect", message };
}

export function evaluateGameAction(game, state, action) {
  const [type, ...parts] = action.split(":");
  const value = parts.join(":");

  if (game.id === "balloon-pop") return evaluateBalloonAction(state, action);

  if (game.id === "memory-match") return evaluateMemoryAction(state, action);

  if (game.id === "number-portal") {
    if (type === "portal-value") {
      state.portalValue = Number(value);
      return { kind: "select", message: `Now choose a portal for ${value}.` };
    }
    if (type === "portal-target" && Number.isInteger(state.portalValue)) {
      const round = gameRound(state, portalRounds);
      const matchesRule = round.rule === "greater"
        ? state.portalValue > 50
        : round.rule === "multiple-of-6"
          ? state.portalValue % 6 === 0
          : 36 % state.portalValue === 0;
      const choseMatch = value === "match";
      state.portalValue = null;
      return matchesRule === choseMatch
        ? success(state, { message: "The value found its portal." })
        : incorrect("Check the rule carefully before choosing a portal.");
    }
  }

  if (game.id === "fruit-fractions") {
    const round = gameRound(state, fruitRounds);
    if (type === "fruit") {
      const index = Number(value);
      state.selected = state.selected.includes(index) ? state.selected.filter((item) => item !== index) : [...state.selected, index];
      return { kind: "select", message: `${state.selected.length} piece${state.selected.length === 1 ? "" : "s"} selected.` };
    }
    if (type === "fruit-reset") { state.selected = []; return { kind: "select", message: "Selection cleared." }; }
    if (type === "fruit-check") {
      const correct = state.selected.length === round.target.length && round.target.every((item) => state.selected.includes(item));
      return correct ? success(state, { message: `${round.label} is correct!` }) : incorrect(`Try building ${round.label} with equal pieces.`);
    }
  }

  if (game.id === "draw-the-line") return evaluateLineAction(state, action);

  if (game.id === "algebra-circuit" && type === "circuit") {
    const round = gameRound(state, circuitRounds);
    return value === round.answer ? success(state, { message: "Circuit activated!" }) : incorrect("Solve for x before choosing a path.");
  }

  if (game.id === "factor-forest" && type === "forest") {
    const round = gameRound(state, forestRounds);
    return value === round.answer ? success(state, { message: "The number found its tree." }) : incorrect("Check how many positive factors the number has.");
  }

  if (game.id === "ratio-builder") {
    const round = gameRound(state, ratioRounds);
    if (type === "ratio") {
      const [color, change] = parts;
      state.ratio[color] = Math.max(0, Math.min(24, state.ratio[color] + Number(change)));
      return { kind: "select" };
    }
    if (type === "ratio-reset") { state.ratio = { red: 0, blue: 0 }; return { kind: "select", message: "Builder reset." }; }
    if (type === "ratio-check") return state.ratio.red === round.red && state.ratio.blue === round.blue ? success(state, { message: "That construction keeps the required ratio." }) : incorrect(`You built ${state.ratio.red} : ${state.ratio.blue}. Check the target ratio.`);
  }

  if (game.id === "function-shift") {
    const round = gameRound(state, functionRounds);
    if (type === "function-h") { state.transform.h = Math.max(-4, Math.min(4, state.transform.h + Number(value))); return { kind: "select" }; }
    if (type === "function-k") { state.transform.k = Math.max(-4, Math.min(4, state.transform.k + Number(value))); return { kind: "select" }; }
    if (type === "function-a") {
      const next = state.transform.a * Number(value);
      state.transform.a = Math.max(-4, Math.min(4, next));
      return { kind: "select" };
    }
    if (type === "function-reset") { state.transform = { h: 0, k: 0, a: 1 }; return { kind: "select", message: "Transformation reset." }; }
    if (type === "function-check") return state.transform.h === round.h && state.transform.k === round.k && Math.abs(state.transform.a - round.a) < 0.001 ? success(state, { message: "Your transformed graph is on target." }) : incorrect("Check the vertex, reflection, and vertical scale.");
  }

  if (game.id === "trig-target" && type === "trig") {
    const round = gameRound(state, trigRounds);
    return value === round.answer ? success(state, { message: "Target reached!" }) : incorrect("Sketch the situation and label the sides first. Then choose the trig ratio — and use degree mode if it is a calculator round.");
  }

  if (game.id === "probability-lab") {
    const round = gameRound(state, probabilityRounds);
    if (type === "probability-run") {
      const trials = 12;
      const rate = [3 / 8, 3 / 10, 2 / 10][state.round] ?? 1 / 2;
      const hits = Array.from({ length: trials }, () => Math.random() < rate).filter(Boolean).length;
      state.simulation = { trials: state.simulation.trials + trials, hits: state.simulation.hits + hits };
      return { kind: "select", message: "Simulation complete. Now choose the theoretical probability." };
    }
    if (type === "probability") return value === round.answer ? success(state, { message: "Your theoretical probability is correct." }) : incorrect("Use the number of favorable outcomes over total equally likely outcomes.");
  }

  if (game.id === "optimization-challenge") {
    const round = gameRound(state, optimizationRounds);
    if (type === "optimization") {
      const maxWidth = round.type === "three" ? Math.floor((round.fence - 5) / 2) : Math.floor(round.fence / 2 - 5);
      state.optimizationWidth = Math.max(5, Math.min(maxWidth, state.optimizationWidth + Number(value)));
      return { kind: "select" };
    }
    if (type === "optimization-check") return state.optimizationWidth === round.target ? success(state, { message: "Correct — you found the maximum-area dimensions under this constraint." }) : incorrect("Write area as a function of one side, then look for where its factors balance.");
  }

  if (game.id === "largest-number-test" && type === "test") {
    const values = [[18, 42, 31], [67, 54, 81], [92, 99, 90]][state.round];
    return Number(value) === Math.max(...values) ? success(state, { message: "Engine hook confirmed." }) : incorrect("Choose the largest value.");
  }

  return { kind: "none" };
}

export function advanceGameState(game, state, outcome) {
  if (!outcome.advance || outcome.complete) return;
  state.round += 1;
  state.selected = [];
  state.popped = game.id === "balloon-pop" ? state.popped : [];
  state.balloon = createBalloonFlight();
  state.portalValue = null;
  state.ratio = { red: 0, blue: 0 };
  state.graph = createLineState();
  state.transform = { h: 0, k: 0, a: 1 };
  state.optimizationWidth = 5;
  state.simulation = { trials: 0, hits: 0 };
}
