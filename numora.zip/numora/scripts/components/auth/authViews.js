import {
  FriendlyAuthError,
  sendPasswordRecovery,
  signIn,
  signUp,
  updatePassword
} from "../../services/authService.js";

const gradeOptions = `
  <option value="">Select your grade level</option>
  <option value="entry">Entry Level — Grades 3–5</option>
  <option value="middle">Middle School — Grades 6–8</option>
  <option value="high">High School — Grades 9–12</option>
`;

function createShell({ eyebrow, title, description, content, footer = "" }) {
  const section = document.createElement("section");
  section.className = "auth-view section";
  section.setAttribute("aria-labelledby", "auth-title");
  section.innerHTML = `
    <div class="page-container page-container--narrow">
      <div class="auth-card card">
        <div class="auth-card__heading">
          <p class="home-section-heading__eyebrow">${eyebrow}</p>
          <h1 id="auth-title">${title}</h1>
          <p>${description}</p>
        </div>
        ${content}
        ${footer ? `<div class="auth-card__footer">${footer}</div>` : ""}
      </div>
    </div>
  `;
  return section;
}

function createField({ id, label, type = "text", autocomplete, hint = "", options = "" }) {
  const control = type === "select"
    ? `<select id="${id}" name="${id}" autocomplete="${autocomplete ?? "off"}" aria-describedby="${id}-error">${options}</select>`
    : `<input id="${id}" name="${id}" type="${type}" autocomplete="${autocomplete ?? "off"}" aria-describedby="${id}-error">`;

  return `
    <div class="auth-field">
      <label for="${id}">${label}</label>
      ${control}
      ${hint ? `<p class="auth-field__hint">${hint}</p>` : ""}
      <p id="${id}-error" class="auth-field__error" data-field-error="${id}" aria-live="polite"></p>
    </div>
  `;
}

function getTrimmedValue(form, fieldName) {
  return String(new FormData(form).get(fieldName) ?? "").trim();
}

function getValue(form, fieldName) {
  return String(new FormData(form).get(fieldName) ?? "");
}

function clearValidation(form) {
  form.querySelectorAll("[data-field-error]").forEach((element) => {
    element.textContent = "";
  });
  form.querySelectorAll("[aria-invalid]").forEach((element) => {
    element.removeAttribute("aria-invalid");
  });
}

function showFieldErrors(form, errors) {
  Object.entries(errors).forEach(([name, message]) => {
    const input = form.elements.namedItem(name);
    const error = form.querySelector(`[data-field-error="${name}"]`);
    input?.setAttribute("aria-invalid", "true");
    if (error) {
      error.textContent = message;
    }
  });
}

function setFormMessage(form, message, type = "error") {
  const status = form.querySelector("[data-form-message]");
  status.textContent = message;
  status.dataset.state = type;
}

function setBusy(form, isBusy, label) {
  const submit = form.querySelector("button[type=submit]");
  submit.disabled = isBusy;
  submit.setAttribute("aria-busy", String(isBusy));
  submit.textContent = isBusy ? "Please wait…" : label;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePassword(password, confirmPassword = password) {
  const errors = {};
  if (password.length < 8) {
    errors.password = "Use at least 8 characters.";
  }
  if (confirmPassword !== password) {
    errors.confirmPassword = "Passwords do not match.";
  }
  return errors;
}

function createSignInView({ onAuthenticated }) {
  const section = createShell({
    eyebrow: "Welcome back",
    title: "Sign in to Numora",
    description: "Pick up where your mathematical thinking left off.",
    content: `
      <form class="auth-form" data-auth-form novalidate>
        ${createField({ id: "email", label: "Email", type: "email", autocomplete: "email" })}
        ${createField({ id: "password", label: "Password", type: "password", autocomplete: "current-password" })}
        <div class="auth-form__options">
          <label class="auth-checkbox"><input type="checkbox" name="rememberMe"> <span>Remember me</span></label>
          <a class="auth-inline-link" href="#/forgot-password" data-route-link data-route="#/forgot-password">Forgot password?</a>
        </div>
        <p class="auth-form__message" data-form-message role="status" aria-live="polite"></p>
        <button class="button button--primary auth-form__submit" type="submit">Sign In</button>
      </form>
    `,
    footer: `New to Numora? <a class="auth-inline-link" href="#/signup" data-route-link data-route="#/signup">Create an account</a>`
  });
  const form = section.querySelector("[data-auth-form]");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearValidation(form);
    const email = getTrimmedValue(form, "email");
    const password = getValue(form, "password");
    const errors = {};

    if (!isValidEmail(email)) {
      errors.email = "Enter a valid email address.";
    }
    if (!password) {
      errors.password = "Enter your password.";
    }
    if (Object.keys(errors).length) {
      showFieldErrors(form, errors);
      setFormMessage(form, "Please review the highlighted fields.");
      return;
    }

    setBusy(form, true, "Sign In");
    setFormMessage(form, "Signing you in…", "info");
    try {
      await signIn({
        email,
        password,
        rememberMe: form.elements.rememberMe.checked
      });
      onAuthenticated();
    } catch (error) {
      setFormMessage(form, error instanceof FriendlyAuthError ? error.message : "We couldn't sign you in. Please try again.");
      setBusy(form, false, "Sign In");
    }
  });

  return section;
}

function createSignUpView({ onAuthenticated, onNavigate }) {
  const section = createShell({
    eyebrow: "Create your path",
    title: "Start learning with Numora",
    description: "A few details help shape the right mathematics pathway for you.",
    content: `
      <form class="auth-form" data-auth-form novalidate>
        <div class="auth-form__name-row">
          ${createField({ id: "firstName", label: "First Name", autocomplete: "given-name" })}
          ${createField({ id: "lastName", label: "Last Name", autocomplete: "family-name" })}
        </div>
        ${createField({ id: "email", label: "Email", type: "email", autocomplete: "email" })}
        ${createField({ id: "gradeLevel", label: "Grade Level", type: "select", autocomplete: "off", options: gradeOptions })}
        ${createField({ id: "password", label: "Password", type: "password", autocomplete: "new-password", hint: "Use at least 8 characters." })}
        ${createField({ id: "confirmPassword", label: "Confirm Password", type: "password", autocomplete: "new-password" })}
        <p class="auth-form__message" data-form-message role="status" aria-live="polite"></p>
        <button class="button button--primary auth-form__submit" type="submit">Create Account</button>
      </form>
    `,
    footer: `Already have an account? <a class="auth-inline-link" href="#/signin" data-route-link data-route="#/signin">Sign in</a>`
  });
  const form = section.querySelector("[data-auth-form]");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearValidation(form);
    const details = {
      firstName: getTrimmedValue(form, "firstName"),
      lastName: getTrimmedValue(form, "lastName"),
      email: getTrimmedValue(form, "email"),
      gradeLevel: getTrimmedValue(form, "gradeLevel"),
      password: getValue(form, "password")
    };
    const confirmPassword = getValue(form, "confirmPassword");
    const errors = validatePassword(details.password, confirmPassword);

    if (!details.firstName) {
      errors.firstName = "Enter your first name.";
    }
    if (!details.lastName) {
      errors.lastName = "Enter your last name.";
    }
    if (!isValidEmail(details.email)) {
      errors.email = "Enter a valid email address.";
    }
    if (!["entry", "middle", "high"].includes(details.gradeLevel)) {
      errors.gradeLevel = "Choose your grade level.";
    }
    if (Object.keys(errors).length) {
      showFieldErrors(form, errors);
      setFormMessage(form, "Please review the highlighted fields.");
      return;
    }

    setBusy(form, true, "Create Account");
    setFormMessage(form, "Creating your account…", "info");
    try {
      const result = await signUp(details);
      if (result.requiresEmailConfirmation) {
        onNavigate("#/check-email");
      } else {
        onAuthenticated();
      }
    } catch (error) {
      setFormMessage(form, error instanceof FriendlyAuthError ? error.message : "We couldn't create your account. Please try again.");
      setBusy(form, false, "Create Account");
    }
  });

  return section;
}

function createForgotPasswordView() {
  const section = createShell({
    eyebrow: "Password help",
    title: "Reset your password",
    description: "Enter your email and we’ll send instructions if there is an account for it.",
    content: `
      <form class="auth-form" data-auth-form novalidate>
        ${createField({ id: "email", label: "Email", type: "email", autocomplete: "email" })}
        <p class="auth-form__message" data-form-message role="status" aria-live="polite"></p>
        <button class="button button--primary auth-form__submit" type="submit">Send Reset Instructions</button>
      </form>
    `,
    footer: `<a class="auth-inline-link" href="#/signin" data-route-link data-route="#/signin">Back to sign in</a>`
  });
  const form = section.querySelector("[data-auth-form]");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearValidation(form);
    const email = getTrimmedValue(form, "email");

    if (!isValidEmail(email)) {
      showFieldErrors(form, { email: "Enter a valid email address." });
      setFormMessage(form, "Please review the highlighted field.");
      return;
    }

    setBusy(form, true, "Send Reset Instructions");
    setFormMessage(form, "Sending instructions…", "info");
    try {
      await sendPasswordRecovery(email);
      setFormMessage(form, "If an account uses that email, reset instructions are on the way.", "success");
    } catch (error) {
      setFormMessage(form, error instanceof FriendlyAuthError ? error.message : "We couldn't send reset instructions right now. Please try again.");
    } finally {
      setBusy(form, false, "Send Reset Instructions");
    }
  });

  return section;
}

function createResetPasswordView() {
  const section = createShell({
    eyebrow: "Choose a new password",
    title: "Set a new password",
    description: "Make it something you can remember and keep private.",
    content: `
      <form class="auth-form" data-auth-form novalidate>
        ${createField({ id: "password", label: "New Password", type: "password", autocomplete: "new-password", hint: "Use at least 8 characters." })}
        ${createField({ id: "confirmPassword", label: "Confirm New Password", type: "password", autocomplete: "new-password" })}
        <p class="auth-form__message" data-form-message role="status" aria-live="polite"></p>
        <button class="button button--primary auth-form__submit" type="submit">Update Password</button>
      </form>
    `
  });
  const form = section.querySelector("[data-auth-form]");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearValidation(form);
    const password = getValue(form, "password");
    const confirmPassword = getValue(form, "confirmPassword");
    const errors = validatePassword(password, confirmPassword);

    if (Object.keys(errors).length) {
      showFieldErrors(form, errors);
      setFormMessage(form, "Please review the highlighted fields.");
      return;
    }

    setBusy(form, true, "Update Password");
    setFormMessage(form, "Updating your password…", "info");
    try {
      await updatePassword(password);
      form.replaceChildren();
      const message = document.createElement("p");
      message.className = "auth-form__message";
      message.dataset.state = "success";
      message.setAttribute("role", "status");
      message.textContent = "Your password is updated. You can now sign in.";
      const link = document.createElement("a");
      link.className = "button button--primary auth-form__submit";
      link.href = "#/signin";
      link.dataset.routeLink = "";
      link.dataset.route = "#/signin";
      link.textContent = "Return to Sign In";
      form.append(message, link);
    } catch (error) {
      setFormMessage(form, error instanceof FriendlyAuthError ? error.message : "We couldn't update your password. Please try again.");
      setBusy(form, false, "Update Password");
    }
  });

  return section;
}

function createEmailConfirmationView() {
  return createShell({
    eyebrow: "One last step",
    title: "Check your email",
    description: "We sent a confirmation link to your email address. Confirm your account, then return to Numora to sign in.",
    content: `<a class="button button--primary auth-form__submit" href="#/signin" data-route-link data-route="#/signin">Return to Sign In</a>`
  });
}

export function createAuthenticationView(route, callbacks) {
  if (route === "#/signup") {
    return createSignUpView(callbacks);
  }
  if (route === "#/forgot-password") {
    return createForgotPasswordView();
  }
  if (route === "#/reset-password") {
    return createResetPasswordView();
  }
  if (route === "#/check-email") {
    return createEmailConfirmationView();
  }
  return createSignInView(callbacks);
}
