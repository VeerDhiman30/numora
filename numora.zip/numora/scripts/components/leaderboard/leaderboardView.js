import { getWeeklyLeaderboard } from "../../services/leaderboardService.js";
import { getAppState, subscribeToAppState } from "../../services/appState.js";
import { formatCalendarDate as date, secondsUntil, formatWeeklyCountdown } from "../../utils/calendar.js";

const escape = (value) => String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
const number = (value) => value.toLocaleString();
const signature = (state) => `${state.totalXp}:${state.economy?.today?.local_date ?? ""}:${state.economy?.calendar?.weekStart ?? ""}`;

function rankMarkup(rank) {
  const medal = ["🥇", "🥈", "🥉"][rank - 1];
  return `<span class="sr-only">Rank ${rank}</span><span aria-hidden="true" class="leaderboard-rank${medal ? " leaderboard-rank--medal" : ""}">${medal ?? number(rank)}</span>`;
}

function rowMarkup(row) {
  return `<tr${row.isCurrentUser ? ' class="leaderboard-you" data-current-student' : ""}>
    <td>${rankMarkup(row.rank)}</td><th scope="row"><span class="leaderboard-name">${escape(row.displayName)}</span>${row.isCurrentUser ? ' <span class="leaderboard-you-label">You</span>' : ""}</th>
    <td class="leaderboard-xp">${number(row.weeklyXp)} <span>XP</span></td></tr>`;
}

function tableMarkup(data) {
  if (!data.entries.length) return `<div class="leaderboard-empty"><h2>No weekly activity yet</h2>
    <p>No weekly activity yet. Complete an activity to join the leaderboard.</p>
    <a class="button button--primary" href="#/quant" data-route-link data-route="#/quant">Practice in Quant Lab</a></div>`;
  const outside = data.currentStudent.rank > 10;
  return `<table class="leaderboard-table"><caption>Top 10${outside ? " and your position" : ""}</caption>
    <colgroup><col class="leaderboard-rank-column"><col><col class="leaderboard-xp-column"></colgroup>
    <thead><tr><th scope="col">Rank</th><th scope="col">Student</th><th scope="col">Weekly XP</th></tr></thead>
    <tbody>${data.entries.map(rowMarkup).join("")}</tbody>
    ${outside ? `<tbody><tr class="leaderboard-divider"><td colspan="3">Your position · outside the Top 10</td></tr>${rowMarkup(data.currentStudent)}</tbody>` : ""}</table>`;
}

export function createLeaderboardView() {
  const root = document.createElement("section");
  root.className = "leaderboard page-container";
  root.setAttribute("aria-labelledby", "leaderboard-title");
  root.innerHTML = `<header class="leaderboard-heading"><div><p class="leaderboard-eyebrow">Weekly tournament</p>
    <h1 id="leaderboard-title">Weekly Leaderboard</h1><p>Every bit of practice adds up.</p></div>
    <div class="leaderboard-actions"><a class="button button--secondary" href="#/dashboard" data-route-link data-route="#/dashboard">Dashboard</a>
    <button type="button" class="button button--secondary" data-leaderboard-refresh>Refresh</button></div></header>
    <p class="leaderboard-period" data-leaderboard-period>Checking this week’s dates…</p>
    <div class="leaderboard-reset"><span>Ends Monday at midnight · your local time</span>
      <p>Weekly reset in <strong role="timer" aria-live="off" data-weekly-countdown>Checking reset time…</strong></p></div>
    <p class="sr-only" role="status" aria-live="polite" data-leaderboard-status></p>
    <div data-leaderboard-error hidden></div>
    <div data-leaderboard-content aria-busy="true"><div class="leaderboard-skeleton" aria-hidden="true">${Array.from({ length: 5 }, () => '<div><i></i><i></i><i></i></div>').join("")}</div></div>
    <details class="leaderboard-rules"><summary>How weekly ranking works</summary>
      <p>Each tournament runs from Monday at midnight to next Monday at midnight. XP is counted from Monday through today. The dates follow your saved time zone and apply to everyone’s saved daily XP, just like your Dashboard. Students in other time zones may see a different date range near midnight. New weeks change the ranking period; lifetime XP, coins, streak history, and saved activities are never reset.</p>
      <p>Decision, Quant, Simulation, and Daily Challenge XP count. Arcade coins don’t. Earn XP this week to receive a rank.</p>
      <p>Higher XP comes first. Ties are ordered alphabetically by full name, with a stable internal tie-breaker for identical names. Refresh to see the latest standings.</p>
    </details>`;

  const userId = getAppState().user?.id;
  const content = root.querySelector("[data-leaderboard-content]");
  const refreshButton = root.querySelector("[data-leaderboard-refresh]");
  const errorBox = root.querySelector("[data-leaderboard-error]");
  const status = root.querySelector("[data-leaderboard-status]");
  let disposed = false;
  let pending = false;
  let refreshAgain = false;
  let changedWhileHidden = false;
  let snapshot = null;
  let lastAttempt = -Infinity;
  let lastSignature = signature(getAppState());
  let timer;
  let transition = false;
  let nextBoundaryAttempt = 0;
  let boundaryDelay = 5000;
  const valid = () => !disposed && getAppState().user?.id === userId;

  async function load() {
    if (!valid()) return;
    if (pending) { refreshAgain = true; return; }
    pending = true;
    changedWhileHidden = false;
    lastAttempt = performance.now();
    content.setAttribute("aria-busy", "true");
    refreshButton.setAttribute("aria-disabled", "true");
    refreshButton.textContent = "Refreshing…";
    errorBox.hidden = true;
    status.textContent = snapshot ? "Refreshing weekly standings…" : "Loading weekly standings…";
    try {
      const data = await getWeeklyLeaderboard();
      if (!valid() || !data) return;
      const newWeek = snapshot && snapshot.weekStart !== data.weekStart;
      snapshot = data;
      transition = false;
      boundaryDelay = 5000;
      root.querySelector("[data-leaderboard-period]").textContent = `${date(data.weekStart)} – ${date(data.calendar.weekEnd)} · Monday to Monday`;
      const own = data.currentStudent;
      content.innerHTML = `<section class="leaderboard-personal" aria-labelledby="leaderboard-your-week"><h2 id="leaderboard-your-week">Your week</h2>
        <dl><div><dt>Your rank</dt><dd>${own.rank === null ? "Not ranked yet" : `#${number(own.rank)}`}</dd></div>
        <div><dt>Weekly XP</dt><dd data-leaderboard-own-xp>${number(own.weeklyXp)} <span>XP</span></dd></div></dl>
        ${own.rank === null ? '<p>Complete an XP-earning activity to join this week’s rankings.</p>' : ""}</section>
        <div class="leaderboard-board">${tableMarkup(data)}</div>`;
      status.textContent = `${newWeek ? "A new week has started. Your saved progress is unchanged. " : ""}${own.rank === null ? "Complete an activity this week to join the leaderboard." : `Leaderboard updated. Your rank is ${own.rank} with ${own.weeklyXp} XP.`}`;
      updateCountdown();
    } catch {
      if (!valid()) return;
      if (!snapshot || transition) content.replaceChildren();
      errorBox.innerHTML = `<h2>We couldn’t load the leaderboard</h2><p>${transition ? "A new week is due. Reconnect to load current standings; your saved progress is safe." : snapshot ? "Showing the last loaded standings. They may be out of date." : "Your progress is safe. Please try again."}</p><button type="button" class="button button--secondary" data-leaderboard-retry>Try again</button>`;
      errorBox.hidden = false;
      status.textContent = "The leaderboard couldn’t refresh. Please try again.";
      nextBoundaryAttempt = performance.now() + boundaryDelay;
      boundaryDelay = Math.min(60000, boundaryDelay * 2);
    } finally {
      pending = false;
      if (valid()) {
        content.setAttribute("aria-busy", "false");
        refreshButton.removeAttribute("aria-disabled");
        refreshButton.textContent = "Refresh";
        if (refreshAgain) { refreshAgain = false; schedule(); }
      }
    }
  }

  function schedule() {
    clearTimeout(timer);
    timer = window.setTimeout(() => { void load(); }, 250);
  }
  function updateCountdown() {
    if (!valid()) return;
    const remaining = secondsUntil(snapshot?.calendar, "nextWeeklyReset");
    root.querySelector("[data-weekly-countdown]").textContent = formatWeeklyCountdown(remaining);
    if (remaining !== 0 || document.hidden) return;
    if (!transition) {
      transition = true;
      content.innerHTML = '<p class="leaderboard-empty">Checking this week’s standings…</p>';
      status.textContent = "Checking the new weekly period. Your saved progress is safe.";
    }
    if (!pending && performance.now() >= nextBoundaryAttempt) {
      nextBoundaryAttempt = performance.now() + boundaryDelay;
      void load();
    }
  }
  const unsubscribe = subscribeToAppState((state) => {
    const next = signature(state);
    if (next !== lastSignature) {
      lastSignature = next;
      if (valid()) {
        if (document.hidden) changedWhileHidden = true;
        else schedule();
      }
    }
  });
  // Refresh on return, coalescing focus/visibility events; no leaderboard polling.
  const onReturn = () => { if (!document.hidden && (changedWhileHidden || secondsUntil(snapshot?.calendar, "nextWeeklyReset") === 0 || performance.now() - lastAttempt > 15000)) schedule(); };
  const onClick = (event) => {
    const button = event.target.closest?.("[data-leaderboard-refresh], [data-leaderboard-retry]");
    if (!button || pending) return;
    if (button.hasAttribute("data-leaderboard-retry")) refreshButton.focus();
    clearTimeout(timer);
    void load();
  };
  root.addEventListener("click", onClick);
  window.addEventListener("focus", onReturn);
  document.addEventListener("visibilitychange", onReturn);
  const countdownTimer = window.setInterval(updateCountdown, 1000);
  root.destroy = () => {
    disposed = true;
    clearTimeout(timer);
    window.clearInterval(countdownTimer);
    unsubscribe();
    root.removeEventListener("click", onClick);
    window.removeEventListener("focus", onReturn);
    document.removeEventListener("visibilitychange", onReturn);
  };
  void load();
  return root;
}
