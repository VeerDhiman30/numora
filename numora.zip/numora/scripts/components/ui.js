const iconPaths = {
  coin: "<circle cx=\"12\" cy=\"12\" r=\"8.5\"></circle><path d=\"M9.5 9.5h4.1a1.4 1.4 0 0 1 0 2.8h-3.2a1.4 1.4 0 1 0 0 2.8h4.1\"></path>",
  flame: "<path d=\"M12.2 3.1c.7 3.3-1.1 4.7-2.2 6.1-.7-.9-.9-1.9-.7-3.1-2.5 1.9-4.1 4.5-4.1 7.1A6.8 6.8 0 0 0 12 20a6.8 6.8 0 0 0 6.8-6.8c0-3.4-2.2-6.9-6.6-10.1Z\"></path><path d=\"M11.8 12.2c1.3 1 2 2 2 3.1a2.2 2.2 0 1 1-4.4 0c0-.9.6-2 2.4-3.1Z\"></path>",
  soundOn: "<path d=\"M4 10v4h3l4 3V7l-4 3H4Z\"></path><path d=\"M15 9.5a4 4 0 0 1 0 5\"></path><path d=\"M17.7 7a7.4 7.4 0 0 1 0 10\"></path>",
  soundOff: "<path d=\"M4 10v4h3l4 3V7l-4 3H4Z\"></path><path d=\"m15 10 5 5\"></path><path d=\"m20 10-5 5\"></path>",
  menu: "<path d=\"M4 7h16\"></path><path d=\"M4 12h16\"></path><path d=\"M4 17h16\"></path>",
  close: "<path d=\"m6 6 12 12\"></path><path d=\"m18 6-12 12\"></path>",
  mark: "<path d=\"M5 7.5 12 4l7 3.5v9L12 20l-7-3.5v-9Z\"></path><path d=\"m8.2 12 2.2 2.2 5.4-5.4\"></path>",
  decision: "<path d=\"M12 3.5 19 7v5c0 4.1-2.8 7.1-7 8.5-4.2-1.4-7-4.4-7-8.5V7l7-3.5Z\"></path><path d=\"m8.7 12 2.1 2.1 4.7-4.8\"></path>",
  quant: "<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"></rect><path d=\"M8 8h2\"></path><path d=\"M8 12h2\"></path><path d=\"M8 16h2\"></path><path d=\"M14 8h2\"></path><path d=\"M14 12h2\"></path><path d=\"M14 16h2\"></path>",
  simulation: "<path d=\"M5 6.5A2.5 2.5 0 0 1 7.5 4h9A2.5 2.5 0 0 1 19 6.5v6a2.5 2.5 0 0 1-2.5 2.5H11l-4.2 3v-3H7.5A2.5 2.5 0 0 1 5 12.5v-6Z\"></path><path d=\"M8.5 9.5h7\"></path><path d=\"M8.5 12h4\"></path>",
  arcade: "<path d=\"M7.2 10h9.6c1.2 0 2.1.8 2.4 1.9l.6 2.6a2.4 2.4 0 0 1-4.1 2.2l-1.1-1.1H9.4l-1.1 1.1a2.4 2.4 0 0 1-4.1-2.2l.6-2.6A2.5 2.5 0 0 1 7.2 10Z\"></path><path d=\"M8 12.2v2.6\"></path><path d=\"M6.7 13.5h2.6\"></path><circle cx=\"15.8\" cy=\"12.7\" r=\".7\" fill=\"currentColor\" stroke=\"none\"></circle><circle cx=\"17.5\" cy=\"14.2\" r=\".7\" fill=\"currentColor\" stroke=\"none\"></circle>",
  arrow: "<path d=\"M5 12h13\"></path><path d=\"m13 7 5 5-5 5\"></path>",
  spark: "<path d=\"m12 3 1.4 5.6L19 10l-5.6 1.4L12 17l-1.4-5.6L5 10l5.6-1.4L12 3Z\"></path>"
};

export function icon(name, className = "") {
  const paths = iconPaths[name] ?? "";
  return `<svg class="${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${paths}</svg>`;
}
