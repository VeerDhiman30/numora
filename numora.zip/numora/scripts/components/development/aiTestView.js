import { sendCoachMessage } from "../../services/aiService.js";
import { getAppState } from "../../services/appState.js";

const localHosts = new Set(["localhost", "127.0.0.1", "[::1]"]);
const gradeLabels = {
  entry: "Entry Level",
  middle: "Middle School",
  high: "High School"
};

function isLocalDevelopment() {
  return localHosts.has(window.location.hostname);
}

function setResult(resultElement, result) {
  resultElement.hidden = false;
  resultElement.dataset.state = result.success ? "success" : result.fallbackMessage ? "fallback" : "error";
  resultElement.replaceChildren();

  const heading = document.createElement("strong");
  const message = document.createElement("p");
  heading.textContent = result.success
    ? "Gemini connection response"
    : result.fallbackMessage
      ? "Connection unavailable — local fallback"
      : "Connection test could not run";
  message.textContent = result.success ? result.message : result.fallbackMessage ?? result.message;
  resultElement.append(heading, message);
}

export function createAiConnectionTestView() {
  const state = getAppState();
  const section = document.createElement("section");
  section.className = "ai-test-view section";

  if (!isLocalDevelopment()) {
    section.innerHTML = `
      <div class="page-container page-container--narrow">
        <div class="ai-test-card card">
          <p class="ai-test__eyebrow">Development utility</p>
          <h1>AI connection test is local-only</h1>
          <p>This temporary tool is available only while Numora runs on your computer.</p>
        </div>
      </div>
    `;
    return section;
  }

  const profileGrade = ["entry", "middle", "high"].includes(state.user?.gradeLevel)
    ? state.user.gradeLevel
    : "middle";
  const isAuthenticated = state.authStatus === "authenticated";

  section.innerHTML = `
    <div class="page-container page-container--narrow">
      <div class="ai-test-card card">
        <p class="ai-test__eyebrow">Local development utility</p>
        <h1>Gemini connection test</h1>
        <p class="ai-test__intro">This temporary page sends one controlled coaching question through Numora’s backend. It is not a student chat screen.</p>
        ${isAuthenticated ? `
          <form class="ai-test-form" data-ai-test-form>
            <label for="ai-test-message">Coaching question</label>
            <textarea id="ai-test-message" name="message" rows="4" maxlength="1200" required>Why is 50% the same as 1/2?</textarea>
            <label for="ai-test-grade">Grade context</label>
            <select id="ai-test-grade" name="gradeLevel">
              ${Object.entries(gradeLabels).map(([value, label]) => `<option value="${value}" ${value === profileGrade ? "selected" : ""}>${label}</option>`).join("")}
            </select>
            <p class="ai-test-form__note">The request is authenticated with the current Supabase session; no key is sent to the browser.</p>
            <button class="button button--primary" type="submit">Test Gemini Connection</button>
          </form>
          <div class="ai-test-result" data-ai-test-result role="status" aria-live="polite" hidden></div>
        ` : `
          <div class="ai-test-signin">
            <p>Sign in with a Numora student account to run this protected connection test.</p>
            <a class="button button--primary" href="#/signin" data-route-link data-route="#/signin">Sign In</a>
          </div>
        `}
      </div>
    </div>
  `;

  if (!isAuthenticated) {
    return section;
  }

  const form = section.querySelector("[data-ai-test-form]");
  const resultElement = section.querySelector("[data-ai-test-result]");
  const submitButton = form.querySelector("button[type=submit]");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const message = String(formData.get("message") ?? "");
    const gradeLevel = String(formData.get("gradeLevel") ?? profileGrade);

    submitButton.disabled = true;
    submitButton.setAttribute("aria-busy", "true");
    submitButton.textContent = "Testing connection…";
    resultElement.hidden = false;
    resultElement.dataset.state = "loading";
    resultElement.textContent = "Sending the protected request through Numora’s backend…";

    const result = await sendCoachMessage(message, { gradeLevel, mode: "test" });
    setResult(resultElement, result);
    submitButton.disabled = false;
    submitButton.removeAttribute("aria-busy");
    submitButton.textContent = "Test Gemini Connection";
  });

  return section;
}
