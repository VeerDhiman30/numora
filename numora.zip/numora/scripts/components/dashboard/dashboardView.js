import { getAppState, subscribeToAppState } from "../../services/appState.js";
import { getDashboardSummary, topicLabel } from "../../services/dashboardService.js";
import { getDailyChallenge, submitDailyChallenge, repairStreak } from "../../services/dailyChallengeService.js";
import { secondsToMidnight, formatDayCountdown, rewardRule } from "../../services/economyService.js";
import { formatGradeLevel } from "../../utils/user.js";
import { formatCalendarDate } from "../../utils/calendar.js";

const names = { decision: "Decision Lab", quant: "Quant Lab", simulation: "Simulation Lab", arcade: "Arcade", daily_challenge: "Daily Challenge", streak: "Streak Repair" };
const escape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
const number = (value) => Number(value).toLocaleString();
const link = (route, label) => `<a class="button button--secondary" href="${route}" data-route-link data-route="${route}">${escape(label)}</a>`;
const bar = (value, max, label) => `<div class="dashboard-meter"><progress value="${Math.min(value, max)}" max="${max}" aria-label="${escape(label)}"></progress><span>${escape(label)}</span></div>`;

function summaryMarkup(user, economy) {
  const percent = Math.min(100, economy.weekly_xp / 250 * 100);
  return `<div><p class="dashboard-eyebrow">Your learning, at a glance</p><h1>Welcome back, ${escape(user.firstName || "learner")}</h1>
    <p class="dashboard-muted">${escape(formatGradeLevel(user.gradeLevel))} · Small steps add up.</p>
    <div class="dashboard-xp"><div><strong>${number(economy.today.xp_earned)}</strong><span>XP today</span></div>
    <div><strong>${number(economy.weekly_xp)}</strong><span>XP this week</span></div><div><strong>${number(economy.stats.total_xp)}</strong><span>Lifetime XP</span></div></div></div>
    <div class="dashboard-week"><div class="dashboard-ring" style="--progress:${percent}%" role="img" aria-label="${economy.weekly_xp} XP this week. Optional motivation goal: 250 XP."><span aria-hidden="true"><strong>${number(economy.weekly_xp)}</strong> / 250 XP</span></div><p>Weekly motivation goal<br><small>Optional · Monday through today${economy.calendar ? `<br>Week of ${formatCalendarDate(economy.calendar.weekStart)}` : ""}</small></p></div>`;
}

function streakMarkup(economy) {
  const xp = economy.today.xp_earned;
  const cost = Math.abs(economy.rules.streak_repair.coins);
  return `<p class="dashboard-eyebrow">Keep your rhythm</p><h2><span aria-hidden="true">🔥</span> ${number(economy.stats.current_streak)} day streak</h2>
    <p>${economy.qualified_today ? "Today's streak secured ✓" : `${Math.max(0, 50 - xp)} XP to qualify today`}</p>
    ${bar(xp, 50, `${xp} / 50 XP today`)}<p class="dashboard-muted">XP above 50 still builds your weekly total. Arcade coins don't count toward this goal.</p>
    ${economy.repair_date ? `<div class="dashboard-repair"><p>You missed yesterday. Repair it to reconnect your streak.</p><button class="button button--secondary" type="button" data-dashboard="repair">Repair streak · ${cost} coins</button>${economy.stats.coin_balance < cost ? `<p class="dashboard-muted">You need ${cost - economy.stats.coin_balance} more coins.</p>` : ""}</div>` : ""}
    <details><summary>How streaks work</summary><p>Earn 50 XP in your local day. Daily Challenges count. One missed day can be repaired the following day if the day before it was credited; two or more missed days start a new streak.</p></details>`;
}

function walletMarkup(economy, rewards, user) {
  const rules = economy.rules;
  return `<p class="dashboard-eyebrow">Your Wallet</p><h2><span aria-hidden="true">🪙</span> ${number(economy.stats.coin_balance)} coins</h2>
    <p>Earn coins in Arcade and Daily Challenges. Spend them on hints or a streak repair.</p>
    ${economy.stats.coin_balance === 0 ? '<p class="dashboard-muted">Play Arcade to start earning coins.</p>' : ""}${link("#/arcade", "Play Arcade")}
    <details><summary>How coins work</summary><ul><li>Arcade correct action: +${rules.arcade_correct.coins} coin</li><li>Daily Challenge: +${rules.daily_challenge.coins} coins</li>
    <li>Decision hint: ${Math.abs(rules.decision_hint.coins)} coins</li><li>Quant hint: ${Math.abs(rules.quant_hint.coins)} coins</li><li>Streak repair: ${Math.abs(rules.streak_repair.coins)} coins</li></ul></details>
    <details><summary>Recent rewards & spending</summary>${activityMarkup(rewards, user)}</details>`;
}

function activityMarkup(events, user) {
  if (!events.length) return '<p class="dashboard-muted">Your saved activities will appear here.</p>';
  return `<ol class="dashboard-activity">${events.map((event) => {
    const parts = [];
    if (event.xpDelta) parts.push(`+${event.xpDelta} XP`);
    if (event.coinDelta) parts.push(`${event.coinDelta > 0 ? "+" : "−"}${Math.abs(event.coinDelta)} coins`);
    let time;
    try { time = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZone: user.timezone }).format(new Date(event.occurredAt)); }
    catch { time = event.localDate; }
    return `<li><div><strong>${names[event.module] ?? "Learning"}${event.activityType === "hint" ? " · Hint" : ""}</strong><span>${escape(topicLabel(event.module, event.topic, user.gradeLevel))}</span><time datetime="${escape(event.occurredAt)}">${escape(time)}</time></div>
      <span class="dashboard-delta">${parts.join("<br>") || (event.activityType === "story_completed" ? "Completed" : "Practiced")}</span></li>`;
  }).join("")}</ol>`;
}

function moduleMarkup(card) {
  const simulation = card.module === "simulation";
  const finished = card.stories.filter((story) => story.status === "completed");
  const percent = card.attempts ? Math.round(card.correct / card.attempts * 100) : 0;
  const summary = simulation ? `${card.stories.length} stories started · ${finished.length} completed`
    : `${card.completed} ${card.module === "decision" ? "decisions" : "questions"} completed · ${card.correct} correct`;
  const progress = simulation ? bar(finished.length, Math.max(1, card.stories.length), `${finished.length} of ${card.stories.length} started stories completed`)
    : card.attempts ? bar(card.correct, card.attempts, `${percent}% accuracy across ${card.attempts} saved answers`) : '<p class="dashboard-muted">Complete your first activity to start building your progress.</p>';
  return `<article class="dashboard-card dashboard-module"><h3>${names[card.module]}</h3><p>${summary}</p>${progress}
    <button class="dashboard-expand" type="button" data-dashboard="expand" data-module="${card.module}" aria-expanded="false" aria-controls="topics-${card.module}">View topics <span aria-hidden="true">＋</span></button>
    <div id="topics-${card.module}" hidden><p class="dashboard-muted">Practice snapshots, not grades. Early results need more attempts.</p>
    ${simulation ? `<ul class="dashboard-topics">${card.stories.map((story) => `<li><div><strong>${escape(story.title)}</strong><span>${escape(formatGradeLevel(story.gradeLevel))}</span><small>${story.status === "completed" ? `Concepts completed: ${escape(story.concepts.join(", "))}` : "Saved story in progress"}</small></div><span class="dashboard-badge">${story.status === "completed" ? "Completed ✓" : "In progress"}</span></li>`).join("") || "<li>No stories started yet.</li>"}</ul>`
    : `<ul class="dashboard-topics">${card.details.map((row) => `<li><div><strong>${escape(row.label)}</strong><span>${escape(formatGradeLevel(row.gradeLevel))} · ${row.attemptCount ? `${row.correctCount} correct / ${row.attemptCount} answers` : "No activity yet"}</span></div><span class="dashboard-badge">${row.mastery}</span></li>`).join("")}</ul>`}
    ${link(`#/${card.module}`, `Open ${names[card.module]}`)}</div></article>`;
}

export function createDashboardView() {
  const root = document.createElement("section");
  root.className = "dashboard page-container";
  const userId = getAppState().user?.id;
  let summary;
  let challenge;
  let grade = getAppState().user?.gradeLevel ?? "middle";
  let selected = null;
  let challengeMessage = "";
  let challengeBusy = false;
  let submitting = false;
  let loadSequence = 0;
  let questionSequence = 0;
  let disposed = false;
  let retryAfter = 0;
  let refreshTimer;
  let activeDate;
  let lastSignature;
  const valid = () => !disposed && getAppState().user?.id === userId;
  const status = (message) => { const target = root.querySelector("[data-dashboard-status]"); if (target) target.textContent = message; };
  const compactLayout = window.matchMedia("(max-width: 700px)");

  function arrangeColumns() {
    const grid = root.querySelector(".dashboard-grid");
    if (!grid) return;
    const focus = document.activeElement;
    const challengeCard = root.querySelector("[data-challenge]");
    const streakCard = root.querySelector("[data-streak]");
    const walletCard = root.querySelector("[data-wallet]");
    const progress = root.querySelector(".dashboard-progress");
    const next = root.querySelector("[data-next]");
    const recent = root.querySelector(".dashboard-recent");
    if (compactLayout.matches) grid.replaceChildren(challengeCard, streakCard, walletCard, progress, next, recent);
    else {
      const primary = document.createElement("div");
      const secondary = document.createElement("div");
      primary.className = secondary.className = "dashboard-column";
      primary.append(challengeCard, progress);
      secondary.append(streakCard, walletCard, next, recent);
      grid.replaceChildren(primary, secondary);
    }
    if (focus && root.contains(focus)) focus.focus({ preventScroll: true });
  }
  compactLayout.addEventListener("change", arrangeColumns);

  function renderChallenge() {
    const target = root.querySelector("[data-challenge]");
    if (!target) return;
    const reward = rewardRule("daily_challenge");
    target.innerHTML = `<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">One good problem, every day</p><h2>Daily Challenge</h2></div><span class="dashboard-badge">+${reward?.xp ?? "—"} XP · +${reward?.coins ?? "—"} coins</span></div>
      <label class="dashboard-difficulty">Difficulty <select data-challenge-grade ${submitting ? "disabled" : ""}>${["entry", "middle", "high"].map((level) => `<option value="${level}" ${grade === level ? "selected" : ""}>${formatGradeLevel(level)}</option>`).join("")}</select></label>
      ${challengeBusy ? '<p role="status">Loading your challenge…</p>' : !challenge ? '<p>We couldn’t load this challenge.</p><button type="button" class="button button--secondary" data-dashboard="challenge-retry">Try again</button>'
      : challenge.completed ? `<div class="dashboard-challenge-complete"><h3>Daily Challenge complete ✓</h3><p>Your daily XP and coins are saved. You can earn the next reward tomorrow.</p></div>`
        : challenge.locked ? '<p>Your daily reward is already claimed in your previous local day. A new reward becomes available after that day has ended.</p>'
          : `<p class="dashboard-eyebrow">${escape(challenge.topic)}</p><form data-challenge-form><fieldset ${submitting ? "disabled" : ""}><legend>${escape(challenge.question)}</legend><div class="dashboard-answers">${challenge.options.map((option, index) => `<label><input type="radio" name="daily-answer" value="${index}" ${selected === index ? "checked" : ""} required><span>${escape(option)}</span></label>`).join("")}</div></fieldset><div class="dashboard-challenge-actions"><button type="submit" class="button button--primary" ${submitting ? "disabled" : ""}>${submitting ? "Checking…" : "Check answer"}</button><span class="dashboard-muted">${challenge.attempt_count} attempt${challenge.attempt_count === 1 ? "" : "s"} today</span></div></form>`}
      <p role="status" class="dashboard-feedback">${escape(challengeMessage)}</p><p class="dashboard-muted" aria-live="off">New challenge in <span data-countdown>—</span></p>
      <details><summary>Challenge rules</summary><p>Choose any difficulty without changing your profile. One correct challenge earns +${reward?.xp ?? "—"} XP and +${reward?.coins ?? "—"} coins per local day, across all levels. Incorrect attempts cost nothing. Resets at local midnight.</p></details>`;
    tick();
  }

  async function loadChallenge() {
    const sequence = ++questionSequence;
    challengeBusy = true;
    selected = null;
    challengeMessage = "";
    renderChallenge();
    try {
      const result = await getDailyChallenge(grade);
      if (!valid() || sequence !== questionSequence) return;
      challenge = result;
      retryAfter = 0;
    } catch {
      if (!valid() || sequence !== questionSequence) return;
      challenge = null;
      retryAfter = performance.now() + 30000;
    } finally {
      if (valid() && sequence === questionSequence) { challengeBusy = false; renderChallenge(); }
    }
  }

  function renderEconomy(economy) {
    if (!summary || !economy) return;
    // Update individual cards, preserving the question, expanded topics, and focus.
    const focused = document.activeElement;
    const repairFocused = focused?.matches?.('[data-dashboard="repair"]');
    root.querySelector("[data-summary]").innerHTML = summaryMarkup(summary.user, economy);
    const streak = root.querySelector("[data-streak]");
    const wallet = root.querySelector("[data-wallet]");
    const streakOpen = streak.querySelector("details")?.open;
    const walletOpen = [...wallet.querySelectorAll("details")].map((detail) => detail.open);
    streak.innerHTML = streakMarkup(economy);
    wallet.innerHTML = walletMarkup(economy, summary.rewards, summary.user);
    if (streakOpen) streak.querySelector("details").open = true;
    wallet.querySelectorAll("details").forEach((detail, index) => { detail.open = Boolean(walletOpen[index]); });
    if (repairFocused) streak.querySelector('[data-dashboard="repair"]')?.focus();
  }

  async function load({ quiet = false } = {}) {
    window.clearTimeout(refreshTimer);
    const sequence = ++loadSequence;
    if (!quiet || !summary) root.innerHTML = '<h1>Your Dashboard</h1><div class="dashboard-skeleton" role="status">Loading your learning progress…</div>';
    try {
      const data = await getDashboardSummary();
      if (!valid() || sequence !== loadSequence) return;
      const dateChanged = Boolean(activeDate && activeDate !== data.economy.today.local_date);
      summary = data;
      activeDate = data.economy.today.local_date;
      const currentEconomy = getAppState().economy ?? data.economy;
      lastSignature = [currentEconomy.stats.total_xp, currentEconomy.stats.coin_balance,
        currentEconomy.stats.current_streak, currentEconomy.today.local_date].join(":");
      window.clearTimeout(refreshTimer);
      if (!root.querySelector("[data-summary]")) {
        root.innerHTML = `<header class="dashboard-summary dashboard-card" data-summary></header><div class="dashboard-grid">
          <section class="dashboard-card dashboard-challenge" data-challenge></section><section class="dashboard-card dashboard-streak" data-streak></section>
          <section class="dashboard-card dashboard-wallet" data-wallet></section><section class="dashboard-progress" aria-labelledby="module-progress-title"><h2 id="module-progress-title">Your academic progress</h2><div data-modules></div></section>
          <section class="dashboard-card dashboard-next" data-next></section><section class="dashboard-card dashboard-recent"><h2>Recent activity</h2><div data-recent></div></section></div>
          <p role="status" data-dashboard-status></p><button class="dashboard-refresh button button--secondary" type="button" data-dashboard="refresh">Refresh progress</button>`;
        arrangeColumns();
      }
      const expanded = [...root.querySelectorAll('[data-dashboard="expand"][aria-expanded="true"]')].map((button) => button.dataset.module);
      root.querySelector("[data-modules]").innerHTML = data.cards.map(moduleMarkup).join("");
      expanded.forEach((module) => {
        const button = root.querySelector(`[data-module="${module}"]`);
        button.setAttribute("aria-expanded", "true");
        root.querySelector(`#topics-${module}`).hidden = false;
      });
      root.querySelector("[data-next]").innerHTML = `<p class="dashboard-eyebrow">Recommended next</p><h2>${escape(data.recommendation.title)}</h2><p>${escape(data.recommendation.description)}</p>${link(data.recommendation.route, "Let's practice")}<p class="dashboard-muted">Based on your saved practice so far.</p>`;
      root.querySelector("[data-recent]").innerHTML = activityMarkup(data.recent, data.user);
      renderEconomy(getAppState().economy ?? data.economy);
      if (dateChanged || (!challenge && !challengeBusy && !retryAfter) || (challenge && challenge.local_date !== activeDate)) await loadChallenge();
      else if (challenge && quiet && !submitting && !challengeBusy) {
        // Reconcile completion made in another tab without losing an in-progress answer.
        const fresh = await getDailyChallenge(grade);
        if (valid() && fresh.completed && !challenge.completed) { challenge = fresh; renderChallenge(); }
      }
    } catch {
      if (!valid() || sequence !== loadSequence) return;
      if (quiet && summary) status("We couldn't refresh your progress. Your last saved view is still here; try again.");
      else root.innerHTML = '<h1>Your Dashboard</h1><div class="dashboard-card" role="alert"><h2>We couldn’t load your progress</h2><p>Please check your connection and try again.</p><button class="button button--primary" type="button" data-dashboard="refresh">Try again</button></div>';
    }
  }

  function tick() {
    const remaining = secondsToMidnight(getAppState().economy);
    const target = root.querySelector("[data-countdown]");
    if (target) target.textContent = remaining === 0 ? "Updating today’s challenge…" : formatDayCountdown(remaining);
    // Shared economy synchronization handles midnight reads and offline backoff.
    // Do not let an expired question submit while those reads are pending.
    const submit = root.querySelector('[data-challenge-form] button[type="submit"]');
    if (submit) {
      submit.disabled = submitting || remaining === 0 || challenge?.local_date !== getAppState().economy?.today?.local_date;
    }
  }

  root.addEventListener("change", (event) => {
    if (event.target.matches("[data-challenge-grade]")) { grade = event.target.value; void loadChallenge(); }
    if (event.target.matches('[name="daily-answer"]')) selected = Number(event.target.value);
  });
  root.addEventListener("submit", async (event) => {
    if (!event.target.matches("[data-challenge-form]")) return;
    event.preventDefault();
    if (!challenge || selected === null || submitting) return;
    if (secondsToMidnight(getAppState().economy) === 0 || challenge.local_date !== getAppState().economy?.today?.local_date) return;
    const current = challenge;
    const answer = current.options[selected];
    submitting = true;
    renderChallenge();
    try {
      const result = await submitDailyChallenge(current, answer);
      if (!valid()) return;
      current.attempt_count += 1;
      current.completed = Boolean(result.correct);
      challengeMessage = result.message;
      if (result.correct) void load({ quiet: true });
    } catch (error) { if (valid()) challengeMessage = error.message; }
    finally {
      submitting = false;
      if (valid()) {
        renderChallenge();
        root.querySelector('[data-challenge] .dashboard-feedback')?.setAttribute("tabindex", "-1");
        root.querySelector('[data-challenge] .dashboard-feedback')?.focus();
      }
    }
  });
  root.addEventListener("click", (event) => {
    const button = event.target.closest?.("[data-dashboard]");
    if (!button) return;
    if (button.dataset.dashboard === "refresh") void load({ quiet: Boolean(summary) });
    if (button.dataset.dashboard === "challenge-retry") void loadChallenge();
    if (button.dataset.dashboard === "expand") {
      const expanded = button.getAttribute("aria-expanded") !== "true";
      button.setAttribute("aria-expanded", String(expanded));
      root.querySelector(`#${button.getAttribute("aria-controls")}`).hidden = !expanded;
    }
    if (button.dataset.dashboard === "repair") openRepairDialog();
  });

  function openRepairDialog() {
    if (root.querySelector("dialog")) return;
    const snapshot = getAppState().economy;
    if (!snapshot?.repair_date) return;
    const dialog = document.createElement("dialog");
    dialog.className = "dashboard-dialog";
    dialog.setAttribute("aria-labelledby", "repair-title");
    const cost = Math.abs(snapshot.rules.streak_repair.coins);
    dialog.innerHTML = `<h2 id="repair-title">Repair your missed streak?</h2><p>This will spend ${cost} coins to repair yesterday. It will not add XP.</p><p>Balance: ${snapshot.stats.coin_balance} coins</p><p role="status" data-repair-status></p><div><button type="button" class="button button--secondary" data-cancel autofocus>Cancel</button><button type="button" class="button button--primary" data-confirm ${snapshot.stats.coin_balance < cost ? "disabled" : ""}>Repair for ${cost} coins</button></div>`;
    root.append(dialog);
    dialog.addEventListener("close", () => { dialog.remove(); root.querySelector('[data-dashboard="repair"]')?.focus(); });
    dialog.querySelector("[data-cancel]").addEventListener("click", () => dialog.close());
    dialog.querySelector("[data-confirm]").addEventListener("click", async () => {
      const confirm = dialog.querySelector("[data-confirm]");
      confirm.disabled = true;
      confirm.textContent = "Repairing…";
      try {
        const result = await repairStreak(snapshot.repair_date);
        if (!valid()) return;
        dialog.close();
        status(result.event_recorded ? "Streak repaired. Your saved balance has been updated." : "That day was already repaired. No extra coins were spent.");
        root.querySelector("[data-dashboard-status]").tabIndex = -1;
        root.querySelector("[data-dashboard-status]").focus();
        void load({ quiet: true });
      } catch (error) {
        if (!valid()) return;
        dialog.querySelector("[data-repair-status]").textContent = error.message;
        confirm.disabled = false;
        confirm.textContent = `Repair for ${cost} coins`;
      }
    });
    dialog.showModal();
  }

  const unsubscribe = subscribeToAppState((state) => {
    if (!valid() || !summary || !state.economy) return;
    renderEconomy(state.economy);
    const signature = [state.totalXp, state.coins, state.streak, state.economy.today.local_date].join(":");
    if (signature !== lastSignature) {
      lastSignature = signature;
      window.clearTimeout(refreshTimer);
      refreshTimer = window.setTimeout(() => { if (valid()) void load({ quiet: true }); }, 250);
    }
  });
  const interval = window.setInterval(tick, 1000);
  root.destroy = () => {
    disposed = true;
    unsubscribe();
    window.clearInterval(interval);
    window.clearTimeout(refreshTimer);
    compactLayout.removeEventListener("change", arrangeColumns);
    root.querySelector("dialog")?.close();
  };
  void load();
  return root;
}
