import { subscribeToAppState } from "../services/appState.js";

export function initializeRewardNotifications() {
  const root = document.createElement("div");
  root.className = "reward-notifications";
  root.setAttribute("role", "status");
  root.setAttribute("aria-live", "polite");
  root.setAttribute("aria-atomic", "true");
  document.body.append(root);
  let timer;
  let celebrationUntil = 0;
  function show(message, celebration = false) {
    // A simultaneous coin/XP toast must not immediately replace the streak notice.
    if (!celebration && performance.now() < celebrationUntil) {
      root.querySelector("p")?.append(` · ${message}`);
      return;
    }
    window.clearTimeout(timer);
    if (celebration) celebrationUntil = performance.now() + 5000;
    const card = document.createElement("div");
    card.className = `reward-toast${celebration ? " reward-toast--celebration" : ""}`;
    const text = document.createElement("p");
    text.textContent = message;
    card.append(text);
    if (celebration) {
      const confetti = document.createElement("span");
      confetti.className = "reward-confetti";
      confetti.setAttribute("aria-hidden", "true");
      confetti.textContent = "✦  ·  ✧  ·  ✦";
      card.append(confetti);
    }
    root.replaceChildren(card);
    timer = window.setTimeout(() => root.replaceChildren(), celebration ? 6000 : 3000);
  }
  window.addEventListener("numora:reward", ({ detail }) => {
    const parts = [];
    if (detail.xp) parts.push(`+${detail.xp} XP`);
    if (detail.coins) parts.push(`${detail.coins > 0 ? "+" : "−"}${Math.abs(detail.coins)} coin${Math.abs(detail.coins) === 1 ? "" : "s"}`);
    show(parts.join(" · "));
  });
  window.addEventListener("numora:streak", ({ detail }) => show(`${detail.count} day streak! ${detail.repaired ? "Your missed day is repaired." : "You reached 50 XP today."}`, true));
  subscribeToAppState((state) => {
    if (!state.user) { root.replaceChildren(); window.clearTimeout(timer); celebrationUntil = 0; }
  });
}
