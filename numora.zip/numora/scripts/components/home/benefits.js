import { icon } from "../ui.js";

const benefits = [
  ["Real-World Math", "Connect mathematics to decisions, situations, and questions that matter beyond a worksheet."],
  ["Learn by Doing", "Use interactive prompts, visual activities, and games to stay actively involved."],
  ["Guided Thinking", "Future feedback will help you examine your approach—not just look for a right answer."],
  ["Visible Progress", "XP, coins, challenges, and skill growth will make your learning journey easier to see."]
];

export function createBenefits() {
  const section = document.createElement("section");
  section.className = "home-section home-benefits section";
  section.setAttribute("aria-labelledby", "benefits-title");
  section.innerHTML = `
    <div class="page-container home-benefits__layout">
      <div class="home-section-heading">
        <p class="home-section-heading__eyebrow">Why Numora works</p>
        <h2 id="benefits-title">Practice that feels more like discovery.</h2>
      </div>
      <div class="home-benefit-grid">
        ${benefits.map(([title, description], index) => `
          <article class="home-benefit">
            <span class="home-benefit__number" aria-hidden="true">0${index + 1}</span>
            <div>
              <span class="home-benefit__spark" aria-hidden="true">${icon("spark")}</span>
              <h3>${title}</h3>
              <p>${description}</p>
            </div>
          </article>
        `).join("")}
      </div>
    </div>
  `;

  return section;
}
