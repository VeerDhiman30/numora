const pathways = [
  {
    key: "entry",
    title: "Entry Level",
    grades: "Grades 3–5",
    description: "Build the habits that make new ideas feel possible.",
    topics: ["Number sense", "Fractions", "Money", "Geometry"]
  },
  {
    key: "middle",
    title: "Middle School",
    grades: "Grades 6–8",
    description: "Connect growing skills to the choices and questions around you.",
    topics: ["Ratios", "Percentages", "Algebra", "Probability"]
  },
  {
    key: "high",
    title: "High School",
    grades: "Grades 9–12",
    description: "Use mathematics as a tool for modelling, proving, and planning.",
    topics: ["Functions", "Trigonometry", "Statistics", "Financial math"]
  }
];

export function createGradePathways(selectedGradeLevel) {
  const section = document.createElement("section");
  section.className = "home-section home-pathways section";
  section.setAttribute("aria-labelledby", "grade-pathways-title");
  section.innerHTML = `
    <div class="page-container">
      <div class="home-section-heading home-section-heading--split">
        <div>
          <p class="home-section-heading__eyebrow">Built around your next step</p>
          <h2 id="grade-pathways-title">A path that meets you where you are.</h2>
        </div>
        <p>Numora is designed for the concepts you are ready to connect, practice, and put to use.</p>
      </div>
      <div class="home-pathway-grid">
        ${pathways.map((pathway) => `
          <article class="home-pathway-card ${pathway.key === selectedGradeLevel ? "is-selected" : ""}">
            <div class="home-pathway-card__heading">
              <div>
                <p class="home-pathway-card__grades">${pathway.grades}</p>
                <h3>${pathway.title}</h3>
              </div>
              ${pathway.key === selectedGradeLevel ? "<span class=\"badge home-pathway-card__badge\">Current demo path</span>" : ""}
            </div>
            <p>${pathway.description}</p>
            <ul class="home-topic-list" aria-label="Example topics">
              ${pathway.topics.map((topic) => `<li>${topic}</li>`).join("")}
            </ul>
          </article>
        `).join("")}
      </div>
    </div>
  `;

  return section;
}
