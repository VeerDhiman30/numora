import { icon } from "../ui.js";

const experiences = [
  {
    name: "Decision Lab",
    route: "#/decision",
    iconName: "decision",
    description: "Use evidence, probability, and trade-offs to make a well-reasoned call.",
    skill: "Reasoning with risk",
    action: "Make a Decision"
  },
  {
    name: "Quant Lab",
    route: "#/quant",
    iconName: "quant",
    description: "Build fluency with structured practice that changes how you approach a problem.",
    skill: "Flexible problem solving",
    action: "Practice Math"
  },
  {
    name: "Simulation Lab",
    route: "#/simulation",
    iconName: "simulation",
    description: "Step into story-based situations where each question helps you reason ahead.",
    skill: "Mathematical storytelling",
    action: "Start a Story"
  },
  {
    name: "Arcade",
    route: "#/arcade",
    iconName: "arcade",
    description: "Take on visual challenges designed to sharpen patterns, speed, and strategy.",
    skill: "Pattern recognition",
    action: "Play Arcade"
  }
];

export function createLearningExperiences() {
  const section = document.createElement("section");
  section.className = "home-section home-experiences section";
  section.id = "learning-experiences";
  section.setAttribute("aria-labelledby", "learning-experiences-title");
  section.innerHTML = `
    <div class="page-container">
      <div class="home-section-heading">
        <p class="home-section-heading__eyebrow">Four ways to learn</p>
        <h2 id="learning-experiences-title">Find the kind of math that pulls you in.</h2>
        <p>Each experience builds a different habit of mind—then brings it back to the same goal: thinking with confidence.</p>
      </div>
      <div class="home-experience-grid">
        ${experiences.map((experience) => `
          <article class="home-experience-card card home-experience-card--${experience.iconName}">
            <div class="home-experience-card__icon" aria-hidden="true">${icon(experience.iconName)}</div>
            <div class="home-experience-card__body">
              <h3>${experience.name}</h3>
              <p>${experience.description}</p>
            </div>
            <p class="home-experience-card__skill"><span>Skill focus</span>${experience.skill}</p>
            <a class="home-experience-card__action" href="${experience.route}" data-route-link data-route="${experience.route}">${experience.action} ${icon("arrow")}</a>
          </article>
        `).join("")}
      </div>
    </div>
  `;

  return section;
}
