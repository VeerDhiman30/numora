import { getAppState } from "../../services/appState.js";
import { createBenefits } from "./benefits.js";
import { createGradePathways } from "./gradePathways.js";
import { createHero } from "./hero.js";
import { createLearningExperiences } from "./learningExperiences.js";
import { icon } from "../ui.js";

function createFinalCallToAction() {
  const section = document.createElement("section");
  section.className = "home-final-cta section";
  section.setAttribute("aria-labelledby", "final-cta-title");
  section.innerHTML = `
    <div class="page-container">
      <div class="home-final-cta__panel">
        <div>
          <p class="home-section-heading__eyebrow">Ready when you are</p>
          <h2 id="final-cta-title">Start with one good question.</h2>
          <p>Every strong mathematical habit begins by noticing what a problem is really asking.</p>
        </div>
        <a class="button button--primary" href="#/decision" data-route-link data-route="#/decision">Start Today’s Practice ${icon("arrow")}</a>
      </div>
    </div>
  `;

  return section;
}

export function createHomeView() {
  const state = getAppState();
  const home = document.createElement("div");
  home.className = "home";
  home.append(
    createHero(state),
    createLearningExperiences(),
    createGradePathways(state.user?.gradeLevel),
    createBenefits(),
    createFinalCallToAction()
  );

  return home;
}
