import { icon } from "../ui.js";
import { formatGradeLevel, getFullName } from "../../utils/user.js";

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

export function createHero(state) {
  const section = document.createElement("section");
  const user = state.user ?? {};
  const studentName = getFullName(user.firstName, user.lastName);
  const gradeLevel = formatGradeLevel(user.gradeLevel);
  const isAuthenticated = state.authStatus === "authenticated";
  const greeting = isAuthenticated ? `Welcome back, ${studentName}` : "Welcome to Numora";
  const hasDailyActivity = Number.isInteger(state.dailyXp);
  const momentumValue = hasDailyActivity ? `${state.dailyXp} XP` : "Ready";
  const momentumLabel = hasDailyActivity
    ? "A focused start, ready when you are."
    : "Your next practice is waiting.";
  const completedSteps = Math.min(Math.max(state.dailyActivities ?? 0, 0), 5);
  const momentumSteps = Array.from({ length: 5 }, (_step, index) => (
    `<span${index < completedSteps ? " class=\"is-complete\"" : ""}></span>`
  )).join("");

  section.className = "home-hero";
  section.setAttribute("aria-labelledby", "home-title");
  section.innerHTML = `
    <div class="page-container home-hero__layout">
      <div class="home-hero__content">
        <p class="home-hero__eyebrow">${escapeHtml(greeting)}</p>
        <h1 id="home-title">Math that helps you see the next move.</h1>
        <p class="home-hero__description">Numora gives every problem a purpose—so you can reason through choices, build confidence with practice, and use mathematics beyond the page.</p>
        <div class="home-hero__actions" aria-label="Start learning">
          <a class="button button--primary" href="#/decision" data-route-link data-route="#/decision">Start Today’s Practice ${icon("arrow")}</a>
          <a class="button button--secondary" href="#/dashboard" data-route-link data-route="#/dashboard">View My Progress</a>
        </div>
        <p class="home-hero__pathway"><span class="home-hero__pathway-mark">${icon("spark")}</span> ${escapeHtml(gradeLevel)} is one of three pathways built for how you learn now.</p>
      </div>

      <div class="home-hero__visual">
        <div class="home-hero__math" aria-hidden="true">
          <span class="home-hero__number home-hero__number--one">3.14</span>
          <span class="home-hero__number home-hero__number--two">x²</span>
          <span class="home-hero__number home-hero__number--three">24%</span>
          <span class="home-hero__shape home-hero__shape--circle"></span>
          <span class="home-hero__shape home-hero__shape--square"></span>
          <svg class="home-hero__graph" viewBox="0 0 480 360" fill="none">
            <path d="M55 302H435M55 302V50" stroke="currentColor" stroke-width="1.5" stroke-dasharray="4 8"></path>
            <path d="M75 263C130 235 141 237 183 202C222 170 230 145 271 147C315 149 335 100 405 77" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>
            <circle cx="183" cy="202" r="6" fill="currentColor"></circle>
            <circle cx="271" cy="147" r="6" fill="currentColor"></circle>
            <circle cx="405" cy="77" r="6" fill="currentColor"></circle>
          </svg>
        </div>
        <aside class="home-momentum" aria-label="Today's learning momentum">
          <div class="home-momentum__topline">
            <span>Today’s momentum</span>
            <span class="home-momentum__spark" aria-hidden="true">${icon("spark")}</span>
          </div>
          <strong>${momentumValue}</strong>
          <span class="home-momentum__label">${momentumLabel}</span>
          <div class="home-momentum__steps" aria-hidden="true">
            ${momentumSteps}
          </div>
          <span class="sr-only">Today's learning totals update when activity is recorded.</span>
        </aside>
      </div>
    </div>
  `;

  return section;
}
