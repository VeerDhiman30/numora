export const navigationItems = [
  { label: "Home", route: "/" },
  { label: "Decision Lab", route: "#/decision" },
  { label: "Quant Lab", route: "#/quant" },
  { label: "Simulation Lab", route: "#/simulation" },
  { label: "Arcade", route: "#/arcade" },
  { label: "Dashboard", route: "#/dashboard" },
  { label: "Leaderboard", route: "#/leaderboard" }
];

export function getCurrentRoute() {
  const authMode = new URLSearchParams(window.location.search).get("auth");

  if (authMode === "reset") {
    return "#/reset-password";
  }

  if (authMode === "confirmed") {
    return "#/signin";
  }

  return window.location.hash || "/";
}

export function navigateToRoute(route, onRouteChange) {
  const url = new URL(window.location.href);
  const hasAuthMode = url.searchParams.has("auth");

  if (route === "/") {
    if (window.location.hash || hasAuthMode) {
      url.hash = "";
      url.searchParams.delete("auth");
      window.history.pushState({}, "", `${url.pathname}${url.search}`);
    }
    onRouteChange();
    return;
  }

  if (window.location.hash === route && !hasAuthMode) {
    onRouteChange();
    return;
  }

  if (hasAuthMode) {
    url.searchParams.delete("auth");
    url.hash = route;
    window.history.pushState({}, "", `${url.pathname}${url.search}${url.hash}`);
    onRouteChange();
    return;
  }

  window.location.hash = route;
}

export function createNavigation(currentRoute, className = "primary-nav", label = "Main navigation") {
  const navigation = document.createElement("nav");
  navigation.className = className;
  navigation.setAttribute("aria-label", label);

  navigationItems.forEach((item) => {
    const link = document.createElement("a");
    link.className = "nav-link";
    link.href = item.route;
    link.dataset.routeLink = "";
    link.dataset.route = item.route;
    link.textContent = item.label;
    navigation.append(link);
  });

  updateNavigationState(navigation, currentRoute);
  return navigation;
}

export function updateNavigationState(container, currentRoute) {
  container.querySelectorAll(".nav-link[data-route-link]").forEach((link) => {
    const isActive = link.dataset.route === currentRoute;
    if (isActive) {
      link.setAttribute("aria-current", "page");
    } else {
      link.removeAttribute("aria-current");
    }
  });
}
