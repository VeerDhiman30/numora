import { createAccountMenuMarkup, attachAccountMenu } from "./accountMenu.js";
import { createNavigation, navigateToRoute, updateNavigationState } from "./navigation.js";
import { icon } from "./ui.js";
import { getAppState, setSoundEnabled } from "../services/appState.js";
import { getFullName, formatGradeLevel, getInitials } from "../utils/user.js";

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

function renderSoundButton(soundEnabled, className = "") {
  const stateLabel = soundEnabled ? "Sound on" : "Sound off";
  return `
    <button
      class="icon-button ${className}"
      type="button"
      data-sound-toggle
      aria-pressed="${soundEnabled}"
      aria-label="${stateLabel}. Toggle sound preference"
      data-tooltip="${stateLabel}"
    >
      ${icon(soundEnabled ? "soundOn" : "soundOff")}
    </button>
  `;
}

function renderRewards(state) {
  const hasXpBalance = Number.isInteger(state.totalXp);
  const hasCoinBalance = Number.isInteger(state.coins);
  const hasStreak = Number.isInteger(state.streak);
  const coinText = hasCoinBalance ? state.coins : "—";
  const xpText = hasXpBalance ? state.totalXp.toLocaleString("en-US") : "—";
  const streakText = hasStreak ? state.streak : "—";
  const coinLabel = hasCoinBalance ? `${state.coins} coins` : "Coins are loading";
  const xpLabel = hasXpBalance ? `${xpText} total XP` : "XP is loading";
  const streakLabel = hasStreak ? `${state.streak} day streak` : "Streak is loading";

  return `
    <div class="header-rewards" aria-label="Student rewards">
      <span class="reward-counter reward-counter--xp" aria-label="${xpLabel}" title="Total XP">
        <span aria-hidden="true">${xpText} <span class="reward-counter__unit">XP</span></span>
      </span>
      <span class="reward-counter reward-counter--coins" aria-label="${coinLabel}">
        <span class="reward-counter__icon">${icon("coin")}</span>
        <span aria-hidden="true">${coinText}</span>
      </span>
      <span class="reward-counter reward-counter--streak" aria-label="${streakLabel}">
        <span class="reward-counter__icon">${icon("flame")}</span>
        <span aria-hidden="true">${streakText}</span>
      </span>
    </div>
  `;
}

function renderDesktopAuthentication(state, user, fullName, initials) {
  if (state.authStatus === "checking") {
    return `<span class="header-session-status header-desktop-only" aria-live="polite">Checking your session…</span>`;
  }

  if (state.authStatus !== "authenticated" || !user) {
    return `
      <a class="header-auth-link header-desktop-only" href="#/signin" data-route-link data-route="#/signin">Sign In</a>
      <a class="button button--primary header-auth-create header-desktop-only" href="#/signup" data-route-link data-route="#/signup">Create Account</a>
    `;
  }

  return `
    ${renderRewards(state)}
    <span class="header-desktop-only" data-desktop-sound>${renderSoundButton(state.soundEnabled)}</span>
    <div class="account-menu-wrapper header-desktop-only" data-account-wrapper>
      <button
        class="avatar avatar--button"
        type="button"
        data-account-button
        aria-expanded="false"
        aria-haspopup="menu"
        aria-controls="account-menu"
        aria-label="Open account menu for ${escapeHtml(fullName)}"
        data-tooltip="Account"
      >${escapeHtml(initials)}</button>
      <div id="account-menu" class="account-menu" role="menu" hidden>
        ${createAccountMenuMarkup(user)}
      </div>
    </div>
  `;
}

function renderMobileAuthentication(state, user, fullName, gradeLevel, initials) {
  if (state.authStatus === "checking") {
    return `<p class="mobile-panel__status" aria-live="polite">Checking your session…</p>`;
  }

  if (state.authStatus !== "authenticated" || !user) {
    return `
      <div class="mobile-panel__auth-links">
        <a class="button button--secondary" href="#/signin" data-route-link data-route="#/signin">Sign In</a>
        <a class="button button--primary" href="#/signup" data-route-link data-route="#/signup">Create Account</a>
      </div>
    `;
  }

  return `
    <div class="mobile-panel__account">
      <span class="avatar" aria-hidden="true">${escapeHtml(initials)}</span>
      <div class="mobile-panel__account-text">
        <span class="account-summary__name">${escapeHtml(fullName)}</span>
        <span class="account-summary__grade">${escapeHtml(gradeLevel)}</span>
      </div>
    </div>
    <button class="mobile-panel__sign-out" type="button" data-mobile-sign-out>Sign Out</button>
  `;
}

export function createHeader(headerElement, { currentRoute, onRouteChange, onSignOut }) {
  const state = getAppState();
  const user = state.user;
  const initials = getInitials(user?.firstName, user?.lastName);
  const fullName = getFullName(user?.firstName, user?.lastName);
  const gradeLevel = formatGradeLevel(user?.gradeLevel);
  const isAuthenticated = state.authStatus === "authenticated" && Boolean(user);

  headerElement.className = "site-header";
  headerElement.innerHTML = `
    <div class="header-shell">
      <a class="brand" href="/" data-route-link data-route="/" aria-label="Numora home">
        ${icon("mark", "brand__mark")}
        <span class="brand__name">Numora</span>
      </a>

      <div class="header-nav-slot" data-desktop-nav></div>

      <div class="header-actions">
        ${renderDesktopAuthentication(state, user, fullName, initials)}

        <button
          class="icon-button mobile-menu-toggle"
          type="button"
          data-mobile-menu-button
          aria-expanded="false"
          aria-controls="mobile-navigation"
          aria-label="Open navigation menu"
          data-tooltip="Menu"
        >
          ${icon("menu")}
        </button>
      </div>

      <div id="mobile-navigation" class="mobile-panel" data-mobile-panel hidden>
        <div data-mobile-nav></div>
        <div class="mobile-panel__divider"></div>
        <div class="mobile-panel__actions">
          <span class="pill">Sound</span>
          <span data-mobile-sound>${renderSoundButton(state.soundEnabled)}</span>
        </div>
        <div class="mobile-panel__divider"></div>
        ${renderMobileAuthentication(state, user, fullName, gradeLevel, initials)}
      </div>
    </div>
  `;

  headerElement.querySelector("[data-desktop-nav]").append(
    createNavigation(currentRoute, "primary-nav", "Main navigation")
  );
  headerElement.querySelector("[data-mobile-nav]").append(
    createNavigation(currentRoute, "mobile-nav", "Mobile navigation")
  );

  const accountMenu = isAuthenticated
    ? attachAccountMenu({
      wrapper: headerElement.querySelector("[data-account-wrapper]"),
      button: headerElement.querySelector("[data-account-button]"),
      menu: headerElement.querySelector("#account-menu"),
      onSignOut
    })
    : null;
  const mobileButton = headerElement.querySelector("[data-mobile-menu-button]");
  const mobilePanel = headerElement.querySelector("[data-mobile-panel]");

  const updateSoundControls = (soundEnabled) => {
    headerElement.querySelectorAll("[data-sound-toggle]").forEach((button) => {
      button.setAttribute("aria-pressed", String(soundEnabled));
      button.setAttribute("aria-label", `${soundEnabled ? "Sound on" : "Sound off"}. Toggle sound preference`);
      button.setAttribute("data-tooltip", soundEnabled ? "Sound on" : "Sound off");
      button.innerHTML = icon(soundEnabled ? "soundOn" : "soundOff");
    });
  };

  const closeMobileMenu = ({ restoreFocus = false } = {}) => {
    if (mobilePanel.hidden) {
      return;
    }

    mobilePanel.hidden = true;
    mobileButton.setAttribute("aria-expanded", "false");
    mobileButton.setAttribute("aria-label", "Open navigation menu");
    mobileButton.innerHTML = icon("menu");
    document.body.classList.remove("menu-open");

    if (restoreFocus) {
      mobileButton.focus();
    }
  };

  const openMobileMenu = () => {
    mobilePanel.hidden = false;
    mobileButton.setAttribute("aria-expanded", "true");
    mobileButton.setAttribute("aria-label", "Close navigation menu");
    mobileButton.innerHTML = icon("close");
    document.body.classList.add("menu-open");
    mobilePanel.querySelector("a")?.focus();
  };

  const handleMobileButtonClick = () => {
    if (mobilePanel.hidden) {
      openMobileMenu();
    } else {
      closeMobileMenu();
    }
  };

  const handleHeaderClick = async (event) => {
    if (!(event.target instanceof Element)) {
      return;
    }

    const soundButton = event.target.closest("[data-sound-toggle]");
    if (soundButton) {
      updateSoundControls(setSoundEnabled(soundButton.getAttribute("aria-pressed") !== "true"));
      return;
    }

    const routeLink = event.target.closest("[data-route-link]");
    if (routeLink) {
      event.preventDefault();
      accountMenu?.closeMenu();
      closeMobileMenu();
      navigateToRoute(routeLink.dataset.route, onRouteChange);
      return;
    }

    const signOutButton = event.target.closest("[data-mobile-sign-out]");
    if (signOutButton) {
      signOutButton.disabled = true;
      closeMobileMenu();
      await onSignOut?.();
    }
  };

  const handleDocumentKeyDown = (event) => {
    if (event.key === "Escape") {
      closeMobileMenu({ restoreFocus: true });
    }
  };

  mobileButton.addEventListener("click", handleMobileButtonClick);
  headerElement.addEventListener("click", handleHeaderClick);
  document.addEventListener("keydown", handleDocumentKeyDown);

  return {
    update(currentRouteValue) {
      updateNavigationState(headerElement, currentRouteValue);
    },
    destroy() {
      accountMenu?.destroy();
      mobileButton.removeEventListener("click", handleMobileButtonClick);
      headerElement.removeEventListener("click", handleHeaderClick);
      document.removeEventListener("keydown", handleDocumentKeyDown);
      document.body.classList.remove("menu-open");
    }
  };
}
