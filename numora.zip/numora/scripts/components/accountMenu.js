import { getFullName, formatGradeLevel, getInitials } from "../utils/user.js";

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[character]));
}

export function createAccountMenuMarkup(user) {
  const initials = getInitials(user.firstName, user.lastName);
  const fullName = getFullName(user.firstName, user.lastName);
  const gradeLevel = formatGradeLevel(user.gradeLevel);

  return `
    <div class="account-summary">
      <span class="avatar" aria-hidden="true">${escapeHtml(initials)}</span>
      <div>
        <p class="account-summary__name">${escapeHtml(fullName)}</p>
        <p class="account-summary__grade">${escapeHtml(gradeLevel)}</p>
      </div>
    </div>
    <button class="account-menu__item" type="button" role="menuitem" data-account-profile>Profile / Account</button>
    <p class="account-menu__note" data-account-note hidden>Available after account setup.</p>
    <button class="account-menu__item" type="button" role="menuitem" data-account-sign-out>Sign Out</button>
  `;
}

export function attachAccountMenu({ wrapper, button, menu, onSignOut }) {
  const closeMenu = ({ restoreFocus = false } = {}) => {
    if (menu.hidden) {
      return;
    }

    menu.hidden = true;
    button.setAttribute("aria-expanded", "false");

    if (restoreFocus) {
      button.focus();
    }
  };

  const openMenu = () => {
    menu.hidden = false;
    button.setAttribute("aria-expanded", "true");
    menu.querySelector("[data-account-profile]")?.focus();
  };

  const handleButtonClick = () => {
    if (menu.hidden) {
      openMenu();
    } else {
      closeMenu();
    }
  };

  const handleMenuClick = async (event) => {
    if (!(event.target instanceof Element)) {
      return;
    }

    if (event.target.closest("[data-account-profile]")) {
      menu.querySelector("[data-account-note]").hidden = false;
      return;
    }

    const signOutButton = event.target.closest("[data-account-sign-out]");
    if (signOutButton) {
      signOutButton.disabled = true;
      await onSignOut?.();
      closeMenu();
    }
  };

  const handleDocumentPointerDown = (event) => {
    if (!wrapper.contains(event.target)) {
      closeMenu();
    }
  };

  const handleDocumentKeyDown = (event) => {
    if (event.key === "Escape") {
      closeMenu({ restoreFocus: true });
    }
  };

  button.addEventListener("click", handleButtonClick);
  menu.addEventListener("click", handleMenuClick);
  document.addEventListener("pointerdown", handleDocumentPointerDown);
  document.addEventListener("keydown", handleDocumentKeyDown);

  return {
    closeMenu,
    destroy() {
      button.removeEventListener("click", handleButtonClick);
      menu.removeEventListener("click", handleMenuClick);
      document.removeEventListener("pointerdown", handleDocumentPointerDown);
      document.removeEventListener("keydown", handleDocumentKeyDown);
    }
  };
}
